# Движок хоррор-видео (CPU + NVIDIA RTX GPU)

Собирает готовое видео из фонов, Gacha-персонажа и анимаций студии. Ничего не требует вручную
двигать в монтажке: всё описано в одном файле сцены.

## Что где лежит

```
Horror/
  bg/                     фоны B00.jpg, B01.jpg ...
  anim/<персонаж>/        пак персонажа из Gacha Nebula
  engine/                 этот движок
    anims/                запечённые анимации студии
  projects/<видео>/
    scenes.py             сценарий: кадры, камера, свет, позы, звуки
    audio/                озвучка, тайминги слов, готовый звук
    output/               готовые видео
```

## Ускорение на GPU (NVIDIA RTX 3060 / CUDA + NVENC)

Движок автоматически задействует видеокарту на двух уровнях:

1. **Аппаратное кодирование видео `h264_nvenc` (работает сразу без дополнительных библиотек):**
   `render.py` сам проверяет наличие NVIDIA NVENC в `ffmpeg` и кодирует поток через чип видеокарты (`-c:v h264_nvenc -preset p5 -rc vbr -cq 18`) вместо загрузки процессора `libx264`.
2. **Полный GPU-рендер кадров и эффектов через CUDA (`PyTorch`):**
   Если в Python установлен `torch` с поддержкой CUDA, все тяжёлые операции (трансформация фонов и частей персонажа `F.grid_sample`, динамический свет ламп, падающие и контактные тени, контурный свет `rim`, `halo`, свечение `bloom`, хроматическая аберрация, виньетка и плёночное зерно) считаются напрямую в видеопамяти RTX 3060.

Чтобы включить полный CUDA-рендер на Windows (Python 3.10+ и RTX 3060), один раз установи PyTorch с CUDA:

```powershell
pip install torch --index-url https://download.pytorch.org/whl/cu121
```

После этого `render.py` будет включать GPU автоматически (в логе появится строка `GPU mode: device=NVIDIA GeForce RTX 3060 | cuda_render=True | nvenc=True`). При необходимости режим можно задать явно флагами `--gpu` или `--no-gpu`.

## Команды

Все запускаются из папки `Horror`.

```bash
# 1. Озвучка Edge (тест) с таймингом каждого слова
python engine/tts.py история.txt projects/01_domovyata/audio --paragraphs 1-4

# 2. Звук: музыка, эффекты, голоса за стеной, сведение
python engine/audio.py projects/01_domovyata

# 3. Проверка: по кадру на каждый план, очень быстро
python engine/render.py projects/01_domovyata --sheet 1 --height 360 --out check.jpg

# 4. Проверка одного момента в полном качестве (секунды через запятую)
python engine/render.py projects/01_domovyata --stills 12.5,48 --out stills

# 5. Черновик 540p (на RTX 3060 с CUDA + NVENC собирается за ~25-40 секунд)
python engine/render.py projects/01_domovyata --height 540 --name draft --gpu

# 6. Финал 1080p (на RTX 3060 оптимально 2 воркера по умолчанию)
python engine/render.py projects/01_domovyata --height 1080 --name pilot --gpu
```

Если студия анимаций обновилась, перезапекаем анимации:

```bash
node engine/bake_anims.js 2d_character_motion_studio_46.html engine/anims
```

## Как устроен scenes.py

Каждый план — словарь. Время берётся не в секундах, а от слов озвучки:

```python
t5 = cue("громкий звук телевизора")     # момент, когда прозвучали эти слова
```

Поэтому после смены голоса монтаж перестраивается сам.

Позиция персонажа и камеры — доли фона: `x=.5, y=.9` значит середина по ширине и 90% высоты.
Чтобы прочитать координаты, есть сетка:

```bash
python engine/bg_grid.py grid.jpg bg/B03.jpg
```

Лицо задаётся парой `(глаза, рот)`. Варианты смотреть в
`anim/<персонаж>/faces/preview-eyes.png` и `preview-mouth.png`.
