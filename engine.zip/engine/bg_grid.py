"""Background with a 10% grid, to read shot coordinates from.

    python bg_grid.py <out.jpg> <bg.jpg> [<bg.jpg> ...]
"""
import sys

import cv2
import numpy as np

out, *paths = sys.argv[1:]
cells = []
for path in paths:
    image = cv2.imdecode(np.fromfile(path, np.uint8), cv2.IMREAD_COLOR)
    image = cv2.resize(image, (960, 536), interpolation=cv2.INTER_AREA)
    for i in range(1, 10):
        x, y = i * 96, int(i * 53.6)
        cv2.line(image, (x, 0), (x, 535), (0, 255, 255), 1)
        cv2.line(image, (0, y), (959, y), (0, 255, 255), 1)
        cv2.putText(image, ".%d" % i, (x + 2, 12), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (0, 255, 0), 1, cv2.LINE_AA)
        cv2.putText(image, ".%d" % i, (2, y - 2), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (0, 255, 0), 1, cv2.LINE_AA)
    cells.append(image)
rows = [np.hstack(cells[i:i + 2]) for i in range(0, len(cells), 2)]
if rows[-1].shape != rows[0].shape:
    rows[-1] = np.hstack([rows[-1], np.zeros_like(cells[0])])
cv2.imencode(".jpg", np.vstack(rows), [cv2.IMWRITE_JPEG_QUALITY, 88])[1].tofile(out)
