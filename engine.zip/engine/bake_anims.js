// Bakes the pose functions of the motion studio into a binary table, so the video engine
// runs exactly the same animations as the studio.
//
//   node bake_anims.js <studio.html> <out_dir>
//
// Writes <out_dir>/anims.json (metadata) and <out_dir>/anims.bin (Float32, mode x frame x key).
// Rebake after every studio update: nothing here is hand-copied.
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const [studioPath, outDir] = process.argv.slice(2);
if (!studioPath || !outDir) {
  console.error('usage: node bake_anims.js <studio.html> <out_dir>');
  process.exit(2);
}

const FPS = 30;
const SECONDS = 40;

const html = fs.readFileSync(studioPath, 'utf8').replace(/data:image\/[a-z]+;base64,[A-Za-z0-9+/=]+/g, '');
const start = html.indexOf('// === src/rig/animations/types.ts ===');
const end = html.indexOf('// === src/rig/animator.ts ===');
if (start < 0 || end < 0) throw new Error('animation modules not found in the studio bundle');

// The animation modules only need the pose helpers from the kinematics module.
const prelude = `
const POSE_KEYS = ['bob','sway','torso','head','tuft','armL','foreL','armR','foreR','thighL','shinL','thighR','shinR'];
function zeroPose() { const p = {}; for (const k of POSE_KEYS) p[k] = 0; return p; }
`;
const epilogue = `
this.__studio = { ANIMATIONS, POSE_KEYS, evaluateAnimationPose };
`;
const context = {Math, console, Object, Array, Number, String, JSON};
vm.createContext(context);
vm.runInContext(prelude + html.slice(start, end) + epilogue, context, {filename: 'studio-animations.js'});

const {ANIMATIONS, POSE_KEYS, evaluateAnimationPose} = context.__studio;
const modes = Object.keys(ANIMATIONS);
const frames = FPS * SECONDS;
const table = new Float32Array(modes.length * frames * POSE_KEYS.length);
const meta = {fps: FPS, frames, keys: POSE_KEYS, modes: {}};

let cursor = 0;
modes.forEach((mode, index) => {
  const info = ANIMATIONS[mode];
  const armFront = new Uint8Array(frames);
  for (let frame = 0; frame < frames; frame++) {
    const t = frame / FPS;
    const pose = evaluateAnimationPose(mode, t, {waveVariant: 'seamless'});
    for (const key of POSE_KEYS) table[cursor++] = pose[key];
    const flag = typeof info.armInFront === 'function' ? info.armInFront(t) : !!info.armInFront;
    armFront[frame] = flag ? 1 : 0;
  }
  meta.modes[mode] = {
    index,
    name: info.name,
    category: info.category,
    speed: info.speed || 0,
    duration: info.duration || 1,
    isLoop: info.isLoop !== false,
    armFront: Array.from(armFront).some(Boolean) ? Array.from(armFront) : 0,
  };
});

fs.mkdirSync(outDir, {recursive: true});
fs.writeFileSync(path.join(outDir, 'anims.bin'), Buffer.from(table.buffer));
fs.writeFileSync(path.join(outDir, 'anims.json'), JSON.stringify(meta));
console.log(`baked ${modes.length} animations, ${frames} frames each`);
