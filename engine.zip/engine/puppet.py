"""Gacha character pack + studio poses = premultiplied RGBA character frames.

A pack (anim/<slug>/) gives depth-ordered layers and measured joints. The studio gives poses
in its own 13 numbers. This module joins them: layers are flattened per bone, posed about the
measured joints, and drawn into a screen-sized region of interest.

The pack has no knee or elbow node (the game's lower limb turns about the ankle and the wrist),
and the game's upper-limb nodes sit near the middle of the sleeve/thigh sprite rather than at the
anatomical shoulder and hip sockets, so all limb joints are measured directly from the art.

Supports both fast sub-box CPU rendering (OpenCV) and GPU rendering on NVIDIA CUDA (PyTorch).
"""

import json
from collections import OrderedDict
from pathlib import Path

import cv2
import numpy as np

try:
    import torch
    import torch.nn.functional as F
    HAS_TORCH = True
except ImportError:
    torch = None
    F = None
    HAS_TORCH = False

FACE_FEATURES = ("mouth", "nose", "eye1", "eye2", "pupil", "highlight")
EYE_PREFIXES = ("eye1", "eye2", "pupil", "highlight")
STAGES = (0.25, 0.5, 1.0, 2.0)
# Hip-to-floor of the studio rig, in studio units. Converts bob and sway to pack pixels.
STUDIO_LEG_LENGTH = 172.0


def read_rgba(path):
    data = cv2.imdecode(np.fromfile(str(path), np.uint8), cv2.IMREAD_UNCHANGED)
    if data is None:
        raise FileNotFoundError(path)
    if data.ndim == 2:
        data = cv2.cvtColor(data, cv2.COLOR_GRAY2BGRA)
    elif data.shape[2] == 3:
        data = cv2.cvtColor(data, cv2.COLOR_BGR2BGRA)
    image = data.astype(np.float32) / (65535.0 if data.dtype == np.uint16 else 255.0)
    image[..., :3] *= image[..., 3:4]
    return image


def over(dst, src):
    """Premultiplied source-over, in place, same shape."""
    dst *= 1.0 - src[..., 3:4]
    dst += src


def rotate_about(pivot, degrees):
    angle = np.deg2rad(degrees)
    cos, sin = np.cos(angle), np.sin(angle)
    x, y = pivot
    return np.array([[cos, -sin, x - cos * x + sin * y],
                     [sin, cos, y - sin * x - cos * y],
                     [0.0, 0.0, 1.0]])


def translate(x, y):
    return np.array([[1.0, 0.0, x], [0.0, 1.0, y], [0.0, 0.0, 1.0]])


def top_cap_center(mask):
    """Anatomical center of the rounded top cap of an upper limb (shoulder or hip)."""
    u8 = mask.astype(np.uint8)
    edt = cv2.distanceTransform(u8, cv2.DIST_L2, 5)
    ys, xs = np.nonzero(mask)
    y_min, y_max = int(ys.min()), int(ys.max())
    h = max(y_max - y_min, 1)
    region = mask & (np.arange(mask.shape[0])[:, None] <= y_min + int(0.42 * h))
    cy, cx = np.unravel_index(np.argmax(edt * region), edt.shape)
    r = float(edt[cy, cx])
    target_y = y_min + r * 1.05
    band = mask & (np.abs(np.arange(mask.shape[0])[:, None] - target_y) <= 3)
    bys, bxs = np.nonzero(band)
    if len(bxs):
        cx = float(bxs.mean())
        cy = float(target_y)
    return np.array([float(cx), float(cy)], dtype=float)


def _affine_theta(matrix_3x3, in_w, in_h, out_w, out_h):
    """Convert pixel-space 3x3 affine matrix (in -> out) to PyTorch affine_grid 2x3 theta (align_corners=False)."""
    inv_m = np.linalg.inv(matrix_3x3)
    # N_in * inv_m * N_out_inv
    # N_out_inv: x_out = (out_w / 2) * u_out + (out_w - 1) / 2
    n_out_inv = np.array([
        [out_w * 0.5, 0.0, (out_w - 1.0) * 0.5],
        [0.0, out_h * 0.5, (out_h - 1.0) * 0.5],
        [0.0, 0.0, 1.0],
    ], dtype=np.float32)
    n_in = np.array([
        [2.0 / in_w, 0.0, (1.0 - in_w) / in_w],
        [0.0, 2.0 / in_h, (1.0 - in_h) / in_h],
        [0.0, 0.0, 1.0],
    ], dtype=np.float32)
    theta = (n_in @ inv_m.astype(np.float32) @ n_out_inv)[:2]
    return theta


class Sprite:
    """One flattened run of layers, cropped, at several resolutions."""

    def __init__(self, canvas_image):
        alpha = canvas_image[..., 3]
        ys, xs = np.nonzero(alpha > 0.002)
        if not len(xs):
            self.empty = True
            return
        self.empty = False
        pad = 3
        x0, y0 = max(xs.min() - pad, 0), max(ys.min() - pad, 0)
        x1, y1 = min(xs.max() + pad + 1, canvas_image.shape[1]), min(ys.max() + pad + 1, canvas_image.shape[0])
        self.x0, self.y0 = float(x0), float(y0)
        self.base = canvas_image[y0:y1, x0:x1].copy()
        self.stages = {}
        self.gpu_stages = {}
        self.capped = None

    def _resample(self, base, chosen):
        height, width = base.shape[:2]
        size = (max(1, int(round(width * chosen))), max(1, int(round(height * chosen))))
        if chosen == 1.0:
            return base
        if chosen < 1.0:
            return cv2.resize(base, size, interpolation=cv2.INTER_AREA)
        image = np.clip(cv2.resize(base, size, interpolation=cv2.INTER_LANCZOS4), 0, 1)
        # Flat-colour art: tighten the edge the upscale softened.
        alpha = image[..., 3:4]
        sharper = np.clip((alpha - 0.5) * 1.6 + 0.5, 0, 1)
        return image * (sharper / np.maximum(alpha, 1e-3))

    def stage(self, scale):
        chosen = next((s for s in STAGES if s >= scale), STAGES[-1])
        if chosen not in self.stages:
            self.stages[chosen] = self._resample(self.base, chosen)
        return chosen, self.stages[chosen]

    def stage_capped(self, scale, amount):
        """amount 0..1 shortens the stub in solid steps: a fade would leave a see-through ghost."""
        chosen, image = self.stage(scale)
        step = int(np.ceil(amount * len(self.capped))) if self.capped else 0
        if not step:
            return chosen, image
        key = (chosen, step)
        if key not in self.stages:
            self.stages[key] = self._resample(self.capped[step - 1], chosen)
        return chosen, self.stages[key]

    def stage_capped_gpu(self, scale, amount, device):
        """Return (chosen, tensor_1x4xHxW_on_device, H, W)."""
        chosen = next((s for s in STAGES if s >= scale), STAGES[-1])
        step = int(np.ceil(amount * len(self.capped))) if self.capped else 0
        key = (chosen, step, str(device))
        if key not in self.gpu_stages:
            _, cpu_img = self.stage_capped(scale, amount)
            # HxWx4 -> 1x4xHxW on GPU
            tensor = torch.from_numpy(cpu_img).permute(2, 0, 1).unsqueeze(0).contiguous().to(device, non_blocking=True)
            self.gpu_stages[key] = (tensor, cpu_img.shape[0], cpu_img.shape[1])
        t_img, h, w = self.gpu_stages[key]
        return chosen, t_img, h, w

    def make_cap(self, pivot, toward, outline):
        """Round the limb off at its joint: the art beyond the joint is the game's hidden stub.

        At rest the stub sits under the body; on a wide swing it would poke out the far side.
        """
        height, width = self.base.shape[:2]
        xs, ys = np.meshgrid(np.arange(width) + self.x0, np.arange(height) + self.y0)
        dx, dy = xs - pivot[0], ys - pivot[1]
        axis = (np.asarray(toward, float) - pivot) / np.linalg.norm(np.asarray(toward, float) - pivot)
        along = dx * axis[0] + dy * axis[1]
        across = -dx * axis[1] + dy * axis[0]
        distance = np.hypot(dx, dy)
        solid = self.base[..., 3] > 0.5
        near_joint = solid & (np.abs(along) < 4)
        radius = max(np.abs(across[near_joint]).max() * 0.92, 10.0) if near_joint.any() else 30.0
        stub = solid & (along < 0)
        reach = max(distance[stub].max(), radius) if stub.any() else radius
        self.capped = []
        for cut in np.linspace(reach, radius, 5)[1:]:
            keep = np.maximum(np.clip(along / 2.0 + 0.5, 0, 1), np.clip((cut - distance) / 2.0 + 0.5, 0, 1))
            capped = self.base * keep[..., None].astype(np.float32)
            if outline is not None:
                band = np.clip(1.0 - np.abs(distance - (cut - 3.0)) / 3.5, 0, 1) * (along < 0) * solid
                band = band[..., None].astype(np.float32)
                capped = capped * (1 - band) + np.array([*outline, 1.0], np.float32) * band
            self.capped.append(capped)


class Animations:
    def __init__(self, directory):
        directory = Path(directory)
        self.meta = json.loads((directory / "anims.json").read_text(encoding="utf-8"))
        self.fps = self.meta["fps"]
        self.keys = self.meta["keys"]
        self.frames = self.meta["frames"]
        table = np.fromfile(directory / "anims.bin", dtype=np.float32)
        self.table = table.reshape(len(self.meta["modes"]), self.frames, len(self.keys))

    def sample(self, mode, t):
        """Pose vector of a mode at time t; beyond the baked range the loop is folded back."""
        info = self.meta["modes"][mode]
        duration = max(info["duration"], 1e-3)
        limit = (self.frames - 2) / self.fps
        if t > limit:
            t = t % duration + np.floor((limit - duration) / duration) * duration
        position = max(t, 0.0) * self.fps
        low = int(position)
        rows = self.table[info["index"]]
        return rows[low] + (rows[low + 1] - rows[low]) * (position - low)

    def arm_front(self, mode, t):
        flags = self.meta["modes"][mode]["armFront"]
        if not flags:
            return False
        return bool(flags[min(int(t * self.fps), self.frames - 1)])


class Puppet:
    def __init__(self, package_dir, animations):
        self.dir = Path(package_dir)
        self.anims = animations
        self.doc = json.loads((self.dir / "layers.json").read_text(encoding="utf-8"))
        atlas_path = self.dir / "faces" / "faces.json"
        self.atlas = json.loads(atlas_path.read_text(encoding="utf-8")) if atlas_path.is_file() else None
        self.size = self.doc["canvas"]["size"]
        self.layers = [layer for layer in self.doc["layers"] if not layer.get("empty") and layer["bone"] != "ground"]
        self.pivots = {bone: np.array(info["pivot"], dtype=float) for bone, info in self.doc["rig"]["bones"].items()}
        self._images = {}
        self._measure()
        self._split_stack()
        self._heads = OrderedDict()

    # --- loading -----------------------------------------------------------------------------

    def _image(self, relative):
        if relative not in self._images:
            self._images[relative] = read_rgba(self.dir / relative)
        return self._images[relative]

    def _flatten(self, layers):
        canvas = np.zeros((self.size, self.size, 4), np.float32)
        for layer in layers:
            over(canvas, self._image(layer["file"]))
        return canvas

    def _silhouette(self, bone):
        chosen = [layer for layer in self.layers if layer["bone"] == bone]
        mask = np.zeros((self.size, self.size), np.float32)
        for layer in chosen:
            mask = np.maximum(mask, self._image(layer["file"])[..., 3])
        return mask > 0.5

    def _joint_between(self, upper, lower):
        overlap = self._silhouette(upper) & self._silhouette(lower)
        ys, xs = np.nonzero(overlap)
        if not len(xs):
            raise ValueError("no overlap between %s and %s" % (upper, lower))
        return np.array([xs.mean(), ys.mean()])

    def _measure(self):
        p = self.pivots
        elbow_l = self._joint_between("armUpperFront", "armLowerFront")
        elbow_r = self._joint_between("armUpperBack", "armLowerBack")
        knee_l = self._joint_between("legUpperFront", "legLowerFront")
        knee_r = self._joint_between("legUpperBack", "legLowerBack")
        shoulder_l = top_cap_center(self._silhouette("armUpperFront"))
        shoulder_r = top_cap_center(self._silhouette("armUpperBack"))
        hip_l = 0.55 * top_cap_center(self._silhouette("legUpperFront")) + 0.45 * p["legUpperFront"]
        hip_r = 0.55 * top_cap_center(self._silhouette("legUpperBack")) + 0.45 * p["legUpperBack"]

        self.joints = {
            "neck": p["head"],
            "waist": p["hips"] + np.array([0.0, -32.0]),
            "shoulderL": shoulder_l,
            "shoulderR": shoulder_r,
            "hipL": hip_l,
            "hipR": hip_r,
            "elbowL": elbow_l,
            "elbowR": elbow_r,
            "kneeL": knee_l,
            "kneeR": knee_r,
        }
        boxes = np.array([layer["bounds"] for layer in self.layers if layer.get("bounds")])
        self.top = float(boxes[:, 1].min())
        self.floor = float(boxes[:, 3].max())
        self.center_x = float(p["hips"][0])
        self.unit = (self.floor - p["hips"][1]) / STUDIO_LEG_LENGTH

    def _round_lower_stub(self, canvas, joint):
        """Round the flat top cut (along < 0) of a lower limb around its elbow/knee pivot so its
        square corners stay inside the upper limb's rounded cap."""
        alpha = canvas[..., 3]
        ys, xs = np.nonzero(alpha > 0.05)
        if not len(xs):
            return canvas
        far_mask = np.hypot(xs - joint[0], ys - joint[1]) > 35
        toward = np.array([xs[far_mask].mean(), ys[far_mask].mean()]) if far_mask.any() else np.array([xs.mean(), ys.mean()])
        axis = toward - joint
        norm = np.linalg.norm(axis)
        if norm < 1e-3:
            return canvas
        axis = axis / norm

        y0, y1 = max(0, int(ys.min()) - 2), min(self.size, int(ys.max()) + 3)
        x0, x1 = max(0, int(xs.min()) - 2), min(self.size, int(xs.max()) + 3)
        gy, gx = np.mgrid[y0:y1, x0:x1]
        dx, dy = gx - joint[0], gy - joint[1]
        along = dx * axis[0] + dy * axis[1]
        across = -dx * axis[1] + dy * axis[0]
        dist = np.hypot(dx, dy)

        solid = alpha[y0:y1, x0:x1] > 0.5
        near = solid & (np.abs(along) < 3.0)
        half_w = float(np.abs(across[near]).max()) if near.any() else 22.0
        cap_r = max(half_w * 0.76, 8.0)
        keep_stub = np.clip((cap_r - dist) / 1.8 + 0.5, 0.0, 1.0)
        blend = np.clip((along - 2.0) / 3.5 + 0.5, 0.0, 1.0)
        factor = blend + (1.0 - blend) * keep_stub
        out = canvas.copy()
        out[y0:y1, x0:x1] *= factor[..., None].astype(np.float32)
        return out

    def _split_stack(self):
        """Runs of same-bone layers become one sprite each; upper arm sleeves are separated so cuffs stay crisp."""
        def is_face(layer):
            return str(layer["name"]).startswith(FACE_FEATURES)

        first_face = next(i for i, layer in enumerate(self.layers) if is_face(layer))
        last_face = max(i for i, layer in enumerate(self.layers) if is_face(layer))
        head_start = first_face
        while head_start > 0 and self.layers[head_start - 1]["bone"] == "head":
            head_start -= 1
        head_end = last_face
        while head_end + 1 < len(self.layers) and self.layers[head_end + 1]["bone"] == "head":
            head_end += 1

        self.head_under = self._flatten(self.layers[head_start:first_face])
        self.head_over = self._flatten(self.layers[last_face + 1:head_end + 1])
        self.base_face = [layer for layer in self.layers[first_face:last_face + 1] if is_face(layer)]

        lower_joints = {
            "armLowerFront": "elbowL",
            "armLowerBack": "elbowR",
            "legLowerFront": "kneeL",
            "legLowerBack": "kneeR",
        }
        caps = {
            "armUpperFront": ("shoulderL", "elbowL", True),
            "armUpperBack": ("shoulderR", "elbowR", True),
            "legUpperFront": ("hipL", "kneeL", False),
            "legUpperBack": ("hipR", "kneeR", False),
        }

        def make_sprite(bone, layers_list):
            flat = self._flatten(layers_list)
            if bone in lower_joints:
                flat = self._round_lower_stub(flat, self.joints[lower_joints[bone]])
            sp = Sprite(flat)
            if not sp.empty and bone in caps:
                joint, toward, stroke = caps[bone]
                sp.make_cap(self.joints[joint], self.joints[toward], self._outline(sp) if stroke else None)
            return sp

        def runs(layers):
            found = []
            for layer in layers:
                if found and found[-1][0] == layer["bone"]:
                    found[-1][1].append(layer)
                else:
                    found.append((layer["bone"], [layer]))
            out = []
            for bone, items in found:
                if bone in ("armUpperFront", "armUpperBack"):
                    skin_items = [l for l in items if not str(l["name"]).startswith("sleeves")]
                    sleeve_items = [l for l in items if str(l["name"]).startswith("sleeves")]
                    if skin_items and sleeve_items:
                        sp_full = make_sprite(bone, items)
                        sp_skin = make_sprite(bone, skin_items)
                        sp_slv = make_sprite(bone, sleeve_items)
                        out.append((bone, sp_full, sp_skin, sp_slv))
                        continue
                sp = make_sprite(bone, items)
                if not sp.empty:
                    out.append((bone, sp, None, None))
            return out

        self.below_runs = runs(self.layers[:head_start])
        self.above_runs = runs(self.layers[head_end + 1:])
        self.below = [(b, sp) for b, sp, _, _ in self.below_runs if not sp.empty]
        self.above = [(b, sp) for b, sp, _, _ in self.above_runs if not sp.empty]
        self.provenance = self.doc.get("provenance", {}).get("selectors", {})
        self.default_eyes = self.provenance.get("eyes1x1", {}).get("value")
        self.default_mouth = self.provenance.get("mouth1", {}).get("value")
        self._images.clear()

    @staticmethod
    def _outline(sprite):
        """Premultiplied colour of the limb's ink line: the darkest solid pixels of its art."""
        solid = sprite.base[sprite.base[..., 3] > 0.95][:, :3]
        if not len(solid):
            return None
        luma = solid.mean(axis=1)
        return solid[luma <= np.percentile(luma, 8)].mean(axis=0)

    # --- face --------------------------------------------------------------------------------

    def _face_layers(self, eyes, mouth):
        chosen = []
        for key, value, kind in ((mouth, "mouths", "mouth"), (eyes, "eyes", "eyes")):
            match = [item for item in self.atlas[value] if item["value"] == key]
            if not match:
                raise ValueError("no measured %s %r in %s" % (kind, key, self.dir.name))
            chosen.extend(match[0]["layers"])
        return chosen

    def head_sprite(self, eyes, mouth, blink):
        key = (eyes, mouth, round(blink * 4) / 4)
        cached = self._heads.get(key)
        if cached is not None:
            self._heads.move_to_end(key)
            return cached
        canvas = self.head_under.copy()
        layers = self._face_layers(eyes, mouth)
        eye_box = None
        if key[2] > 0:
            masks = [read_rgba(self.dir / l["file"])[..., 3] for l in layers if l["name"].startswith(EYE_PREFIXES)]
            ys, xs = np.nonzero(np.max(masks, axis=0) > 0.1)
            if len(ys):
                eye_box = (ys.min() + ys.max()) / 2.0
        for layer in layers:
            image = read_rgba(self.dir / layer["file"])
            if eye_box is not None and layer["name"].startswith(EYE_PREFIXES):
                height = max(0.04, 1.0 - key[2])
                matrix = np.array([[1, 0, 0], [0, height, eye_box * (1 - height)]], dtype=np.float32)
                image = cv2.warpAffine(image, matrix, (self.size, self.size), flags=cv2.INTER_LINEAR)
            over(canvas, image)
        over(canvas, self.head_over)
        sprite = Sprite(canvas)
        self._heads[key] = sprite
        while len(self._heads) > 48:
            self._heads.popitem(last=False)
        return sprite

    # --- pose --------------------------------------------------------------------------------

    @staticmethod
    def _adapt_gacha_arms(p):
        """Adapt studio arm angles to Gacha A-pose proportions and back-arm depth ordering."""
        p = dict(p)
        arm_l, fore_l = float(p["armL"]), float(p["foreL"])
        arm_r, fore_r = float(p["armR"]), float(p["foreR"])
        torso_ang = float(p.get("torso", 0.0))
        sitting = (float(p.get("thighR", 0.0)) < -45.0) and (abs(torso_ang) < 40.0)
        high_reach_r = (arm_r + fore_r < -135.0) or (arm_r < -70.0) or (arm_r > 65.0)

        # 1. Back arm (armUpperBack / armLowerBack sits behind torso):
        # Positive foreR in the studio folds the forearm across the chest, which behind an opaque Gacha torso
        # hides the hand behind the spine and leaves a severed elbow spike sticking out of the ribs.
        if not high_reach_r:
            if fore_r > 10.0 or arm_r > 12.0:
                tuck = min(max((max(fore_r - 10.0, arm_r - 12.0)) / 25.0, 0.0), 1.0)
                target_ar = -12.0 if sitting else 1.5
                target_fr = -15.0 if sitting else -6.0
                arm_r = arm_r * (1.0 - tuck) + target_ar * tuck
                fore_r = fore_r * (1.0 - tuck) + target_fr * tuck
            else:
                if sitting:
                    # Rest the back hand on/beside the right thigh so the shoulder & hand stay visible
                    if arm_r < 0.0:
                        arm_r *= 0.45
                    if fore_r < 0.0:
                        fore_r *= 0.42
                else:
                    # Standing: Gacha rest pose is already ~22 deg outward in an A-pose, so damp outward reach
                    if arm_r < 0.0:
                        arm_r *= 0.42
                    if fore_r < 0.0:
                        fore_r *= 0.45

        # 2. Front arm (armUpperFront / armLowerFront):
        # Preserve full reach for high face/head gestures (thinking, cry, cover_face, wave, point, salute),
        # while gently damping moderate waist/lap bends so short Gacha arms stay balanced over the body.
        high_reach = (arm_l + fore_l < -135.0) or (arm_l < -75.0) or (arm_l > 65.0)
        if not high_reach:
            if sitting:
                if arm_l < 0.0:
                    arm_l *= 0.52
                if fore_l < 0.0:
                    fore_l *= 0.58
            else:
                if arm_l < -10.0:
                    arm_l = -10.0 + (arm_l + 10.0) * 0.65
                if fore_l < -10.0:
                    fore_l = -10.0 + (fore_l + 10.0) * 0.65

        p["armL"], p["foreL"] = arm_l, fore_l
        p["armR"], p["foreR"] = arm_r, fore_r
        return p

    def rig(self, pose, keys):
        p = self._adapt_gacha_arms(dict(zip(keys, pose)))
        j = self.joints
        unit = self.unit
        root = translate(p["sway"] * unit, p["bob"] * unit)
        torso = root @ rotate_about(j["waist"], p["torso"])
        head = torso @ rotate_about(j["neck"], p["head"])
        upper_l = torso @ rotate_about(j["shoulderL"], p["armL"])
        lower_l = upper_l @ rotate_about(j["elbowL"], p["foreL"])
        upper_r = torso @ rotate_about(j["shoulderR"], p["armR"])
        lower_r = upper_r @ rotate_about(j["elbowR"], p["foreR"])
        thigh_l = root @ rotate_about(j["hipL"], p["thighL"])
        shin_l = thigh_l @ rotate_about(j["kneeL"], p["shinL"])
        thigh_r = root @ rotate_about(j["hipR"], p["thighR"])
        shin_r = thigh_r @ rotate_about(j["kneeR"], p["shinR"])
        return {"root": root, "hips": root, "torso": torso, "head": head,
                "armUpperFront": upper_l, "armLowerFront": lower_l,
                "armUpperBack": upper_r, "armLowerBack": lower_r,
                "legUpperFront": thigh_l, "legLowerFront": shin_l,
                "legUpperBack": thigh_r, "legLowerBack": shin_r}, p

    def _expand_runs(self, runs_list, adapted_pose):
        """Place the upper-arm sleeve cuff over the bare elbow joint unless the forearm folds acutely back."""
        out = []
        i = 0
        while i < len(runs_list):
            bone, sp_full, sp_skin, sp_slv = runs_list[i]
            if bone in ("armUpperFront", "armUpperBack") and sp_skin is not None and sp_slv is not None:
                lower_bone = "armLowerFront" if bone == "armUpperFront" else "armLowerBack"
                fore_key = "foreL" if bone == "armUpperFront" else "foreR"
                fore_ang = adapted_pose.get(fore_key, 0.0)
                if i + 1 < len(runs_list) and runs_list[i + 1][0] == lower_bone and fore_ang >= -88.0:
                    out.append((bone, sp_skin))
                    out.append((lower_bone, runs_list[i + 1][1]))
                    out.append((bone, sp_slv))
                    i += 2
                    continue
            out.append((bone, sp_full))
            i += 1
        return out

    def _build_stack(self, pose, keys, eyes, mouth, blink, arm_front):
        eyes = self.default_eyes if eyes is None else eyes
        mouth = self.default_mouth if mouth is None else mouth
        bones, named = self.rig(pose, keys)
        swings = {"armUpperFront": named["armL"], "armUpperBack": named["armR"],
                  "legUpperFront": named["thighL"], "legUpperBack": named["thighR"]}
        head = ("head", self.head_sprite(eyes, mouth, blink))
        stack = self._expand_runs(self.below_runs, named)
        above = self._expand_runs(self.above_runs, named)
        reach_head = arm_front and (named["armL"] + named["foreL"] < -120.0 or named["armL"] < -70.0)
        if reach_head:
            arm = [item for item in stack if item[0] == "armLowerFront"]
            stack = [item for item in stack if item[0] != "armLowerFront"]
            stack += [head] + above + arm
        else:
            stack += [head] + above
        return bones, swings, stack

    def render(self, pose, keys, view, size, eyes=None, mouth=None, blink=0.0, arm_front=False):
        """Draw the character on CPU using tight per-sprite sub-boxes. Returns (premult RGBA ROI, x, y) or None."""
        bones, swings, stack = self._build_stack(pose, keys, eyes, mouth, blink, arm_front)
        scale = float(np.sqrt(abs(np.linalg.det(view[:2, :2]))))
        width, height = size

        placed = []
        x_min, y_min, x_max, y_max = width, height, 0, 0
        for bone, sprite in stack:
            thresh = 20.0 if "arm" in bone else 14.0
            amount = float(np.clip((abs(swings.get(bone, 0.0)) - thresh) / 24.0, 0.0, 1.0))
            chosen, image = sprite.stage_capped(scale, amount)
            sh, sw = image.shape[:2]
            local = translate(sprite.x0, sprite.y0) @ np.diag([1.0 / chosen, 1.0 / chosen, 1.0])
            matrix = view @ bones[bone] @ local
            corners = matrix @ np.array([[0, sw, 0, sw], [0, 0, sh, sh], [1, 1, 1, 1]], dtype=float)
            sx0 = max(int(np.floor(corners[0].min())) - 3, 0)
            sy0 = max(int(np.floor(corners[1].min())) - 3, 0)
            sx1 = min(int(np.ceil(corners[0].max())) + 4, width)
            sy1 = min(int(np.ceil(corners[1].max())) + 4, height)
            if sx1 > sx0 and sy1 > sy0:
                x_min = min(x_min, sx0)
                y_min = min(y_min, sy0)
                x_max = max(x_max, sx1)
                y_max = max(y_max, sy1)
                placed.append((image, matrix, sx0, sy0, sx1, sy1))

        if x_max <= x_min or y_max <= y_min:
            return None
        roi = np.zeros((y_max - y_min, x_max - x_min, 4), np.float32)
        for image, matrix, sx0, sy0, sx1, sy1 in placed:
            target = (translate(-sx0, -sy0) @ matrix)[:2].astype(np.float32)
            layer = cv2.warpAffine(image, target, (sx1 - sx0, sy1 - sy0), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
            over(roi[sy0 - y_min:sy1 - y_min, sx0 - x_min:sx1 - x_min], layer)
        return roi, x_min, y_min

    def render_gpu(self, pose, keys, view, size, device, eyes=None, mouth=None, blink=0.0, arm_front=False):
        """Draw the character directly on CUDA GPU (1x4xHxW tensor). Returns (roi_tensor_4xHxW, x, y) or None."""
        bones, swings, stack = self._build_stack(pose, keys, eyes, mouth, blink, arm_front)
        scale = float(np.sqrt(abs(np.linalg.det(view[:2, :2]))))
        width, height = size

        placed = []
        x_min, y_min, x_max, y_max = width, height, 0, 0
        for bone, sprite in stack:
            thresh = 20.0 if "arm" in bone else 14.0
            amount = float(np.clip((abs(swings.get(bone, 0.0)) - thresh) / 24.0, 0.0, 1.0))
            chosen, t_img, sh, sw = sprite.stage_capped_gpu(scale, amount, device)
            local = translate(sprite.x0, sprite.y0) @ np.diag([1.0 / chosen, 1.0 / chosen, 1.0])
            matrix = view @ bones[bone] @ local
            corners = matrix @ np.array([[0, sw, 0, sw], [0, 0, sh, sh], [1, 1, 1, 1]], dtype=float)
            sx0 = max(int(np.floor(corners[0].min())) - 3, 0)
            sy0 = max(int(np.floor(corners[1].min())) - 3, 0)
            sx1 = min(int(np.ceil(corners[0].max())) + 4, width)
            sy1 = min(int(np.ceil(corners[1].max())) + 4, height)
            if sx1 > sx0 and sy1 > sy0:
                x_min = min(x_min, sx0)
                y_min = min(y_min, sy0)
                x_max = max(x_max, sx1)
                y_max = max(y_max, sy1)
                placed.append((t_img, sw, sh, matrix, sx0, sy0, sx1, sy1))

        if x_max <= x_min or y_max <= y_min:
            return None
        roi = torch.zeros((4, y_max - y_min, x_max - x_min), dtype=torch.float32, device=device)
        for t_img, sw, sh, matrix, sx0, sy0, sx1, sy1 in placed:
            sub_w, sub_h = sx1 - sx0, sy1 - sy0
            m_sub = translate(-sx0, -sy0) @ matrix
            theta = torch.from_numpy(_affine_theta(m_sub, sw, sh, sub_w, sub_h)).unsqueeze(0).to(device)
            grid = F.affine_grid(theta, (1, 4, sub_h, sub_w), align_corners=False)
            layer = F.grid_sample(t_img, grid, mode="bilinear", padding_mode="zeros", align_corners=False).squeeze(0)
            dst = roi[:, sy0 - y_min:sy1 - y_min, sx0 - x_min:sx1 - x_min]
            dst.mul_(1.0 - layer[3:4]).add_(layer)
        return roi, x_min, y_min
