"""The sound of a film, synthesised from scratch so nothing in it has third-party rights.

    python audio.py <project_dir>

Reads the event lists from scenes.py and narration.wav, writes audio/mix.wav. Sounds are recipes
in the SOUNDS table: to replace one with a real recording, drop <name>.wav into audio/sfx/ and it
is used instead. The same goes for music: audio/music.wav replaces the generated score.
"""

import asyncio
import hashlib
import importlib.util
import json
import subprocess
import sys
from pathlib import Path

import numpy as np
from scipy import signal
from scipy.io import wavfile

ENGINE = Path(__file__).resolve().parent
sys.path.insert(0, str(ENGINE))

RATE = 48000
rng = np.random.default_rng(38)


def seconds(n):
    return int(n * RATE)


def time_axis(length):
    return np.arange(seconds(length)) / RATE


def lowpass(x, cutoff, order=4):
    return signal.sosfilt(signal.butter(order, cutoff, "low", fs=RATE, output="sos"), x, axis=0)


def highpass(x, cutoff, order=2):
    return signal.sosfilt(signal.butter(order, cutoff, "high", fs=RATE, output="sos"), x, axis=0)


def bandpass(x, low, high, order=2):
    return signal.sosfilt(signal.butter(order, (low, high), "band", fs=RATE, output="sos"), x, axis=0)


def noise(length):
    return rng.normal(0, 1, seconds(length)).astype(np.float64)


def room(x, tail=1.4, wet=0.25, tone=4000.0):
    """Cheap convolution reverb: decaying filtered noise."""
    t = time_axis(tail)
    response = lowpass(noise(tail), tone) * np.exp(-t * 6.0 / tail)
    response /= np.sqrt((response ** 2).sum())
    pad = np.concatenate([x, np.zeros(seconds(tail))])
    return pad * (1.0 - wet) + signal.fftconvolve(pad, response)[:len(pad)] * wet


def normal(x, peak=1.0):
    return x / max(np.abs(x).max(), 1e-9) * peak


# --- effects ----------------------------------------------------------------------------------

def thump(length, start_hz, end_hz, decay):
    t = time_axis(length)
    frequency = end_hz + (start_hz - end_hz) * np.exp(-t * 18.0)
    return np.sin(2 * np.pi * np.cumsum(frequency) / RATE) * np.exp(-t * decay)


def door_slam():
    body = thump(1.0, 130, 52, 7.0)
    crack = lowpass(noise(1.0), 1600) * np.exp(-time_axis(1.0) * 34.0) * 0.5
    rattle = bandpass(noise(1.0), 300, 2400) * np.exp(-(time_axis(1.0) - 0.09).clip(0) * 26.0) * 0.14
    rattle[:seconds(0.09)] = 0
    return normal(room(lowpass(body + crack + rattle, 1100), tail=1.5, wet=0.35, tone=1800))


def door_far():
    return normal(room(lowpass(thump(0.7, 100, 50, 10.0) + 0.3 * noise(0.7) * np.exp(-time_axis(0.7) * 40), 500), wet=0.4, tone=900))


def footsteps_up():
    out = np.zeros(seconds(3.6))
    for i in range(6):
        hit = lowpass(thump(0.3, 95, 55, 22.0), 300) * (0.8 + 0.2 * rng.random())
        at = seconds(i * 0.52 + rng.random() * 0.03)
        out[at:at + len(hit)] += hit
    return normal(out)


def knock():
    out = np.zeros(seconds(1.3))
    for at in (0.0, 0.2, 0.46):
        hit = bandpass(noise(0.14), 180, 1300) * np.exp(-time_axis(0.14) * 50) + thump(0.14, 240, 170, 42.0)
        at = seconds(at)
        out[at:at + len(hit)] += hit
    return normal(room(lowpass(out, 1500), tail=0.6, wet=0.25, tone=1400))


def drill():
    length = 1.9
    t = time_axis(length)
    wobble = 1.0 + 0.02 * np.sin(2 * np.pi * 7 * t)
    tone = signal.sawtooth(2 * np.pi * np.cumsum(142.0 * wobble) / RATE)
    grind = bandpass(noise(length), 500, 2200) * (0.6 + 0.4 * np.sin(2 * np.pi * 31 * t))
    shape = np.minimum(t / 0.05, 1) * np.minimum((length - t) / 0.2, 1) * (0.72 + 0.28 * (np.sin(2 * np.pi * 2.2 * t) > 0))
    return normal(lowpass(tone * 0.5 + grind * 0.5, 1300) * shape)


def balls():
    out = np.zeros(seconds(2.0))
    t = time_axis(2.0)
    out += lowpass(noise(2.0), 170) * np.exp(-t * 1.2) * 0.7
    position, gap = 0.0, 0.32
    while gap > 0.02 and position < 1.8:
        hit = lowpass(thump(0.1, 300, 160, 46.0), 900) * max(gap * 3.2, 0.2)
        at = seconds(position)
        out[at:at + len(hit)] += hit
        position += gap
        gap *= 0.74
    return normal(out)


def buzz():
    t = time_axis(0.36)
    wave = signal.sawtooth(2 * np.pi * 100 * t) * (rng.random(len(t)) > 0.2)
    return normal(bandpass(wave, 90, 2600) * np.minimum(t / 0.01, 1) * np.minimum((0.36 - t) / 0.03, 1))


def fridge_open():
    t = time_axis(0.8)
    seal = bandpass(noise(0.8), 300, 2600) * np.exp(-t * 16) * 0.5
    clunk = thump(0.8, 170, 90, 24.0)
    return normal(room(seal + clunk, tail=0.5, wet=0.2, tone=2400))


def fridge_hum_off():
    t = time_axis(0.9)
    return normal(room(lowpass(thump(0.9, 90, 42, 11.0) + 0.3 * np.sin(2 * np.pi * 100 * t) * np.exp(-t * 7), 400), tail=0.5, wet=0.2, tone=800))


def knife():
    length = 0.5
    t = time_axis(length)
    return normal(bandpass(noise(length), 1500, 6500) * np.sin(np.pi * t / length) ** 2)


def tick():
    t = time_axis(0.06)
    return normal(highpass(np.sin(2 * np.pi * 2300 * t) * np.exp(-t * 170) + 0.4 * noise(0.06) * np.exp(-t * 220), 500))


def hit():
    length = 4.0
    t = time_axis(length)
    sub = thump(length, 72, 34, 1.5)
    # Inharmonic cluster: the stinger of the toy motif played on metal.
    metal = sum(np.sin(2 * np.pi * f * t + p) * a for f, a, p in ((311, 1, 0), (331, .8, 1), (466, .6, 2), (1187, .3, .5), (1702, .18, 1.1)))
    metal = metal * np.exp(-t * 2.6) * 0.1
    return normal(room(sub + metal, tail=3.0, wet=0.35, tone=2600))


SOUNDS = dict(door_slam=door_slam, door_far=door_far, footsteps_up=footsteps_up, knock=knock, drill=drill,
              balls=balls, buzz=buzz, fridge_open=fridge_open, fridge_hum_off=fridge_hum_off, knife=knife,
              tick=tick, hit=hit)


def bed_fridge(length):
    t = time_axis(length)
    return normal(np.sin(2 * np.pi * 50 * t) * .6 + np.sin(2 * np.pi * 100 * t) * .4 + lowpass(noise(length), 400) * .25)


def bed_wind(length):
    gust = lowpass(noise(length), 0.6, order=2)
    gust = normal(gust) * 0.5 + 0.5
    return normal(bandpass(noise(length), 120, 850) * gust)


def bed_room(length):
    return normal(lowpass(noise(length), 260))


BEDS = dict(fridge=bed_fridge, wind=bed_wind, room=bed_room)


# --- score ------------------------------------------------------------------------------------

def bell(frequency, length=2.6, velocity=1.0):
    """A music-box tine: a slightly sharp upper partial, a fast decay, a tick of the comb."""
    t = time_axis(length)
    tone = (np.sin(2 * np.pi * frequency * t) * np.exp(-t * 2.2)
            + 0.42 * np.sin(2 * np.pi * frequency * 3.01 * t) * np.exp(-t * 5.0)
            + 0.16 * np.sin(2 * np.pi * frequency * 5.97 * t) * np.exp(-t * 11.0))
    comb = highpass(noise(length), 3000) * np.exp(-t * 500) * 0.2
    return (tone + comb) * velocity


NOTES = dict(E4=329.63, G4=392.00, A4=440.00, B4=493.88, C5=523.25, D5=587.33, E5=659.25, F5=698.46)
MOTIF = ["A4", "C5", "E5", "D5", "C5", "B4", "A4", None, "E4", "A4", "C5", "B4", "G4", "F5", "E5", None]


def score(duration, plan):
    out = np.zeros(seconds(duration + 5))

    # Low drone in fifths that never settles.
    t = time_axis(duration + 5)
    drone = (np.sin(2 * np.pi * 55.0 * t + 1.5 * np.sin(2 * np.pi * .05 * t))
             + 0.7 * np.sin(2 * np.pi * 82.6 * t) + 0.4 * np.sin(2 * np.pi * 110.7 * t))
    drone += lowpass(noise(duration + 5), 180) * 3.0
    drone *= 0.5 + 0.5 * np.sin(2 * np.pi * .07 * t) ** 2
    out += normal(lowpass(drone, 300)) * 0.5

    # The toy motif: it runs down during the film, like a spring losing tension.
    step = 0.86
    position = plan["first_note"]
    index = 0
    spacing_rest = 7.0
    while position < plan["end"]:
        wear = position / plan["end"]
        for name in MOTIF:
            if name is not None and position < plan["end"]:
                if not any(a - 1.5 < position < b + .5 for a, b in plan["tense"]):
                    droop = 1.0 - 0.018 * wear * (rng.random() * 0.8 + 0.2)
                    note = bell(NOTES[name] * droop, velocity=0.45 + rng.random() * 0.2)
                    at = seconds(position + rng.random() * 0.03)
                    end = min(at + len(note), len(out))
                    out[at:end] += note[:end - at] * 0.2
            position += step * (1.0 + 0.3 * wear)
        position += spacing_rest
        index += 1

    # Tension: a cluster that swells through the scare and is cut dead.
    for a, b in plan["tense"]:
        length = b - a
        w = time_axis(length)
        cluster = sum(np.sin(2 * np.pi * f * w) for f in (110.0, 116.5, 164.8, 174.6))
        swell = (w / length) ** 2
        at = seconds(a)
        out[at:at + len(cluster)] += lowpass(cluster, 900) * swell * 0.14
    return room(out, tail=2.6, wet=0.3, tone=3000)[:seconds(duration)]


# --- voices behind the wall -------------------------------------------------------------------

async def edge(text, voice, pitch, rate):
    import edge_tts

    audio = bytearray()
    communicate = edge_tts.Communicate(text, voice, pitch=pitch, rate=rate)
    async for chunk in communicate.stream():
        if chunk["type"] == "audio":
            audio += chunk["data"]
    return bytes(audio)


def voice_line(line, cache):
    text, voice, pitch, rate, speed = line
    key = hashlib.sha1(json.dumps(line, ensure_ascii=False).encode("utf-8")).hexdigest()[:16]
    path = cache / (key + ".wav")
    if not path.is_file():
        import time
        for attempt in range(14):
            try:
                audio = asyncio.run(edge(text, voice, pitch, rate))
                break
            except Exception as error:
                print("  voice retry", attempt + 1, type(error).__name__, flush=True)
                time.sleep(1.5 + attempt)
        else:
            raise RuntimeError("Edge TTS refused: " + text)
        raw = cache / (key + ".mp3")
        raw.write_bytes(audio)
        # Pitch and speed go together on purpose: that is what makes a voice sound drawn.
        subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(raw), "-af",
                        "asetrate=%d,aresample=%d" % (int(24000 * speed), RATE), "-ac", "1", str(path)], check=True)
    rate_read, data = wavfile.read(str(path))
    return data.astype(np.float64) / 32768.0


def wall_voices(lines, directory):
    """A loop of the cartoon argument, as heard through a panel wall."""
    cache = directory / "cache"
    cache.mkdir(parents=True, exist_ok=True)
    parts = []
    for line in lines:
        parts.append(normal(voice_line(line, cache)))
        parts.append(np.zeros(seconds(0.12 + rng.random() * 0.45)))
    dry = np.concatenate(parts)
    muffled = lowpass(highpass(dry, 170), 950, order=3) + 0.12 * bandpass(dry, 1000, 2600)
    return normal(room(muffled, tail=0.5, wet=0.28, tone=900))


# --- mix --------------------------------------------------------------------------------------

def read_narration(path):
    rate, data = wavfile.read(str(path))
    data = data.astype(np.float64)
    if data.ndim > 1:
        data = data.mean(axis=1)
    if rate != RATE:
        data = signal.resample_poly(data, RATE, rate)
    return data / max(np.abs(data).max(), 1.0)


def load_override(path):
    rate, data = wavfile.read(str(path))
    data = data.astype(np.float64)
    data /= 32768.0 if np.abs(data).max() > 2 else 1.0
    if data.ndim > 1:
        data = data.mean(axis=1)
    return signal.resample_poly(data, RATE, rate) if rate != RATE else data


def place(track, sound, at, gain):
    start = seconds(at)
    if start >= len(track) or start < 0:
        return
    stop = min(start + len(sound), len(track))
    track[start:stop] += sound[:stop - start] * gain


def envelope(x, attack, release):
    level = np.abs(x)
    out = signal.lfilter([1 - np.exp(-1 / (release * RATE))], [1, -np.exp(-1 / (release * RATE))], level)
    return signal.lfilter([1 - np.exp(-1 / (attack * RATE))], [1, -np.exp(-1 / (attack * RATE))], out)


def main():
    from render import Words

    project = Path(sys.argv[1]).resolve()
    audio_dir = project / "audio"
    words = Words(json.loads((audio_dir / "words.json").read_text(encoding="utf-8")))
    spec = importlib.util.spec_from_file_location("scenes", project / "scenes.py")
    scenes = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scenes)
    film = scenes.build({"words": words})

    duration = film["duration"]
    samples = seconds(duration)
    narration = np.zeros(samples)
    place(narration, normal(highpass(read_narration(audio_dir / "narration.wav"), 75)), film["voice_offset"], 1.0)
    ducking = np.clip(envelope(narration, 0.05, 0.5) * 7.0, 0, 1)

    music_file = audio_dir / "music.wav"
    music = load_override(music_file) if music_file.is_file() else score(duration, film["music"])
    music = normal(music)[:samples]
    music = np.pad(music, (0, samples - len(music)))

    effects = np.zeros(samples)
    made = {}
    for at, name, gain in film["sfx"]:
        if name not in made:
            custom = audio_dir / "sfx" / (name + ".wav")
            made[name] = load_override(custom) if custom.is_file() else SOUNDS[name]()
        place(effects, made[name], at, gain)

    beds = np.zeros(samples)
    for start, stop, name, gain in film.get("beds", ()):
        length = stop - start
        sound = BEDS[name](length)
        fade = np.minimum(np.minimum(time_axis(length) / 0.8, (length - time_axis(length)) / 0.8), 1.0)
        place(beds, sound[:len(fade)] * fade[:len(sound)], start, gain)

    voices = np.zeros(samples)
    if film.get("voice_lines"):
        loop = wall_voices(film["voice_lines"], audio_dir / "voices")
        for start, stop, gain in film["voices"]:
            length = seconds(stop - start)
            sound = np.tile(loop, length // len(loop) + 1)[:length]
            w = np.arange(length) / RATE
            fade = np.minimum(np.minimum(w / 1.2, (stop - start - w) / 1.2), 1.0)
            place(voices, sound * fade, start, gain)

    # The wall sits to one side of the listener: voices lean left.
    left = narration * 0.92 + music * 0.16 * (1 - 0.45 * ducking) + effects * 0.5 + beds * 0.05 + voices * 0.30 * 1.25
    right = narration * 0.92 + music * 0.16 * (1 - 0.45 * ducking) + effects * 0.5 + beds * 0.05 + voices * 0.30 * 0.75
    stereo = np.stack([left, right], axis=1)
    peak = np.abs(stereo).max()
    stereo = stereo / peak * 0.89
    wavfile.write(str(audio_dir / "mix.wav"), RATE, (stereo * 32767).astype(np.int16))
    stems = dict(narration=narration, music=music, effects=effects, voices=voices)
    print({name: round(float(20 * np.log10(np.sqrt((s ** 2).mean()) + 1e-9)), 1) for name, s in stems.items()}, "peak", round(float(peak), 2))
    print("mix", round(duration, 2), "s")


if __name__ == "__main__":
    main()
