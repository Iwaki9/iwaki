"""Contact sheet of every animation on one pack, to check the rig by eye.

    python pose_sheet.py <pack_dir> <anims_dir> <out.jpg> [mode ...] [--t SECONDS]
"""
import sys
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).parent))
from puppet import Animations, Puppet, translate

args = sys.argv[1:]
at = None
if "--t" in args:
    index = args.index("--t")
    at = float(args[index + 1])
    del args[index:index + 2]
pack, anims_dir, out, *modes = args
animations = Animations(anims_dir)
puppet = Puppet(pack, animations)
print("joints", {k: [round(float(c), 1) for c in v] for k, v in puppet.joints.items()}, "unit", round(puppet.unit, 3))
modes = modes or list(animations.meta["modes"])

CELL_W, CELL_H, COLS = 300, 340, 8
rows = (len(modes) + COLS - 1) // COLS
sheet = np.full((rows * CELL_H, COLS * CELL_W, 3), 62, np.uint8)
scale = 0.32
for index, mode in enumerate(modes):
    info = animations.meta["modes"][mode]
    t = at if at is not None else info["duration"] * 0.3
    pose = animations.sample(mode, t)
    arm_front = animations.arm_front(mode, t) or abs(pose[animations.keys.index("armL")]) > 25 or abs(pose[animations.keys.index("foreL")]) > 35
    view = translate(CELL_W / 2 - puppet.center_x * scale, CELL_H - 30 - puppet.floor * scale) @ np.diag([scale, scale, 1.0])
    drawn = puppet.render(pose, animations.keys, view, (CELL_W, CELL_H), arm_front=arm_front)
    cell = np.full((CELL_H, CELL_W, 3), 62, np.float32) / 255.0
    if drawn:
        roi, x, y = drawn
        region = cell[y:y + roi.shape[0], x:x + roi.shape[1]]
        region[:] = roi[..., :3] + region * (1 - roi[..., 3:4])
    cell = (cell * 255).astype(np.uint8)
    cv2.putText(cell, mode, (6, 18), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1, cv2.LINE_AA)
    row, col = index // COLS, index % COLS
    sheet[row * CELL_H:(row + 1) * CELL_H, col * CELL_W:(col + 1) * CELL_W] = cell
cv2.imencode(".jpg", sheet, [cv2.IMWRITE_JPEG_QUALITY, 92])[1].tofile(out)
print("written", out)
