"""Renders a project (with automatic NVIDIA RTX / CUDA GPU + h264_nvenc support).

    python render.py <project_dir> --stills 1.0,12.5 --out <dir>     single frames for checking
    python render.py <project_dir> --from 10 --to 20 --height 540    part of the film, small
    python render.py <project_dir> --gpu                             render on NVIDIA GPU (CUDA + NVENC)
    python render.py <project_dir> --workers 6                       the whole film

The project folder holds scenes.py (def build(ctx) -> {"shots": [...], "duration": seconds}) and
audio/ (narration.wav, words.json, mix.wav). Frames are pure functions of their number, so each
worker renders a contiguous range to its own segment and the segments are joined at the end.
"""

import argparse
import importlib.util
import json
import multiprocessing
import os
import subprocess
import sys
import time
from pathlib import Path

ENGINE = Path(__file__).resolve().parent
sys.path.insert(0, str(ENGINE))

import cv2
import numpy as np
from puppet import HAS_TORCH, torch


def has_nvenc():
    """Detect whether ffmpeg can open an h264_nvenc session on an NVIDIA GPU (such as RTX 3060)."""
    try:
        res = subprocess.run(
            ["ffmpeg", "-hide_banner", "-v", "error", "-f", "lavfi", "-i", "color=c=black:s=256x256:d=0.04",
             "-c:v", "h264_nvenc", "-f", "null", "-"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=4,
        )
        return res.returncode == 0
    except Exception:
        return False


class Words:
    """Find a phrase in the narration and get its time: cuts stay tied to the words."""

    def __init__(self, words):
        self.words = words
        self.norm = ["".join(c for c in w["word"].lower().replace("ё", "е") if c.isalnum()) for w in words]

    def find(self, phrase, after=0.0):
        target = ["".join(c for c in p.lower().replace("ё", "е") if c.isalnum()) for p in phrase.split()]
        for index in range(len(self.norm) - len(target) + 1):
            if self.words[index]["start"] >= after and self.norm[index:index + len(target)] == target:
                return index, index + len(target) - 1
        raise KeyError("phrase not in narration: %s" % phrase)

    def start(self, phrase, after=0.0):
        return self.words[self.find(phrase, after)[0]]["start"]

    def end(self, phrase, after=0.0):
        return self.words[self.find(phrase, after)[1]]["end"]


def load_project(directory, height, use_gpu=None):
    import compose
    from puppet import Animations, Puppet

    directory = Path(directory).resolve()
    horror = directory.parent.parent
    words = Words(json.loads((directory / "audio" / "words.json").read_text(encoding="utf-8")))

    spec = importlib.util.spec_from_file_location("scenes", directory / "scenes.py")
    scenes = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scenes)

    animations = Animations(ENGINE / "anims")
    film = scenes.build({"words": words})
    packs = {actor["pack"] for shot in film["shots"] for actor in shot.get("actors", ())}
    puppets = {pack: Puppet(horror / "anim" / pack, animations) for pack in packs}
    project = {"bg_dir": horror / "bg", "animations": animations, "puppets": puppets, "fps": film.get("fps", 30),
               "envelope": narration_envelope(directory / "audio" / "narration.wav", film.get("voice_offset", 0.0))}
    width = int(round(height * 16 / 9 / 2)) * 2
    renderer = compose.Renderer(project, width, height, use_gpu=use_gpu)
    return film, compose.layout(film["shots"], film["duration"]), renderer


def narration_envelope(path, offset):
    from scipy.io import wavfile

    rate, data = wavfile.read(str(path))
    data = data.astype(np.float32)
    if data.ndim > 1:
        data = data.mean(axis=1)
    data /= max(float(np.abs(data).max()), 1.0)
    hop = rate // 60
    usable = len(data) // hop
    rms = np.sqrt((data[:usable * hop].reshape(usable, hop) ** 2).mean(axis=1))
    rms = np.convolve(rms, np.ones(3) / 3, mode="same")
    rms /= max(np.percentile(rms, 97), 1e-5)

    def level(t):
        index = int((t - offset) * 60)
        return float(rms[index]) if 0 <= index < len(rms) else 0.0
    return level


def to_bytes(frame):
    return (np.clip(frame, 0, 1) * 255.0 + 0.5).astype(np.uint8)


def encoder_args(use_nvenc):
    if use_nvenc:
        return ["-c:v", "h264_nvenc", "-preset", "p5", "-rc", "vbr", "-cq", "18", "-b:v", "0", "-pix_fmt", "yuv420p"]
    return ["-c:v", "libx264", "-preset", "fast", "-crf", "16", "-threads", "3", "-pix_fmt", "yuv420p"]


def worker(job):
    index, directory, height, first, last, segment, use_gpu, use_nvenc = job
    cv2.setNumThreads(2)
    film, shots, renderer = load_project(directory, height, use_gpu=use_gpu)
    width = renderer.width
    command = ["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", "%dx%d" % (width, height),
               "-r", str(renderer.fps), "-i", "-", "-an"] + encoder_args(use_nvenc) + [segment]
    encoder = subprocess.Popen(command, stdin=subprocess.PIPE)
    started = time.time()
    for number in range(first, last):
        encoder.stdin.write(renderer.frame_bytes(shots, number).tobytes())
        if (number - first) % 60 == 0:
            print("worker %d (%s): %d/%d, %.3f s/frame" % (
                index, "GPU" if renderer.use_gpu else "CPU",
                number - first, last - first,
                (time.time() - started) / max(number - first, 1)), flush=True)
    encoder.stdin.close()
    encoder.wait()
    return segment


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("--stills")
    parser.add_argument("--sheet", help="contact sheet of N frames per shot, written to --out")
    parser.add_argument("--out", default=None)
    parser.add_argument("--from", dest="start", type=float, default=0.0)
    parser.add_argument("--to", dest="stop", type=float, default=None)
    parser.add_argument("--height", type=int, default=1080)
    parser.add_argument("--workers", type=int, default=None)
    parser.add_argument("--name", default="pilot")
    parser.add_argument("--gpu", dest="gpu", action="store_true", default=None, help="force GPU rendering (CUDA + NVENC)")
    parser.add_argument("--no-gpu", dest="gpu", action="store_false", help="force CPU rendering")
    args = parser.parse_args()
    project = Path(args.project).resolve()

    cuda_ok = bool(HAS_TORCH and torch.cuda.is_available())
    use_gpu = cuda_ok if args.gpu is None else bool(args.gpu and cuda_ok)
    use_nvenc = False if (args.gpu is False) else has_nvenc()
    if args.gpu and not cuda_ok:
        print("note: PyTorch CUDA not found in this Python env; using fast ROI-CPU renderer" +
              (" + NVIDIA h264_nvenc" if use_nvenc else "") +
              ". Install CUDA PyTorch via: pip install torch --index-url https://download.pytorch.org/whl/cu121", flush=True)
    elif use_gpu or use_nvenc:
        dev_name = torch.cuda.get_device_name(0) if cuda_ok else "NVIDIA GPU"
        print("GPU mode: device=%s | cuda_render=%s | nvenc=%s" % (dev_name, use_gpu, use_nvenc), flush=True)

    if args.stills:
        out = Path(args.out or project / "stills")
        out.mkdir(parents=True, exist_ok=True)
        film, shots, renderer = load_project(project, args.height, use_gpu=use_gpu)
        for value in args.stills.split(","):
            t = float(value)
            started = time.time()
            frame = renderer.frame_bytes(shots, int(t * renderer.fps))
            target = out / ("t%07.2f.jpg" % t)
            cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 93])[1].tofile(str(target))
            print(target.name, "%.2f s" % (time.time() - started), flush=True)
        return

    if args.sheet:
        film, shots, renderer = load_project(project, args.height, use_gpu=use_gpu)
        columns = int(args.sheet)
        cells = []
        for shot in shots:
            for step in range(columns):
                t = shot["start"] + shot["length"] * (step + 0.5) / columns
                frame = renderer.frame_bytes(shots, int(t * renderer.fps))
                cv2.putText(frame, "%s %.1fs" % (shot.get("id", ""), t), (8, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.6,
                            (0, 255, 255), 1, cv2.LINE_AA)
                cells.append(frame)
        rows = [np.hstack(cells[i:i + columns * 2]) for i in range(0, len(cells), columns * 2)]
        width = rows[0].shape[1]
        rows = [np.pad(r, ((0, 0), (0, width - r.shape[1]), (0, 0))) for r in rows]
        cv2.imencode(".jpg", np.vstack(rows), [cv2.IMWRITE_JPEG_QUALITY, 90])[1].tofile(args.out)
        return

    film, shots, renderer = load_project(project, args.height, use_gpu=use_gpu)
    fps = renderer.fps
    first = int(args.start * fps)
    last = int((args.stop if args.stop is not None else film["duration"]) * fps)
    del shots, renderer

    output = project / "output"
    output.mkdir(exist_ok=True)
    segments = output / "segments"
    segments.mkdir(exist_ok=True)
    # On GPU, 2 workers saturate CUDA + NVENC without duplicating VRAM 6 times
    default_workers = 2 if use_gpu else 6
    count = max(1, args.workers if args.workers is not None else default_workers)
    cuts = [first + (last - first) * i // count for i in range(count + 1)]
    jobs = [(i, str(project), args.height, cuts[i], cuts[i + 1], str(segments / ("seg%02d.mp4" % i)), use_gpu, use_nvenc)
            for i in range(count)]

    started = time.time()
    if count == 1:
        done = [worker(jobs[0])]
    else:
        multiprocessing.set_start_method("spawn", force=True)
        with multiprocessing.Pool(count) as pool:
            done = pool.map(worker, jobs, chunksize=1)
    listing = segments / "list.txt"
    listing.write_text("".join("file '%s'\n" % Path(item).name for item in done), encoding="utf-8")

    target = output / ("%s_%dp.mp4" % (args.name, args.height))
    command = ["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", str(listing)]
    mix = project / "audio" / "mix.wav"
    if mix.is_file():
        command += ["-ss", str(args.start), "-i", str(mix), "-map", "0:v", "-map", "1:a", "-c:a", "aac", "-b:a", "256k", "-shortest"]
    command += ["-c:v", "copy", "-movflags", "+faststart", str(target)]
    subprocess.run(command, check=True)
    print("done", target, "%.0f s" % (time.time() - started), flush=True)


if __name__ == "__main__":
    main()
