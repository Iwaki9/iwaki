"""Сборка персонажа из папки с частями.

Читает `layers.json` и складывает PNG по рамкам в указанном порядке. Ничего
кроме этой папки не нужно: все координаты общие, порядок задан.

    python assemble.py            # соберёт assembled.png рядом с частями
    python assemble.py --check    # сверит сборку с кадром игры

Формат `layers.json` (schema gacha-character-parts, version 2):
  canvas   — размер холста, в котором заданы все координаты
  order    — порядок отрисовки, сзади вперёд
  layers   — имя части → box [x, y, w, h]: куда класть PNG
  joints   — суставы в тех же координатах (для анимации)
  ground   — линия пола (y, где стоят ноги)
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from PIL import Image
from scipy.ndimage import distance_transform_edt


def assemble(folder: Path) -> Image.Image:
    """Складывает части по описанию.

    Если задан `head_split`, голова режется по линии подбородка: нижняя часть
    (волосы на затылке) уходит ПОД тело, верхняя (лицо, чёлка) ложится ПОВЕРХ.
    Иначе затылочные волосы ложатся на шею и плечи.
    """
    spec = json.loads((folder / "layers.json").read_text(encoding="utf-8"))
    width, height = spec["canvas"]
    canvas = Image.new("RGBA", (width, height), (0, 0, 0, 0))

    def paste(name: str, image: Image.Image | None = None, offset: int = 0) -> None:
        if image is None:
            path = folder / f"{name}.png"
            if not path.exists():
                print(f"  нет файла {path.name} — пропуск")
                return
            image = Image.open(path).convert("RGBA")
        x, y, w, h = spec["layers"][name]["box"]
        if offset:
            y += offset
        canvas.alpha_composite(image, (x, y))

    split = spec.get("head_split")
    head = Image.open(folder / "head.png").convert("RGBA") if split else None

    for name in spec["order"]:
        if name == "body" and split and head is not None:
            # сначала затылочные волосы, потом тело — они должны быть под ним
            paste("head", head.crop((0, split, head.width, head.height)), split)
        if name == "head" and split and head is not None:
            paste("head", head.crop((0, 0, head.width, split)))
            continue
        paste(name)
    return canvas


def close_seams(image: Image.Image, background, tolerance: float = 34) -> Image.Image:
    """Заливает щели между частями.

    На стыках остаются пиксели в один пиксель, через которые просвечивает фон.
    Находим всё, что фон и при этом не соединено с краем кадра, и закрашиваем
    цветом ближайшей части.
    """
    import cv2

    array = np.asarray(image.convert("RGBA")).copy()
    rgb = array[..., :3].astype(float)
    bg = np.array(background, float)
    empty = (np.linalg.norm(rgb - bg, axis=2) < tolerance) | (array[..., 3] < 20)

    # «снаружи» — то, что связано с рамкой кадра
    height, width = empty.shape
    mask = empty.astype(np.uint8)
    flood = mask.copy()
    flood_mask = np.zeros((height + 2, width + 2), np.uint8)
    for x in range(width):
        if flood[0, x]:
            cv2.floodFill(flood, flood_mask, (x, 0), 2)
        if flood[height - 1, x]:
            cv2.floodFill(flood, flood_mask, (x, height - 1), 2)
    for y in range(height):
        if flood[y, 0]:
            cv2.floodFill(flood, flood_mask, (0, y), 2)
        if flood[y, width - 1]:
            cv2.floodFill(flood, flood_mask, (width - 1, y), 2)

    holes = (flood == 1) & (mask == 1)
    if not holes.any():
        return image

    # цвет для щели — у ближайшего непрозрачного пикселя
    solid = ~holes
    indices = distance_transform_edt(~solid, return_distances=False, return_indices=True)
    filled = array[..., :3][indices[0], indices[1]]
    array[holes, :3] = filled[holes]
    array[holes, 3] = 255
    return Image.fromarray(array)


def main() -> int:
    parser = argparse.ArgumentParser(description="Сборка персонажа из частей")
    parser.add_argument("folder", nargs="?", default="",
                        help="папка с частями; по умолчанию — где лежит сам скрипт")
    parser.add_argument("--check", action="store_true", help="сверить с _base.png")
    args = parser.parse_args()

    folder = Path(args.folder) if args.folder else Path(__file__).resolve().parent
    sprite = assemble(folder)
    sprite.save(folder / "assembled.png")
    print(f"собрано: {folder / 'assembled.png'}  {sprite.width}×{sprite.height}")

    base_path = folder / "_base.png"
    if args.check and base_path.exists():
        spec = json.loads((folder / "layers.json").read_text(encoding="utf-8"))
        base = Image.open(base_path).convert("RGB")
        bg = Image.new("RGB", sprite.size, tuple(spec["background"]))
        bg.paste(sprite, (0, 0), sprite)
        diff = np.abs(np.asarray(bg).astype(float) - np.asarray(base).astype(float))
        print(f"расхождение с кадром игры: {diff.mean():.1f} из 255 "
              f"(пикселей заметно отличается: {(diff.sum(axis=2) > 60).mean() * 100:.1f}%)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
