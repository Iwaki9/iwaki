# Пакет персонажа `chubbzee`

Это **собранный персонаж**: слои, которые игра рисует сама, и суставы, которые игра сама
задаёт. Ничего не нарисовано и не додумано — это снимки движка, разложенные по глубине.

## Что внутри

| файл | что это |
|---|---|
| `layers.json` | порядок слоёв, их кость, измеренный сустав, измеренные границы, палитра кадра |
| `parts/NN-имя.png` | сам слой, 1024×1024, общий холст, прозрачный фон |
| `reference.png` | кадр, из которого всё снято (эталон сборки) |
| `README.ru.md` | этот файл |

Холст общий: `gameToCanvas` = `{"c": 0, "a": 2.742857142857143, "b": 0, "ty": -259.42857142857144, "d": 2.742857142857143, "tx": -323.7142857142857}`. Слои **уже** в пикселях холста, складывать их
нужно просто по порядку `order` (по возрастанию), без матриц.

Проверка сборки: если сложить все слои без единого преобразования, получается
`reference.png`. Замер: расходится 222 пикселей из 1048576 (>1.0% канала) —
это ошибка alpha-наложения, а не геометрии.

## Суставы

`pivot` — это origin игрового узла, переведённый в пиксели холста. Не оценка: игра
ставит конечность именно вокруг этой точки.

| кость | родитель | узел игры | сустав (x, y) |
|---|---|---|---|
| `ground` | — | `static ground plane; never transformed, so the cast shadow stays put` | 0.0, 0.0 |
| `root` | — | `silhouette bottom centre of the measured reference frame` | 515.0, 934.0 |
| `hips` | `root` | `midpoint(thigh, backthigh)` | 525.5, 685.1 |
| `torso` | `hips` | `body` | 514.9, 529.1 |
| `head` | `torso` | `head` | 502.6, 439.3 |
| `armUpperFront` | `torso` | `shoulder` | 443.6, 511.3 |
| `armLowerFront` | `armUpperFront` | `handx` | 410.7, 608.7 |
| `armUpperBack` | `torso` | `backshoulder` | 554.0, 513.4 |
| `armLowerBack` | `armUpperBack` | `backhand` | 593.8, 603.9 |
| `legUpperFront` | `hips` | `thigh` | 485.4, 690.3 |
| `legLowerFront` | `legUpperFront` | `foot` | 470.3, 821.9 |
| `legUpperBack` | `hips` | `backthigh` | 565.7, 680.0 |
| `legLowerBack` | `legUpperBack` | `backfoot` | 583.5, 815.1 |

`hips` — середина двух измеренных тазобедренных суставов, `root` — низ силуэта
эталонного кадра (центр по x), `ground` — статичная плоскость (тень не двигается).

## Слои

| # | слой | кость | цепочка узлов | пиксели (x0,y0,x1,y1) |
|---|---|---|---|---|
| 0 | `shadow` | `ground` | `shadow/shadow` | 424, 888, 632, 927 |
| 1 | `skinc` | `armUpperBack` | `backshoulder/skinc` | 521, 451, 591, 578 |
| 2 | `handx` | `armLowerBack` | `backhand/handx` | 550, 537, 643, 696 |
| 3 | `skinc` | `legUpperBack` | `backthigh/skinc` | 520, 597, 608, 779 |
| 4 | `socks` | `legUpperBack` | `backthigh/socks` | 525, 662, 612, 773 |
| 5 | `pants` | `legUpperBack` | `backthigh/pants` | 515, 575, 603, 684 |
| 6 | `skinc` | `legLowerBack` | `backfoot/skinc` | 535, 732, 627, 911 |
| 7 | `socks` | `legLowerBack` | `backfoot/socks` | 535, 728, 631, 912 |
| 8 | `pants` | `legLowerBack` | `backfoot/pants` | — |
| 9 | `shoe` | `legLowerBack` | `backfoot/shoe` | 548, 832, 644, 929 |
| 10 | `skinc` | `torso` | `body/skinc` | 451, 396, 587, 663 |
| 11 | `pants` | `torso` | `body/pants` | 450, 560, 595, 671 |
| 12 | `shirt` | `torso` | `body/shirt` | 428, 417, 595, 647 |
| 13 | `skinc` | `legUpperFront` | `thigh/skinc` | 442, 604, 522, 789 |
| 14 | `socks` | `legUpperFront` | `thigh/socks` | 442, 675, 528, 782 |
| 15 | `pants` | `legUpperFront` | `thigh/pants` | 443, 584, 531, 685 |
| 16 | `skinc` | `legLowerFront` | `foot/skinc` | 426, 739, 516, 917 |
| 17 | `socks` | `legLowerFront` | `foot/socks` | 428, 734, 524, 918 |
| 18 | `pants` | `legLowerFront` | `foot/pants` | — |
| 19 | `shoe` | `legLowerFront` | `foot/shoe` | 417, 838, 508, 934 |
| 20 | `shirt` | `torso` | `belt/shirt` | 430, 565, 595, 643 |
| 21 | `skinc` | `armUpperFront` | `shoulder/skinc` | 406, 451, 480, 576 |
| 22 | `handx` | `armLowerFront` | `handx/handx` | 364, 539, 449, 698 |
| 23 | `scarf1` | `torso` | `scarf/scarf1` | 422, 468, 579, 523 |
| 24 | `skinc` | `head` | `head/head/skinc` | 361, 126, 648, 439 |
| 25 | `accessory3` | `head` | `head/head/accessory3` | 379, 149, 648, 407 |
| 26 | `blush` | `head` | `head/head/blush` | 367, 293, 674, 417 |
| 27 | `mouth` | `head` | `head/head/mouth` | 545, 404, 568, 413 |
| 28 | `eye2-channels-000` | `head` | `head/head/eye2/eye2/c4` | 580, 323, 641, 362 |
| 29 | `pupil` | `head` | `head/head/eye2/eye2/pupil/pupil` | 582, 323, 625, 362 |
| 30 | `eye2-channels-005` | `head` | `head/head/eye2/eye2/c3` | 575, 308, 675, 369 |
| 31 | `nose` | `head` | `head/head/nose` | 562, 374, 569, 381 |
| 32 | `eye1-channels-000` | `head` | `head/head/eye1/eye1/c4` | 447, 317, 539, 361 |
| 33 | `pupil` | `head` | `head/head/eye1/eye1/pupil/pupil` | 471, 317, 534, 361 |
| 34 | `eye1-channels-005` | `head` | `head/head/eye1/eye1/c3` | 399, 302, 546, 363 |
| 35 | `rearhair` | `head` | `head/head/rearhair` | 333, 86, 697, 575 |
| 36 | `fronthair` | `head` | `head/head/fronthair/fronthair/fronthair` | 395, 139, 676, 585 |
| 37 | `eyebrow1` | `head` | `head/head/eyebrow1/eyebrow1` | 421, 241, 525, 274 |
| 38 | `eyebrow2` | `head` | `head/head/eyebrow2/eyebrow2` | 580, 244, 648, 283 |

Пустые слои (`—` в границах) — измеренные пустые группы глубины, это не ошибка.

## Как собрать кадр

Матрица кости = произведение по цепочке родителей: `world(кость) = world(родитель) @ R(сустав, угол)`.
Слой рисуется своей `world`-матрицей, слои накладываются по `order`.

Готовый код: `character-export/tools/anim/riglib.py`
(`forward()` — прямая кинематика, `compose()` — сборка, `blink()` — моргание).

## Готовая ходьба

`walk-cycle-002/` — 24 кадра, 24 fps: `frames/000..023.png` (RGBA, прозрачный фон),
`walk.mp4` (белый фон), `walk-alpha.webm` (с альфой), `walk.gif`, `frames.json` (углы по кадрам).
Сделано так:

```powershell
python character-export\tools\anim\render_walk.py --package character-export\anim\chubbzee `
  --out character-export\anim\chubbzee\walk-cycle-002 --swing 20 --bend 28
```

## Чего здесь нет

- Нет скелетной деформации кожи: каждый слой — жёсткая картинка, вращается целиком.
  Поэтому в широком шаге видно стык у бедра — это предел жёстких слоёв, а не баг.
- Нет сустава стопы: `foot` — это голень + ботинок, вращается вокруг колена.
- Нет физики и интерполяции между позами: кадры задаются углами.

## Откуда снято

- прогон: `E:\Gacha Nebula Windows 1.7\Gacha Nebula Windows 1.7\character-export\experiments\native-controls\output\chubbzee-parts-001`
- сэмпл: `00-baseline`
- форма рецепта: `paste`
- рецепт: `E:\Gacha Nebula Windows 1.7\Gacha Nebula Windows 1.7\character-export\inputs\Chubbzee_Lime.txt`
- sha256 рецепта: `None`
- селекторы кадра: `{"pose1": {"value": 3, "type": "number"}, "eyes1x1": {"value": 70, "type": "number"}, "facepreset1": {"value": 1, "type": "number"}, "mouth1": {"value": 277, "type": "number"}, "eyes2x1": {"value": 70, "type": "number"}}`
