# Анимация персонажа кодом

Здесь лежит **собранный персонаж**, из которого можно делать анимацию кодом: ходьбу, бег,
прыжок, поворот, моргание — без рисования новых кадров и без генерации картинок.

Идея простая: игра уже держит персонажа как куклу из 39–43 слоёв и сама задаёт им
суставы. Мы эти слои сняли и суставы измерили. Дальше любой кадр — это поворот нужных
слоёв вокруг нужных суставов и наложение в исходном порядке.

## Готовые пакеты

| персонаж | пакет | слоёв | базовый кадр | готовый цикл ходьбы |
|---|---|---:|---|---|
| `Chubbzee_Lime` (paste-форма) | `anim/chubbzee/` | 39 | `pose=3`, `eyes=70/70`, `mouth=277` | `anim/chubbzee/walk-cycle-002/` (24 кадра, mp4+gif+webm) |
| `soft_helen` (share-code) | `anim/soft_helen/` | 43 | `pose=33`, `eyes=71/71`, `mouth=131` | `anim/soft_helen/walk-cycle-002/` (24 кадра, mp4+gif+webm) |

В каждом пакете:

```
anim/<slug>/
  layers.json        порядок слоёв, кость, измеренный сустав, границы, холст, провенанс
  parts/NN-*.png     сами слои, 1024×1024 RGBA, прозрачный фон
  reference.png      кадр, из которого всё снято (эталон сборки)
  README.ru.md       таблицы суставов и слоёв именно этого персонажа
  walk-cycle-002/    готовый пример: frames/000..023.png, walk.mp4 (белый фон),
                     walk-alpha.webm (с альфой), walk.gif, frames.json
```

Рядом лежит `HANDOFF-TASK.ru.md` — готовое задание, которое можно отдать другой модели
вместе с этой папкой.

## Откуда взято (это важно)

Слои — **нативные рендеры** групп глубины, которые делает сама игра, а не вырезка из
итоговой картинки:

- прогон `chubbzee-parts-001` и `soft_helen-parts-001`, флаг `-PartsCapture`;
- ревьюер (`review-tools/verify_native_controls.py`) проверяет каждый прогон, в том числе
  проверкой `sample-parts`: он **сам** складывает присланные слои в порядке глубины и
  сравнивает с кадром прогона. Оба прогона: `verified`, 41 проверка.

Суставы — не оценка: `pivot` каждой кости равен origin соответствующего игрового узла
(`thigh`, `foot`, `shoulder`, `handx`, …), переведённому в пиксели холста. Таз (`hips`) —
середина двух измеренных тазобедренных суставов.

Сборка без преобразований воспроизводит эталон: расхождение 0.02% пикселей (ошибка
alpha-наложения, не геометрии). Это зафиксировано в `verify_package.py`.

## Как устроен кадр

`layers.json`:

```json
{
  "canvas": {"size": 1024, "matrix": {...}},
  "rig": {"order": ["ground","root","hips","torso","head","armUpperFront", ...],
          "bones": {"legUpperFront": {"parent": "hips", "node": "thigh", "pivot": [485.4, 690.3]}, ...}},
  "layers": [{"order": 0, "name": "shadow", "file": "parts/01-shadow.png",
              "chain": ["shadow","shadow"], "bone": "ground", "eye": false,
              "bounds": [424,888,632,927], "pivot": [0.0,0.0]}, ...]
}
```

Правило сборки:

1. Для каждой кости: `world = world(родитель) @ R(pivot, угол)`, где `R` — поворот вокруг
   `pivot` (плюс, если нужно, сдвиг/масштаб). Порядок родителей — в `rig.order`.
2. Каждый слой рисуется матрицей своей кости.
3. Наложение — строго по `order` (0 → N-1), обычный alpha-over.
4. Всё уже в пикселях общего холста: никаких дополнительных матриц не нужно.

Готовый код — `tools/anim/riglib.py`: `forward(rig, pose)` (кинематика),
`compose(layers, package, transforms, layer_transforms=...)` (сборка), `blink(...)`.

## Инструменты

Всё в `character-export/tools/anim/`:

| файл | что делает |
|---|---|
| `riglib.py` | библиотека: слои, суставы, прямая кинематика, сборка, моргание, сравнение кадров |
| `build_rig.py` | из прогона с `-PartsCapture` собирает пакет `anim/<slug>/` и сразу проверяет сборку |
| `verify_package.py` | независимая проверка пакета: порядок слоёв, наличие файлов, суставы, identity-рендер |
| `render_walk.py` | цикл ходьбы: углы по кадрам, моргание, посадка стопы на измеренную землю, mp4/gif |
| `render_poses.py` | **рендер по плану поз в JSON** — интерфейс для любой другой модели/скрипта |
| `write_package_readme.py` | пересобирает `README.ru.md` пакета из `layers.json` |
| `test_anim.py` | тесты: порядок слоёв, суставы, кинематика, моргание, план кадров, цикл замыкается |

Команды:

```powershell
cd "E:\Gacha Nebula Windows 1.7\Gacha Nebula Windows 1.7"

# проверка пакета (ничего не меняет)
python character-export\tools\anim\verify_package.py --package character-export\anim\chubbzee

# готовый цикл ходьбы, 24 кадра при 24 fps, новое имя каталога
python character-export\tools\anim\render_walk.py --package character-export\anim\chubbzee `
  --out character-export\anim\chubbzee\walk-cycle-002 --swing 20 --bend 28

# один кадр из того же цикла
python character-export\tools\anim\render_walk.py --package character-export\anim\chubbzee `
  --out character-export\anim\chubbzee\still-12.png --still 12

# тесты
cd character-export\tools\anim; python test_anim.py
```

`render_walk.py` никогда не перезаписывает существующий каталог: на каждый прогон новое
`--out`.

## Как задать свою анимацию планом (интерфейс для другой модели)

Если анимацию придумывает другая модель или человек, ей не нужен Python: достаточно
записать план в JSON и вызвать один инструмент. Пример — `anim/example-plan.json`:

```json
{
  "fps": 24,
  "frames": [
    {"blink": 0.0, "bones": {}},
    {"blink": 0.0, "bones": {"legUpperFront": {"angle": 14},
                             "legLowerFront": {"angle": 6},
                             "legUpperBack": {"angle": -12},
                             "armUpperFront": {"angle": -8},
                             "armUpperBack": {"angle": 8},
                             "head": {"angle": 1.5}}},
    {"blink": 1.0, "bones": {"legUpperFront": {"angle": -12}, "plant": true}}
  ]
}
```

Поля кадра:

| поле | смысл |
|---|---|
| `bones` | какие кости двигаются; не указанные остаются в измеренной позе |
| `blink` | 0 — глаза открыты, 1 — закрыты (сжатие глазных слоёв до линии ресниц) |
| `plant` | `true` (по умолчанию) — посадить самую низкую точку тела на измеренную линию земли |
| `hold` | сколько кадров держать эту позу (по умолчанию 1) |

**Важно про `plant`:** он выравнивает низ тела по земле, поэтому вертикальный сдвиг через
`root.translate` им же и компенсируется. Если нужен управляемый подскок/присед — ставьте
`"plant": false` в этих кадрах (см. третий кадр в `example-plan.json`).

Поля кости: `angle` (градусы, **плюс = по часовой стрелке на экране**, потому что y растёт
вниз), `translate` (`[x, y]`, пиксели холста), `scale` (`[x, y]`, > 0).

```powershell
python character-export\tools\anim\render_poses.py `
  --package character-export\anim\chubbzee `
  --plan character-export\anim\example-plan.json `
  --out character-export\anim\chubbzee\my-anim-001
```

На выходе: `frames/NNN.png` (1024×1024 RGBA), `frames.json` (что именно нарисовано в
каждом кадре) и, если найден ffmpeg, `walk.mp4` (белый фон), `walk-alpha.webm` (с альфой)
и `walk.gif`.

Инструмент строгий, чтобы чужая анимация не сломала персонажа: неизвестная кость, лишний
ключ, не-число, `NaN`, `scale <= 0`, `blink` вне 0..1 — отказ с сообщением; существующий
каталог `--out` не перезаписывается никогда.

## Параметры цикла

| флаг | смысл | по умолчанию |
|---|---|---|
| `--frames` / `--fps` | длина цикла и частота | 24 / 24 |
| `--swing` | амплитуда бедра, градусы | 24 |
| `--bend` | сгиб колена, градусы | 34 |
| `--knee-lead` | фаза сгиба колена | -0.7 |
| `--arm` | амплитуда рук | 13 |
| `--lean` | наклон корпуса | 2.5 |
| `--bob` | дополнительное покачивание, px | 0 |
| `--blink-at` | первые кадры морганий | `8,19` |
| `--blink-open` | сколько оставить от глаза при закрытии | 0.12 |
| `--no-plant` | не сажать стопу на землю | — |

## Моргание

Отдельных кадров «глаз закрыт» у нас нет: индекс глаз в игре — это **форма** глаза, а не
фаза блинка. Поэтому моргание делается деформацией: глазные слои (`eye1`, `eye2`, `pupil*`,
`highlight*`) сжимаются по вертикали вокруг измеренного центра глаз до линии ресниц
(`--blink-open 0.12`). Кожа под ними — отдельный слой, поэтому сжатие оставляет щель
правильной: видно лицо, а не дырку.

## Чего здесь нет (честные пределы)

- **Нет скиннинга.** Каждый слой — жёсткая картинка и вращается целиком. На широком шаге
  видно стык у бедра: это предел жёстких слоёв, а не ошибка сборки.
- **Нет сустава стопы.** `foot` — это голень вместе с ботинком, вращается вокруг колена.
- **Нет физики и интерполяции между позами.** Кадры задаются углами; «правильная» походка
  получается подбором фаз, а не симуляцией.
- **Один базовый кадр.** Пакет — это одна поза. Пакеты разных поз можно снять тем же
  флагом и смешивать, но тогда следите за суставами: они тоже меняются.

## Как снять пакет для нового персонажа

1. Список кадров (достаточно базовой позы и возврата к ней):

```powershell
# inputs/<Character>.parts.json — {"formatVersion":1,"samples":[{"id":"00-baseline","patch":{}},
#                                                     {"id":"01-restored","patch":{}}]}
```

2. Прогон игры (новое `-Name`, старые каталоги не трогаются):

```powershell
cd character-export\experiments\native-controls
powershell -ExecutionPolicy Bypass -NoProfile -File Run-Native-Controls.ps1 -Name <character>-parts-001 `
  -RecipePath "E:\Gacha Nebula Windows 1.7\Gacha Nebula Windows 1.7\character-export\inputs\<Character>.txt" `
  -DeriveBaseline -UseVerifiedHomeCompatibility `
  -SamplesFile "E:\Gacha Nebula Windows 1.7\Gacha Nebula Windows 1.7\character-export\inputs\<Character>.parts.json" `
  -PartsCapture -TimeoutSeconds 3600
```

Для share-code персонажа добавляется `-RecipeShape share-code` (как у `soft_helen`).

3. Ревьюер, пакет, проверка:

```powershell
cd review-tools; python verify_native_controls.py ..\output\<character>-parts-001
cd ..\..\..\..\..
python character-export\tools\anim\build_rig.py --run character-export\experiments\native-controls\output\<character>-parts-001 `
  --sample 00-baseline --out character-export\anim\<slug> --slug <slug>
python character-export\tools\anim\write_package_readme.py --package character-export\anim\<slug>
```

`build_rig.py` сам завершится с ошибкой, если слои не собираются в эталонный кадр.
