// Tiny 2D affine-matrix helpers. Matrix layout matches CSS matrix(a,b,c,d,e,f):
//   x' = a*x + c*y + e
//   y' = b*x + d*y + f
// Screen space has y pointing down, so a positive angle rotates clockwise,
// exactly like CSS rotate().
export type M = [number, number, number, number, number, number];

export const IDENTITY: M = [1, 0, 0, 1, 0, 0];

/** m1 ∘ m2 : apply m2 first, then m1. */
export function mul(m1: M, m2: M): M {
  return [
    m1[0] * m2[0] + m1[2] * m2[1],
    m1[1] * m2[0] + m1[3] * m2[1],
    m1[0] * m2[2] + m1[2] * m2[3],
    m1[1] * m2[2] + m1[3] * m2[3],
    m1[0] * m2[4] + m1[2] * m2[5] + m1[4],
    m1[1] * m2[4] + m1[3] * m2[5] + m1[5],
  ];
}

export function translate(x: number, y: number): M {
  return [1, 0, 0, 1, x, y];
}

/** Rotation by `deg` (clockwise) around the point (px, py). */
export function rotateAbout(deg: number, px: number, py: number): M {
  const r = (deg * Math.PI) / 180;
  const c = Math.cos(r);
  const s = Math.sin(r);
  return [c, s, -s, c, px - c * px + s * py, py - s * px - c * py];
}

export function toCss(m: M): string {
  return `matrix(${m[0].toFixed(5)},${m[1].toFixed(5)},${m[2].toFixed(5)},${m[3].toFixed(5)},${m[4].toFixed(2)},${m[5].toFixed(2)})`;
}
