import { POSE_KEYS, zeroPose, type Pose } from './kinematics';

export type Mode = 'idle' | 'walk' | 'run' | 'wave';
const MODES: Mode[] = ['idle', 'walk', 'run', 'wave'];

const TAU = Math.PI * 2;
const pos = (v: number) => Math.max(0, v);

/* ------------------------------------------------------------------ */
/* Individual poses                                                     */
/* ------------------------------------------------------------------ */

function idlePose(t: number): Pose {
  const breath = Math.sin(t * 2.1);
  const slow = Math.sin(t * 1.05);
  return {
    bob: breath * 1.6,
    sway: 0,
    torso: slow * 0.6,
    head: Math.sin(t * 1.05 + 0.9) * 1.5,
    tuft: Math.sin(t * 2.1 - 0.9) * 3.2,
    armL: 1.5 + Math.sin(t * 2.1 + 0.4) * 1.2,
    foreL: -2 + breath * 1.2,
    armR: -1.5 - Math.sin(t * 2.1 + 0.4) * 1.2,
    foreR: -2 - breath * 1.2,
    thighL: 0,
    shinL: 0,
    thighR: 0,
    shinR: 0,
  };
}

interface Gait {
  hip: number; // thigh swing amplitude
  knee: number; // max knee flexion
  kneePhase: number; // shifts when the knee flexes in the cycle
  arm: number; // arm swing amplitude
  elbow: number; // elbow bend always present
  elbowSwing: number; // extra bend when the arm goes forward
  lean: number; // forward lean of the torso
  twist: number; // torso twist amplitude
  bob: number; // body bounce
  bobLift: number; // constant offset of the bounce
  sway: number; // sideways weight shift
  tuft: number; // ponytail streaming back
  tuftFlutter: number;
}

const WALK: Gait = {
  hip: 20,
  knee: 30,
  kneePhase: 0,
  arm: 21,
  elbow: 7,
  elbowSwing: 16,
  lean: 2,
  twist: 2.6,
  bob: 8.5,
  bobLift: 0,
  sway: 3,
  tuft: -3,
  tuftFlutter: 3.5,
};

const RUN: Gait = {
  hip: 35,
  knee: 78,
  kneePhase: 0.9,
  arm: 50,
  elbow: 62,
  elbowSwing: 22,
  lean: 11,
  twist: 5,
  bob: -17,
  bobLift: 5,
  sway: 2,
  tuft: -15,
  tuftFlutter: 7,
};

/** One full stride has phase `phi` in [0, 2π). Left leg goes forward when sin(phi) > 0. */
function gaitPose(phi: number, g: Gait): Pose {
  const s = Math.sin(phi);
  const kneeL = g.knee * pos(Math.cos(phi + g.kneePhase));
  const kneeR = g.knee * pos(-Math.cos(phi + g.kneePhase));
  const double = Math.sin(2 * phi);
  return {
    bob: g.bob * Math.abs(s) + g.bobLift,
    sway: g.sway * s,
    torso: g.lean + g.twist * s,
    head: -g.lean * 0.6 - g.twist * 0.7 * s + double * 1.2,
    tuft: g.tuft + g.tuftFlutter * Math.sin(2 * phi - 1.1),
    // arms swing against the legs; swinging forward = negative angle
    armL: g.arm * s,
    foreL: -(g.elbow + g.elbowSwing * pos(-s)),
    armR: -g.arm * s,
    foreR: -(g.elbow + g.elbowSwing * pos(s)),
    thighL: -g.hip * s,
    shinL: kneeL,
    thighR: g.hip * s,
    shinR: kneeR,
  };
}

/** Friendly wave with the arm on the viewer's left. */
function wavePose(t: number): Pose {
  const w = Math.sin(t * TAU * 1.9);
  const slow = Math.sin(t * 1.3);
  return {
    bob: Math.abs(Math.sin(t * TAU * 0.95)) * -2.2 + 1,
    sway: 0,
    torso: -1.2 + slow * 0.8,
    head: -5 + Math.sin(t * 1.3 + 0.5) * 1.6,
    tuft: Math.sin(t * TAU * 0.95 - 0.8) * 4.5,
    armL: 98 + Math.sin(t * 1.7) * 3,
    // forearm points up and slightly outward so the hand waves beside the face
    foreL: 42 + w * 19,
    armR: -2 - slow * 1,
    foreR: -3,
    thighL: 0,
    shinL: 0,
    thighR: 0,
    shinR: 0,
  };
}

/* ------------------------------------------------------------------ */
/* Animator: blends the modes smoothly and drives the shared gait phase */
/* ------------------------------------------------------------------ */

export interface Frame {
  pose: Pose;
  /** Ground speed in rig pixels / second (used to scroll the scenery). */
  speed: number;
  /** How strongly the "wave" pose is active, 0..1. */
  wave: number;
  /** Vertical lift of the body, used to shrink the shadow. */
  weights: Record<Mode, number>;
}

const WALK_FREQ = 1.25; // strides / second
const RUN_FREQ = 2.0;
const WALK_SPEED = 300;
const RUN_SPEED = 760;

export class Animator {
  private weights: Record<Mode, number> = { idle: 1, walk: 0, run: 0, wave: 0 };
  private target: Mode = 'idle';
  private time = 0;
  private phi = 0;

  setMode(m: Mode) {
    this.target = m;
  }

  getMode(): Mode {
    return this.target;
  }

  step(dtRaw: number): Frame {
    const dt = Math.min(dtRaw, 0.05);
    this.time += dt;

    // ease the mode weights toward the one-hot target
    const k = 1 - Math.exp(-dt * 8);
    let sum = 0;
    for (const m of MODES) {
      const goal = m === this.target ? 1 : 0;
      this.weights[m] += (goal - this.weights[m]) * k;
      sum += this.weights[m];
    }
    for (const m of MODES) this.weights[m] /= sum;

    const wWalk = this.weights.walk;
    const wRun = this.weights.run;
    const gaitW = wWalk + wRun;

    // stride frequency follows the blended gait so walk <-> run is seamless
    const freq = gaitW > 0.001 ? (wWalk * WALK_FREQ + wRun * RUN_FREQ) / gaitW : WALK_FREQ;
    this.phi = (this.phi + dt * TAU * freq) % (TAU * 1000);

    const poses: [Mode, Pose][] = [
      ['idle', idlePose(this.time)],
      ['walk', gaitPose(this.phi, WALK)],
      ['run', gaitPose(this.phi, RUN)],
      ['wave', wavePose(this.time)],
    ];

    const out = zeroPose();
    for (const [m, p] of poses) {
      const w = this.weights[m];
      if (w < 0.0005) continue;
      for (const key of POSE_KEYS) out[key] += p[key] * w;
    }

    return {
      pose: out,
      speed: wWalk * WALK_SPEED + wRun * RUN_SPEED,
      wave: this.weights.wave,
      weights: { ...this.weights },
    };
  }
}
