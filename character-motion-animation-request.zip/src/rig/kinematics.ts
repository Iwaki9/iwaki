import { GEOM, JOINTS, PART_ORDER, type PartKey } from './rigData';
import { mul, rotateAbout, translate, type M } from './affine';

/**
 * Pose of the character. Every angle is in degrees, clockwise-positive
 * (CSS convention) and *relative* to the rest pose shown in the reference
 * picture, so an all-zero pose reproduces the original whole character.
 *
 * "L" / "R" follow the reference sheet: L = the arm/leg on the viewer's left.
 * The character faces to the viewer's right.
 */
export interface Pose {
  bob: number; // vertical shift of the whole body (px, +down)
  sway: number; // horizontal shift of the whole body (px)
  torso: number; // lean/twist around the waist
  head: number; // head tilt around the neck (relative to torso)
  tuft: number; // ponytail swing around its root (relative to head)
  armL: number; // upper arm around the shoulder (relative to torso)
  foreL: number; // forearm around the elbow (relative to upper arm)
  armR: number;
  foreR: number;
  thighL: number; // thigh around the hip
  shinL: number; // shin around the knee (relative to thigh)
  thighR: number;
  shinR: number;
}

export const POSE_KEYS = [
  'bob',
  'sway',
  'torso',
  'head',
  'tuft',
  'armL',
  'foreL',
  'armR',
  'foreR',
  'thighL',
  'shinL',
  'thighR',
  'shinR',
] as const satisfies readonly (keyof Pose)[];

export function zeroPose(): Pose {
  return {
    bob: 0,
    sway: 0,
    torso: 0,
    head: 0,
    tuft: 0,
    armL: 0,
    foreL: 0,
    armR: 0,
    foreR: 0,
    thighL: 0,
    shinL: 0,
    thighR: 0,
    shinR: 0,
  };
}

// Rest-pose matrix of every part: part-box coordinates -> rest-pose world.
const LOCAL = {} as Record<PartKey, M>;
for (const k of PART_ORDER) {
  const g = GEOM[k];
  LOCAL[k] = mul(
    translate(g.cx, g.cy),
    mul(rotateAbout(g.rot, 0, 0), translate(-g.w / 2, -g.h / 2)),
  );
}

const J = JOINTS;

/** Forward kinematics: pose -> world matrix of every sprite. */
export function solve(p: Pose): Record<PartKey, M> {
  const root = translate(p.sway, p.bob);

  const torso = mul(root, rotateAbout(p.torso, J.waist.x, J.waist.y));
  const head = mul(torso, rotateAbout(p.head, J.neck.x, J.neck.y));
  const tuft = mul(head, rotateAbout(p.tuft, J.tuft.x, J.tuft.y));

  const upL = mul(torso, rotateAbout(p.armL, J.shoulderL.x, J.shoulderL.y));
  const foL = mul(upL, rotateAbout(p.foreL, J.elbowL.x, J.elbowL.y));
  const upR = mul(torso, rotateAbout(p.armR, J.shoulderR.x, J.shoulderR.y));
  const foR = mul(upR, rotateAbout(p.foreR, J.elbowR.x, J.elbowR.y));

  const thL = mul(root, rotateAbout(p.thighL, J.hipL.x, J.hipL.y));
  const shL = mul(thL, rotateAbout(p.shinL, J.kneeL.x, J.kneeL.y));
  const thR = mul(root, rotateAbout(p.thighR, J.hipR.x, J.hipR.y));
  const shR = mul(thR, rotateAbout(p.shinR, J.kneeR.x, J.kneeR.y));

  return {
    tuft: mul(tuft, LOCAL.tuft),
    head: mul(head, LOCAL.head),
    torso: mul(torso, LOCAL.torso),
    hem: mul(torso, LOCAL.hem),
    upperArmL: mul(upL, LOCAL.upperArmL),
    foreArmL: mul(foL, LOCAL.foreArmL),
    upperArmR: mul(upR, LOCAL.upperArmR),
    foreArmR: mul(foR, LOCAL.foreArmR),
    thighL: mul(thL, LOCAL.thighL),
    shinL: mul(shL, LOCAL.shinL),
    thighR: mul(thR, LOCAL.thighR),
    shinR: mul(shR, LOCAL.shinR),
  };
}

export const REST_MATRICES = solve(zeroPose());
