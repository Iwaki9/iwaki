// AUTO-GENERATED geometry. All numbers are in the coordinate space of the
// reference picture where the character is shown whole (rest pose).
export type PartKey =
  | 'tuft'
  | 'thighL'
  | 'thighR'
  | 'shinL'
  | 'shinR'
  | 'upperArmR'
  | 'foreArmR'
  | 'torso'
  | 'hem'
  | 'upperArmL'
  | 'foreArmL'
  | 'head';

// Back-to-front drawing order in the rest pose.
export const PART_ORDER: PartKey[] = ['tuft', 'thighL', 'thighR', 'shinL', 'shinR', 'upperArmR', 'foreArmR', 'torso', 'hem', 'upperArmL', 'foreArmL', 'head'];

export interface PartGeom { w: number; h: number; cx: number; cy: number; rot: number }
// w/h: size of the part, cx/cy: its centre in the rest pose, rot: rest rotation in degrees (clockwise).
export const GEOM: Record<PartKey, PartGeom> = {
  tuft: { w: 125, h: 146, cx: 243.0, cy: 236.5, rot: -0.0 },
  thighL: { w: 60, h: 123, cx: 346.0, cy: 620.5, rot: 0.5 },
  thighR: { w: 58, h: 121, cx: 401.0, cy: 608.5, rot: -0.0 },
  shinL: { w: 62, h: 121, cx: 342.5, cy: 696.5, rot: -0.0 },
  shinR: { w: 65, h: 119, cx: 406.5, cy: 691.5, rot: -0.0 },
  upperArmR: { w: 56, h: 88, cx: 404.5, cy: 505.5, rot: 6.0 },
  foreArmR: { w: 61, h: 92, cx: 426.5, cy: 554.5, rot: 0.5 },
  torso: { w: 102, h: 173, cx: 375.0, cy: 505.5, rot: -0.0 },
  hem: { w: 114, h: 61, cx: 373.0, cy: 566.5, rot: -0.0 },
  upperArmL: { w: 55, h: 89, cx: 329.0, cy: 494.5, rot: -0.0 },
  foreArmL: { w: 60, h: 93, cx: 306.0, cy: 556.5, rot: -0.0 },
  head: { w: 310, h: 292, cx: 355.0, cy: 324.0, rot: -0.0 },
};

export interface Pt { x: number; y: number }
// Joint pivots in rest-pose coordinates.
export const JOINTS = {
  shoulderL: { x: 341.1, y: 462.9 },
  elbowL: { x: 317.0, y: 524.6 },
  hipL: { x: 337.5, y: 575.6 },
  kneeL: { x: 343.1, y: 658.3 },
  shoulderR: { x: 394.1, y: 471.8 },
  elbowR: { x: 414.4, y: 529.2 },
  hipR: { x: 391.5, y: 564.4 },
  kneeR: { x: 400.5, y: 649.8 },
  neck: { x: 366.3, y: 433.6 },
  waist: { x: 372.5, y: 544.0 },
  tuft: { x: 276.7, y: 282.9 },
} as const;

// Visible region of the rig (shadow and wave/run overshoot included).
export const VIEW = { x: 122, y: 138, w: 500, h: 642 };
// Contact shadow under the feet (taken from the reference picture).
export const SHADOW = { cx: 379, cy: 747, rx: 78, ry: 11 };
