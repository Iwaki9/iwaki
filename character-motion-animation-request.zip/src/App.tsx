import { useEffect, useState } from 'react';
import Stage from './components/Stage';
import type { Mode } from './rig/animator';

const MODES: { id: Mode; label: string; emoji: string; hint: string }[] = [
  { id: 'idle', label: 'Покой', emoji: '🙂', hint: '1' },
  { id: 'walk', label: 'Ходьба', emoji: '🚶', hint: '2' },
  { id: 'run', label: 'Бег', emoji: '🏃', hint: '3' },
  { id: 'wave', label: 'Махание рукой', emoji: '👋', hint: '4' },
];

function initialMode(): Mode {
  const h = window.location.hash.replace('#', '');
  return (MODES.find((m) => m.id === h)?.id ?? 'wave') as Mode;
}

export default function App() {
  const [mode, setMode] = useState<Mode>(initialMode);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const found = MODES.find((m) => m.hint === e.key);
      if (found) setMode(found.id);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    <div className="min-h-screen w-full bg-[radial-gradient(ellipse_at_top,_#3a2d63_0%,_#1a1430_55%,_#0d0a1a_100%)] text-white flex flex-col items-center">
      <header className="w-full max-w-4xl px-5 pt-8 pb-5 text-center">
        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight bg-gradient-to-r from-pink-300 via-rose-200 to-amber-200 bg-clip-text text-transparent">
          Анимация персонажа
        </h1>
        <p className="mt-3 text-sm sm:text-base text-violet-200/80 max-w-xl mx-auto">
          Персонаж собран из твоих частей точно по цельному примеру. Выбери
          движение: ходьба, бег или махание рукой.
        </p>
      </header>

      <main className="w-full max-w-4xl px-4 sm:px-6 pb-12 flex flex-col items-center gap-6">
        <Stage mode={mode} />

        <div className="flex flex-wrap items-center justify-center gap-3">
          {MODES.map((m) => {
            const active = mode === m.id;
            return (
              <button
                key={m.id}
                onClick={() => setMode(m.id)}
                aria-pressed={active}
                className={`flex items-center gap-2 rounded-full px-5 py-2.5 text-sm sm:text-base font-semibold border transition-all cursor-pointer ${
                  active
                    ? 'bg-gradient-to-r from-pink-500 to-amber-400 text-slate-900 border-transparent shadow-lg shadow-pink-500/30 scale-105'
                    : 'bg-white/5 border-white/15 text-violet-100 hover:bg-white/10 hover:border-white/30'
                }`}
              >
                <span className="text-lg leading-none">{m.emoji}</span>
                {m.label}
                <kbd
                  className={`hidden sm:inline rounded px-1.5 text-[11px] font-mono ${
                    active ? 'bg-black/15' : 'bg-white/10 text-violet-300'
                  }`}
                >
                  {m.hint}
                </kbd>
              </button>
            );
          })}
        </div>

        <p className="text-xs text-violet-300/60 text-center max-w-md">
          Переключать режимы можно клавишами 1–4. Движения плавно перетекают
          друг в друга, а фон прокручивается в такт шагам.
        </p>
      </main>
    </div>
  );
}
