// Seamless SVG tiles for the parallax background (kept inline so the final
// single-file build has no external assets).

const svgUrl = (svg: string) =>
  `url("data:image/svg+xml,${encodeURIComponent(svg.replace(/\s+/g, ' ').trim())}")`;

const cloud = (x: number, y: number, s: number) => `
  <g transform="translate(${x} ${y}) scale(${s})">
    <ellipse cx="0" cy="20" rx="78" ry="22"/>
    <ellipse cx="-28" cy="4" rx="38" ry="26"/>
    <ellipse cx="22" cy="-6" rx="46" ry="32"/>
    <ellipse cx="58" cy="10" rx="30" ry="20"/>
  </g>`;

const CLOUDS = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 260">
  <g fill="#ffffff" opacity="0.88">
    ${cloud(140, 90, 1)}
    ${cloud(470, 150, 0.7)}
    ${cloud(760, 70, 0.9)}
    ${cloud(930, 190, 0.55)}
  </g>
</svg>`;

const HILLS = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 300" preserveAspectRatio="none">
  <path fill="#c8b8f0" d="M0 190 C160 70 330 90 470 170 S760 250 920 140 S1120 110 1200 190 L1200 300 L0 300 Z"/>
  <path fill="#ad9be4" d="M0 240 C140 170 300 170 430 225 S720 280 880 215 S1110 190 1200 240 L1200 300 L0 300 Z"/>
</svg>`;

const tree = (x: number, h: number, c1: string, c2: string) => `
  <g transform="translate(${x} 360)">
    <rect x="-7" y="${-h * 0.45}" width="14" height="${h * 0.45}" rx="5" fill="#5a3f6b"/>
    <circle cx="0" cy="${-h * 0.62}" r="${h * 0.3}" fill="${c1}"/>
    <circle cx="${-h * 0.17}" cy="${-h * 0.5}" r="${h * 0.2}" fill="${c2}"/>
    <circle cx="${h * 0.18}" cy="${-h * 0.52}" r="${h * 0.19}" fill="${c2}"/>
  </g>`;

const bush = (x: number, r: number) => `
  <g transform="translate(${x} 360)" fill="#4f9b8a">
    <ellipse cx="0" cy="-${r * 0.5}" rx="${r}" ry="${r * 0.62}"/>
    <ellipse cx="${r * 0.7}" cy="-${r * 0.35}" rx="${r * 0.6}" ry="${r * 0.45}" fill="#5eb09c"/>
  </g>`;

const TREES = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 360">
  ${tree(90, 250, '#4aa088', '#5cb39b')}
  ${bush(230, 46)}
  ${tree(380, 190, '#3f8f7d', '#52a58f')}
  ${tree(590, 280, '#4aa088', '#5cb39b')}
  ${bush(740, 54)}
  ${tree(880, 210, '#3f8f7d', '#52a58f')}
  ${bush(1010, 40)}
  ${tree(1110, 170, '#4aa088', '#5cb39b')}
</svg>`;

const GROUND = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 420 100">
  <g fill="#5cae62">
    <path d="M30 40 l5 -16 l5 16 z"/><path d="M42 40 l4 -11 l4 11 z"/>
    <path d="M190 38 l5 -15 l5 15 z"/><path d="M202 38 l4 -10 l4 10 z"/>
    <path d="M330 41 l5 -17 l5 17 z"/><path d="M342 41 l4 -11 l4 11 z"/>
  </g>
  <g fill="#ffffff" opacity="0.55">
    <rect x="20" y="66" width="70" height="7" rx="3.5"/>
    <rect x="230" y="66" width="70" height="7" rx="3.5"/>
  </g>
  <g fill="#c9a373" opacity="0.9">
    <ellipse cx="150" cy="86" rx="9" ry="4"/>
    <ellipse cx="370" cy="84" rx="7" ry="3.2"/>
    <ellipse cx="305" cy="92" rx="5" ry="2.4"/>
  </g>
</svg>`;

export interface Layer {
  key: string;
  /** scroll speed relative to the character's ground speed */
  factor: number;
  aspect: number; // tile width / height
  height: number; // as a fraction of the stage height
  bottom: number; // distance from the stage bottom, fraction of stage height
  image: string;
}

export const LAYERS: Layer[] = [
  { key: 'clouds', factor: 0.06, aspect: 1000 / 260, height: 0.3, bottom: 0.62, image: svgUrl(CLOUDS) },
  { key: 'hills', factor: 0.16, aspect: 1200 / 300, height: 0.5, bottom: 0.2, image: svgUrl(HILLS) },
  { key: 'trees', factor: 0.5, aspect: 1200 / 360, height: 0.42, bottom: 0.2, image: svgUrl(TREES) },
  { key: 'ground', factor: 1, aspect: 420 / 100, height: 0.24, bottom: 0, image: svgUrl(GROUND) },
];
