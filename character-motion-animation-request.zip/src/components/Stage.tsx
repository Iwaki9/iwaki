import { useEffect, useRef, useState } from 'react';
import CharacterRig, { type RigHandle } from './CharacterRig';
import { LAYERS } from './scenery';
import { Animator, type Mode } from '../rig/animator';
import { VIEW } from '../rig/rigData';

interface StageProps {
  mode: Mode;
}

// distance (rig px) between the soles of the shoes and the bottom of the rig view
const FEET_TO_BOTTOM = VIEW.y + VIEW.h - 752;
const FEET_LEVEL = 0.105; // feet sit at this fraction of the stage height

export default function Stage({ mode }: StageProps) {
  const holder = useRef<HTMLDivElement | null>(null);
  const rig = useRef<RigHandle | null>(null);
  const layerEls = useRef<(HTMLDivElement | null)[]>([]);
  const animator = useRef<Animator>(new Animator());
  const [size, setSize] = useState({ w: 900, h: 520 });
  const sizeRef = useRef(size);
  sizeRef.current = size;

  useEffect(() => {
    animator.current.setMode(mode);
  }, [mode]);

  useEffect(() => {
    const el = holder.current;
    if (!el) return;
    const ro = new ResizeObserver(() => {
      setSize({ w: el.clientWidth, h: el.clientHeight });
    });
    ro.observe(el);
    setSize({ w: el.clientWidth, h: el.clientHeight });
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    let travelled = 0;

    const tick = (now: number) => {
      const dt = (now - last) / 1000;
      last = now;
      const frame = animator.current.step(dt);
      rig.current?.apply(frame.pose, frame.pose.armL > 45);

      const { h } = sizeRef.current;
      const k = (h * 0.86) / VIEW.h;
      travelled += frame.speed * k * dt;
      LAYERS.forEach((layer, i) => {
        const el = layerEls.current[i];
        if (!el) return;
        const tileW = layer.height * h * layer.aspect;
        el.style.backgroundPositionX = `${-((travelled * layer.factor) % tileW)}px`;
      });

      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  const k = (size.h * 0.86) / VIEW.h;

  return (
    <div
      ref={holder}
      className="relative w-full h-[420px] sm:h-[520px] overflow-hidden rounded-[28px] border border-white/15 shadow-2xl shadow-black/50"
      style={{
        background:
          'linear-gradient(180deg, #7fb0ff 0%, #a9c4ff 38%, #f6d2ec 78%, #ffe6cf 100%)',
      }}
    >
      {/* sun */}
      <div
        className="absolute rounded-full"
        style={{
          right: '9%',
          top: '9%',
          width: size.h * 0.17,
          height: size.h * 0.17,
          background:
            'radial-gradient(circle, #fffbe0 0%, #fff0a8 45%, rgba(255,240,168,0) 72%)',
          boxShadow: '0 0 60px 20px rgba(255,244,190,0.45)',
        }}
      />

      {LAYERS.map((layer, i) => (
        <div
          key={layer.key}
          ref={(el) => {
            layerEls.current[i] = el;
          }}
          className="absolute left-0 right-0"
          style={{
            bottom: layer.bottom * size.h,
            height: layer.height * size.h,
            backgroundImage: layer.image,
            backgroundRepeat: 'repeat-x',
            backgroundSize: `${layer.height * size.h * layer.aspect}px ${layer.height * size.h}px`,
            backgroundPositionY: 'bottom',
            zIndex: layer.key === 'ground' ? 1 : 0,
          }}
        />
      ))}

      {/* ground colour bands (grass + sandy path) sit under the scrolling details */}
      <div
        className="absolute left-0 right-0 bottom-0"
        style={{
          height: '24%',
          background:
            'linear-gradient(180deg, #86d08a 0%, #6fbf73 40%, #ecd2a2 40.5%, #dcb987 100%)',
          zIndex: 0,
        }}
      />

      {/* the character */}
      <div
        className="absolute"
        style={{
          left: '50%',
          bottom: FEET_LEVEL * size.h - FEET_TO_BOTTOM * k,
          width: VIEW.w,
          height: VIEW.h,
          transform: `translateX(-50%) scale(${k})`,
          transformOrigin: '50% 100%',
          zIndex: 2,
        }}
      >
        <CharacterRig ref={rig} />
      </div>
    </div>
  );
}
