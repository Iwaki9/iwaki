import { forwardRef, useImperativeHandle, useRef } from 'react';
import { GEOM, PART_ORDER, SHADOW, VIEW, type PartKey } from '../rig/rigData';
import { PART_IMAGES } from '../rig/partImages';
import { REST_MATRICES, solve, type Pose } from '../rig/kinematics';
import { toCss } from '../rig/affine';

export interface RigHandle {
  /** Re-pose the character. `armInFront` lifts the waving arm above the head. */
  apply: (pose: Pose, armInFront: boolean) => void;
}

const BASE_Z: Record<PartKey, number> = {} as Record<PartKey, number>;
PART_ORDER.forEach((k, i) => {
  BASE_Z[k] = i + 1;
});

const CharacterRig = forwardRef<RigHandle>(function CharacterRig(_props, ref) {
  const parts = useRef<Partial<Record<PartKey, HTMLImageElement | null>>>({});
  const shadow = useRef<HTMLDivElement | null>(null);
  const lastFront = useRef<boolean | null>(null);

  useImperativeHandle(
    ref,
    () => ({
      apply(pose, armInFront) {
        const m = solve(pose);
        for (const k of PART_ORDER) {
          const el = parts.current[k];
          if (el) el.style.transform = toCss(m[k]);
        }

        if (lastFront.current !== armInFront) {
          lastFront.current = armInFront;
          const up = parts.current.upperArmL;
          const fore = parts.current.foreArmL;
          if (up) up.style.zIndex = String(armInFront ? 30 : BASE_Z.upperArmL);
          if (fore) fore.style.zIndex = String(armInFront ? 31 : BASE_Z.foreArmL);
        }

        // contact shadow follows the body and shrinks while it is in the air
        if (shadow.current) {
          const air = Math.max(-1, Math.min(1, -pose.bob / 22));
          const scale = 1 - air * 0.22;
          shadow.current.style.transform = `translateX(${(pose.sway * 0.6).toFixed(2)}px) scale(${scale.toFixed(3)})`;
          shadow.current.style.opacity = String(0.85 - air * 0.3);
        }
      },
    }),
    [],
  );

  return (
    <div
      style={{
        position: 'relative',
        width: VIEW.w,
        height: VIEW.h,
        pointerEvents: 'none',
        userSelect: 'none',
      }}
    >
      {/* everything inside uses the coordinates of the reference picture */}
      <div
        style={{
          position: 'absolute',
          left: 0,
          top: 0,
          width: 0,
          height: 0,
          transform: `translate(${-VIEW.x}px, ${-VIEW.y}px)`,
        }}
      >
        <div
          ref={shadow}
          style={{
            position: 'absolute',
            left: SHADOW.cx - SHADOW.rx,
            top: SHADOW.cy - SHADOW.ry,
            width: SHADOW.rx * 2,
            height: SHADOW.ry * 2,
            borderRadius: '50%',
            background:
              'radial-gradient(ellipse at center, rgba(30,20,60,0.55) 0%, rgba(30,20,60,0.35) 55%, rgba(30,20,60,0) 100%)',
            zIndex: 0,
          }}
        />
        {PART_ORDER.map((k) => (
          <img
            key={k}
            ref={(el) => {
              parts.current[k] = el;
            }}
            src={PART_IMAGES[k]}
            alt=""
            draggable={false}
            style={{
              position: 'absolute',
              left: 0,
              top: 0,
              width: GEOM[k].w,
              height: GEOM[k].h,
              transformOrigin: '0 0',
              transform: toCss(REST_MATRICES[k]),
              zIndex: BASE_Z[k],
              willChange: 'transform',
              maxWidth: 'none',
            }}
          />
        ))}
      </div>
    </div>
  );
});

export default CharacterRig;
