"""The film. Paragraphs 1-4 (the pilot) are here, paragraphs 5-77 are in story.py and are added
when the narration in audio/words.json covers them. Cuts are tied to words of the narration, never
to raw seconds, so a new voice recording re-times the film by itself.

Colours in specs are written with rgb() and stored in the engine's BGR order.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import story  # noqa: E402

ACTOR = "rasskazchik_home_v7"      # narrator at home
STREET = "rasskazchik_street_v3"    # narrator outdoors and in the stairwell
OFFSET = 6.0            # the title plays before the first word
TAIL = 7.0              # after the last word: fade, then the voices come back

CALM, TIRED = ("base", 331), ("base", 277)   # "base" = the pack's own eyes (tired, dark circles)
SMILE = (172, 277)
LOOK = (172, 331)
UNEASY = (77, 331)
SCARED = (1, 28)
ANNOYED = (20, 331)
ASLEEP = (39, 331)
TALK_MOUTHS = (331, 358, 303, 221)

# Puppet.rig() now adapts the far arm to Gacha proportions automatically without pushing idle behind the torso.
EASED_ARM = {}
# Tense stance: lower both arms toward the sides so fear reads through the face and not raised sleeves.
EASED_BOTH = {"armL": [(0, 22.0)], "foreL": [(0, 48.0)], "armR": [(0, 18.0)], "foreR": [(0, 44.0)]}


def eased_from(t):
    """EASED_BOTH that starts when the tense pose does: on idle all offsets stay at 0."""
    return {
        "armL": [(t, 0.0), (t + .3, 22.0)],
        "foreL": [(t, 0.0), (t + .3, 48.0)],
        "armR": [(t, 0.0), (t + .3, 18.0)],
        "foreR": [(t, 0.0), (t + .3, 44.0)],
    }


SEATED = [(0.0, .685, .780, .54)]
BED = [(0.0, .688, .685, .34)]


# The argument behind the wall: (text, voice, pitch, rate, speed-up). Heavily muffled in the mix.
NASAL = ("ru-RU-DmitryNeural", "+30Hz", "-10%", 1.28)
SHRILL = ("ru-RU-SvetlanaNeural", "+60Hz", "+5%", 1.42)
VOICE_LINES = [
    ("Ну отдай, ну пожалуйста, это моё, я первый нашёл, я первый!", *NASAL),
    ("Нет, нет, нет! Не отдам! Сам виноват! Сам, сам, сам!", *SHRILL),
    ("А вот и не сам. Тебе говорили, а ты не слушал, а теперь обидно, очень обидно.", *NASAL),
    ("Ха-ха-ха! Обидно ему! Всем обидно! Сидеть тихо, я сказал!", *SHRILL),
    ("Темно тут. Сыро тут. Ну сколько можно, ну сколько можно уже.", *NASAL),
    ("Молчи! Молчи! Сейчас услышат! Ха-ха! Услышат!", *SHRILL),
]


def rgb(r, g, b):
    return (b, g, r)


WARM_ROOM = dict(ambient=rgb(.70, .65, .58), key=rgb(.26, .20, .11), dir=(1.0, -.25),
                 rim=dict(color=rgb(1.0, .78, .5), amount=.34, width=6.0))
BLUE_NIGHT = dict(ambient=rgb(.20, .25, .40), key=rgb(.16, .22, .38), dir=(1.0, -.5),
                  rim=dict(color=rgb(.5, .68, 1.0), amount=.42, width=7.0))
FRIDGE = dict(ambient=rgb(.17, .19, .30), key=rgb(.82, .64, .42), dir=(-1.0, -.12),
              rim=dict(color=rgb(1.0, .84, .6), amount=.62, width=9.0))
HUB = dict(ambient=rgb(.40, .44, .62), key=rgb(.50, .42, .30), dir=(1.0, -.35),
           rim=dict(color=rgb(1.0, .80, .55), amount=.5, width=8.0))
STAIR = dict(ambient=rgb(.70, .70, .62), key=rgb(.30, .27, .18), dir=(.2, -1.0),
             rim=dict(color=rgb(1.0, .92, .72), amount=.3, width=6.0))
DUSK = dict(ambient=rgb(.50, .50, .58), key=rgb(.42, .32, .26), dir=(1.0, -.4),
            rim=dict(color=rgb(1.0, .72, .55), amount=.34, width=5.0))

HALO_NIGHT = dict(color=rgb(.55, .68, 1.0), amount=.16, radius=14.0)
HALO_WARM = dict(color=rgb(1.0, .85, .65), amount=.12, radius=13.0)


def actor(path, clips, face=(), light=WARM_ROOM, pack=None, **extra):
    spec = dict(pack=pack or ACTOR, path=[(key[0], key[1:]) for key in path], clips=[dict(t=t, anim=a, **o) for t, a, o in clips],
                face=list(face), light=light, seed=len(clips) * 3 + 2)
    spec.update(extra)
    return spec


def build(ctx):
    words = ctx["words"]

    def cue(phrase, after=0.0):
        return words.start(phrase, after) + OFFSET

    def cue_end(phrase, after=0.0):
        return words.end(phrase, after) + OFFSET

    voice_end = words.words[-1]["end"] + OFFSET
    duration = voice_end + TAIL
    shots, sfx = [], []

    # ------------------------------------------------------------------ title
    hub_light = [dict(x=.62, y=.365, r=.05, color=rgb(.9, .95, 1.0), amount=.34, flicker=dict(speed=5, depth=.25)),
                 dict(x=.91, y=.455, r=.09, color=rgb(1.0, .75, .4), amount=.12, flicker=dict(speed=.8, depth=.5))]
    shots.append(dict(
        id="title", start=0.0, bg="B00", fade_in=2.2,
        camera={"from": (.46, .52, 1.12), "to": (.44, .50, 1.05)},
        lights=hub_light, dust=dict(count=46, amount=.06, color=rgb(.75, .85, 1.0)),
        grade=dict(exposure=.92, tint=rgb(.92, .96, 1.08), saturation=.86, vignette=.62, grain=.02, bloom=.4),
        text=[dict(text="Мультики за стеной", t=1.4, length=4.0, size=96, y=.46, jitter=1.6, fade=.9)],
    ))

    # ------------------------------------------------------------------ paragraph 1
    t0 = cue("Пару")
    t1 = cue("Обычная первоэтажная")
    shots.append(dict(
        id="yard", start=t0, bg="B01", **{"in": dict(type="black", length=1.0)},
        camera={"from": (.56, .55, 1.14), "to": (.46, .56, 1.28)},
        lights=[dict(x=.565, y=.375, r=.05, color=rgb(.8, 1.0, .85), amount=.3, flicker=dict(speed=4, depth=.2))],
        grade=dict(exposure=.95, saturation=.9, vignette=.5, tint=rgb(.97, .97, 1.03)),
        actors=[actor([(0.0, .80, .96, .50), (t1 - t0, .43, .685, .235)],
                      [(0.0, "walk", dict(speed=.95))], [(0, CALM)], DUSK, pack=STREET, flip=True,
                      halo=dict(color=rgb(.8, .85, 1.0), amount=.08, radius=9.0), contact=.5)],
    ))
    sfx.append((t1 - .9, "door_far", .5))

    t2 = cue("Ну и, как водится")
    shots.append(dict(
        id="stairs", start=t1, bg="B02", **{"in": dict(type="cross", length=.7)},
        camera={"from": (.52, .50, 1.05), "to": (.60, .52, 1.26)},
        flicker=dict(speed=9, depth=.09, drops=[(3.4, .22, .35), (6.2, .12, .5)]),
        lights=[dict(x=.597, y=.14, r=.14, color=rgb(1.0, .86, .55), amount=.55, flicker=dict(speed=9, depth=.2))],
        dust=dict(count=60, amount=.08, color=rgb(1.0, .93, .78)),
        grade=dict(exposure=.9, saturation=.88, vignette=.55, contrast=1.05),
        actors=[actor([(0.0, .66, .94, .63)], [(0.0, "look_around", dict(speed=.7))], [(0, LOOK)], STAIR, pack=STREET, flip=True,
                      offsets=EASED_ARM, contact=.6, halo=HALO_WARM,
                      cast=dict(scale=(.95, .9), skew=.12, x=-.05, y=-.02, blur=10.0, opacity=.32))],
    ))
    sfx.append((t1 + 3.4, "buzz", .3))

    t3 = cue("Поначалу казалось")
    door_hit = cue("хлопками")
    room_lamp = [dict(x=.915, y=.565, r=.13, color=rgb(1.0, .78, .42), amount=.28, flicker=dict(speed=3, depth=.08))]
    shots.append(dict(
        id="room_sound", start=t2, bg="B03", **{"in": dict(type="cross", length=.6)},
        camera={"from": (.42, .52, 1.08), "to": (.37, .55, 1.22)},
        lights=room_lamp, shake=[(door_hit - t2, .34, .35)],
        grade=dict(exposure=.92, saturation=.92, vignette=.48),
        actors=[actor([(0.0, .33, .94, .68)],
                      [(0.0, "idle", dict()), (2.2, "sigh", dict(speed=.8))],
                      [(0, CALM), (door_hit - t2, UNEASY), (door_hit - t2 + 1.4, CALM)], WARM_ROOM,
                      contact=.55, halo=HALO_WARM,
                      cast=dict(scale=(1.0, .55), skew=.9, y=-.012, blur=8.0, opacity=.3))],
    ))
    sfx += [(door_hit, "door_slam", 1.0), (door_hit + 2.6, "footsteps_up", .35)]

    t4 = cue("Сперва я даже")
    shots.append(dict(
        id="room_lucky", start=t3, bg="B03", **{"in": dict(type="cross", length=.5)},
        camera={"from": (.34, .58, 1.5), "to": (.30, .54, 1.62)},
        lights=room_lamp,
        grade=dict(exposure=.96, saturation=.98, vignette=.42, blur=1.6, tint=rgb(1.04, 1.0, .95)),
        actors=[actor([(0.0, .33, 1.02, .76)],
                      [(0.0, "idle", dict()), (2.8, "shrug", dict(speed=.7)), (7.0, "idle", dict())],
                      [(0, TIRED), (2.8, SMILE)], WARM_ROOM, offsets=EASED_ARM, contact=0, halo=HALO_WARM)],
    ))

    t5 = cue("громкий звук телевизора")
    shots.append(dict(
        id="room_family", start=t4, bg="B03", **{"in": dict(type="blur", length=.8)},
        camera={"from": (.62, .57, 1.28), "to": (.64, .57, 1.38)},
        lights=room_lamp,
        grade=dict(exposure=.86, saturation=.92, vignette=.5),
        actors=[actor(SEATED, [(0.0, "sit_bed", dict())], [(0, TIRED), (t5 - t4 - 1.0, LOOK)],
                      WARM_ROOM, flip=True, offsets=EASED_ARM, contact=.35, halo=HALO_WARM, blink=True)],
    ))

    t6 = cue("Я никогда не придавал")
    shots.append(dict(
        id="wall_tv", start=t5, bg="B08", **{"in": dict(type="cross", length=.6)},
        camera={"from": (.5, .5, 1.05), "to": (.52, .52, 1.32), "ease": "linear"},
        flicker=dict(speed=7, depth=.16),
        lights=[dict(x=.5, y=.42, r=.42, color=rgb(.55, .68, 1.0), amount=.16, flicker=dict(speed=11, depth=.55))],
        grade=dict(exposure=.96, saturation=.8, vignette=.72, contrast=1.08),
    ))

    # ------------------------------------------------------------------ paragraph 2
    t7 = cue("Первую неделю")
    knocks = cue("стукачам")
    shots.append(dict(
        id="hub_habit", start=t6, bg="B00", **{"in": dict(type="black", length=.9)},
        camera={"from": (.27, .46, 1.24), "to": (.30, .44, 1.32)},
        lights=hub_light, dust=dict(count=46, amount=.07, color=rgb(.75, .85, 1.0)),
        grade=dict(exposure=1.08, tint=rgb(.94, .97, 1.08), saturation=.88, vignette=.6, bloom=.4),
        actors=[actor([(0.0, .225, 1.26, 1.12)], [(0.0, "idle", dict(speed=.8))], [(0, CALM)], HUB, pack=STREET, contact=0,
                      halo=HALO_NIGHT, talk=[(0.0, 99.0)], mouths=TALK_MOUTHS)],
    ))
    sfx += [(knocks, "knock", .34), (cue("дриллерам"), "drill", .3), (cue("катателям"), "balls", .4), (cue("скандалистам"), "knock", .24)]

    t8 = cue("Времена тогда")
    shots.append(dict(
        id="room_week", start=t7, bg="B03", **{"in": dict(type="black", length=.8)},
        camera={"from": (.50, .52, 1.02), "to": (.54, .54, 1.12)},
        lights=room_lamp, grade=dict(exposure=.94, saturation=.94, vignette=.45),
        actors=[actor(SEATED, [(0.0, "sit_bed", dict())], [(0, TIRED)], WARM_ROOM,
                      flip=True, offsets=EASED_ARM, contact=.35, halo=HALO_WARM)],
    ))

    t9 = cue("Первый раз я понял")
    shots.append(dict(
        id="room_laptop", start=t8, bg="B03", **{"in": dict(type="cross", length=.6)},
        camera={"from": (.74, .57, 1.68), "to": (.70, .56, 1.54)},
        lights=[dict(x=.86, y=.69, r=.12, color=rgb(.75, .85, 1.0), amount=.24, flicker=dict(speed=5, depth=.18))] + room_lamp,
        grade=dict(exposure=.86, saturation=.9, vignette=.58, blur=1.0),
        actors=[actor(SEATED, [(0.0, "sit_bed", dict())], [(0, CALM)], WARM_ROOM,
                      flip=True, offsets=EASED_ARM, contact=.35, halo=HALO_WARM)],
    ))

    # ------------------------------------------------------------------ paragraph 3
    t10 = cue("проснулся посреди")
    t11 = cue("Сооружая")
    phone_glow = [dict(x=.625, y=.59, r=.075, color=rgb(.7, .92, 1.0), amount=.16, flicker=dict(speed=2, depth=.1))]
    blanket = [dict(polygon=[(.635, .665), (.665, .652), (.705, .665), (.745, .69), (.775, .735), (.745, .79), (.62, .735)],
                    feather=7.0, shift=(.0, -.052)),
               dict(polygon=[(.60, .66), (.79, .70), (.79, .80), (.585, .75)], feather=10.0),
               # The heap of clothes at the foot of the bed hides his shoes.
               dict(polygon=[(.738, .595), (.80, .585), (.805, .69), (.742, .70)], feather=6.0)]
    shots.append(dict(
        id="night_wake", start=t9, bg="B04", **{"in": dict(type="black", length=1.1)},
        camera={"from": (.64, .60, 1.72), "to": (.64, .60, 1.95)},
        lights=phone_glow, occluders=blanket,
        grade=dict(exposure=1.16, saturation=.8, vignette=.6, tint=rgb(.92, .98, 1.12), grain=.024),
        actors=[actor(BED, [(0.0, "lie_down", dict())],
                      [(0, ASLEEP), (t10 - t9 + .35, UNEASY)], BLUE_NIGHT, contact=0,
                      halo=dict(color=rgb(.5, .7, 1.0), amount=.08, radius=8.0))],
    ))

    t12 = cue("я заметил")
    shots.append(dict(
        id="sandwich", start=t11, bg="B06", **{"in": dict(type="cross", length=.7)},
        camera={"from": (.42, .62, 1.3), "to": (.46, .60, 1.48), "ease": "linear"},
        flicker=dict(speed=8, depth=.05),
        grade=dict(exposure=.98, saturation=.95, vignette=.6, tint=rgb(1.04, .98, .94)),
    ))
    sfx += [(t11 - 1.2, "fridge_open", .5), (t11 + .4, "knife", .32), (t11 + 2.6, "knife", .28)]

    t13 = cue("Двое о чём-то")
    t14 = cue("Голоса эти звучали")
    fridge_lights = [dict(x=.21, y=.40, r=.26, color=rgb(1.0, .82, .55), amount=.2, flicker=dict(speed=10, depth=.16))]
    kitchen_cast = dict(scale=(1.25, .92), skew=-.1, x=.07, y=-.02, blur=11.0, opacity=.5)
    shots.append(dict(
        id="kitchen", start=t12, bg="B05", **{"in": dict(type="cross", length=.5)},
        camera={"keys": [(0.0, (.54, .52, 1.04)), (t13 - t12 + 2.0, (.58, .50, 1.2)), (t14 - t12, (.60, .46, 1.34))]},
        flicker=dict(speed=10, depth=.06), lights=fridge_lights,
        dust=dict(count=40, amount=.05, color=rgb(1.0, .9, .72)),
        grade=dict(exposure=.98, saturation=.92, vignette=.6),
        grade_track={"saturation": [(0.0, .92), (t14 - t12, .6)]},
        actors=[actor([(0.0, .70, .975, .84)],
                      [(0.0, "idle", dict()), (t12 - t12 + .9, "freeze", dict())],
                      [(0, CALM), (.9, UNEASY), (t13 - t12 + 2.5, (1, 331))], FRIDGE, flip=True,
                      offsets=eased_from(.9), contact=.55, halo=dict(color=rgb(1.0, .8, .55), amount=.1, radius=12.0),
                      cast=kitchen_cast)],
    ))
    sfx.append((t12 + 1.0, "fridge_hum_off", .5))

    t15 = cue("Однако я быстро")
    stinger = cue("стало жутко")
    shots.append(dict(
        id="face", start=t14, bg="B05", **{"in": dict(type="cut")},
        camera={"from": (.69, .335, 2.05), "to": (.69, .325, 2.5), "ease": "linear", "handheld": 2.4},
        flicker=dict(speed=10, depth=.08, drops=[(stinger - t14, .16, .3)]),
        shake=[(stinger - t14, .35, .5)],
        grade=dict(exposure=1.0, saturation=.4, vignette=.82, blur=3.0, aberration=.0016, grain=.024, contrast=1.1),
        grade_track={"bw": [(0.0, 0.0), (stinger - t14, .85)], "aberration": [(0.0, .0012), (stinger - t14, .0034)]},
        actors=[actor([(0.0, .70, .975, .84)], [(0.0, "freeze", dict())], [(0, SCARED)], FRIDGE, flip=True,
                      offsets=EASED_BOTH, contact=0, blink=False,
                      halo=dict(color=rgb(1.0, .8, .55), amount=.08, radius=12.0))],
    ))
    sfx.append((stinger, "hit", .8))

    t16 = cue("Взглянув на время")
    shots.append(dict(
        id="kitchen_annoyed", start=t15, bg="B05", **{"in": dict(type="flash", length=.2)},
        camera={"from": (.60, .48, 1.3), "to": (.62, .48, 1.2)},
        flicker=dict(speed=10, depth=.05), lights=fridge_lights,
        grade=dict(exposure=1.0, saturation=.94, vignette=.55),
        actors=[actor([(0.0, .70, .975, .84)],
                      [(0.0, "idle", dict()), (1.0, "shake_head", dict(speed=.8))],
                      [(0, (172, 331)), (1.0, ANNOYED)], FRIDGE, flip=True, offsets=eased_from(1.0), contact=.55,
                      halo=dict(color=rgb(1.0, .8, .55), amount=.1, radius=12.0), cast=kitchen_cast,
                      talk=[(cue("Опять") - t15, cue_end("мультики") - t15)], mouths=TALK_MOUTHS)],
    ))

    # ------------------------------------------------------------------ paragraph 4
    t17 = cue("Видимо")
    shots.append(dict(
        id="clock", start=t16, bg="B07", **{"in": dict(type="cross", length=.4)},
        camera={"from": (.53, .60, 1.25), "to": (.51, .62, 1.62), "ease": "linear"},
        lights=[dict(x=.5, y=.62, r=.16, color=rgb(.8, .9, 1.0), amount=.14, flicker=dict(speed=2, depth=.1))],
        grade=dict(exposure=.98, saturation=.9, vignette=.62),
    ))
    sfx += [(t16 + i * 1.0, "tick", .34) for i in range(int(t17 - t16))]

    t18 = cue("Разве нормальные")
    shots.append(dict(
        id="kitchen_think", start=t17, bg="B05", **{"in": dict(type="cross", length=.5)},
        camera={"from": (.60, .50, 1.22), "to": (.56, .50, 1.1)},
        flicker=dict(speed=10, depth=.05), lights=fridge_lights,
        grade=dict(exposure=.96, saturation=.88, vignette=.58),
        actors=[actor([(0.0, .70, .975, .84)], [(0.0, "thinking", dict(speed=.6))], [(0, (172, 331))], FRIDGE, flip=True,
                      contact=.55, halo=dict(color=rgb(1.0, .8, .55), amount=.1, radius=12.0), cast=kitchen_cast)],
    ))

    t19 = cue("С этими мыслями")
    shots.append(dict(
        id="wall_parents", start=t18, bg="B08", **{"in": dict(type="cross", length=.7)},
        camera={"from": (.50, .50, 1.3), "to": (.48, .50, 1.05), "ease": "linear"},
        flicker=dict(speed=7, depth=.2),
        lights=[dict(x=.5, y=.42, r=.42, color=rgb(.55, .68, 1.0), amount=.14, flicker=dict(speed=11, depth=.6))],
        grade=dict(exposure=.9, saturation=.7, vignette=.78, contrast=1.1),
    ))

    pilot_end = max(w["end"] for w in words.words if w.get("paragraph", 1) <= 4) + OFFSET
    full = any(w.get("paragraph", 1) > 4 for w in words.words)
    shots.append(dict(
        id="sleep", start=t19, bg="B04", **{"in": dict(type="black", length=.9)},
        camera={"from": (.64, .60, 1.95), "to": (.62, .58, 1.5)},
        lights=phone_glow, occluders=blanket, fade_out=2.6,
        grade=dict(exposure=1.14, saturation=.76, vignette=.66, tint=rgb(.92, .98, 1.12), grain=.024),
        actors=[actor(BED, [(0.0, "lie_down", dict())],
                      [(0, CALM), (pilot_end - t19 - 3.0, ASLEEP)], BLUE_NIGHT, contact=0,
                      halo=dict(color=rgb(.5, .7, 1.0), amount=.08, radius=8.0))],
    ))

    # The wall: voices run from these moments, on top of the rest of the mix.
    voices = [(t5 - .3, t6 - .2, .55), (t13 - .6, t15 - .1, .8), (t18 - .4, t19 + 2.5, .42)]
    tense = [(t14, t15)]
    beds = [(0.0, t1, "wind", 1.0), (t1, t2, "room", .7), (t2, t5, "room", .4), (t6, t7, "wind", .8),
            (t11, t16 + 1.0, "fridge", .5), (t17, t18, "fridge", .5)]
    lines = list(VOICE_LINES)

    if full:
        # Paragraphs 5-77 live in story.py; it appends to the same lists.
        story.build(words, OFFSET, shots, sfx, voices, tense, beds, lines)
        tail_from = voice_end + 3.0
    else:
        tail_from = pilot_end + 3.0
    # After the fade the screen stays black and the voices are left alone with the viewer.
    shots.append(dict(id="black", start=tail_from, bg="B08", camera={"from": (.5, .5, 1.0)},
                      grade=dict(exposure=0.0, grain=0.0, bloom=0.0, vignette=0.0)))
    voices.append((tail_from - .8, duration - .2, .7))
    music = dict(first_note=1.2, tense=tense, end=duration - 1.0)
    return dict(shots=shots, duration=duration, voice_offset=OFFSET, sfx=sfx, voices=voices, music=music,
                beds=beds, voice_lines=lines)
