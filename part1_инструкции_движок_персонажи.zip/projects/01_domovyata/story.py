"""Paragraphs 5-77: from the nightly voices to moving out. See раскадровка_полная.md.

Every cut is found from the narration: P(n) is the first word of paragraph n, E(n) its last word,
at(n, "слова") the first time those words are said in paragraph n or later. Paragraph numbers are
the non-empty lines of история.txt, as tts.py counts them.
"""

# ---------------------------------------------------------------------------------- characters
R_HOME = "rasskazchik_home_v7"
R_STREET = "rasskazchik_street_v3"
GALINA = "galina_home_v3"
KOLLEGA = "kollega_office_v7"
STEPAN = "stepan_work_v1"
MARGO = "margarita_home_v5"

# Faces as (eyes, mouth). The numbers mean the same thing in every pack; "base" is the pack's own eyes.
CALM = ("base", 331)
TIRED = ("base", 277)
SMILE = (172, 277)
SMIRK = ("base", 276)
LAUGH = (58, 303)
LOOK = (172, 331)
SIDE = (115, 331)
UNEASY = (77, 331)
WORRIED = (1, 28)
SCARED = (1, 28)
SHOCK = (1, 248)
ANNOYED = (20, 331)
ASLEEP = (39, 331)
SAD = (153, 331)
TALK = (331, 358, 303, 221)


def rgb(r, g, b):
    return (b, g, r)


# ---------------------------------------------------------------------------------- light
WARM_ROOM = dict(ambient=rgb(.70, .65, .58), key=rgb(.26, .20, .11), dir=(1.0, -.25),
                 rim=dict(color=rgb(1.0, .78, .5), amount=.34, width=6.0))
BLUE_NIGHT = dict(ambient=rgb(.20, .25, .40), key=rgb(.16, .22, .38), dir=(1.0, -.5),
                  rim=dict(color=rgb(.5, .68, 1.0), amount=.42, width=7.0))
HUB = dict(ambient=rgb(.40, .44, .62), key=rgb(.50, .42, .30), dir=(1.0, -.35),
           rim=dict(color=rgb(1.0, .80, .55), amount=.5, width=8.0))
DARK_STAIR = dict(ambient=rgb(.22, .23, .27), key=rgb(.45, .45, .42), dir=(1.0, -.2),
                  rim=dict(color=rgb(.95, .97, 1.0), amount=.5, width=7.0))
MORNING = dict(ambient=rgb(.78, .74, .64), key=rgb(.34, .28, .16), dir=(-1.0, -.4),
               rim=dict(color=rgb(1.0, .9, .65), amount=.45, width=7.0))
DOORWAY = dict(ambient=rgb(.62, .56, .48), key=rgb(.38, .28, .14), dir=(1.0, -.2),
               rim=dict(color=rgb(1.0, .78, .45), amount=.6, width=8.0))
LANDING = dict(ambient=rgb(.42, .44, .48), key=rgb(.30, .24, .14), dir=(1.0, -.2),
               rim=dict(color=rgb(1.0, .82, .55), amount=.3, width=6.0))
OFFICE = dict(ambient=rgb(.66, .66, .64), key=rgb(.22, .22, .24), dir=(.3, -1.0),
              rim=dict(color=rgb(.85, .9, 1.0), amount=.3, width=6.0))
OVERCAST = dict(ambient=rgb(.66, .68, .72), key=rgb(.18, .18, .20), dir=(.2, -1.0),
                rim=dict(color=rgb(.9, .92, 1.0), amount=.2, width=5.0))
STAIR = dict(ambient=rgb(.70, .70, .62), key=rgb(.30, .27, .18), dir=(.2, -1.0),
             rim=dict(color=rgb(1.0, .92, .72), amount=.3, width=6.0))
BULB = dict(ambient=rgb(.50, .44, .34), key=rgb(.40, .30, .14), dir=(0.0, -1.0),
            rim=dict(color=rgb(1.0, .80, .45), amount=.45, width=7.0))
FLASHLIGHT = dict(ambient=rgb(.30, .30, .30), key=rgb(.55, .55, .52), dir=(-1.0, -.1),
                  rim=dict(color=rgb(.95, .97, 1.0), amount=.55, width=8.0))
LAMPLIGHT = dict(ambient=rgb(.72, .62, .48), key=rgb(.34, .24, .10), dir=(-1.0, -.4),
                 rim=dict(color=rgb(1.0, .80, .5), amount=.4, width=7.0))
GREY_DAY = dict(ambient=rgb(.66, .66, .68), key=rgb(.20, .20, .22), dir=(1.0, -.3),
                rim=dict(color=rgb(.9, .92, 1.0), amount=.22, width=5.0))

HALO_NIGHT = dict(color=rgb(.55, .68, 1.0), amount=.16, radius=14.0)
HALO_WARM = dict(color=rgb(1.0, .85, .65), amount=.12, radius=13.0)
HALO_COLD = dict(color=rgb(.8, .85, 1.0), amount=.08, radius=10.0)

# Grades
NIGHT = dict(exposure=1.14, saturation=.78, vignette=.64, tint=rgb(.92, .98, 1.12), grain=.024)
WALL = dict(exposure=.94, saturation=.75, vignette=.74, contrast=1.08)
FLASHBACK = dict(exposure=1.02, saturation=.45, tint=rgb(1.10, 1.0, .82), vignette=.7, blur=1.4, grain=.04, bloom=.5)
BASEMENT = dict(exposure=.95, saturation=.8, vignette=.7, contrast=1.08, grain=.03)

# Places
HUB_SPOT = [(0.0, .225, 1.26, 1.12)]
HUB_CAM = {"from": (.27, .46, 1.24), "to": (.30, .44, 1.32)}
HUB_LIGHT = [dict(x=.62, y=.365, r=.05, color=rgb(.9, .95, 1.0), amount=.34, flicker=dict(speed=5, depth=.25)),
             dict(x=.91, y=.455, r=.09, color=rgb(1.0, .75, .4), amount=.12, flicker=dict(speed=.8, depth=.5))]
BED = [(0.0, .688, .685, .34)]
BED_CAM_CLOSE = (.605, .545, 3.0)   # his face on the pillow
PHONE_GLOW = [dict(x=.625, y=.59, r=.075, color=rgb(.7, .92, 1.0), amount=.16, flicker=dict(speed=2, depth=.1))]
BLANKET = [dict(polygon=[(.635, .665), (.665, .652), (.705, .665), (.745, .69), (.775, .735), (.745, .79), (.62, .735)],
                feather=7.0, shift=(.0, -.052)),
           dict(polygon=[(.60, .66), (.79, .70), (.79, .80), (.585, .75)], feather=10.0),
           dict(polygon=[(.738, .595), (.80, .585), (.805, .69), (.742, .70)], feather=6.0)]
# Pulled over the head: the blanket polygon raised to cover the face too.
BLANKET_HEAD = [dict(polygon=[(.60, .64), (.66, .61), (.72, .63), (.79, .70), (.79, .80), (.585, .75)],
                     feather=9.0, shift=(.0, -.07))] + BLANKET[1:]
ROOM_LAMP = [dict(x=.915, y=.565, r=.13, color=rgb(1.0, .78, .42), amount=.28, flicker=dict(speed=3, depth=.08))]
SEATED = [(0.0, .685, .780, .54)]
WALL_GLOW = [dict(x=.5, y=.42, r=.42, color=rgb(.55, .68, 1.0), amount=.15, flicker=dict(speed=11, depth=.55))]
BEAM = [dict(x=.53, y=.30, r=.30, color=rgb(.95, .97, 1.0), amount=.12, flicker=dict(speed=6, depth=.12))]

# Colours of the creatures' lines on screen.
INK = dict(mickey=rgb(.95, .86, .55), bass=rgb(.62, .70, .90), crow=rgb(.92, .38, .30),
           monkey=rgb(.70, .90, .78), falsetto=rgb(.96, .78, .88), song=rgb(.86, .82, .72))

# More lines for the loop behind the wall, from the story itself.
NASAL = ("ru-RU-DmitryNeural", "+30Hz", "-10%", 1.28)
SHRILL = ("ru-RU-SvetlanaNeural", "+60Hz", "+5%", 1.42)
DEEP = ("ru-RU-DmitryNeural", "-40Hz", "-25%", .78)
CROAK = ("ru-RU-SvetlanaNeural", "-20Hz", "+10%", 1.12)
EXTRA_LINES = [
    ("Бей, бей! Прям по башке!", *SHRILL),
    ("Больно. Не могу больше. Нету сил моих.", *DEEP),
    ("Ржавое! Ржаво-красная ржавчина! Всё равно красная!", *CROAK),
    ("Сейчас выверну тебя наизнанку. Хочешь, выверну?", *NASAL),
    ("Ржавая ржавчина пахнет как мясо, чёрная-чёрная толстая дверь.", *SHRILL),
    ("Бом-бом-бом, любимый ржавый дом. Нет-нет-нет, не видим белый свет.", *DEEP),
]


def act(pack, path, clips, face=(), light=WARM_ROOM, **extra):
    """One character in a shot. path: (t, x, y, height) keys; clips: (t, anim, options)."""
    spec = dict(pack=pack, path=[(key[0], key[1:]) for key in path],
                clips=[dict(t=t, anim=a, **o) for t, a, o in clips], face=list(face), light=light,
                seed=len(clips) * 5 + len(pack))
    spec.update(extra)
    return spec


def wrap(text, width=30):
    lines, line = [], ""
    for word in text.split():
        if line and len(line) + 1 + len(word) > width:
            lines.append(line)
            line = word
        else:
            line = (line + " " + word).strip()
    return lines + [line] if line else lines


def story_text():
    """Paragraphs of история.txt without stress marks, numbered like tts.py numbers them."""
    import unicodedata
    from pathlib import Path

    raw = (Path(__file__).resolve().parent.parent.parent / "история.txt").read_text(encoding="utf-8")
    plain = unicodedata.normalize("NFC", "".join(c for c in unicodedata.normalize("NFD", raw) if c != "\u0301"))
    return {n: line.strip() for n, line in enumerate((l for l in plain.splitlines() if l.strip()), 1)}


def spoken(paragraph):
    """The creature's own words: «— Бей-бей! — прикрикивал голосок» -> «Бей-бей!»."""
    parts = paragraph.strip().lstrip("—– ").split(" — ")
    keep = [parts[0]]
    for part in parts[1:]:
        if keep[-1][-1:] in "!?.…," and part[:1].islower():
            break
        keep.append(part)
    return " — ".join(keep).strip("«» ")


def build(words, offset, shots, sfx, voices, tense, beds, lines):
    text_of = story_text()
    index = {}
    for w in words.words:
        index.setdefault(w.get("paragraph", 1), []).append(w)

    def P(n):
        return index[n][0]["start"] + offset

    def E(n):
        return index[n][-1]["end"] + offset

    def at(n, phrase):
        return words.start(phrase, index[n][0]["start"] - .01) + offset

    def end_at(n, phrase):
        return words.end(phrase, index[n][0]["start"] - .01) + offset

    def shot(id, start, bg, camera, cut=("cross", .6), **extra):
        spec = dict(id=id, start=start, bg=bg, camera=camera, **{"in": dict(type=cut[0], length=cut[1])})
        spec.update(extra)
        shots.append(spec)
        return spec

    def quote(text, t, length, color, y=.5, size=56, jitter=2.2):
        """A creature's line as shaking text, one item per line of the wrap."""
        rows = wrap(text)
        step = size * 1.25 / 1080.0
        top = y - step * (len(rows) - 1) / 2
        return [dict(text=row, t=t, length=length, size=size, y=top + i * step, jitter=jitter, fade=.35,
                     color=color, font="C:/Windows/Fonts/georgiai.ttf") for i, row in enumerate(rows)]

    def say(start, a, b):
        """A talk window, local to a shot that begins at start."""
        return [(a - start, b - start)]

    def hub(id, start, face, talk=None, cut=("black", .8)):
        extra = dict(talk=say(start, *talk), mouths=TALK) if talk else {}
        return shot(id, start, "B00", HUB_CAM, cut, lights=HUB_LIGHT,
                    dust=dict(count=46, amount=.07, color=rgb(.75, .85, 1.0)),
                    grade=dict(exposure=1.08, tint=rgb(.94, .97, 1.08), saturation=.88, vignette=.6, bloom=.4),
                    actors=[act(R_STREET, HUB_SPOT, [(0.0, "idle", dict(speed=.8))], face, HUB, contact=0,
                                halo=HALO_NIGHT, **extra)])

    def wall(id, start, camera, cut=("cross", .6), **extra):
        extra.setdefault("grade", WALL)
        return shot(id, start, "B08", camera, cut, flicker=dict(speed=7, depth=.16), lights=WALL_GLOW, **extra)

    def bed(id, start, camera, face, clips=None, cut=("cross", .6), head=False, **extra):
        extra.setdefault("lights", PHONE_GLOW)
        extra.setdefault("grade", NIGHT)
        return shot(id, start, "B04", camera, cut, occluders=BLANKET_HEAD if head else BLANKET,
                    actors=[act(R_HOME, BED, clips or [(0.0, "lie_down", dict())], face, BLUE_NIGHT,
                                             contact=0, halo=dict(color=rgb(.5, .7, 1.0), amount=.08, radius=8.0))],
                    **extra)

    # ============================================================== A. every night (5-18)
    a_mid = at(5, "Потом")
    a_police = at(5, "Однажды")
    bed("a_nights", P(5), {"from": (.62, .60, 1.6), "to": (.64, .60, 1.85)}, [(0, UNEASY)], cut=("black", 1.0))
    bed("a_teeth", a_mid, {"from": BED_CAM_CLOSE, "to": (.605, .54, 3.4), "ease": "linear"},
        [(0, ANNOYED)], shake=[(1.2, .2, .4)])
    hub("a_police", a_police, [(0, CALM), (at(5, "стыдной") - a_police - 1.5, SMIRK)], talk=(a_police, E(5)))
    voices += [(P(5) - .5, a_police, .5)]
    beds.append((P(5), a_police, "room", .4))

    wall("a_others", P(6), {"from": (.5, .5, 1.05), "to": (.52, .52, 1.3), "ease": "linear"})
    voices.append((P(6), P(7) - .2, .7))

    creatures = [(7, "mickey", (.5, .48, 1.2), (.46, .46, 1.35)), (8, "bass", (.42, .55, 1.3), (.44, .56, 1.15)),
                 (10, "crow", (.6, .5, 1.25), (.58, .47, 1.45)), (11, "monkey", (.5, .55, 1.4), (.5, .5, 1.2))]
    for n, who, a, b in creatures:
        wall("a_line_%d" % n, P(n), {"from": a, "to": b, "ease": "linear"}, cut=("cut", 0),
             text=quote(spoken(text_of[n]), .25, E(n) - P(n) + .3, INK[who]),
             grade_track={"aberration": [(0.0, .0006), (E(n) - P(n), .0024)]})
        sfx.append((P(n) + .05, "whoosh", .18))
    bed("a_cruel", P(9), {"from": (.64, .60, 1.7), "to": (.64, .59, 1.95)}, [(0, UNEASY)],
        clips=[(0.0, "lie_down", dict())], cut=("cross", .5))
    voices.append((P(9), E(9), .5))

    shot("a_door_flash", at(12, "огромной"), "B17", {"from": (.5, .5, 1.1), "to": (.5, .52, 1.25)}, ("flash", .2),
         grade=dict(BASEMENT, exposure=.8), flicker=dict(speed=12, depth=.3))
    shot("a_themes", P(12), "B08", {"from": (.5, .5, 1.0), "to": (.5, .5, 1.15)}, ("cross", .5),
         grade=WALL, lights=WALL_GLOW, flicker=dict(speed=7, depth=.16))
    shots.sort(key=lambda s: s["start"])  # a_themes starts before the flash it contains
    sfx.append((at(12, "огромной"), "hit", .45))
    wall("a_after_door", E(12) - .1, {"from": (.5, .5, 1.15), "to": (.5, .5, 1.25)}, cut=("cross", .4))

    a_sang = at(13, "Не высыпаясь")
    a_wrong = at(13, "Когда я впервые")
    bed("a_singing", P(13), {"from": (.62, .60, 1.55), "to": (.64, .60, 1.8)}, [(0, TIRED)], cut=("cross", .7))
    hub("a_late", a_sang, [(0, TIRED)], cut=("cross", .6))
    bed("a_wrong", a_wrong, {"from": BED_CAM_CLOSE, "to": (.605, .54, 3.9), "ease": "linear"}, [(0, SCARED)],
        grade_track={"bw": [(0.0, 0.0), (E(13) - a_wrong, .6)]})
    voices.append((P(13), a_sang, .55))

    # The song, line by line, on the wall; the door comes back on «толстая дверь».
    song_cams = [((.5, .5, 1.1), (.5, .5, 1.3)), ((.5, .52, 1.2), (.5, .52, 1.45)),
                 ((.48, .5, 1.3), (.52, .5, 1.5)), ((.5, .5, 1.5), (.5, .5, 1.9))]
    for i, n in enumerate(range(14, 18)):
        text = text_of[n].strip("«»,! ")
        bg = "B17" if n == 15 else "B08"
        shot("a_song_%d" % n, P(n) - .15, bg, {"from": song_cams[i][0], "to": song_cams[i][1], "ease": "linear"},
             ("cross", .35), grade=BASEMENT if bg == "B17" else WALL, lights=WALL_GLOW if bg == "B08" else [],
             flicker=dict(speed=9, depth=.2), text=quote(text, .15, E(n) - P(n) + .5, INK["song"], size=60),
             grade_track={"aberration": [(0.0, .001), (E(n) - P(n), .0035)]})
    voices.append((P(14) - .3, E(17) + .5, .75))

    a_think = at(18, "Чувства")
    shot("a_decide", P(18), "B03", {"from": (.40, .52, 1.12), "to": (.36, .54, 1.25)}, ("black", .9),
         lights=ROOM_LAMP, grade=dict(exposure=.9, saturation=.9, vignette=.5),
         actors=[act(R_HOME, [(0.0, .33, .94, .68)],
                     [(0.0, "arms_crossed", dict()), (a_think - P(18), "thinking", dict(speed=.6))],
                     [(0, ANNOYED), (a_think - P(18), SIDE)], WARM_ROOM, contact=.55, halo=HALO_WARM,
                     cast=dict(scale=(1.0, .55), skew=.9, y=-.012, blur=8.0, opacity=.3))])
    beds.append((P(18), E(18), "room", .4))

    # ============================================================== B. checks (19-23)
    b_none = at(19, "Никаких")
    shot("b_search", P(19), "B09", {"from": (.55, .40, 1.1), "to": (.58, .38, 1.4), "ease": "linear"}, ("cross", .6),
         grade=dict(exposure=.95, saturation=.9, vignette=.6),
         lights=[dict(x=.6, y=.35, r=.25, color=rgb(.75, .85, 1.0), amount=.12, flicker=dict(speed=5, depth=.15))])
    shot("b_nothing", b_none, "B03", {"from": (.74, .57, 1.68), "to": (.70, .56, 1.54)}, ("cross", .5),
         lights=[dict(x=.86, y=.69, r=.12, color=rgb(.75, .85, 1.0), amount=.24, flicker=dict(speed=5, depth=.18))] + ROOM_LAMP,
         grade=dict(exposure=.84, saturation=.88, vignette=.6),
         actors=[act(R_HOME, SEATED, [(0.0, "sit_bed", dict())], [(0, LOOK), (1.2, ANNOYED)], WARM_ROOM,
                     flip=True, contact=.35, halo=HALO_WARM)])

    b_morning = at(20, "Наутро")
    b_relief = at(20, "Я прочитал")
    bed("b_record", P(20), {"from": (.63, .59, 1.7), "to": (.64, .58, 2.0)}, [(0, UNEASY)], cut=("black", .7),
        lights=[dict(x=.625, y=.59, r=.11, color=rgb(.7, .92, 1.0), amount=.3, flicker=dict(speed=2, depth=.1))])
    voices.append((P(20) + .5, b_morning, .8))
    k_spot, r_spot = [(0.0, .74, .99, .80)], [(0.0, .30, .99, .80)]
    smoke = dict(count=70, amount=.05, color=rgb(.85, .85, .85))
    shot("b_office", b_morning, "B10", {"from": (.52, .52, 1.08), "to": (.52, .54, 1.15)}, ("cross", .7),
         grade=dict(exposure=.98, saturation=.84, vignette=.45), dust=smoke,
         actors=[act(KOLLEGA, k_spot, [(0.0, "laugh", dict(speed=.8)), (3.5, "idle", dict())],
                     [(0, LAUGH), (3.5, SMILE)], OFFICE, flip=True, contact=.5, halo=HALO_COLD),
                 act(R_STREET, r_spot, [(0.0, "idle", dict())], [(0, TIRED)], OFFICE, contact=.5, halo=HALO_COLD)])
    shot("b_relief", b_relief, "B10", {"from": (.32, .50, 1.6), "to": (.32, .50, 1.75)}, ("cross", .4),
         grade=dict(exposure=1.0, saturation=.86, vignette=.5), dust=smoke,
         actors=[act(R_STREET, r_spot, [(0.0, "sigh", dict(speed=.8))], [(0, TIRED), (1.0, SMILE)], OFFICE,
                     contact=.5, halo=HALO_COLD)])
    beds.append((b_morning, P(21), "room", .5))

    b_left = at(21, "Слева")
    b_right = at(21, "Справа")
    b_but = at(21, "Однако")
    wall("b_mug", P(21), {"from": (.5, .5, 1.0), "to": (.5, .5, 1.15)}, cut=("black", .8))
    wall("b_left", b_left, {"from": (.35, .5, 1.4), "to": (.30, .5, 1.45)}, cut=("cut", 0))
    wall("b_right", b_right, {"from": (.65, .5, 1.4), "to": (.70, .5, 1.45)}, cut=("cut", 0))
    sfx.append((b_right + .4, "snore", .22))
    wall("b_wait", b_but, {"from": (.55, .5, 1.3), "to": (.5, .5, 1.6), "ease": "linear"}, cut=("cross", .4),
         grade_track={"exposure": [(0.0, .94), (E(21) - b_but, .8)]})
    teeth = spoken(text_of[22])
    wall("b_teeth", P(22), {"from": (.5, .5, 1.6), "to": (.5, .5, 1.75), "handheld": 2.4}, cut=("flash", .15),
         shake=[(0.0, .4, .5)], text=quote(teeth, .1, E(22) - P(22) + .6, INK["falsetto"]),
         grade=dict(WALL, aberration=.003, bw=.4))
    sfx.append((P(22), "hit", .6))
    tense.append((P(22) - 3.0, P(22)))
    voices.append((b_but, E(22) + .5, .6))

    up = at(23, "в квартире сверху")
    shot("b_up", P(23), "B04", {"from": (.55, .62, 1.2), "to": (.55, .40, 1.3)}, ("cross", .6),
         grade=NIGHT, actors=[act(R_HOME, [(0.0, .40, .97, .62)], [(0.0, "look_around", dict(speed=.6))],
                                  [(0, UNEASY), (up - P(23), LOOK)], BLUE_NIGHT, contact=.4,
                                  halo=dict(color=rgb(.5, .7, 1.0), amount=.1, radius=9.0))])

    # ============================================================== C. the black door (24-26)
    c_want = at(24, "Мне хотелось")
    c_tv = at(24, "Хотелось нагло")
    c_bell = at(25, "Я видел")
    c_figures = at(25, "Стоя в")
    c_home = at(25, "Я развернулся")
    c_blanket = at(25, "залез в кровать")
    flash_beam = [dict(x=.52, y=.30, r=.32, color=rgb(.95, .97, 1.0), amount=.1, flicker=dict(speed=8, depth=.18))]
    r_landing = [(0.0, .20, 1.02, .86)]
    shot("c_landing", P(24), "B11", {"from": (.45, .48, 1.08), "to": (.45, .46, 1.18)}, ("black", 1.0),
         lights=flash_beam, grade=dict(exposure=.95, saturation=.8, vignette=.7, grain=.03),
         actors=[act(R_HOME, r_landing, [(0.0, "look_around", dict(speed=.5))], [(0, UNEASY)], DARK_STAIR,
                     contact=.3, halo=HALO_COLD)])
    beds.append((P(24), c_figures, "wind", .25))
    shot("c_anger", c_want, "B11", {"from": (.32, .45, 1.45), "to": (.30, .44, 1.6), "handheld": 1.8}, ("cross", .4),
         lights=flash_beam, grade=dict(exposure=.95, saturation=.7, vignette=.75, contrast=1.1),
         shake=[(1.0, .25, .3), (2.2, .25, .3), (c_tv - c_want + 1.5, .4, .5)],
         actors=[act(R_HOME, r_landing, [(0.0, "punch", dict(speed=.9)), (c_tv - c_want, "punch", dict(speed=1.1))],
                     [(0, ANNOYED), (c_tv - c_want, SHOCK)], DARK_STAIR, contact=.3, halo=HALO_COLD)])
    sfx += [(c_want + 1.0, "knock", .5), (c_want + 2.2, "knock", .55)]
    shot("c_bell", c_bell, "B11", {"from": (.45, .45, 1.2), "to": (.62, .34, 2.2), "ease": "linear"}, ("cross", .6),
         lights=flash_beam, grade=dict(exposure=.92, saturation=.75, vignette=.75),
         actors=[act(R_HOME, r_landing, [(0.0, "freeze", dict())], [(0, UNEASY)], DARK_STAIR, contact=.3,
                     halo=HALO_COLD)])
    shot("c_figures", c_figures, "B23", {"from": (.5, .5, 1.05), "to": (.55, .55, 1.5), "ease": "linear"}, ("black", 1.2),
         grade=dict(exposure=.9, saturation=.6, vignette=.8, grain=.04, contrast=1.1),
         flicker=dict(speed=3, depth=.12),
         lights=[dict(x=.52, y=.55, r=.06, color=rgb(1.0, .95, .7), amount=.25, flicker=dict(speed=13, depth=.8))])
    voices.append((c_figures + 1.5, c_home, .35))
    tense.append((c_figures, c_home))
    shot("c_retreat", c_home, "B11", {"from": (.40, .48, 1.15), "to": (.38, .48, 1.05)}, ("flash", .2),
         lights=flash_beam, grade=dict(exposure=.95, saturation=.8, vignette=.7),
         actors=[act(R_HOME, [(0.0, .22, 1.02, .86), (3.0, .05, 1.04, .9)], [(0.0, "back_away", dict(speed=.8))],
                     [(0, SCARED)], DARK_STAIR, contact=.3, halo=HALO_COLD,
                     fade=[(2.0, 1.0), (3.0, 0.0)])])
    bed("c_blanket", c_blanket, {"from": (.64, .60, 1.7), "to": (.64, .62, 1.5)}, [(0, ASLEEP)], cut=("cross", .6),
        head=True, fade_out=1.5)

    c_door = at(26, "В свете")
    c_ring = at(26, "я позвонил")
    sunny = dict(exposure=1.12, saturation=1.02, vignette=.35, tint=rgb(1.06, 1.02, .94), bloom=.5)
    shot("c_sunday", P(26), "B03", {"from": (.40, .52, 1.08), "to": (.44, .52, 1.16)}, ("black", 1.2),
         grade=sunny, actors=[act(R_HOME, [(0.0, .33, .94, .68)],
                                  [(0.0, "idle", dict(speed=.8)), (2.5, "sigh", dict(speed=.8)), (5.0, "idle", dict())],
                                  [(0, TIRED), (2.0, CALM)], MORNING, contact=.55, halo=HALO_WARM,
                                  cast=dict(scale=(1.0, .55), skew=.9, y=-.012, blur=8.0, opacity=.3))])
    beds.append((P(26), P(28), "day", .9))
    r_green = [(0.0, .28, 1.0, .82)]
    shot("c_green", c_door, "B12", {"from": (.50, .48, 1.1), "to": (.48, .48, 1.2)}, ("cross", .7),
         grade=dict(exposure=1.04, saturation=.96, vignette=.4, bloom=.5), dust=dict(count=80, amount=.09, color=rgb(1.0, .92, .7)),
         actors=[act(R_STREET, r_green, [(0.0, "idle", dict()), (c_ring - c_door - .4, "reach_hand", dict(speed=.8)),
                                         (c_ring - c_door + 1.5, "idle", dict())],
                     [(0, CALM), (c_ring - c_door, UNEASY)], MORNING, contact=.5, halo=HALO_WARM)])
    sfx.append((c_ring + .3, "doorbell", .55))

    # ============================================================== D. the neighbour (27-43)
    sfx.append((at(27, "мягко сказал") - 1.2, "footsteps_up", .25))
    shot("d_wait", P(27), "B12", {"from": (.48, .48, 1.2), "to": (.52, .46, 1.35), "ease": "linear"}, ("cut", 0),
         grade=dict(exposure=1.04, saturation=.96, vignette=.42, bloom=.5), dust=dict(count=80, amount=.09, color=rgb(1.0, .92, .7)),
         actors=[act(R_STREET, r_green, [(0.0, "idle", dict())], [(0, UNEASY)], MORNING, contact=.5, halo=HALO_WARM)])

    g_spot = [(0.0, .615, .975, .66)]
    r_door = [(0.0, .22, 1.04, .92)]
    wide = {"from": (.45, .52, 1.05), "to": (.45, .52, 1.1)}
    g_close = {"from": (.60, .50, 1.9), "to": (.60, .50, 2.0)}
    r_close = {"from": (.27, .42, 1.8), "to": (.27, .42, 1.9)}
    door_glow = [dict(x=.6, y=.13, r=.12, color=rgb(1.0, .85, .55), amount=.25, flicker=dict(speed=2, depth=.05))]
    hall = dict(exposure=1.0, saturation=.92, vignette=.5)

    def doorstep(id, start, camera, g_face, r_face, g_clips=None, r_clips=None, g_talk=None, r_talk=None,
                 cut=("cut", 0), g_fade=None):
        g_extra = dict(talk=say(start, *g_talk), mouths=TALK) if g_talk else {}
        r_extra = dict(talk=say(start, *r_talk), mouths=TALK) if r_talk else {}
        if g_fade:
            g_extra["fade"] = g_fade
        return shot(id, start, "B13", camera, cut, lights=door_glow, grade=hall,
                    actors=[act(GALINA, g_spot, g_clips or [(0.0, "idle", dict())], g_face, DOORWAY, flip=True,
                                contact=.45, halo=HALO_WARM, **g_extra),
                            act(R_STREET, r_door, r_clips or [(0.0, "idle", dict())], r_face, LANDING,
                                contact=.4, halo=HALO_WARM, **r_extra)])

    sfx.append((P(28) - .2, "creak", .3))
    doorstep("d_open", P(28), wide, [(0, CALM)], [(0, UNEASY)], cut=("cross", .5),
             g_fade=[(0.0, 0.0), (1.0, 1.0)])
    doorstep("d_hello", P(29), wide, [(0, CALM)], [(0, SMILE)], r_clips=[(0.0, "wave", dict(speed=.9)), (2.0, "idle", dict())],
             r_talk=(P(29), end_at(29, "снизу")))
    doorstep("d_worry", P(30), g_close, [(0, WORRIED)], [(0, SMILE)])
    doorstep("d_flood", P(31), g_close, [(0, WORRIED)], [(0, SMILE)], g_talk=(P(31), end_at(31, "что ли")))
    doorstep("d_nono", P(32), r_close, [(0, WORRIED)], [(0, SMILE)],
             r_clips=[(0.0, "shake_head", dict(speed=1.1)), (1.6, "idle", dict())],
             r_talk=(P(32), at(32, "заверил")))
    d_ask = at(32, "Я просто")
    doorstep("d_ask", d_ask, r_close, [(0, WORRIED)], [(0, SMILE)], r_talk=(d_ask, E(32)))
    d_relief_said = at(33, "женщина")
    doorstep("d_relief", P(33), wide, [(0, LAUGH), (d_relief_said - P(33), SMILE)], [(0, SMILE)],
             g_clips=[(0.0, "laugh", dict(speed=.8)), (2.5, "idle", dict())],
             g_talk=(P(33), end_at(33, "богу")))
    d_ask2 = at(33, "Ну спрашивайте")
    doorstep("d_go_on", d_ask2, g_close, [(0, SMILE)], [(0, SMILE)], g_talk=(d_ask2, E(33)))
    doorstep("d_lost", P(34), r_close, [(0, SMILE)], [(0, SIDE)])
    doorstep("d_tv", P(35), wide, [(0, CALM)], [(0, UNEASY)], r_talk=(P(35), E(35)),
             r_clips=[(0.0, "shrug", dict(speed=.7)), (2.5, "idle", dict())])
    doorstep("d_frown", P(36), g_close, [(0, ANNOYED)], [(0, UNEASY)])
    doorstep("d_sleep", P(37), g_close, [(0, ANNOYED)], [(0, UNEASY)], g_talk=(P(37), E(37)))
    doorstep("d_music", P(38), r_close, [(0, ANNOYED)], [(0, UNEASY)], r_talk=(P(38), E(38)))
    doorstep("d_head", P(39), wide, [(0, CALM)], [(0, UNEASY)], g_clips=[(0.0, "shake_head", dict(speed=.8)), (2.4, "idle", dict())])
    g_teen = at(40, "Может")
    doorstep("d_notme", P(40), g_close, [(0, CALM), (g_teen - P(40), LOOK)], [(0, UNEASY)],
             g_talk=(P(40), E(40)))
    doorstep("d_normal", P(41), {"from": (.27, .42, 1.9), "to": (.27, .40, 2.3), "ease": "linear"}, [(0, CALM)], [(0, SIDE)],
             r_clips=[(0.0, "thinking", dict(speed=.5))], cut=("cross", .5))
    doorstep("d_bye", P(42), wide, [(0, SMILE)], [(0, SMILE)], r_clips=[(0.0, "nod", dict(speed=.9)), (1.8, "wave", dict(speed=.8)),
                                                                     (3.4, "idle", dict())],
             r_talk=(P(42), end_at(42, "шумели")))
    d_shut = at(43, "закрыла")
    doorstep("d_shrug", P(43), wide, [(0, CALM)], [(0, SMILE)], g_clips=[(0.0, "shrug", dict(speed=.8))],
             g_fade=[(d_shut - P(43), 1.0), (d_shut - P(43) + .6, 0.0)])
    sfx.append((d_shut + .3, "door_slam", .45))
    d_junkie = at(43, "Спускаясь")
    hub("d_junkie", d_junkie, [(0, SIDE), (at(43, "Теперь") - d_junkie, SMIRK)], talk=(at(43, "Теперь"), E(43)),
        cut=("cross", .6))

    # ============================================================== E. under the floor (44-53)
    e_used = at(44, "Жить")
    shot("e_calm", P(44), "B03", {"from": (.62, .57, 1.28), "to": (.64, .57, 1.38)}, ("cross", .8),
         lights=ROOM_LAMP, grade=dict(exposure=.92, saturation=.95, vignette=.45),
         actors=[act(R_HOME, SEATED, [(0.0, "sit_bed", dict())], [(0, CALM), (2.0, SMILE)], WARM_ROOM, flip=True,
                     contact=.35, halo=HALO_WARM)])
    hub("e_used", e_used, [(0, SMIRK)], talk=(e_used, E(44)), cut=("cross", .6))
    beds.append((P(44), e_used, "room", .4))

    k_close = {"from": (.70, .42, 1.8), "to": (.70, .42, 1.88)}
    r_close2 = {"from": (.34, .42, 1.8), "to": (.34, .42, 1.88)}
    two = {"from": (.52, .52, 1.08), "to": (.52, .53, 1.14)}

    def smoking(id, start, camera, k_face, r_face, k_talk=None, r_talk=None, k_clips=None, r_clips=None, cut=("cut", 0)):
        k_extra = dict(talk=say(start, *k_talk), mouths=TALK) if k_talk else {}
        r_extra = dict(talk=say(start, *r_talk), mouths=TALK) if r_talk else {}
        return shot(id, start, "B10", camera, cut, dust=smoke, grade=dict(exposure=.98, saturation=.84, vignette=.45),
                    actors=[act(KOLLEGA, k_spot, k_clips or [(0.0, "idle", dict())], k_face, OFFICE, flip=True,
                                contact=.5, halo=HALO_COLD, **k_extra),
                            act(R_STREET, r_spot, r_clips or [(0.0, "idle", dict())], r_face, OFFICE,
                                contact=.5, halo=HALO_COLD, **r_extra)])

    smoking("e_smoke", P(45), two, [(0, CALM)], [(0, TIRED)], cut=("black", .9))
    smoking("e_roaches", P(46), k_close, [(0, LOOK)], [(0, TIRED)], k_talk=(P(46), E(46)))
    smoking("e_no", P(47), r_close2, [(0, LOOK)], [(0, SIDE)], r_talk=(P(47), end_at(47, "встречались")),
            r_clips=[(0.0, "shrug", dict(speed=.8))])
    e_base = at(48, "Ты же")
    smoking("e_lucky", P(48), k_close, [(0, SMILE)], [(0, SIDE)], k_talk=(P(48), at(48, "заверил")),
            k_clips=[(0.0, "nod", dict(speed=.9))])
    smoking("e_cellar", e_base, two, [(0, LOOK)], [(0, CALM), (at(48, "над подвалом") - e_base, UNEASY)],
            k_talk=(e_base, E(48)), k_clips=[(0.0, "point", dict(speed=.6)), (3.0, "idle", dict())])
    beds.append((P(45), P(49), "room", .5))

    e_bom = P(50)
    shot("e_floor", P(49), "B04", {"from": (.45, .65, 1.4), "to": (.42, .70, 1.55)}, ("black", .9),
         grade=NIGHT, actors=[act(R_HOME, [(0.0, .40, .98, .62)], [(0.0, "crouch", dict())], [(0, UNEASY)],
                                  BLUE_NIGHT, contact=.4, halo=dict(color=rgb(.5, .7, 1.0), amount=.1, radius=9.0))])
    floor_cams = [((.55, .55, 1.1), (.55, .58, 1.25)), ((.52, .58, 1.3), (.54, .60, 1.45)), ((.55, .60, 1.45), (.55, .62, 1.65))]
    for i, n in enumerate((50, 51, 52)):
        who = ("falsetto", "crow", "bass")[i]
        shot("e_line_%d" % n, P(n), "B14", {"from": floor_cams[i][0], "to": floor_cams[i][1], "ease": "linear"},
             ("cut", 0) if i else ("cross", .5), grade=dict(exposure=.95, saturation=.75, vignette=.75, grain=.03),
             flicker=dict(speed=6, depth=.12), text=quote(spoken(text_of[n]), .2, E(n) - P(n) + .4, INK[who], y=.3),
             grade_track={"aberration": [(0.0, .0008), (E(n) - P(n), .0026)]})
        sfx.append((P(n) + .05, "whoosh", .16))
    e_under = at(53, "Я слышал")
    song = text_of[53].split("»")[0].strip("«")
    shot("e_song", P(53), "B14", {"from": (.55, .62, 1.6), "to": (.56, .66, 1.9), "ease": "linear"}, ("cross", .3),
         grade=dict(exposure=.92, saturation=.7, vignette=.8, grain=.03), flicker=dict(speed=8, depth=.18),
         text=quote(song, .1, e_under - P(53) + .2, INK["song"], y=.3, size=60))
    shot("e_under", e_under, "B14", {"from": (.56, .66, 1.9), "to": (.56, .78, 2.8), "ease": "linear"}, ("cross", .3),
         grade=dict(exposure=.9, saturation=.6, vignette=.85, grain=.035, contrast=1.1), fade_out=1.2,
         shake=[(at(53, "подо мной") - e_under, .45, .6)],
         grade_track={"bw": [(0.0, 0.0), (E(53) - e_under, .7)]})
    sfx.append((at(53, "подо мной"), "hit", .7))
    voices.append((P(49) + 1.0, E(53) + 1.0, .75))
    tense.append((e_under - 1.0, E(53)))

    # ============================================================== F. the basement (54-62)
    f_stepan = at(54, "Когда я наконец")
    f_after = at(54, "я чуть ли")
    r_bench = [(0.0, .42, .80, .30)]
    shot("f_bench", P(54), "B15", {"from": (.42, .58, 1.5), "to": (.42, .58, 1.6)}, ("black", 1.0),
         grade=dict(exposure=1.0, saturation=.85, vignette=.4),
         grade_track={"exposure": [(0.0, 1.0), (f_stepan - P(54), .82)]},
         actors=[act(R_STREET, r_bench, [(0.0, "sit_bench", dict())], [(0, TIRED), (4.0, CALM)], OVERCAST,
                     contact=.4, halo=HALO_COLD)])
    walk = f_after - f_stepan + 2.0
    shot("f_stepan", f_stepan, "B15", {"from": (.40, .56, 1.2), "to": (.30, .56, 1.25)}, ("cross", .6),
         grade=dict(exposure=.82, saturation=.82, vignette=.45),
         actors=[act(STEPAN, [(0.0, .88, .72, .25), (walk, .14, .76, .27)], [(0.0, "walk", dict(speed=.9))], [(0, CALM)],
                     OVERCAST, flip=True, contact=.4, halo=HALO_COLD, fade=[(walk - .4, 1.0), (walk, 0.0)]),
                 act(R_STREET, [(0.0, .42, .80, .30), (f_after - f_stepan, .42, .80, .30), (walk + 1.5, .14, .76, .27)],
                     [(0.0, "sit_bench", dict()), (f_after - f_stepan - .6, "get_up", dict()),
                      (f_after - f_stepan, "run", dict())],
                     [(0, CALM), (f_after - f_stepan - 1.0, LOOK)], OVERCAST, flip=True, contact=.4, halo=HALO_COLD,
                     fade=[(walk + 1.0, 1.0), (walk + 1.5, 0.0)])])
    beds.append((P(54), P(55), "day", .8))

    s_spot = [(0.0, .76, .97, .78)]
    r_stair = [(0.0, .48, .97, .74)]
    stair_lamp = [dict(x=.597, y=.14, r=.14, color=rgb(1.0, .86, .55), amount=.45, flicker=dict(speed=9, depth=.2))]
    s_close = {"from": (.74, .44, 1.85), "to": (.74, .44, 1.95)}
    r_close3 = {"from": (.48, .45, 1.85), "to": (.48, .45, 1.95)}
    stair_wide = {"from": (.58, .52, 1.12), "to": (.60, .52, 1.18)}

    def stairwell(id, start, camera, s_face, r_face, s_talk=None, r_talk=None, s_clips=None, r_clips=None, cut=("cut", 0)):
        s_extra = dict(talk=say(start, *s_talk), mouths=TALK) if s_talk else {}
        r_extra = dict(talk=say(start, *r_talk), mouths=TALK) if r_talk else {}
        return shot(id, start, "B02", camera, cut, lights=stair_lamp,
                    flicker=dict(speed=9, depth=.06), grade=dict(exposure=.9, saturation=.88, vignette=.55),
                    actors=[act(STEPAN, s_spot, s_clips or [(0.0, "idle", dict())], s_face, STAIR, flip=True,
                                contact=.55, halo=HALO_WARM, **s_extra),
                            act(R_STREET, r_stair, r_clips or [(0.0, "idle", dict())], r_face, STAIR,
                                contact=.55, halo=HALO_WARM, **r_extra)])

    sfx.append((P(55) - .6, "door_slam", .4))
    stairwell("f_keys", P(55), stair_wide, [(0, CALM)], [(0, UNEASY)], r_talk=(P(55), E(55)), cut=("cross", .4))
    stairwell("f_look", P(56), s_close, [(0, SIDE)], [(0, UNEASY)])
    stairwell("f_cat", P(57), r_close3, [(0, SIDE)], [(0, SMILE)], r_talk=(P(57), end_at(57, "забилась")),
              r_clips=[(0.0, "shrug", dict(speed=.8))])
    stairwell("f_closed", P(58), s_close, [(0, CALM)], [(0, SMILE)], s_talk=(P(58), E(58)),
              s_clips=[(0.0, "shake_head", dict(speed=.7))])
    stairwell("f_shift", P(59), stair_wide, [(0, CALM)], [(0, UNEASY)], r_clips=[(0.0, "look_around", dict(speed=.6))])
    f_pull = at(60, "сказал")
    stairwell("f_lets", P(60), s_close, [(0, SMILE)], [(0, UNEASY)], s_talk=(P(60), end_at(60, "будет")),
              s_clips=[(0.0, "idle", dict()), (f_pull - P(60), "reach_hand", dict(speed=.8))])
    sfx.append((f_pull + .6, "keys", .5))

    f_down = at(61, "Затем")
    f_light = at(61, "Степан достал")
    f_click = at(61, "Наконец")
    shot("f_utility", P(61), "B16", {"from": (.40, .55, 1.15), "to": (.55, .55, 1.2)}, ("cross", .7),
         grade=dict(exposure=.92, saturation=.85, vignette=.6), flicker=dict(speed=8, depth=.12),
         lights=[dict(x=.53, y=.06, r=.12, color=rgb(1.0, .9, .65), amount=.4, flicker=dict(speed=8, depth=.25))],
         actors=[act(STEPAN, [(0.0, .30, .97, .72), (f_down - P(61), .62, .95, .68)], [(0.0, "walk", dict(speed=.8))],
                     [(0, CALM)], BULB, contact=.5, halo=HALO_WARM),
                 act(R_STREET, [(0.0, .05, 1.0, .76), (f_down - P(61), .40, .98, .72)], [(0.0, "walk", dict(speed=.8))],
                     [(0, UNEASY)], BULB, contact=.5, halo=HALO_WARM)])
    s_door = [(0.0, .40, .90, .62)]
    r_back = [(0.0, .76, 1.08, .98)]
    bulb = [dict(x=.505, y=.10, r=.1, color=rgb(1.0, .85, .5), amount=.35, flicker=dict(speed=7, depth=.2))]

    def cellar(id, start, camera, s_face, r_face, s_clips=None, r_clips=None, s_talk=None, r_talk=None,
               cut=("cut", 0), light=BULB, **extra):
        s_extra = dict(talk=say(start, *s_talk), mouths=TALK) if s_talk else {}
        r_extra = dict(talk=say(start, *r_talk), mouths=TALK) if r_talk else {}
        extra.setdefault("grade", BASEMENT)
        return shot(id, start, "B17", camera, cut, lights=bulb, flicker=dict(speed=7, depth=.08),
                    actors=[act(STEPAN, s_door, s_clips or [(0.0, "idle", dict())], s_face, light, contact=.5,
                                halo=HALO_WARM, **s_extra),
                            act(R_STREET, r_back, r_clips or [(0.0, "idle", dict())], r_face, light, flip=True,
                                contact=0, halo=HALO_WARM, **r_extra)], **extra)

    cellar_wide = {"from": (.52, .52, 1.05), "to": (.52, .54, 1.12)}
    cellar("f_door", f_down, cellar_wide, [(0, CALM)], [(0, UNEASY)], cut=("cross", .6),
           s_clips=[(0.0, "idle", dict()), (f_light - f_down + 1.0, "reach_hand", dict(speed=.8)),
                    (f_light - f_down + 3.0, "crouch", dict())])
    sfx.append((f_click, "lock", .7))
    beds.append((f_down, P(63), "basement", .7))
    s_close2 = {"from": (.42, .52, 1.8), "to": (.42, .52, 1.95)}
    cellar("f_open", P(62), s_close2, [(0, SMILE)], [(0, UNEASY)], s_talk=(P(62), end_at(62, "кошку")),
           s_clips=[(0.0, "idle", dict()), (end_at(62, "кошку") - P(62), "push", dict(speed=.7))],
           shake=[(end_at(62, "кошку") - P(62) + .8, .3, .8)])
    sfx.append((end_at(62, "кошку") + .6, "creak", .7))

    # ============================================================== G. the domovyata (63-76)
    g_eyes = at(63, "оттуда")
    shot("g_dark", P(63), "B18", {"from": (.5, .5, 1.05), "to": (.5, .5, 1.12)}, ("cross", .5),
         grade=dict(exposure=.8, saturation=.7, vignette=.8, grain=.04),
         lights=[dict(x=.52, y=.55, r=.18, color=rgb(.95, .97, 1.0), amount=.12, flicker=dict(speed=9, depth=.3))])
    shot("g_eyes", g_eyes, "B18", {"from": (.5, .5, 1.3), "to": (.5, .52, 1.9), "ease": "linear", "handheld": 3.0},
         ("flash", .15), shake=[(0.0, .6, .9)], grade=dict(exposure=1.0, saturation=.7, vignette=.8, contrast=1.2,
                                                         aberration=.004, grain=.04))
    sfx.append((g_eyes, "hit", 1.0))
    tense.append((P(63), g_eyes))

    cellar_two_s = [(0.0, .30, .94, .70)]
    cellar_two_r = [(0.0, .70, 1.0, .80)]

    def cellar_two(id, start, camera, s_face, r_face, s_clips=None, r_clips=None, s_talk=None, r_talk=None,
                   cut=("cut", 0), **extra):
        s_extra = dict(talk=say(start, *s_talk), mouths=TALK) if s_talk else {}
        r_extra = dict(talk=say(start, *r_talk), mouths=TALK) if r_talk else {}
        extra.setdefault("grade", BASEMENT)
        return shot(id, start, "B17", camera, cut, lights=bulb, flicker=dict(speed=7, depth=.08),
                    actors=[act(STEPAN, cellar_two_s, s_clips or [(0.0, "idle", dict())], s_face, BULB, contact=.5,
                                halo=HALO_WARM, **s_extra),
                            act(R_STREET, cellar_two_r, r_clips or [(0.0, "idle", dict())], r_face, FLASHLIGHT, flip=True,
                                contact=.5, halo=HALO_COLD, **r_extra)], **extra)

    s_c = {"from": (.31, .44, 1.8), "to": (.31, .44, 1.9)}
    r_c = {"from": (.70, .44, 1.75), "to": (.70, .44, 1.85)}
    two_c = {"from": (.50, .54, 1.05), "to": (.50, .54, 1.1)}
    cellar_two("g_what", P(64), two_c, [(0, LOOK)], [(0, SHOCK)], cut=("cut", 0),
               s_clips=[(0.0, "reach_hand", dict(speed=.8))], s_talk=(P(64), end_at(64, "чего")),
               r_clips=[(0.0, "recoil", dict(speed=.9)), (1.6, "freeze", dict())])
    cellar_two("g_breathe", P(65), r_c, [(0, LOOK)], [(0, SCARED)], r_clips=[(0.0, "shiver", dict())])
    cellar_two("g_who", P(66), r_c, [(0, LOOK)], [(0, SHOCK)], r_clips=[(0.0, "freeze", dict())], r_talk=(P(66), E(66)))
    cellar_two("g_domovyata", P(67), s_c, [(0, LAUGH), (at(67, "Это") - P(67), SMILE)], [(0, SCARED)],
               s_clips=[(0.0, "laugh", dict(speed=.9)), (3.0, "idle", dict())], s_talk=(P(67), E(67)))
    tense.append((P(64), P(67)))

    g_toys = at(69, "Разные")
    g_harlequin = at(69, "Посередине")
    g_old = at(69, "Все они")
    cellar_two("g_second_light", P(68), two_c, [(0, SMILE)], [(0, SCARED)], cut=("cross", .4),
               s_clips=[(0.0, "point", dict(speed=.7))], grade_track={"exposure": [(0.0, .9), (E(68) - P(68), 1.1)]})
    toy_lights = [dict(x=.25, y=.35, r=.25, color=rgb(.95, .97, 1.0), amount=.12, flicker=dict(speed=6, depth=.15)),
                  dict(x=.65, y=.45, r=.3, color=rgb(1.0, .9, .7), amount=.08, flicker=dict(speed=5, depth=.15))]
    shot("g_basement", P(69), "B19", {"from": (.30, .45, 1.45), "to": (.62, .45, 1.45), "ease": "linear"}, ("cross", .8),
         grade=BASEMENT, lights=toy_lights, dust=dict(count=40, amount=.05, color=rgb(.85, .9, 1.0)))
    shot("g_toys", g_toys, "B19", {"from": (.40, .40, 1.8), "to": (.70, .38, 1.8), "ease": "linear"}, ("cross", .5),
         grade=BASEMENT, lights=toy_lights)
    shot("g_harlequin", g_harlequin, "B20", {"from": (.40, .65, 1.15), "to": (.38, .70, 1.5), "ease": "linear"},
         ("cross", .6), grade=BASEMENT, flicker=dict(speed=6, depth=.12))
    shot("g_old", g_old, "B19", {"from": (.5, .5, 1.05), "to": (.5, .5, 1.15)}, ("cross", .5), grade=BASEMENT,
         lights=toy_lights)

    cellar_two("g_why", P(70), r_c, [(0, CALM)], [(0, SCARED)], r_talk=(P(70), end_at(70, "делают")), cut=("cross", .4))
    cellar_two("g_embarrassed", P(71), s_c, [(0, SIDE)], [(0, UNEASY)], s_clips=[(0.0, "thinking", dict(speed=.6))])

    m_spot = [(0.0, .34, .86, .56)]
    m_dead = at(72, "Померла")
    m_daughter = at(72, "А потом")
    m_note = at(72, "Прямо на")
    m_basement = at(72, "В общем, попросили")
    m_soul = at(72, "Но рука")
    cellar_two("g_story", P(72), s_c, [(0, SAD)], [(0, UNEASY)], s_talk=(P(72), at(72, "Она эти")),
               s_clips=[(0.0, "sigh", dict(speed=.7))], cut=("cut", 0))
    shot("g_margarita", at(72, "Она эти"), "B21", {"from": (.40, .55, 1.25), "to": (.38, .56, 1.4), "ease": "linear"},
         ("blur", 1.2), grade=FLASHBACK, dust=dict(count=50, amount=.07, color=rgb(1.0, .9, .7)),
         lights=[dict(x=.12, y=.28, r=.2, color=rgb(1.0, .85, .55), amount=.3, flicker=dict(speed=2, depth=.06))],
         actors=[act(MARGO, m_spot, [(0.0, "sit_chair", dict())], [(0, SMILE), (8.0, (58, 277))], LAMPLIGHT,
                     contact=.4, halo=HALO_WARM)])
    shot("g_margarita_gone", m_dead, "B21", {"from": (.40, .55, 1.4), "to": (.42, .55, 1.3)}, ("cross", 1.5),
         grade=dict(FLASHBACK, saturation=.25, exposure=.9),
         lights=[dict(x=.12, y=.28, r=.2, color=rgb(1.0, .85, .55), amount=.18, flicker=dict(speed=2, depth=.1))])
    shot("g_box", m_daughter, "B22", {"from": (.55, .62, 1.15), "to": (.58, .78, 1.9), "ease": "linear"}, ("cross", 1.0),
         grade=dict(FLASHBACK, saturation=.35))
    shot("g_box_note", m_note, "B22", {"from": (.58, .78, 1.9), "to": (.58, .80, 2.3), "ease": "linear"}, ("cross", .5),
         grade=dict(FLASHBACK, saturation=.35))
    shot("g_soul", m_soul, "B21", {"from": (.55, .62, 1.6), "to": (.60, .62, 1.9), "ease": "linear"}, ("cross", .8),
         grade=dict(FLASHBACK, saturation=.3, exposure=.92))
    shot("g_guard", m_basement, "B19", {"from": (.5, .5, 1.25), "to": (.5, .48, 1.05)}, ("blur", 1.2),
         grade=BASEMENT, lights=toy_lights)
    tense_free_from = m_basement  # noqa: F841  (kept for reading: the music box returns here)

    cellar_two("g_grin", P(73), s_c, [(0, SMIRK)], [(0, UNEASY)], cut=("cross", .5))
    cellar_two("g_cat", P(74), two_c, [(0, SMIRK)], [(0, UNEASY)], s_talk=(P(74), E(74)))
    g_move = at(75, "мне показалось")
    shot("g_light_jump", P(75), "B20", {"from": (.42, .62, 1.3), "to": (.40, .55, 1.55), "ease": "linear", "handheld": 2.6},
         ("cross", .3), grade=BASEMENT, flicker=dict(speed=14, depth=.35, drops=[(g_move - P(75), .18, .25)]))
    shot("g_moved", g_move, "B19", {"from": (.35, .40, 1.6), "to": (.28, .38, 2.2), "ease": "linear", "handheld": 2.8},
         ("flash", .15), grade=dict(BASEMENT, bw=.5, aberration=.003), shake=[(0.6, .4, .5)],
         flicker=dict(speed=12, depth=.3))
    sfx.append((g_move + .6, "hit", .8))
    tense.append((P(75), g_move + .6))
    cellar_two("g_backaway", P(76), two_c, [(0, LOOK)], [(0, SCARED)], cut=("cross", .4),
               r_clips=[(0.0, "back_away", dict(speed=.8))])

    # ============================================================== H. moving out (77)
    h_fear = at(77, "К чувству")
    h_last = at(77, "Тем не менее")
    h_mad = at(77, "давно сошли")
    shot("h_boxes", P(77), "B24", {"from": (.50, .52, 1.06), "to": (.54, .52, 1.14)}, ("black", 1.4),
         grade=dict(exposure=1.0, saturation=.8, vignette=.45, tint=rgb(.97, .98, 1.02)),
         actors=[act(R_STREET, [(0.0, .66, .98, .78)], [(0.0, "idle", dict(speed=.7)), (2.0, "sigh", dict(speed=.7))],
                     [(0, SAD)], GREY_DAY, flip=True, contact=.55, halo=HALO_COLD)])
    hub("h_longing", h_fear, [(0, SAD)], talk=(h_fear, h_mad), cut=("cross", .8))
    shot("h_toys", h_mad - .3, "B19", {"from": (.5, .5, 1.1), "to": (.48, .46, 1.6), "ease": "linear"}, ("cross", 1.2),
         grade=dict(BASEMENT, saturation=.6, exposure=.9), lights=toy_lights, fade_out=2.5)
    voices.append((h_mad - .5, h_mad + 6.0, .5))
    lines += EXTRA_LINES
