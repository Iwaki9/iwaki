"""Whisper's slips in this recording, fixed in audio/words_whisper.json before refine.py runs.

    python projects/03_tri_dnya/fix_words.py
    python engine/refine.py projects/03_tri_dnya/audio projects/03_tri_dnya/elevenlabs/full_elevenlabs.srt

1. Runs of zero-length words: Whisper heard the speech but stamped every word at one point. They get
   the stretch up to the end of the next good word, shared by letter count. The worst run sat at
   355-360 s; shared this way its commas land on the real dips in the audio (356.8 s, 358.8 s).
2. Shouted and drawn-out lines start earlier than Whisper thinks. The times below were read from the
   loudness of narration.wav, because refine.py finds no pause to snap to where a breath comes first.

Times belong to this recording: with a new voice, delete this step. The untouched Whisper output
stays in words_whisper_raw.json, and the script always starts from it, so it can be run again.
"""
import json
import shutil
from pathlib import Path

AUDIO = Path(__file__).resolve().parent / "audio"
LETTERS = str.maketrans("", "", "-")

# First word of the collapsed run -> where speech really resumes (default: the previous word's end).
RUN_START = {"на": 355.25}
# (word, approximate old start, new start, new end or None)
ONSETS = [("Стоять", 510.08, 509.90, None),
          ("Помо-о-огите", 650.20, 648.95, 651.08),
          ("Холодно", 652.24, 651.75, None),
          ("Пусти", 717.44, 716.98, None),
          ("Открой", 721.38, 721.00, None)]


def main():
    source = AUDIO / "words_whisper.json"
    raw = AUDIO / "words_whisper_raw.json"
    if not raw.exists():
        shutil.copy(source, raw)
    words = json.loads(raw.read_text(encoding="utf-8"))

    i = 0
    while i < len(words):
        if words[i]["end"] - words[i]["start"] >= 0.02:
            i += 1
            continue
        j = i
        while words[j]["end"] - words[j]["start"] < 0.02:
            j += 1
        lo = RUN_START.get(words[i]["word"], words[i - 1]["end"])
        hi = words[j]["end"]
        weights = [len(w["word"].translate(LETTERS)) + 1 for w in words[i:j + 1]]
        at = lo
        for w, share in zip(words[i:j + 1], weights):
            w["start"] = round(at, 3)
            at += (hi - lo) * share / sum(weights)
            w["end"] = round(at, 3)
        print("run: %s ... %s  %.2f-%.2f" % (words[i]["word"], words[j]["word"], lo, hi))
        i = j + 1

    for word, old, start, end in ONSETS:
        hits = [w for w in words if w["word"] == word and abs(w["start"] - old) < 0.5]
        if len(hits) != 1:
            raise SystemExit("onset not found: %s near %.2f" % (word, old))
        hits[0]["start"] = start
        if end is not None:
            hits[0]["end"] = end
        print("onset: %s %.2f -> %.2f" % (word, old, start))

    source.write_text(json.dumps(words, ensure_ascii=False, indent=0), encoding="utf-8")


if __name__ == "__main__":
    main()
