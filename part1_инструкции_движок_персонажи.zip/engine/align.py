"""Word timings for a finished voice recording (ElevenLabs, HeyGen, your own mic) through Whisper.

    python engine/align.py <recording.mp3> история.txt projects/01_domovyata/audio [--paragraphs 1-77]

Writes narration.wav and words.json (word, start, end, paragraph) into the audio folder, exactly
like tts.py does, so scenes.py re-times the film by itself. Several files are joined in the order
given:  python engine/align.py part1.mp3 part2.mp3 история.txt <audio_dir>

Whisper hears the words; the words themselves are taken from the story, so a cue such as
cue("громкий звук телевизора") still finds them even where Whisper misspelled something. Words that
Whisper missed get times spread between their matched neighbours.
"""
import argparse
import difflib
import json
import subprocess
import unicodedata
from pathlib import Path

import numpy as np
from scipy.io import wavfile

SAMPLE_RATE = 48000


def plain(text):
    return unicodedata.normalize("NFC", "".join(c for c in unicodedata.normalize("NFD", text) if c != "́"))


def norm(word):
    return "".join(c for c in word.lower().replace("ё", "е") if c.isalnum())


def story_words(story, first, last):
    paragraphs = [plain(line).strip() for line in Path(story).read_text(encoding="utf-8").splitlines() if line.strip()]
    out = []
    for number in range(first, last + 1):
        for token in paragraphs[number - 1].split():
            word = token.strip("«»“”\"—–-.,!?…:;()")
            if norm(word):
                out.append({"word": word, "paragraph": number})
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("inputs", nargs="+", help="recording file(s), then story.txt, then the audio folder")
    parser.add_argument("--paragraphs", default=None, help="e.g. 1-77; default: the whole story")
    parser.add_argument("--model", default="medium")
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()
    *recordings, story, out = args.inputs
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)

    # 1. One mono 48 kHz narration.wav from all the recordings, in order.
    parts = []
    for path in recordings:
        decoded = subprocess.run(["ffmpeg", "-v", "error", "-i", str(path), "-f", "s16le", "-ac", "1",
                                  "-ar", str(SAMPLE_RATE), "-"], capture_output=True, check=True).stdout
        parts.append(np.frombuffer(decoded, np.int16))
        parts.append(np.zeros(int(0.6 * SAMPLE_RATE), np.int16))
    track = np.concatenate(parts)
    wav = out / "narration.wav"
    wavfile.write(str(wav), SAMPLE_RATE, track)
    print("narration", round(len(track) / SAMPLE_RATE, 1), "s", flush=True)

    # 2. What Whisper hears, word by word.
    from faster_whisper import WhisperModel

    compute = "float16" if args.device == "cuda" else "int8"
    model = WhisperModel(args.model, device=args.device, compute_type=compute)
    segments, _ = model.transcribe(str(wav), language="ru", word_timestamps=True, beam_size=5,
                                   condition_on_previous_text=False)
    heard = []
    for segment in segments:
        for w in segment.words:
            for piece in w.word.split():
                if norm(piece):
                    heard.append({"word": piece, "start": w.start, "end": w.end})
        print("  heard up to %.0f s" % segment.end, flush=True)

    # 3. Match the story's words to the heard ones; hyphenated words may come apart in Whisper.
    total = sum(1 for line in Path(story).read_text(encoding="utf-8").splitlines() if line.strip())
    first, last = (int(v) for v in args.paragraphs.split("-")) if args.paragraphs else (1, total)
    words = story_words(story, first, last)
    a = [norm(w["word"]) for w in words]
    b = [norm(w["word"]) for w in heard]
    matcher = difflib.SequenceMatcher(None, a, b, autojunk=False)
    times = [None] * len(words)
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            for k in range(i2 - i1):
                times[i1 + k] = (heard[j1 + k]["start"], heard[j1 + k]["end"])
        elif tag == "replace" and j2 > j1:
            # Same stretch, different spelling (or "бей-бей" heard as "бей бей"): share its time out.
            start, end = heard[j1]["start"], heard[j2 - 1]["end"]
            weights = np.cumsum([0] + [max(len(x), 1) for x in a[i1:i2]], dtype=float)
            weights /= weights[-1]
            for k in range(i2 - i1):
                times[i1 + k] = (start + (end - start) * weights[k], start + (end - start) * weights[k + 1])
    matched = sum(t is not None for t in times)

    # 4. Anything still unknown sits evenly between its known neighbours.
    known = [i for i, t in enumerate(times) if t is not None]
    if not known:
        raise SystemExit("Whisper heard nothing that matches the story")
    for i, t in enumerate(times):
        if t is None:
            before = max((k for k in known if k < i), default=None)
            after = min((k for k in known if k > i), default=None)
            lo = times[before][1] if before is not None else 0.0
            hi = times[after][0] if after is not None else lo + 0.4 * (i - (before or 0))
            gap_from = before if before is not None else -1
            gap_to = after if after is not None else len(times)
            share = (hi - lo) / (gap_to - gap_from)
            times[i] = (lo + share * (i - gap_from - 1) + 0.0, lo + share * (i - gap_from))

    result = [dict(word=w["word"], start=round(s, 3), end=round(e, 3), paragraph=w["paragraph"])
              for w, (s, e) in zip(words, times)]
    (out / "words.json").write_text(json.dumps(result, ensure_ascii=False, indent=0), encoding="utf-8")
    print("words", len(result), "matched exactly %.1f%%" % (100.0 * matched / len(result)),
          "last word at %.1f s" % result[-1]["end"])


if __name__ == "__main__":
    main()
