"""One fused CUDA kernel for the limb / hem bend of SkinSprite (puppet.py).

The torch version (_chain_gpu / _hem_gpu + _chain_search_gpu) launches ~200 tiny kernels per limb,
so with 8 render workers the GPU drowned in launches. Here one thread per screen pixel walks the
chain grid, refines every bracketed root (4 regula-falsi steps), keeps the most opaque solution
(alpha rounded to 1/4096, first interval on ties) and samples the art: one launch per limb.

Compiled at first use with the NVRTC that ships with PyTorch and launched through the CUDA driver
API (ctypes) on torch's current stream, so no CUDA toolkit or C++ compiler is needed.
If anything fails, available() is False and puppet.py keeps the torch path.
"""

import ctypes
import glob
import os
import sys

import torch

SOURCE = r"""
struct Params {
    double m00, m01, m02, m10, m11, m12;      // screen pixel -> torso/body bone space
    double sx0, sy0;                          // screen box origin
    double x0, y0, chosen;                    // art origin, stage scale
    double p0, p1, p2, p3, p4, p5, p6, p7, p8, p9;   // chain: a b S0 S1 E0 E1 | hem: lap drop squash H0 H1 K0 K1 O0 O1
    int mode;                                 // 0 chain, 1 hem
    int n1, n2;                               // grid steps on the two segments
    int bw, bh;                               // screen box size
    int sw, sh;                               // art size
    int wplanes;                              // channels in the weight image
};

__device__ __forceinline__ float tap(const float* p, int sw, int sh, int x, int y) {
    return (x >= 0 && y >= 0 && x < sw && y < sh) ? p[y * sw + x] : 0.0f;
}

// cv2.remap INTER_LINEAR == grid_sample(align_corners=True); rep: BORDER_REPLICATE, else 0 outside
__device__ float bil(const float* p, int sw, int sh, float x, float y, bool rep) {
    if (rep) {
        x = fminf(fmaxf(x, 0.0f), (float)(sw - 1));
        y = fminf(fmaxf(y, 0.0f), (float)(sh - 1));
    } else if (!(x > -1.0f && y > -1.0f && x < (float)sw && y < (float)sh)) {
        return 0.0f;
    }
    float fx = floorf(x), fy = floorf(y);
    int ix = (int)fx, iy = (int)fy;
    float ax = x - fx, ay = y - fy;
    float v00 = tap(p, sw, sh, ix, iy), v10 = tap(p, sw, sh, ix + 1, iy);
    float v01 = tap(p, sw, sh, ix, iy + 1), v11 = tap(p, sw, sh, ix + 1, iy + 1);
    return (v00 * (1.0f - ax) + v10 * ax) * (1.0f - ay) + (v01 * (1.0f - ax) + v11 * ax) * ay;
}

__device__ void at(const Params& P, const float* wts, float lam, float ux, float uy,
                   float& sx, float& sy, float& g) {
    float x0 = (float)P.x0, y0 = (float)P.y0, ch = (float)P.chosen;
    float fs = fminf(lam, 1.0f), fe = fmaxf(lam - 1.0f, 0.0f);
    if (P.mode == 0) {
        float a = (float)P.p0, b = (float)P.p1;
        float S0 = (float)P.p2, S1 = (float)P.p3, E0 = (float)P.p4, E1 = (float)P.p5;
        float al = a * fs, th = al + b * fe;
        float sth, cth, sal, cal;
        sincosf(th, &sth, &cth);
        sincosf(al, &sal, &cal);
        float tx = -(cth * E0 - sth * E1) + (cal * (E0 - S0) - sal * (E1 - S1)) + S0;
        float ty = -(sth * E0 + cth * E1) + (sal * (E0 - S0) + cal * (E1 - S1)) + S1;
        float dx = ux - tx, dy = uy - ty;
        sx = (cth * dx + sth * dy - x0) * ch;
        sy = (-sth * dx + cth * dy - y0) * ch;
    } else {
        float lap = (float)P.p0, drop = (float)P.p1, sq = (float)P.p2;
        bool up = lam <= 1.0f;
        float th = up ? lap * fs : lap + (drop - lap) * fe;
        float sc = up ? 1.0f + (sq - 1.0f) * fs : sq;
        float px = up ? (float)P.p3 : (float)P.p5, py = up ? (float)P.p4 : (float)P.p6;
        float ox = up ? (float)P.p3 : (float)P.p7, oy = up ? (float)P.p4 : (float)P.p8;
        float s, c;
        sincosf(th, &s, &c);
        float dx = ux - ox, dy = uy - oy;
        float lx = (c * dx + s * dy) / sc + px;
        float ly = (-s * dx + c * dy) + py;
        sx = (lx - x0) * ch;
        sy = (ly - y0) * ch;
    }
    int plane = P.sw * P.sh;
    float fs_p = 1.0f - bil(wts, P.sw, P.sh, sx, sy, true);
    float fe_p = fs_p > 1e-4f ? bil(wts + 2 * plane, P.sw, P.sh, sx, sy, true) / fmaxf(fs_p, 1e-4f) : 0.0f;
    g = fs_p + fe_p - lam;
}

__device__ __forceinline__ float grid_lam(const Params& P, int n) {
    return n <= P.n1 ? (float)((double)n / P.n1) : (float)(1.0 + (double)(n - P.n1) / P.n2);
}

extern "C" __global__ void skin(Params P, const float* img, const float* wts, float* out) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    int count = P.bw * P.bh;
    if (i >= count) return;
    double qx = P.sx0 + (double)(i % P.bw), qy = P.sy0 + (double)(i / P.bw);
    float ux = (float)(P.m00 * qx + P.m01 * qy + P.m02);
    float uy = (float)(P.m10 * qx + P.m11 * qy + P.m12);
    int plane = P.sw * P.sh;
    float lam0 = 0.0f, sx, sy, g0;
    at(P, wts, lam0, ux, uy, sx, sy, g0);
    int best = 0;
    float bx = -10.0f, by = -10.0f;
    for (int n = 1; n <= P.n1 + P.n2; ++n) {
        float lam1 = grid_lam(P, n), g1;
        at(P, wts, lam1, ux, uy, sx, sy, g1);
        if ((g0 >= 0.0f && g1 <= 0.0f) || (g0 <= 0.0f && g1 >= 0.0f)) {
            float lo = lam0, hi = lam1, glo = g0, ghi = g1, msx = 0.0f, msy = 0.0f, gm = 1.0f;
            for (int it = 0; it < 4; ++it) {
                float den = glo - ghi;
                float mid = fabsf(den) > 1e-6f ? lo + glo * (hi - lo) / den : (lo + hi) * 0.5f;
                mid = fminf(fmaxf(mid, fminf(lo, hi)), fmaxf(lo, hi));
                at(P, wts, mid, ux, uy, msx, msy, gm);
                if ((gm >= 0.0f) == (glo >= 0.0f)) { lo = mid; glo = gm; } else { hi = mid; ghi = gm; }
            }
            float al = fabsf(gm) < 0.03f ? bil(img + 3 * plane, P.sw, P.sh, msx, msy, false) : 0.0f;
            int level = (int)rintf(al * 4096.0f);
            if (level > best) { best = level; bx = msx; by = msy; }
        }
        lam0 = lam1;
        g0 = g1;
    }
    for (int c = 0; c < 4; ++c)
        out[c * count + i] = bil(img + c * plane, P.sw, P.sh, bx, by, false);
}
"""


class _Params(ctypes.Structure):
    _fields_ = ([(n, ctypes.c_double) for n in ("m00", "m01", "m02", "m10", "m11", "m12", "sx0", "sy0",
                                                 "x0", "y0", "chosen")] +
                [("p%d" % i, ctypes.c_double) for i in range(10)] +
                [(n, ctypes.c_int) for n in ("mode", "n1", "n2", "bw", "bh", "sw", "sh", "wplanes")])


_state = {"tried": False, "fn": None, "error": None}
_cuda = None


def _load():
    global _cuda
    _state["tried"] = True
    if sys.platform != "win32" or not torch.cuda.is_available():
        raise RuntimeError("needs CUDA on Windows")
    lib = os.path.join(os.path.dirname(torch.__file__), "lib")
    found = sorted(glob.glob(os.path.join(lib, "nvrtc64_*.dll")))
    if not found:
        raise RuntimeError("nvrtc not found in torch/lib")
    nvrtc = ctypes.CDLL(found[-1])
    _cuda = ctypes.CDLL("nvcuda.dll")
    torch.zeros(1, device="cuda")                       # make torch's primary context current

    prog = ctypes.c_void_p()
    _check_nvrtc(nvrtc, nvrtc.nvrtcCreateProgram(ctypes.byref(prog), SOURCE.encode(), b"skin.cu", 0, None, None))
    major, minor = torch.cuda.get_device_capability()
    opts = [("--gpu-architecture=compute_%d%d" % (major, minor)).encode(), b"--std=c++14"]
    arr = (ctypes.c_char_p * len(opts))(*opts)
    res = nvrtc.nvrtcCompileProgram(prog, len(opts), arr)
    if res:
        size = ctypes.c_size_t()
        nvrtc.nvrtcGetProgramLogSize(prog, ctypes.byref(size))
        log = ctypes.create_string_buffer(size.value)
        nvrtc.nvrtcGetProgramLog(prog, log)
        raise RuntimeError("nvrtc compile failed: " + log.value.decode(errors="replace"))
    size = ctypes.c_size_t()
    _check_nvrtc(nvrtc, nvrtc.nvrtcGetPTXSize(prog, ctypes.byref(size)))
    ptx = ctypes.create_string_buffer(size.value)
    _check_nvrtc(nvrtc, nvrtc.nvrtcGetPTX(prog, ptx))
    nvrtc.nvrtcDestroyProgram(ctypes.byref(prog))

    ctx = ctypes.c_void_p()
    _check_cu(_cuda.cuCtxGetCurrent(ctypes.byref(ctx)))
    if not ctx.value:
        raise RuntimeError("no current CUDA context")
    module, fn = ctypes.c_void_p(), ctypes.c_void_p()
    _check_cu(_cuda.cuModuleLoadData(ctypes.byref(module), ptx))
    _check_cu(_cuda.cuModuleGetFunction(ctypes.byref(fn), module, b"skin"))
    _state["fn"] = fn
    _state["module"] = module


def _check_nvrtc(nvrtc, res):
    if res:
        raise RuntimeError("nvrtc error %d" % res)


def _check_cu(res):
    if res:
        raise RuntimeError("CUDA driver error %d" % res)


def available():
    if not _state["tried"]:
        try:
            _load()
        except Exception as exc:                        # keep rendering on the torch path
            _state["error"] = exc
            _state["fn"] = None
    return _state["fn"] is not None


def run(mode, matrix_inv, box, art, params, n1, n2, t_img, t_w):
    """matrix_inv 3x3 (screen -> bone space), box (sx0, sy0, sx1, sy1), art (x0, y0, chosen),
    params up to 10 floats (see Params), t_img 1x4xHxW and t_w 1xCxHxW float32 on the GPU.
    Returns the 4 x bh x bw premultiplied layer."""
    sx0, sy0, sx1, sy1 = box
    bw, bh = sx1 - sx0, sy1 - sy0
    if t_img.dtype != torch.float32 or not t_img.is_contiguous():
        t_img = t_img.float().contiguous()
    if t_w.dtype != torch.float32 or not t_w.is_contiguous():
        t_w = t_w.float().contiguous()
    out = torch.empty((4, bh, bw), dtype=torch.float32, device=t_img.device)
    m = matrix_inv
    p = list(params) + [0.0] * (10 - len(params))
    P = _Params(float(m[0, 0]), float(m[0, 1]), float(m[0, 2]), float(m[1, 0]), float(m[1, 1]), float(m[1, 2]),
                float(sx0), float(sy0), float(art[0]), float(art[1]), float(art[2]),
                *[float(v) for v in p], int(mode), int(n1), int(n2), int(bw), int(bh),
                int(t_img.shape[3]), int(t_img.shape[2]), int(t_w.shape[1]))
    a_img = ctypes.c_void_p(t_img.data_ptr())
    a_w = ctypes.c_void_p(t_w.data_ptr())
    a_out = ctypes.c_void_p(out.data_ptr())
    args = (ctypes.c_void_p * 4)(ctypes.cast(ctypes.byref(P), ctypes.c_void_p),
                                 ctypes.cast(ctypes.byref(a_img), ctypes.c_void_p),
                                 ctypes.cast(ctypes.byref(a_w), ctypes.c_void_p),
                                 ctypes.cast(ctypes.byref(a_out), ctypes.c_void_p))
    threads = 128
    blocks = (bw * bh + threads - 1) // threads
    stream = ctypes.c_void_p(torch.cuda.current_stream(t_img.device).cuda_stream)
    _check_cu(_cuda.cuLaunchKernel(_state["fn"], blocks, 1, 1, threads, 1, 1, 0, stream, args, None))
    return out
