"""Gacha character pack + studio poses = premultiplied RGBA character frames.

A pack (anim/<slug>/) gives depth-ordered layers and measured joints. The studio gives poses
in its own 13 numbers. This module joins them: layers are flattened per bone, posed about the
measured joints, and drawn into a screen-sized region of interest.

The pack has no knee or elbow node (the game's lower limb turns about the ankle and the wrist),
and the game's upper-limb nodes sit near the middle of the sleeve/thigh sprite rather than at the
anatomical shoulder and hip sockets, so all limb joints are measured directly from the art.

Supports both fast sub-box CPU rendering (OpenCV) and GPU rendering on NVIDIA CUDA (PyTorch).
"""

import json
import math
import os
from collections import OrderedDict
from pathlib import Path

import cv2
import numpy as np

try:
    import torch
    import torch.nn.functional as F
    HAS_TORCH = True
except ImportError:
    torch = None
    F = None
    HAS_TORCH = False

FACE_FEATURES = ("mouth", "nose", "eye1", "eye2", "pupil", "highlight")
EYE_PREFIXES = ("eye1", "eye2", "pupil", "highlight")
STAGES = (0.25, 0.5, 1.0, 2.0)
# Hip-to-floor of the studio rig, in studio units. Converts bob and sway to pack pixels.
STUDIO_LEG_LENGTH = 172.0


def read_rgba(path):
    data = cv2.imdecode(np.fromfile(str(path), np.uint8), cv2.IMREAD_UNCHANGED)
    if data is None:
        raise FileNotFoundError(path)
    if data.ndim == 2:
        data = cv2.cvtColor(data, cv2.COLOR_GRAY2BGRA)
    elif data.shape[2] == 3:
        data = cv2.cvtColor(data, cv2.COLOR_BGR2BGRA)
    image = data.astype(np.float32) / (65535.0 if data.dtype == np.uint16 else 255.0)
    image[..., :3] *= image[..., 3:4]
    return image


def over(dst, src):
    """Premultiplied source-over, in place, same shape."""
    dst *= 1.0 - src[..., 3:4]
    dst += src


def rotate_about(pivot, degrees):
    angle = np.deg2rad(degrees)
    cos, sin = np.cos(angle), np.sin(angle)
    x, y = pivot
    return np.array([[cos, -sin, x - cos * x + sin * y],
                     [sin, cos, y - sin * x - cos * y],
                     [0.0, 0.0, 1.0]])


def translate(x, y):
    return np.array([[1.0, 0.0, x], [0.0, 1.0, y], [0.0, 0.0, 1.0]])


def top_cap_center(mask):
    """Anatomical center of the rounded top cap of an upper limb (shoulder or hip)."""
    u8 = mask.astype(np.uint8)
    edt = cv2.distanceTransform(u8, cv2.DIST_L2, 5)
    ys, xs = np.nonzero(mask)
    y_min, y_max = int(ys.min()), int(ys.max())
    h = max(y_max - y_min, 1)
    region = mask & (np.arange(mask.shape[0])[:, None] <= y_min + int(0.42 * h))
    cy, cx = np.unravel_index(np.argmax(edt * region), edt.shape)
    r = float(edt[cy, cx])
    target_y = y_min + r * 1.05
    band = mask & (np.abs(np.arange(mask.shape[0])[:, None] - target_y) <= 3)
    bys, bxs = np.nonzero(band)
    if len(bxs):
        cx = float(bxs.mean())
        cy = float(target_y)
    return np.array([float(cx), float(cy)], dtype=float)


def _affine_theta(matrix_3x3, in_w, in_h, out_w, out_h):
    """Convert pixel-space 3x3 affine matrix (in -> out) to PyTorch affine_grid 2x3 theta (align_corners=False)."""
    inv_m = np.linalg.inv(matrix_3x3)
    # N_in * inv_m * N_out_inv
    # N_out_inv: x_out = (out_w / 2) * u_out + (out_w - 1) / 2
    n_out_inv = np.array([
        [out_w * 0.5, 0.0, (out_w - 1.0) * 0.5],
        [0.0, out_h * 0.5, (out_h - 1.0) * 0.5],
        [0.0, 0.0, 1.0],
    ], dtype=np.float32)
    n_in = np.array([
        [2.0 / in_w, 0.0, (1.0 - in_w) / in_w],
        [0.0, 2.0 / in_h, (1.0 - in_h) / in_h],
        [0.0, 0.0, 1.0],
    ], dtype=np.float32)
    theta = (n_in @ inv_m.astype(np.float32) @ n_out_inv)[:2]
    return theta


class Sprite:
    """One flattened run of layers, cropped, at several resolutions."""

    def __init__(self, canvas_image):
        alpha = canvas_image[..., 3]
        ys, xs = np.nonzero(alpha > 0.002)
        if not len(xs):
            self.empty = True
            return
        self.empty = False
        pad = 3
        x0, y0 = max(xs.min() - pad, 0), max(ys.min() - pad, 0)
        x1, y1 = min(xs.max() + pad + 1, canvas_image.shape[1]), min(ys.max() + pad + 1, canvas_image.shape[0])
        self.x0, self.y0 = float(x0), float(y0)
        self.base = canvas_image[y0:y1, x0:x1].copy()
        self.stages = {}
        self.gpu_stages = {}
        self.capped = None

    def _resample(self, base, chosen):
        height, width = base.shape[:2]
        size = (max(1, int(round(width * chosen))), max(1, int(round(height * chosen))))
        if chosen == 1.0:
            return base
        if chosen < 1.0:
            return cv2.resize(base, size, interpolation=cv2.INTER_AREA)
        image = np.clip(cv2.resize(base, size, interpolation=cv2.INTER_LANCZOS4), 0, 1)
        # Flat-colour art: tighten the edge the upscale softened.
        alpha = image[..., 3:4]
        sharper = np.clip((alpha - 0.5) * 1.6 + 0.5, 0, 1)
        return image * (sharper / np.maximum(alpha, 1e-3))

    def stage(self, scale):
        chosen = next((s for s in STAGES if s >= scale), STAGES[-1])
        if chosen not in self.stages:
            self.stages[chosen] = self._resample(self.base, chosen)
        return chosen, self.stages[chosen]

    def stage_capped(self, scale, amount):
        """amount 0..1 shortens the stub in solid steps: a fade would leave a see-through ghost."""
        chosen, image = self.stage(scale)
        step = int(np.ceil(amount * len(self.capped))) if self.capped else 0
        if not step:
            return chosen, image
        key = (chosen, step)
        if key not in self.stages:
            self.stages[key] = self._resample(self.capped[step - 1], chosen)
        return chosen, self.stages[key]

    def stage_capped_gpu(self, scale, amount, device):
        """Return (chosen, tensor_1x4xHxW_on_device, H, W)."""
        chosen = next((s for s in STAGES if s >= scale), STAGES[-1])
        step = int(np.ceil(amount * len(self.capped))) if self.capped else 0
        key = (chosen, step, str(device))
        if key not in self.gpu_stages:
            _, cpu_img = self.stage_capped(scale, amount)
            # HxWx4 -> 1x4xHxW on GPU
            tensor = torch.from_numpy(cpu_img).permute(2, 0, 1).unsqueeze(0).contiguous().to(device, non_blocking=True)
            self.gpu_stages[key] = (tensor, cpu_img.shape[0], cpu_img.shape[1])
        t_img, h, w = self.gpu_stages[key]
        return chosen, t_img, h, w

    def make_cap(self, pivot, toward, outline):
        """Round the limb off at its joint: the art beyond the joint is the game's hidden stub.

        At rest the stub sits under the body; on a wide swing it would poke out the far side.
        """
        height, width = self.base.shape[:2]
        xs, ys = np.meshgrid(np.arange(width) + self.x0, np.arange(height) + self.y0)
        dx, dy = xs - pivot[0], ys - pivot[1]
        axis = (np.asarray(toward, float) - pivot) / np.linalg.norm(np.asarray(toward, float) - pivot)
        along = dx * axis[0] + dy * axis[1]
        across = -dx * axis[1] + dy * axis[0]
        distance = np.hypot(dx, dy)
        solid = self.base[..., 3] > 0.5
        near_joint = solid & (np.abs(along) < 4)
        radius = max(np.abs(across[near_joint]).max() * 0.92, 10.0) if near_joint.any() else 30.0
        stub = solid & (along < 0)
        reach = max(distance[stub].max(), radius) if stub.any() else radius
        self.capped = []
        for cut in np.linspace(reach, radius, 5)[1:]:
            keep = np.maximum(np.clip(along / 2.0 + 0.5, 0, 1), np.clip((cut - distance) / 2.0 + 0.5, 0, 1))
            capped = self.base * keep[..., None].astype(np.float32)
            if outline is not None:
                band = np.clip(1.0 - np.abs(distance - (cut - 3.0)) / 3.5, 0, 1) * (along < 0) * solid
                band = band[..., None].astype(np.float32)
                capped = capped * (1 - band) + np.array([*outline, 1.0], np.float32) * band
            self.capped.append(capped)


class SkinSprite:
    """A whole limb as one picture, bent smoothly between up to three bones (linear blend skinning).

    Used by AI-drawn packs: a rigid cut at the elbow shows on painted art, a blended bend does not.
    weights: HxWxN on the canvas, one channel per bone in self.bones, summing to 1.
    """

    def __init__(self, canvas_image, weights, bones):
        alpha = canvas_image[..., 3]
        ys, xs = np.nonzero(alpha > 0.002)
        self.empty = not len(xs)
        self.bones = list(bones)
        self.capped = None
        self.alt_up = None
        if self.empty:
            return
        pad = 3
        x0, y0 = max(xs.min() - pad, 0), max(ys.min() - pad, 0)
        x1, y1 = min(xs.max() + pad + 1, canvas_image.shape[1]), min(ys.max() + pad + 1, canvas_image.shape[0])
        self.x0, self.y0 = float(x0), float(y0)
        self.base = canvas_image[y0:y1, x0:x1].copy()
        self.wbase = np.ascontiguousarray(weights[y0:y1, x0:x1, :len(self.bones)].astype(np.float32))
        self.stages = {}

    def stage(self, scale):
        chosen = next((s for s in STAGES if s >= scale), STAGES[-1])
        if chosen not in self.stages:
            h, w = self.base.shape[:2]
            size = (max(1, int(round(w * chosen))), max(1, int(round(h * chosen))))
            if chosen == 1.0:
                img, wts = self.base, self.wbase
            else:
                interp = cv2.INTER_AREA if chosen < 1.0 else cv2.INTER_LINEAR
                img = np.clip(cv2.resize(self.base, size, interpolation=interp), 0, 1)
                wts = cv2.resize(self.wbase, size, interpolation=cv2.INTER_LINEAR)
                if wts.ndim == 2:
                    wts = wts[..., None]
            self.stages[chosen] = (img, np.ascontiguousarray(wts))
        return chosen, self.stages[chosen]

    @staticmethod
    def _blend(wts, x, y, A):
        w = cv2.remap(wts, x, y, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        if w.ndim == 2:
            w = w[..., None]
        return np.tensordot(w, A, axes=([2], [0]))  # H x W x 2 x 3

    @staticmethod
    def _rotation(rel):
        """Angle and pivot of a pure rotation-about-a-point matrix."""
        angle = float(np.arctan2(rel[1, 0], rel[0, 0]))
        if abs(angle) < 1e-6:
            return 0.0, np.zeros(2)
        R = rel[:2, :2]
        pivot = np.linalg.solve(np.eye(2) - R, rel[:2, 2])
        return angle, pivot

    def _draw_chain(self, bone_mats, view, chosen, img, wts, qx, qy, scale):
        """Body -> upper -> lower limb, bent by turning each pixel a weighted share of the joint angle
        about the joint. Unlike blending matrices this keeps the limb's width on a big swing, so a
        raised arm does not smear its shoulder into a wing."""
        B0, B1, B2 = (bone_mats[b] for b in self.bones)
        try:
            a, S = self._rotation(np.linalg.inv(B0) @ B1)
            b, E = self._rotation(np.linalg.inv(B1) @ B2)
        except np.linalg.LinAlgError:
            return None
        if not np.allclose(np.linalg.inv(B0) @ B1, rotate_about(S, np.degrees(a)), atol=1e-3) and abs(a) > 1e-6:
            return None
        if b == 0.0:
            E = np.zeros(2)
        V0inv = np.linalg.inv(view @ B0)
        ux = (V0inv[0, 0] * qx + V0inv[0, 1] * qy + V0inv[0, 2]).astype(np.float32)
        uy = (V0inv[1, 0] * qx + V0inv[1, 1] * qy + V0inv[1, 2]).astype(np.float32)
        # Plain Python floats: NumPy 2 promotes float32 arrays to float64 when mixed with np.float64
        # scalars, which doubled the memory traffic of every full-limb pass below.
        x0, y0, chosen = float(self.x0), float(self.y0), float(chosen)
        S, E = [float(v) for v in S], [float(v) for v in E]

        def at(lam, ux_, uy_):
            """Source of each output point if its pixel sat at chain position lam (0 body, 1 upper,
            2 lower) and how far that source's own position is from lam."""
            if np.ndim(lam) == 0:
                lam = float(lam)
                fs, fe = min(lam, 1.0), max(lam - 1.0, 0.0)
                al = a * fs
                th = al + b * fe
                cth, sth, cal, sal = math.cos(th), math.sin(th), math.cos(al), math.sin(al)
            else:
                fs, fe = np.minimum(lam, 1.0), np.maximum(lam - 1.0, 0.0)
                al = a * fs
                th = al + b * fe
                cth, sth, cal, sal = np.cos(th), np.sin(th), np.cos(al), np.sin(al)
            tx = -(cth * E[0] - sth * E[1]) + (cal * (E[0] - S[0]) - sal * (E[1] - S[1])) + S[0]
            ty = -(sth * E[0] + cth * E[1]) + (sal * (E[0] - S[0]) + cal * (E[1] - S[1])) + S[1]
            dx, dy = ux_ - tx, uy_ - ty
            sx = ((cth * dx + sth * dy - x0) * chosen).astype(np.float32)
            sy = ((-sth * dx + cth * dy - y0) * chosen).astype(np.float32)
            w = cv2.remap(wts, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
            fs_p = 1.0 - w[..., 0]
            fe_p = np.where(fs_p > 1e-4, w[..., 2] / np.maximum(fs_p, 1e-4), 0.0)
            return sx, sy, fs_p + fe_p - lam

        grid = [0.0]
        for start, angle in ((0.0, a), (1.0, b)):
            steps = max(1, int(np.ceil(abs(angle) / 0.15)))
            grid += [start + (i + 1) / steps for i in range(steps)]
        return self._chain_search(at, grid, ux, uy, img)

    def _draw_hem(self, hem, bone_mats, view, chosen, img, wts, qx, qy):
        """A long skirt or apron on the torso: bends at the hips with the lap (and gets as thin as the
        thighs there, so its front does not bulge up into a belly) and again at the knees, where it
        hangs. Chain position lam 0 = torso, 1 = lap, 2 = hanging part; same root search as limbs."""
        lap, drop, squash = np.radians(hem["lap"]), np.radians(hem["drop"]), hem["squash"]
        H, K = np.asarray(hem["hip"], float), np.asarray(hem["knee"], float)
        cl, sl = np.cos(lap), np.sin(lap)
        U1K = H + np.array([cl * squash * (K[0] - H[0]) - sl * (K[1] - H[1]),
                            sl * squash * (K[0] - H[0]) + cl * (K[1] - H[1])])
        V0inv = np.linalg.inv(view @ bone_mats["torso"])
        ux = (V0inv[0, 0] * qx + V0inv[0, 1] * qy + V0inv[0, 2]).astype(np.float32)
        uy = (V0inv[1, 0] * qx + V0inv[1, 1] * qy + V0inv[1, 2]).astype(np.float32)
        x0, y0 = self.x0, self.y0

        def at(lam, ux_, uy_):
            lam = np.asarray(lam, np.float64)
            fs, fe = np.minimum(lam, 1.0), np.maximum(lam - 1.0, 0.0)
            upper = lam <= 1.0
            th = np.where(upper, lap * fs, lap + (drop - lap) * fe)
            sc = np.where(upper, 1.0 + (squash - 1.0) * fs, squash)
            c, s = np.cos(th), np.sin(th)
            px_ = np.where(upper, H[0], K[0])
            py_ = np.where(upper, H[1], K[1])
            ox = np.where(upper, H[0], U1K[0])
            oy = np.where(upper, H[1], U1K[1])
            # u = o + R(th) diag(sc, 1) (p - pivot)  ->  p = pivot + diag(1/sc, 1) R(-th) (u - o)
            dx, dy = ux_ - ox, uy_ - oy
            lx = (c * dx + s * dy) / sc + px_
            ly = (-s * dx + c * dy) + py_
            sx = ((lx - x0) * chosen).astype(np.float32)
            sy = ((ly - y0) * chosen).astype(np.float32)
            w = cv2.remap(wts, sx, sy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
            fs_p = 1.0 - w[..., 0]
            fe_p = np.where(fs_p > 1e-4, w[..., 2] / np.maximum(fs_p, 1e-4), 0.0)
            return sx, sy, (fs_p + fe_p - lam).astype(np.float32)

        grid = [0.0]
        for start, angle in ((0.0, max(abs(lap), 1.0 - squash)), (1.0, abs(drop - lap))):
            steps = max(1, int(np.ceil(angle / 0.15)))
            grid += [start + (i + 1) / steps for i in range(steps)]
        return self._chain_search(at, grid, ux, uy, img)

    @staticmethod
    def _chain_search(at, grid, ux, uy, img):
        # A one-parameter root search along the chain instead of a fixed-point iteration: on a deep
        # bend with a narrow blend the iteration diverges and the knee or elbow drops out.
        best_alpha = np.zeros(ux.shape, np.float32)
        best_x = np.full(ux.shape, -10.0, np.float32)
        best_y = np.full(ux.shape, -10.0, np.float32)
        alpha_img = np.ascontiguousarray(img[..., 3])
        lam0, (sx0_, sy0_, g0) = grid[0], at(grid[0], ux, uy)
        for lam1 in grid[1:]:
            sx1_, sy1_, g1 = at(lam1, ux, uy)
            cross_ = ((g0 >= 0) & (g1 <= 0)) | ((g0 <= 0) & (g1 >= 0))
            iy, ix = np.nonzero(cross_)
            n = len(iy)
            if n:
                # remap maps must stay under 32767 per side: pack the points into rows
                rows = (n + 1023) // 1024

                def pk(v):
                    return np.concatenate([v, np.repeat(v[-1:], rows * 1024 - n)]).reshape(rows, 1024)

                u_x, u_y = pk(ux[iy, ix]), pk(uy[iy, ix])
                lo, hi = np.full(u_x.shape, lam0), np.full(u_x.shape, lam1)
                glo, ghi = pk(g0[iy, ix]), pk(g1[iy, ix])
                for _ in range(4):
                    den = glo - ghi
                    mid = np.where(np.abs(den) > 1e-6, lo + glo * (hi - lo) / np.where(np.abs(den) > 1e-6, den, 1.0), (lo + hi) / 2)
                    mid = np.clip(mid, np.minimum(lo, hi), np.maximum(lo, hi))
                    msx, msy, gm = at(mid, u_x, u_y)
                    same = (gm >= 0) == (glo >= 0)
                    lo, glo = np.where(same, mid, lo), np.where(same, gm, glo)
                    hi, ghi = np.where(same, hi, mid), np.where(same, ghi, gm)
                al_ = cv2.remap(alpha_img, msx, msy, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
                al_ = np.where(np.abs(gm) < 0.03, al_, 0.0).ravel()[:n]
                take = al_ > best_alpha[iy, ix]
                ty_, tx_ = iy[take], ix[take]
                best_alpha[ty_, tx_] = al_[take]
                best_x[ty_, tx_] = msx.ravel()[:n][take]
                best_y[ty_, tx_] = msy.ravel()[:n][take]
            lam0, g0 = lam1, g1
        return cv2.remap(img, best_x, best_y, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)

    def draw(self, bone_mats, view, scale, size, mode=None):
        """Returns (layer HxWx4 premultiplied, sx0, sy0) in screen pixels, or None.

        Inverse skinning per output pixel: a fixed-point search from each bone's rigid guess,
        keeping the solution that lands on the most opaque art."""
        if self.alt_up is not None and mode in self.alt_modes:
            # waving: the hand drawn for a raised arm (only there: at the face, when falling or
            # hugging the hanging hand reads right)
            d = bone_mats[self.bones[-1]][:2, :2] @ self.alt_forearm
            if d[1] < -0.2 * np.hypot(*d):
                return self.alt_up.draw(bone_mats, view, scale, size)
        chosen, (img, wts) = self.stage(scale)
        sh, sw = img.shape[:2]
        local = translate(self.x0, self.y0) @ np.diag([1.0 / chosen, 1.0 / chosen, 1.0])
        mats = [view @ bone_mats[b] @ local for b in self.bones]
        width, height = size
        corners = np.array([[0, sw, 0, sw], [0, 0, sh, sh], [1, 1, 1, 1]], dtype=float)
        pts = np.concatenate([(m @ corners)[:2] for m in mats], axis=1)
        sx0 = max(int(np.floor(pts[0].min())) - 3, 0)
        sy0 = max(int(np.floor(pts[1].min())) - 3, 0)
        sx1 = min(int(np.ceil(pts[0].max())) + 4, width)
        sy1 = min(int(np.ceil(pts[1].max())) + 4, height)
        if sx1 <= sx0 or sy1 <= sy0:
            return None
        qx, qy = np.meshgrid(np.arange(sx0, sx1, dtype=np.float32), np.arange(sy0, sy1, dtype=np.float32))
        if self.bones[1:] == ["hemUpper", "hemLower"] and "hem" in bone_mats:
            return self._draw_hem(bone_mats["hem"], bone_mats, view, chosen, img, wts, qx, qy), sx0, sy0
        if len(self.bones) == 3:
            layer = self._draw_chain(bone_mats, view, chosen, img, wts, qx, qy, scale)
            if layer is not None:
                return layer, sx0, sy0
        A = np.array([m[:2] for m in mats], dtype=np.float32)
        best_alpha = np.zeros(qx.shape, np.float32)
        best_x = np.full(qx.shape, -10.0, np.float32)
        best_y = np.full(qx.shape, -10.0, np.float32)
        alpha_img = np.ascontiguousarray(img[..., 3])
        for start in range(len(mats)):
            inv = np.linalg.inv(mats[start])
            x = (inv[0, 0] * qx + inv[0, 1] * qy + inv[0, 2]).astype(np.float32)
            y = (inv[1, 0] * qx + inv[1, 1] * qy + inv[1, 2]).astype(np.float32)
            for _ in range(6):
                m = self._blend(wts, x, y, A)
                a, b, c = m[..., 0, 0], m[..., 0, 1], m[..., 0, 2]
                d, e, f = m[..., 1, 0], m[..., 1, 1], m[..., 1, 2]
                det = a * e - b * d
                det = np.where(np.abs(det) < 1e-6, 1e-6, det)
                rx, ry = qx - c, qy - f
                x = ((e * rx - b * ry) / det).astype(np.float32)
                y = ((a * ry - d * rx) / det).astype(np.float32)
            m = self._blend(wts, x, y, A)
            fx = m[..., 0, 0] * x + m[..., 0, 1] * y + m[..., 0, 2]
            fy = m[..., 1, 0] * x + m[..., 1, 1] * y + m[..., 1, 2]
            ok = np.hypot(fx - qx, fy - qy) < 0.75
            al = cv2.remap(alpha_img, x, y, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
            al = np.where(ok, al, 0.0)
            take = al > best_alpha
            best_alpha = np.where(take, al, best_alpha)
            best_x = np.where(take, x, best_x)
            best_y = np.where(take, y, best_y)
        layer = cv2.remap(img, best_x, best_y, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        return layer, sx0, sy0

    # --- GPU twin of draw() ------------------------------------------------------------------------
    # Same inverse skinning as _draw_chain/_draw_hem + _chain_search, but in torch on the GPU and
    # batched: every grid step of the chain is evaluated at once (G x H x W), the root refinement runs
    # densely on all intervals, and the per-pixel "most opaque solution, first one on ties" pick is an
    # argmax. Limbs that the CPU path would not bend as a chain fall back to draw() and are uploaded.
    # Off switch: HORROR_GPU_SKIN=0.

    def stage_gpu(self, scale, device):
        chosen, (img, wts) = self.stage(scale)
        cache = self.__dict__.setdefault("_gpu_stages", {})
        key = (chosen, str(device))
        if key not in cache:
            def up(a):
                return torch.from_numpy(np.ascontiguousarray(a)).permute(2, 0, 1).unsqueeze(0).to(device)
            cache[key] = (up(img), up(wts))
        return chosen, img, cache[key]

    def draw_gpu(self, bone_mats, view, scale, size, device, mode=None):
        """(layer 4xHxW premultiplied tensor, sx0, sy0) in screen pixels, or None."""
        if self.alt_up is not None and mode in self.alt_modes:
            d = bone_mats[self.bones[-1]][:2, :2] @ self.alt_forearm
            if d[1] < -0.2 * np.hypot(*d):
                return self.alt_up.draw_gpu(bone_mats, view, scale, size, device)
        chosen, img, (t_img, t_w) = self.stage_gpu(scale, device)
        sh, sw = img.shape[:2]
        local = translate(self.x0, self.y0) @ np.diag([1.0 / chosen, 1.0 / chosen, 1.0])
        mats = [view @ bone_mats[b] @ local for b in self.bones]
        width, height = size
        corners = np.array([[0, sw, 0, sw], [0, 0, sh, sh], [1, 1, 1, 1]], dtype=float)
        pts = np.concatenate([(m @ corners)[:2] for m in mats], axis=1)
        sx0 = max(int(np.floor(pts[0].min())) - 3, 0)
        sy0 = max(int(np.floor(pts[1].min())) - 3, 0)
        sx1 = min(int(np.ceil(pts[0].max())) + 4, width)
        sy1 = min(int(np.ceil(pts[1].max())) + 4, height)
        if sx1 <= sx0 or sy1 <= sy0:
            return None
        layer = None
        if self.bones[1:] == ["hemUpper", "hemLower"] and "hem" in bone_mats:
            layer = self._hem_gpu(bone_mats["hem"], bone_mats, view, chosen, t_img, t_w, sx0, sy0, sx1, sy1)
        elif len(self.bones) == 3:
            layer = self._chain_gpu(bone_mats, view, chosen, t_img, t_w, sx0, sy0, sx1, sy1)
        if layer is not None:
            return layer, sx0, sy0
        drawn = self.draw(bone_mats, view, scale, size, mode=mode)
        if drawn is None:
            return None
        cpu_layer, x, y = drawn
        return torch.from_numpy(np.ascontiguousarray(cpu_layer)).permute(2, 0, 1).to(device), x, y

    @staticmethod
    def _screen_uv(matrix_inv, sx0, sy0, sx1, sy1, device):
        qy, qx = torch.meshgrid(torch.arange(sy0, sy1, dtype=torch.float64, device=device),
                                torch.arange(sx0, sx1, dtype=torch.float64, device=device), indexing="ij")
        m = matrix_inv
        ux = (m[0, 0] * qx + m[0, 1] * qy + m[0, 2]).float()
        uy = (m[1, 0] * qx + m[1, 1] * qy + m[1, 2]).float()
        return ux, uy

    def _chain_gpu(self, bone_mats, view, chosen, t_img, t_w, sx0, sy0, sx1, sy1):
        B0, B1, B2 = (bone_mats[b] for b in self.bones)
        try:
            a, S = self._rotation(np.linalg.inv(B0) @ B1)
            b, E = self._rotation(np.linalg.inv(B1) @ B2)
        except np.linalg.LinAlgError:
            return None
        if not np.allclose(np.linalg.inv(B0) @ B1, rotate_about(S, np.degrees(a)), atol=1e-3) and abs(a) > 1e-6:
            return None
        if b == 0.0:
            E = np.zeros(2)
        x0, y0, chosen = float(self.x0), float(self.y0), float(chosen)
        S0, S1, E0, E1 = float(S[0]), float(S[1]), float(E[0]), float(E[1])
        if _skin_kernel():
            n1 = max(1, int(np.ceil(abs(a) / 0.15)))
            n2 = max(1, int(np.ceil(abs(b) / 0.15)))
            return skin_kernel.run(0, np.linalg.inv(view @ B0), (sx0, sy0, sx1, sy1), (x0, y0, chosen),
                                   (float(a), float(b), S0, S1, E0, E1), n1, n2, t_img, t_w)
        ux, uy = self._screen_uv(np.linalg.inv(view @ B0), sx0, sy0, sx1, sy1, t_img.device)

        def at(lam, ux_, uy_):
            fs, fe = lam.clamp(max=1.0), (lam - 1.0).clamp(min=0.0)
            al = a * fs
            th = al + b * fe
            cth, sth, cal, sal = torch.cos(th), torch.sin(th), torch.cos(al), torch.sin(al)
            tx = -(cth * E0 - sth * E1) + (cal * (E0 - S0) - sal * (E1 - S1)) + S0
            ty = -(sth * E0 + cth * E1) + (sal * (E0 - S0) + cal * (E1 - S1)) + S1
            dx, dy = ux_ - tx, uy_ - ty
            sx = (cth * dx + sth * dy - x0) * chosen
            sy = (-sth * dx + cth * dy - y0) * chosen
            w = remap_gpu(t_w, sx, sy, replicate=True)
            fs_p = 1.0 - w[0]
            fe_p = torch.where(fs_p > 1e-4, w[2] / fs_p.clamp(min=1e-4), torch.zeros_like(fs_p))
            return sx, sy, fs_p + fe_p - lam

        grid = [0.0]
        for start, angle in ((0.0, a), (1.0, b)):
            steps = max(1, int(np.ceil(abs(angle) / 0.15)))
            grid += [start + (i + 1) / steps for i in range(steps)]
        return self._chain_search_gpu(at, grid, ux, uy, t_img)

    def _hem_gpu(self, hem, bone_mats, view, chosen, t_img, t_w, sx0, sy0, sx1, sy1):
        lap, drop, squash = np.radians(hem["lap"]), np.radians(hem["drop"]), hem["squash"]
        H, K = np.asarray(hem["hip"], float), np.asarray(hem["knee"], float)
        cl, sl = np.cos(lap), np.sin(lap)
        U1K = H + np.array([cl * squash * (K[0] - H[0]) - sl * (K[1] - H[1]),
                            sl * squash * (K[0] - H[0]) + cl * (K[1] - H[1])])
        x0, y0, chosen = float(self.x0), float(self.y0), float(chosen)
        lap, drop, squash = float(lap), float(drop), float(squash)
        H0, H1, K0, K1, O0, O1 = (float(v) for v in (H[0], H[1], K[0], K[1], U1K[0], U1K[1]))
        if _skin_kernel():
            n1 = max(1, int(np.ceil(max(abs(lap), 1.0 - squash) / 0.15)))
            n2 = max(1, int(np.ceil(abs(drop - lap) / 0.15)))
            return skin_kernel.run(1, np.linalg.inv(view @ bone_mats["torso"]), (sx0, sy0, sx1, sy1),
                                   (x0, y0, chosen), (lap, drop, squash, H0, H1, K0, K1, O0, O1), n1, n2,
                                   t_img, t_w)
        ux, uy = self._screen_uv(np.linalg.inv(view @ bone_mats["torso"]), sx0, sy0, sx1, sy1, t_img.device)

        def at(lam, ux_, uy_):
            up = (lam <= 1.0).float()                     # 1 on torso->lap, 0 on the hanging part
            fs, fe = lam.clamp(max=1.0), (lam - 1.0).clamp(min=0.0)
            th = up * (lap * fs) + (1.0 - up) * (lap + (drop - lap) * fe)
            sc = up * (1.0 + (squash - 1.0) * fs) + (1.0 - up) * squash
            c, s = torch.cos(th), torch.sin(th)
            px_, py_ = K0 + (H0 - K0) * up, K1 + (H1 - K1) * up
            ox, oy = O0 + (H0 - O0) * up, O1 + (H1 - O1) * up
            dx, dy = ux_ - ox, uy_ - oy
            lx = (c * dx + s * dy) / sc + px_
            ly = (-s * dx + c * dy) + py_
            sx, sy = (lx - x0) * chosen, (ly - y0) * chosen
            w = remap_gpu(t_w, sx, sy, replicate=True)
            fs_p = 1.0 - w[0]
            fe_p = torch.where(fs_p > 1e-4, w[2] / fs_p.clamp(min=1e-4), torch.zeros_like(fs_p))
            return sx, sy, fs_p + fe_p - lam

        grid = [0.0]
        for start, angle in ((0.0, max(abs(lap), 1.0 - squash)), (1.0, abs(drop - lap))):
            steps = max(1, int(np.ceil(angle / 0.15)))
            grid += [start + (i + 1) / steps for i in range(steps)]
        return self._chain_search_gpu(at, grid, ux, uy, t_img)

    @staticmethod
    def _chain_search_gpu(at, grid, ux, uy, t_img):
        lams = torch.tensor(grid, dtype=torch.float32, device=ux.device).view(-1, 1, 1)
        _, _, g = at(lams, ux, uy)                          # G x H x W
        g0, g1 = g[:-1], g[1:]
        cross = ((g0 >= 0) & (g1 <= 0)) | ((g0 <= 0) & (g1 >= 0))
        # Refine only the (interval, pixel) pairs that bracket a root, like the CPU path: dense
        # refinement of every interval kept the GPU at 100% with just two render workers.
        k, iy, ix = cross.nonzero(as_tuple=True)
        width = ux.shape[1]
        bx = torch.full_like(ux, -10.0)
        by = torch.full_like(ux, -10.0)
        if len(k):
            u_x, u_y = ux[iy, ix], uy[iy, ix]
            lo, hi = lams.view(-1)[k], lams.view(-1)[k + 1]
            glo, ghi = g0[k, iy, ix], g1[k, iy, ix]
            for _ in range(4):
                den = glo - ghi
                big = den.abs() > 1e-6
                mid = torch.where(big, lo + glo * (hi - lo) / torch.where(big, den, torch.ones_like(den)), (lo + hi) / 2)
                mid = torch.minimum(torch.maximum(mid, torch.minimum(lo, hi)), torch.maximum(lo, hi))
                msx, msy, gm = at(mid, u_x, u_y)
                same = (gm >= 0) == (glo >= 0)
                lo, glo = torch.where(same, mid, lo), torch.where(same, gm, glo)
                hi, ghi = torch.where(same, hi, mid), torch.where(same, ghi, gm)
            al = remap_gpu(t_img[:, 3:4], msx, msy, replicate=False)[0]
            al = torch.where(gm.abs() < 0.03, al, torch.zeros_like(al))
            # Per pixel: most opaque solution, the first interval on ties, as on the CPU. Alpha is
            # rounded first: inside opaque art two folds both give ~1, and a last-bit difference between
            # grid_sample and cv2.remap must not flip the pick (dark outline specks mid-leg).
            level = torch.round(al * 4096.0).long()
            key = level * 4096 + (4095 - k)
            pixel = iy * width + ix
            best = torch.zeros(ux.numel(), dtype=torch.long, device=ux.device)
            best.scatter_reduce_(0, pixel, key, reduce="amax")
            win = (key == best[pixel]) & (level > 0)
            bx.view(-1)[pixel[win]] = msx[win]
            by.view(-1)[pixel[win]] = msy[win]
        return remap_gpu(t_img, bx, by, replicate=False)


def remap_gpu(src, x, y, replicate):
    """cv2.remap(INTER_LINEAR) for a 1xCxHxW tensor: x, y (same shape) are source pixel coordinates,
    pixel centres on integers. replicate=True is BORDER_REPLICATE, else BORDER_CONSTANT 0.
    Returns a C x <shape of x> tensor."""
    h, w = src.shape[2], src.shape[3]
    shape = x.shape
    gx = x.reshape(1, -1, 1) * (2.0 / max(w - 1, 1)) - 1.0
    gy = y.reshape(1, -1, 1) * (2.0 / max(h - 1, 1)) - 1.0
    out = F.grid_sample(src, torch.stack((gx, gy), dim=-1), mode="bilinear",
                        padding_mode="border" if replicate else "zeros", align_corners=True)
    return out.reshape(src.shape[1], *shape)


GPU_SKIN = os.environ.get("HORROR_GPU_SKIN", "1") != "0"
# HORROR_GPU_SKIN=torch: the torch twin above instead of the fused kernel (engine/skin_kernel.py).
_KERNEL_WANTED = os.environ.get("HORROR_GPU_SKIN", "1") not in ("0", "torch")
skin_kernel = None


def _skin_kernel():
    global skin_kernel, _KERNEL_WANTED
    if not _KERNEL_WANTED:
        return False
    if skin_kernel is None:
        try:
            import skin_kernel as module
            ok = module.available()
        except Exception as exc:
            module, ok = None, False
            print("note: fused limb kernel unavailable (%s); using the torch path" % exc, flush=True)
        if not ok:
            if module is not None:
                print("note: fused limb kernel unavailable (%s); using the torch path" % module._state["error"],
                      flush=True)
            _KERNEL_WANTED = False
            return False
        skin_kernel = module
    return True


class Animations:
    def __init__(self, directory):
        directory = Path(directory)
        self.meta = json.loads((directory / "anims.json").read_text(encoding="utf-8"))
        self.fps = self.meta["fps"]
        self.keys = self.meta["keys"]
        self.frames = self.meta["frames"]
        table = np.fromfile(directory / "anims.bin", dtype=np.float32)
        self.table = table.reshape(len(self.meta["modes"]), self.frames, len(self.keys))

    def sample(self, mode, t):
        """Pose vector of a mode at time t; beyond the baked range the loop is folded back."""
        info = self.meta["modes"][mode]
        duration = max(info["duration"], 1e-3)
        limit = (self.frames - 2) / self.fps
        if t > limit:
            t = t % duration + np.floor((limit - duration) / duration) * duration
        position = max(t, 0.0) * self.fps
        low = int(position)
        rows = self.table[info["index"]]
        return rows[low] + (rows[low + 1] - rows[low]) * (position - low)

    def arm_front(self, mode, t):
        flags = self.meta["modes"][mode]["armFront"]
        if not flags:
            return False
        return bool(flags[min(int(t * self.fps), self.frames - 1)])


class Puppet:
    def __init__(self, package_dir, animations):
        self.dir = Path(package_dir)
        self.anims = animations
        self.doc = json.loads((self.dir / "layers.json").read_text(encoding="utf-8"))
        atlas_path = self.dir / "faces" / "faces.json"
        self.atlas = json.loads(atlas_path.read_text(encoding="utf-8")) if atlas_path.is_file() else None
        self.size = self.doc["canvas"]["size"]
        self.layers = [layer for layer in self.doc["layers"] if not layer.get("empty") and layer["bone"] != "ground"]
        self.pivots = {bone: np.array(info["pivot"], dtype=float) for bone, info in self.doc["rig"]["bones"].items()}
        self._images = {}
        self._measure()
        self._split_stack()
        self._heads = OrderedDict()

    # --- loading -----------------------------------------------------------------------------

    def _image(self, relative):
        if relative not in self._images:
            self._images[relative] = read_rgba(self.dir / relative)
        return self._images[relative]

    def _box(self, key, image):
        """(y0, y1, x0, x1) of the image's non-empty pixels, or None; cached under key."""
        boxes = self.__dict__.setdefault("_boxes", {})
        if key not in boxes:
            ys, xs = np.nonzero(np.abs(image).max(axis=2) > 0)
            boxes[key] = (ys.min(), ys.max() + 1, xs.min(), xs.max() + 1) if len(ys) else None
        return boxes[key]

    def _over_cached(self, canvas, key, image):
        """over() limited to the image's non-empty box (premultiplied: outside it nothing changes).
        A face layer is a small patch on a full-size canvas, so this is most of head_sprite's time."""
        box = self._box(key, image)
        if box is not None:
            y0, y1, x0, x1 = box
            over(canvas[y0:y1, x0:x1], image[y0:y1, x0:x1])

    def _flatten(self, layers):
        canvas = np.zeros((self.size, self.size, 4), np.float32)
        for layer in layers:
            over(canvas, self._image(layer["file"]))
        return canvas

    def _silhouette(self, bone):
        chosen = [layer for layer in self.layers if layer["bone"] == bone]
        mask = np.zeros((self.size, self.size), np.float32)
        for layer in chosen:
            mask = np.maximum(mask, self._image(layer["file"])[..., 3])
        return mask > 0.5

    def _joint_between(self, upper, lower):
        overlap = self._silhouette(upper) & self._silhouette(lower)
        ys, xs = np.nonzero(overlap)
        if not len(xs):
            raise ValueError("no overlap between %s and %s" % (upper, lower))
        return np.array([xs.mean(), ys.mean()])

    def _measure(self):
        p = self.pivots
        if "joints" in self.doc:  # AI packs carry their joints; their limbs have no Gacha overlap to measure
            self.joints = {k: np.array(v, dtype=float) for k, v in self.doc["joints"].items()}
            self._measure_frame()
            return
        elbow_l = self._joint_between("armUpperFront", "armLowerFront")
        elbow_r = self._joint_between("armUpperBack", "armLowerBack")
        knee_l = self._joint_between("legUpperFront", "legLowerFront")
        knee_r = self._joint_between("legUpperBack", "legLowerBack")
        shoulder_l = top_cap_center(self._silhouette("armUpperFront"))
        shoulder_r = top_cap_center(self._silhouette("armUpperBack"))
        hip_l = 0.55 * top_cap_center(self._silhouette("legUpperFront")) + 0.45 * p["legUpperFront"]
        hip_r = 0.55 * top_cap_center(self._silhouette("legUpperBack")) + 0.45 * p["legUpperBack"]

        self.joints = {
            "neck": p["head"],
            "waist": p["hips"] + np.array([0.0, -32.0]),
            "shoulderL": shoulder_l,
            "shoulderR": shoulder_r,
            "hipL": hip_l,
            "hipR": hip_r,
            "elbowL": elbow_l,
            "elbowR": elbow_r,
            "kneeL": knee_l,
            "kneeR": knee_r,
        }
        self._measure_frame()

    def _measure_frame(self):
        p = self.pivots
        boxes = np.array([layer["bounds"] for layer in self.layers if layer.get("bounds")])
        self.top = float(boxes[:, 1].min())
        self.floor = float(boxes[:, 3].max())
        self.center_x = float(p["hips"][0])
        self.unit = (self.floor - p["hips"][1]) / STUDIO_LEG_LENGTH

    def _round_lower_stub(self, canvas, joint):
        """Round the flat top cut (along < 0) of a lower limb around its elbow/knee pivot so its
        square corners stay inside the upper limb's rounded cap."""
        alpha = canvas[..., 3]
        ys, xs = np.nonzero(alpha > 0.05)
        if not len(xs):
            return canvas
        far_mask = np.hypot(xs - joint[0], ys - joint[1]) > 35
        toward = np.array([xs[far_mask].mean(), ys[far_mask].mean()]) if far_mask.any() else np.array([xs.mean(), ys.mean()])
        axis = toward - joint
        norm = np.linalg.norm(axis)
        if norm < 1e-3:
            return canvas
        axis = axis / norm

        y0, y1 = max(0, int(ys.min()) - 2), min(self.size, int(ys.max()) + 3)
        x0, x1 = max(0, int(xs.min()) - 2), min(self.size, int(xs.max()) + 3)
        gy, gx = np.mgrid[y0:y1, x0:x1]
        dx, dy = gx - joint[0], gy - joint[1]
        along = dx * axis[0] + dy * axis[1]
        across = -dx * axis[1] + dy * axis[0]
        dist = np.hypot(dx, dy)

        solid = alpha[y0:y1, x0:x1] > 0.5
        near = solid & (np.abs(along) < 3.0)
        half_w = float(np.abs(across[near]).max()) if near.any() else 22.0
        cap_r = max(half_w * 0.76, 8.0)
        keep_stub = np.clip((cap_r - dist) / 1.8 + 0.5, 0.0, 1.0)
        blend = np.clip((along - 2.0) / 3.5 + 0.5, 0.0, 1.0)
        factor = blend + (1.0 - blend) * keep_stub
        out = canvas.copy()
        out[y0:y1, x0:x1] *= factor[..., None].astype(np.float32)
        return out

    def _split_stack(self):
        """Runs of same-bone layers become one sprite each; upper arm sleeves are separated so cuffs stay crisp."""
        def is_face(layer):
            return str(layer["name"]).startswith(FACE_FEATURES)

        first_face = next(i for i, layer in enumerate(self.layers) if is_face(layer))
        last_face = max(i for i, layer in enumerate(self.layers) if is_face(layer))
        head_start = first_face
        while head_start > 0 and self.layers[head_start - 1]["bone"] == "head":
            head_start -= 1
        head_end = last_face
        while head_end + 1 < len(self.layers) and self.layers[head_end + 1]["bone"] == "head":
            head_end += 1

        self.head_under = self._flatten(self.layers[head_start:first_face])
        self.head_over = self._flatten(self.layers[last_face + 1:head_end + 1])
        self.base_face = [layer for layer in self.layers[first_face:last_face + 1] if is_face(layer)]

        lower_joints = {
            "armLowerFront": "elbowL",
            "armLowerBack": "elbowR",
            "legLowerFront": "kneeL",
            "legLowerBack": "kneeR",
        }
        caps = {
            "armUpperFront": ("shoulderL", "elbowL", True),
            "armUpperBack": ("shoulderR", "elbowR", True),
            "legUpperFront": ("hipL", "kneeL", False),
            "legUpperBack": ("hipR", "kneeR", False),
        }

        def make_sprite(bone, layers_list):
            flat = self._flatten(layers_list)
            if bone in lower_joints:
                flat = self._round_lower_stub(flat, self.joints[lower_joints[bone]])
            sp = Sprite(flat)
            if not sp.empty and bone in caps:
                joint, toward, stroke = caps[bone]
                sp.make_cap(self.joints[joint], self.joints[toward], self._outline(sp) if stroke else None)
            return sp

        def runs(layers):
            found = []
            for layer in layers:
                if layer.get("weights"):
                    found.append((layer["bone"], [layer], True))
                elif found and found[-1][0] == layer["bone"] and not found[-1][2]:
                    found[-1][1].append(layer)
                else:
                    found.append((layer["bone"], [layer], False))
            out = []
            for bone, items, skinned in found:
                if skinned:
                    layer = items[0]
                    wimg = cv2.imdecode(np.fromfile(str(self.dir / layer["weights"]), np.uint8), cv2.IMREAD_UNCHANGED)
                    wimg = wimg.astype(np.float32) / 255.0
                    if wimg.ndim == 2:
                        wimg = wimg[..., None]
                    sp = SkinSprite(self._image(layer["file"]), wimg, layer["skin"])
                    alt = layer.get("alt_up")
                    if alt and not sp.empty:
                        # the same arm with the hand the other way round, for a raised forearm
                        sp.alt_up = SkinSprite(self._image(alt["file"]), wimg, layer["skin"])
                        sp.alt_forearm = np.asarray(alt["forearm"], float)
                        sp.alt_modes = tuple(alt.get("modes", ("wave",)))
                    if not sp.empty:
                        out.append((bone, sp, None, None))
                    continue
                if bone in ("armUpperFront", "armUpperBack"):
                    skin_items = [l for l in items if not str(l["name"]).startswith("sleeves")]
                    sleeve_items = [l for l in items if str(l["name"]).startswith("sleeves")]
                    if skin_items and sleeve_items:
                        sp_full = make_sprite(bone, items)
                        sp_skin = make_sprite(bone, skin_items)
                        sp_slv = make_sprite(bone, sleeve_items)
                        out.append((bone, sp_full, sp_skin, sp_slv))
                        continue
                sp = make_sprite(bone, items)
                if not sp.empty:
                    out.append((bone, sp, None, None))
            return out

        self.below_runs = runs(self.layers[:head_start])
        self.above_runs = runs(self.layers[head_end + 1:])
        self.below = [(b, sp) for b, sp, _, _ in self.below_runs if not sp.empty]
        self.above = [(b, sp) for b, sp, _, _ in self.above_runs if not sp.empty]
        self.provenance = self.doc.get("provenance", {}).get("selectors", {})
        self.default_eyes = self.provenance.get("eyes1x1", {}).get("value")
        self.default_mouth = self.provenance.get("mouth1", {}).get("value")
        # AI packs: their own talking mouths (closed, small, mid, wide) and drawn closed eyes for blinks
        self.talk_mouths = tuple((self.atlas or {}).get("talk", ())) or None
        self.blink_eyes = (self.atlas or {}).get("blink")
        self._images.clear()

    @staticmethod
    def _outline(sprite):
        """Premultiplied colour of the limb's ink line: the darkest solid pixels of its art."""
        solid = sprite.base[sprite.base[..., 3] > 0.95][:, :3]
        if not len(solid):
            return None
        luma = solid.mean(axis=1)
        return solid[luma <= np.percentile(luma, 8)].mean(axis=0)

    # --- face --------------------------------------------------------------------------------

    def _base_face(self):
        """The character's own eyes and mouth, as exported from Gacha (the first verified sample)."""
        verified = (self.atlas or {}).get("verified") or [{}]
        return verified[0].get("eyes"), verified[0].get("mouth")

    def _face_layers(self, eyes, mouth):
        # "base" means the pack's own eyes/mouth, so one scene works for packs whose native eyes differ.
        base_eyes, base_mouth = self._base_face()
        eyes = base_eyes if eyes == "base" else eyes
        mouth = base_mouth if mouth == "base" else mouth
        chosen = []
        for key, value, kind in ((mouth, "mouths", "mouth"), (eyes, "eyes", "eyes")):
            match = [item for item in self.atlas[value] if item["value"] == key]
            if not match:
                raise ValueError("no measured %s %r in %s" % (kind, key, self.dir.name))
            chosen.extend(match[0]["layers"])
        return chosen

    def head_sprite(self, eyes, mouth, blink):
        key = (eyes, mouth, round(blink * 4) / 4)
        cached = self._heads.get(key)
        if cached is not None:
            self._heads.move_to_end(key)
            return cached
        canvas = self.head_under.copy()
        if self.blink_eyes is not None:
            # drawn closed eyes instead of squashing the open ones
            layers = self._face_layers(self.blink_eyes if key[2] >= 0.5 else eyes, mouth)
            key_blink = 0
        else:
            layers = self._face_layers(eyes, mouth)
            key_blink = key[2]
        eye_box = None
        if key_blink > 0:
            files = tuple(l["file"] for l in layers if l["name"].startswith(EYE_PREFIXES))
            centres = self.__dict__.setdefault("_eye_centres", {})
            if files not in centres:
                ys, xs = np.nonzero(np.max([self._image(f)[..., 3] for f in files], axis=0) > 0.1) if files else ((), ())
                centres[files] = (ys.min() + ys.max()) / 2.0 if len(ys) else None
            eye_box = centres[files]
        for layer in layers:
            image = self._image(layer["file"])  # cached: a talking/blinking face rebuilds its head often
            if eye_box is not None and layer["name"].startswith(EYE_PREFIXES):
                height = max(0.04, 1.0 - key_blink)
                matrix = np.array([[1, 0, 0], [0, height, eye_box * (1 - height)]], dtype=np.float32)
                # only the columns that hold the eye: the squash is vertical, so this is exact
                box = self._box(layer["file"], image)
                if box is not None:
                    x0, x1 = box[2], box[3]
                    strip = cv2.warpAffine(np.ascontiguousarray(image[:, x0:x1]), matrix, (x1 - x0, self.size),
                                           flags=cv2.INTER_LINEAR)
                    over(canvas[:, x0:x1], strip)
            else:
                self._over_cached(canvas, layer["file"], image)
        self._over_cached(canvas, "<head_over>", self.head_over)
        sprite = Sprite(canvas)
        self._heads[key] = sprite
        while len(self._heads) > 48:
            self._heads.popitem(last=False)
        return sprite

    # --- pose --------------------------------------------------------------------------------

    @staticmethod
    def _adapt_gacha_arms(p):
        """Adapt studio arm angles to Gacha A-pose proportions and back-arm depth ordering."""
        p = dict(p)
        arm_l, fore_l = float(p["armL"]), float(p["foreL"])
        arm_r, fore_r = float(p["armR"]), float(p["foreR"])
        torso_ang = float(p.get("torso", 0.0))
        sitting = (float(p.get("thighR", 0.0)) < -45.0) and (abs(torso_ang) < 40.0)
        high_reach_r = (arm_r + fore_r < -135.0) or (arm_r < -70.0) or (arm_r > 65.0)

        # 1. Back arm (armUpperBack / armLowerBack sits behind torso):
        # Positive foreR in the studio folds the forearm across the chest, which behind an opaque Gacha torso
        # hides the hand behind the spine and leaves a severed elbow spike sticking out of the ribs.
        if not high_reach_r:
            if fore_r > 10.0 or arm_r > 12.0:
                tuck = min(max((max(fore_r - 10.0, arm_r - 12.0)) / 25.0, 0.0), 1.0)
                target_ar = -12.0 if sitting else 1.5
                target_fr = -15.0 if sitting else -6.0
                arm_r = arm_r * (1.0 - tuck) + target_ar * tuck
                fore_r = fore_r * (1.0 - tuck) + target_fr * tuck
            else:
                if sitting:
                    # Rest the back hand on/beside the right thigh so the shoulder & hand stay visible
                    if arm_r < 0.0:
                        arm_r *= 0.45
                    if fore_r < 0.0:
                        fore_r *= 0.42
                else:
                    # Standing: Gacha rest pose is already ~22 deg outward in an A-pose, so damp outward reach
                    if arm_r < 0.0:
                        arm_r *= 0.42
                    if fore_r < 0.0:
                        fore_r *= 0.45

        # 2. Front arm (armUpperFront / armLowerFront):
        # Preserve full reach for high face/head gestures (thinking, cry, cover_face, wave, point, salute),
        # while gently damping moderate waist/lap bends so short Gacha arms stay balanced over the body.
        high_reach = (arm_l + fore_l < -135.0) or (arm_l < -75.0) or (arm_l > 65.0)
        if not high_reach:
            if sitting:
                if arm_l < 0.0:
                    arm_l *= 0.52
                if fore_l < 0.0:
                    fore_l *= 0.58
            else:
                if arm_l < -10.0:
                    arm_l = -10.0 + (arm_l + 10.0) * 0.65
                if fore_l < -10.0:
                    fore_l = -10.0 + (fore_l + 10.0) * 0.65

        p["armL"], p["foreL"] = arm_l, fore_l
        p["armR"], p["foreR"] = arm_r, fore_r
        return p

    def rig(self, pose, keys):
        p = self._adapt_gacha_arms(dict(zip(keys, pose)))
        # A pack drawn in its own rest pose (AI packs: arms out) turns back to the Gacha rest here.
        for key, offset in self.doc.get("restOffsets", {}).items():
            p[key] = p[key] + offset
        j = self.joints
        unit = self.unit
        root = translate(p["sway"] * unit, p["bob"] * unit)
        torso = root @ rotate_about(j["waist"], p["torso"])
        head = torso @ rotate_about(j["neck"], p["head"])
        upper_l = torso @ rotate_about(j["shoulderL"], p["armL"])
        lower_l = upper_l @ rotate_about(j["elbowL"], p["foreL"])
        upper_r = torso @ rotate_about(j["shoulderR"], p["armR"])
        lower_r = upper_r @ rotate_about(j["elbowR"], p["foreR"])
        thigh_l = root @ rotate_about(j["hipL"], p["thighL"])
        shin_l = thigh_l @ rotate_about(j["kneeL"], p["shinL"])
        thigh_r = root @ rotate_about(j["hipR"], p["thighR"])
        shin_r = thigh_r @ rotate_about(j["kneeR"], p["shinR"])
        bones = {"root": root, "hips": root, "torso": torso, "head": head,
                 "armUpperFront": upper_l, "armLowerFront": lower_l,
                 "armUpperBack": upper_r, "armLowerBack": lower_r,
                 "legUpperFront": thigh_l, "legLowerFront": shin_l,
                 "legUpperBack": thigh_r, "legLowerBack": shin_r}
        hem = self.doc.get("hem")
        if hem:
            bones.update(self._hem_bones(hem, torso, p))
        return bones, p

    @staticmethod
    def _hem_bones(hem, torso, p):
        """A long skirt, apron or coat tail (AI packs): the lap follows the forward thigh, fully when
        sitting and damped on a step; below the knee the cloth follows the shin but never swings
        past hanging straight down, so it drapes over the knees when sitting or kneeling."""
        front = p["thighL"] <= p["thighR"]
        thigh = min(p["thighL"], p["thighR"], 0.0)
        if hem.get("balance"):
            # on a step the other thigh swings back: the skirt hangs between them instead of
            # following the front one and baring the back one; sitting, both are forward
            thigh += max(p["thighL"], p["thighR"], 0.0)
        k = float(np.clip((abs(thigh) - hem.get("calm", 10.0)) / hem.get("ramp", 30.0), 0.0, 1.0))
        k = hem.get("damp", 0.55) + (1.0 - hem.get("damp", 0.55)) * k * k * (3 - 2 * k)
        lap = thigh * k
        shin = (p["thighL"] + p["shinL"]) if front else (p["thighR"] + p["shinR"])
        drop = float(np.clip(shin, min(lap, 0.0), max(lap, 0.0)))
        # On the lap the cloth is seen edge-on: as thick as the thighs, not as wide as the apron.
        squash = 1.0 - (1.0 - hem.get("squash", 0.5)) * abs(np.sin(np.radians(lap))) ** hem.get("squash_pow", 1.0)
        rel_lap, rel_drop = lap - p["torso"], drop - p["torso"]
        H, K = np.array(hem["hip"], float), np.array(hem["knee"], float)
        sq = np.diag([squash, 1.0, 1.0])
        up_local = rotate_about(H, rel_lap) @ translate(*H) @ sq @ translate(*-H)
        knee_at = (up_local @ np.array([K[0], K[1], 1.0]))[:2]
        low_local = translate(*knee_at) @ rotate_about((0.0, 0.0), rel_drop) @ sq @ translate(*-K)
        return {"hemUpper": torso @ up_local, "hemLower": torso @ low_local,
                "hem": {"lap": rel_lap, "drop": rel_drop, "squash": squash, "hip": H, "knee": K}}

    def _expand_runs(self, runs_list, adapted_pose):
        """Place the upper-arm sleeve cuff over the bare elbow joint unless the forearm folds acutely back."""
        out = []
        i = 0
        while i < len(runs_list):
            bone, sp_full, sp_skin, sp_slv = runs_list[i]
            if bone in ("armUpperFront", "armUpperBack") and sp_skin is not None and sp_slv is not None:
                lower_bone = "armLowerFront" if bone == "armUpperFront" else "armLowerBack"
                fore_key = "foreL" if bone == "armUpperFront" else "foreR"
                fore_ang = adapted_pose.get(fore_key, 0.0)
                if i + 1 < len(runs_list) and runs_list[i + 1][0] == lower_bone and fore_ang >= -88.0:
                    out.append((bone, sp_skin))
                    out.append((lower_bone, runs_list[i + 1][1]))
                    out.append((bone, sp_slv))
                    i += 2
                    continue
            out.append((bone, sp_full))
            i += 1
        return out

    def _build_stack(self, pose, keys, eyes, mouth, blink, arm_front):
        eyes = self.default_eyes if eyes is None else eyes
        mouth = self.default_mouth if mouth is None else mouth
        bones, named = self.rig(pose, keys)
        swings = {"armUpperFront": named["armL"], "armUpperBack": named["armR"],
                  "legUpperFront": named["thighL"], "legUpperBack": named["thighR"]}
        head = ("head", self.head_sprite(eyes, mouth, blink))
        stack = self._expand_runs(self.below_runs, named)
        above = self._expand_runs(self.above_runs, named)
        reach_head = arm_front and (named["armL"] + named["foreL"] < -120.0 or named["armL"] < -70.0)
        if reach_head:
            arm = [item for item in stack if item[0] == "armLowerFront"]
            stack = [item for item in stack if item[0] != "armLowerFront"]
            stack += [head] + above + arm
        else:
            stack += [head] + above
        return bones, swings, stack

    def render(self, pose, keys, view, size, eyes=None, mouth=None, blink=0.0, arm_front=False, mode=None):
        """Draw the character on CPU using tight per-sprite sub-boxes. Returns (premult RGBA ROI, x, y) or None."""
        bones, swings, stack = self._build_stack(pose, keys, eyes, mouth, blink, arm_front)
        scale = float(np.sqrt(abs(np.linalg.det(view[:2, :2]))))
        width, height = size

        placed = []
        x_min, y_min, x_max, y_max = width, height, 0, 0
        for bone, sprite in stack:
            if isinstance(sprite, SkinSprite):
                drawn = sprite.draw(bones, view, scale, size, mode=mode)
                if drawn is not None:
                    layer, sx0, sy0 = drawn
                    sx1, sy1 = sx0 + layer.shape[1], sy0 + layer.shape[0]
                    x_min, y_min = min(x_min, sx0), min(y_min, sy0)
                    x_max, y_max = max(x_max, sx1), max(y_max, sy1)
                    placed.append((layer, None, sx0, sy0, sx1, sy1))
                continue
            thresh = 20.0 if "arm" in bone else 14.0
            amount = float(np.clip((abs(swings.get(bone, 0.0)) - thresh) / 24.0, 0.0, 1.0))
            chosen, image = sprite.stage_capped(scale, amount)
            sh, sw = image.shape[:2]
            local = translate(sprite.x0, sprite.y0) @ np.diag([1.0 / chosen, 1.0 / chosen, 1.0])
            matrix = view @ bones[bone] @ local
            corners = matrix @ np.array([[0, sw, 0, sw], [0, 0, sh, sh], [1, 1, 1, 1]], dtype=float)
            sx0 = max(int(np.floor(corners[0].min())) - 3, 0)
            sy0 = max(int(np.floor(corners[1].min())) - 3, 0)
            sx1 = min(int(np.ceil(corners[0].max())) + 4, width)
            sy1 = min(int(np.ceil(corners[1].max())) + 4, height)
            if sx1 > sx0 and sy1 > sy0:
                x_min = min(x_min, sx0)
                y_min = min(y_min, sy0)
                x_max = max(x_max, sx1)
                y_max = max(y_max, sy1)
                placed.append((image, matrix, sx0, sy0, sx1, sy1))

        if x_max <= x_min or y_max <= y_min:
            return None
        roi = np.zeros((y_max - y_min, x_max - x_min, 4), np.float32)
        for image, matrix, sx0, sy0, sx1, sy1 in placed:
            if matrix is None:  # skinned limb, already in screen pixels
                over(roi[sy0 - y_min:sy1 - y_min, sx0 - x_min:sx1 - x_min], image)
                continue
            target = (translate(-sx0, -sy0) @ matrix)[:2].astype(np.float32)
            layer = cv2.warpAffine(image, target, (sx1 - sx0, sy1 - sy0), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
            over(roi[sy0 - y_min:sy1 - y_min, sx0 - x_min:sx1 - x_min], layer)
        return roi, x_min, y_min

    def render_gpu(self, pose, keys, view, size, device, eyes=None, mouth=None, blink=0.0, arm_front=False, mode=None):
        """Draw the character directly on CUDA GPU (1x4xHxW tensor). Returns (roi_tensor_4xHxW, x, y) or None."""
        bones, swings, stack = self._build_stack(pose, keys, eyes, mouth, blink, arm_front)
        scale = float(np.sqrt(abs(np.linalg.det(view[:2, :2]))))
        width, height = size

        placed = []
        x_min, y_min, x_max, y_max = width, height, 0, 0
        for bone, sprite in stack:
            if isinstance(sprite, SkinSprite):
                if GPU_SKIN:
                    drawn = sprite.draw_gpu(bones, view, scale, size, device, mode=mode)
                    if drawn is not None:
                        t_layer, sx0, sy0 = drawn
                        sx1, sy1 = sx0 + t_layer.shape[2], sy0 + t_layer.shape[1]
                else:
                    drawn = sprite.draw(bones, view, scale, size, mode=mode)
                    if drawn is not None:
                        layer, sx0, sy0 = drawn
                        sx1, sy1 = sx0 + layer.shape[1], sy0 + layer.shape[0]
                        t_layer = torch.from_numpy(np.ascontiguousarray(layer)).permute(2, 0, 1).to(device)
                if drawn is not None:
                    x_min, y_min = min(x_min, sx0), min(y_min, sy0)
                    x_max, y_max = max(x_max, sx1), max(y_max, sy1)
                    placed.append((t_layer, None, None, None, sx0, sy0, sx1, sy1))
                continue
            thresh = 20.0 if "arm" in bone else 14.0
            amount = float(np.clip((abs(swings.get(bone, 0.0)) - thresh) / 24.0, 0.0, 1.0))
            chosen, t_img, sh, sw = sprite.stage_capped_gpu(scale, amount, device)
            local = translate(sprite.x0, sprite.y0) @ np.diag([1.0 / chosen, 1.0 / chosen, 1.0])
            matrix = view @ bones[bone] @ local
            corners = matrix @ np.array([[0, sw, 0, sw], [0, 0, sh, sh], [1, 1, 1, 1]], dtype=float)
            sx0 = max(int(np.floor(corners[0].min())) - 3, 0)
            sy0 = max(int(np.floor(corners[1].min())) - 3, 0)
            sx1 = min(int(np.ceil(corners[0].max())) + 4, width)
            sy1 = min(int(np.ceil(corners[1].max())) + 4, height)
            if sx1 > sx0 and sy1 > sy0:
                x_min = min(x_min, sx0)
                y_min = min(y_min, sy0)
                x_max = max(x_max, sx1)
                y_max = max(y_max, sy1)
                placed.append((t_img, sw, sh, matrix, sx0, sy0, sx1, sy1))

        if x_max <= x_min or y_max <= y_min:
            return None
        roi = torch.zeros((4, y_max - y_min, x_max - x_min), dtype=torch.float32, device=device)
        for t_img, sw, sh, matrix, sx0, sy0, sx1, sy1 in placed:
            if matrix is None:  # skinned limb, already in screen pixels
                dst = roi[:, sy0 - y_min:sy1 - y_min, sx0 - x_min:sx1 - x_min]
                dst.mul_(1.0 - t_img[3:4]).add_(t_img)
                continue
            sub_w, sub_h = sx1 - sx0, sy1 - sy0
            m_sub = translate(-sx0, -sy0) @ matrix
            theta = torch.from_numpy(_affine_theta(m_sub, sw, sh, sub_w, sub_h)).unsqueeze(0).to(device)
            grid = F.affine_grid(theta, (1, 4, sub_h, sub_w), align_corners=False)
            layer = F.grid_sample(t_img, grid, mode="bilinear", padding_mode="zeros", align_corners=False).squeeze(0)
            dst = roi[:, sy0 - y_min:sy1 - y_min, sx0 - x_min:sx1 - x_min]
            dst.mul_(1.0 - layer[3:4]).add_(layer)
        return roi, x_min, y_min
