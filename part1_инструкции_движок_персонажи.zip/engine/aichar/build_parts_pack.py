"""AI-repainted parts sheet -> engine pack on the template's own Gacha rig.

    python build_parts_pack.py <char_dir> <template_pack> <layout.json> <out_pack> <slug>

char_dir/sheet.png: Nano Banana's repaint of ai_chars/шаблон_детали.png (made by make_parts_sheet.py)
into the character. Every piece is whole, like a Gacha sprite (round shoulder, body without arms,
neck under the hair), so nothing is cut out of a picture or guessed: each piece is lifted off the
sheet, put back where the template's piece sits at rest, and bent on the template's joints.

Other pictures in char_dir are edits of sheet.png with only the face changed, named as for
build_skin_pack.py: mouth_<name>, eyes_closed, <emotion>.
"""
import json
import shutil
import sys
from pathlib import Path

import cv2
import numpy as np

ENGINE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ENGINE))
sys.path.insert(0, str(Path(__file__).parent))
from puppet import Animations, Puppet
from groups import GROUPS
from mirror_hand import drawn_mirrored, mirror_forearm, skin_mask

IMAGE_EXT = (".png", ".jpg", ".jpeg", ".webp")
char_dir, template, layout_path, out, slug = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3]), Path(sys.argv[4]), sys.argv[5]
layout = json.loads(layout_path.read_text(encoding="utf-8"))
SCALE, SHEET = layout["scale"], layout["sheet"]
pup = Puppet(template, Animations(ENGINE / "anims"))
size = pup.size
tdoc = json.loads((Path(template) / "layers.json").read_text(encoding="utf-8"))
pics = {p.stem: p for p in sorted(char_dir.iterdir()) if p.suffix.lower() in IMAGE_EXT}
if "sheet" not in pics:
    sys.exit("no sheet.png in %s" % char_dir)
variants = {k: v for k, v in pics.items() if k not in ("sheet", "A", "body", "arms")}
ORDER = ["armB", "legB", "legF", "torso", "armF", "head"]


def read_sheet(path):
    im = cv2.imdecode(np.fromfile(str(path), np.uint8), cv2.IMREAD_COLOR)
    h, w = im.shape[:2]
    if h != w:
        s = max(h, w)
        pad = np.full((s, s, 3), im[2, 2], np.uint8)
        pad[(s - h) // 2:(s - h) // 2 + h, (s - w) // 2:(s - w) // 2 + w] = im
        im = pad
    if im.shape[0] != SHEET:
        im = cv2.resize(im, (SHEET, SHEET), interpolation=cv2.INTER_AREA)
    return im


def key_image(img):
    f = img.astype(np.float32)
    key = f[..., 1] - np.maximum(f[..., 0], f[..., 2])
    alpha = 1.0 - np.clip((key - 25.0) / 70.0, 0, 1)
    spill = np.maximum(f[..., 0], f[..., 2])
    f[..., 1] = np.where(key > 0, spill, f[..., 1])
    return np.clip(f, 0, 255).astype(np.uint8), alpha


# --- template pieces where the sheet put them --------------------------------------------------
tsheet = np.zeros((SHEET, SHEET), np.float32)
tpiece = {}
for g, bones in GROUPS.items():
    m = np.zeros((size, size), np.float32)
    for layer in pup.layers:
        if layer["bone"] in bones:
            m = np.maximum(m, pup._image(layer["file"])[..., 3])
    ox, oy = layout["parts"][g]["canvas_origin"]
    px, py = layout["parts"][g]["sheet_origin"]
    M = np.float32([[SCALE, 0, px - ox * SCALE], [0, SCALE, py - oy * SCALE]])
    tpiece[g] = cv2.warpAffine(m, M, (SHEET, SHEET), flags=cv2.INTER_LINEAR)


def lift(img_bgr):
    """Pieces of one sheet: {group: (rgb, alpha) on the sheet} and each piece's shift vs the template."""
    rgb, alpha = key_image(img_bgr)
    n, cl, st, _ = cv2.connectedComponentsWithStats((alpha > 0.5).astype(np.uint8), 8)
    owner = {}
    for i in range(1, n):
        if st[i, cv2.CC_STAT_AREA] < 60:
            continue
        comp = cl == i
        best, best_v = None, 0.0
        for g in GROUPS:
            x0, y0, x1, y1 = layout["parts"][g]["box"]
            box = np.zeros_like(comp)
            box[max(y0 - 30, 0):y1 + 30, max(x0 - 30, 0):x1 + 30] = True
            v = (comp & box).sum() + 3.0 * (comp & (tpiece[g] > 0.5)).sum()
            if v > best_v:
                best, best_v = g, v
        if best:
            owner.setdefault(best, []).append(i)
    pieces = {}
    for g in GROUPS:
        m = np.isin(cl, owner.get(g, [-1]))
        m = cv2.dilate(m.astype(np.uint8), np.ones((5, 5), np.uint8)) > 0
        a = alpha * m
        # where does this piece sit vs the template's? (the AI shifts pieces a little)
        warp = np.eye(2, 3, dtype=np.float32)
        try:
            _, warp = cv2.findTransformECC(cv2.GaussianBlur(tpiece[g], (0, 0), 3), cv2.GaussianBlur(a.astype(np.float32), (0, 0), 3),
                                           warp, cv2.MOTION_TRANSLATION,
                                           (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 100, 1e-4), None, 5)
        except cv2.error:
            pass
        shift = warp[:, 2].copy()
        fit = np.float32([[1, 0, 0], [0, 1, 0]])
        if g in ("head", "torso"):
            # a cap, a hood or a long coat changes these silhouettes on purpose: matching the
            # outline would pull the neck or the hips off their joints. The sheet layout holds.
            shift[:] = 0
        if np.hypot(*shift) > 40:
            # Redrawn, not just nudged (the narrator's legs: straight, longer, off to one side).
            # Fit the piece's box onto the template's, then let ECC refine it as an affine map.
            fit = fit_box(tpiece[g], a)
            if fit is None:
                print("warning: %s moved %.0f px on the sheet, not trusted" % (g, np.hypot(*shift)))
            else:
                print("%s redrawn by the AI: fitted, scale %.2f x %.2f" % (g, fit[0, 0], fit[1, 1]))
            shift[:] = 0
        else:
            fit[:, 2] = shift
        pieces[g] = (rgb, a, fit)
    return pieces


def fit_box(tmask, a):
    """Affine map template-sheet -> sheet for a piece the AI drew in another size or place."""
    def box(m):
        yy, xx = np.nonzero(m > 0.5)
        return xx.min(), yy.min(), xx.max(), yy.max()
    if (a > 0.5).sum() < 500:
        return None
    tx0, ty0, tx1, ty1 = box(tmask)
    sx0, sy0, sx1, sy1 = box(a)
    kx, ky = (sx1 - sx0) / max(tx1 - tx0, 1), (sy1 - sy0) / max(ty1 - ty0, 1)
    warp = np.float32([[kx, 0, sx0 - kx * tx0], [0, ky, sy0 - ky * ty0]])
    try:
        _, w2 = cv2.findTransformECC(cv2.GaussianBlur(tmask, (0, 0), 4), cv2.GaussianBlur(a.astype(np.float32), (0, 0), 4),
                                     warp.copy(), cv2.MOTION_AFFINE,
                                     (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 200, 1e-5), None, 5)
        sv = np.linalg.svd(w2[:, :2], compute_uv=False)
        if sv.min() > 0.7 and sv.max() < 1.4:
            warp = w2
    except cv2.error:
        pass
    return warp if 0.7 < kx < 1.4 and 0.7 < ky < 1.4 else None


def to_canvas(g, rgb, a, fit):
    ox, oy = layout["parts"][g]["canvas_origin"]
    px, py = layout["parts"][g]["sheet_origin"]
    # canvas -> template sheet -> this sheet (fit), sampled backwards
    T = np.float64([[SCALE, 0, px - ox * SCALE], [0, SCALE, py - oy * SCALE], [0, 0, 1]])
    M = (np.vstack([fit, [0, 0, 1]]).astype(np.float64) @ T)[:2].astype(np.float32)
    rgba = np.dstack([rgb, (a * 255).astype(np.uint8)])
    rgba = rgba.astype(np.float32)
    rgba[..., :3] *= rgba[..., 3:4] / 255.0          # premultiply so edges do not pick up green
    o = cv2.warpAffine(rgba, M, (size, size), flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP)
    al = o[..., 3:4]
    o[..., :3] = np.where(al > 1e-3, o[..., :3] / np.maximum(al / 255.0, 1e-3), 0)
    return np.clip(o, 0, 255).astype(np.uint8)


sheet_img = read_sheet(pics["sheet"])
base_pieces = lift(sheet_img)
parts = {}
for g in GROUPS:
    rgb, a, fit = base_pieces[g]
    parts[g] = to_canvas(g, rgb, a, fit)
    print("%-5s shift %5.1f %5.1f px, %d px" % (g, fit[0, 2], fit[1, 2], (parts[g][..., 3] > 128).sum()))

# --- skin weights on the template's joints ----------------------------------------------------
j = pup.joints
ys, xs = np.mgrid[0:size, 0:size].astype(np.float32)


def ink_of(img):
    """The piece's outline colour: the darkest solid pixels along its edge."""
    solid = (img[..., 3] > 128).astype(np.uint8)
    edge = (solid > 0) & (cv2.erode(solid, np.ones((9, 9), np.uint8)) == 0)
    px = img[..., :3][edge].astype(np.float32)
    if not len(px):
        return np.zeros(3, np.float32)
    lum = px.mean(axis=1)
    return np.median(px[lum <= np.percentile(lum, 30)], axis=0)


# --- under a long skirt the thighs are slimmer at the top -------------------------------------------
# The skirt follows only the forward thigh; on a step the other one swings back and its upper part
# came out of the skirt's side. Under the skirt nobody sees the thigh at rest, so (like Gacha's hidden
# parts) it narrows towards the hip, outline kept: compressed toward its own centre line row by row.
hip_c0 = (np.asarray(j["hipL"]) + np.asarray(j["hipR"])) / 2
knee_c0 = (np.asarray(j["kneeL"]) + np.asarray(j["kneeR"])) / 2
L0 = float(knee_c0[1] - hip_c0[1])
t_rows = np.nonzero(parts["torso"][..., 3] > 128)[0]
if len(t_rows) and t_rows.max() > hip_c0[1] + 0.6 * L0:
    SLIM = 0.72
    for g, jn in (("legF", "hipL"), ("legB", "hipR")):
        jy = float(j[jn][1])
        al = parts[g][..., 3] > 128
        cx = np.full(size, np.nan, np.float32)
        for y in range(size):
            row = np.nonzero(al[y])[0]
            if len(row):
                cx[y] = (row.min() + row.max()) / 2.0
        ok = ~np.isnan(cx)
        cx = np.interp(np.arange(size), np.nonzero(ok)[0], cx[ok]).astype(np.float32)
        cx = cv2.GaussianBlur(cx.reshape(-1, 1), (1, 0), 6).ravel()
        s = (np.arange(size, dtype=np.float32) - jy) / L0
        tt = np.clip((s - 0.4) / 0.6, 0, 1)
        fac = SLIM + (1 - SLIM) * tt * tt * (3 - 2 * tt)
        mx = (cx[:, None] + (xs - cx[:, None]) / fac[:, None]).astype(np.float32)
        parts[g] = cv2.remap(parts[g], mx, ys, cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
    print("legs: slimmed to %.0f%% at the hips (they are under the skirt)" % (SLIM * 100))

# --- round thigh tops ------------------------------------------------------------------------------
# The AI paints the top of a leg flat, ~65 px above the hip joint. Turning about the joint, the corner
# of that flat top sweeps out from under the skirt or jacket (crouch, sit). A Gacha thigh ends in a
# round cap around its hip joint, so that whatever the angle it stays inside the same disk.
HIP_R = {}
for g, jn in (("legF", "hipL"), ("legB", "hipR")):
    jx, jy = (float(v) for v in j[jn])
    al = parts[g][..., 3]
    row = np.nonzero(al[int(round(jy))] > 128)[0]
    if not len(row):
        continue
    r = max(jx - row.min(), row.max() - jx) + 1.0
    d = np.hypot(xs - jx, ys - jy)
    keep = np.maximum(np.clip((ys - jy) / 2.0 + 0.5, 0, 1), np.clip((r - d) / 1.5 + 0.5, 0, 1))
    cut = parts[g].astype(np.float32)
    cut[..., 3] *= keep
    ink = ink_of(parts[g])
    band = np.clip(1.0 - np.abs(d - (r - 2.5)) / 2.5, 0, 1) * (ys < jy) * (cut[..., 3] > 128)
    cut[..., :3] = cut[..., :3] * (1 - band[..., None]) + ink * band[..., None]
    above = int(round(jy - np.nonzero(al > 128)[0].min()))
    parts[g] = np.clip(cut, 0, 255).astype(np.uint8)
    HIP_R[jn] = r
    print("%s: top rounded, was %d px above the hip, now %.0f" % (g, above, r))


def far_end(bone, joint):
    m = pup._silhouette(bone)
    yy, xx = np.nonzero(m)
    d = np.hypot(xx - joint[0], yy - joint[1])
    sel = d > np.percentile(d, 90)
    return np.array([xx[sel].mean(), yy[sel].mean()])


def smooth(x, a, b):
    t = np.clip((x - a) / max(b - a, 1e-6), 0, 1)
    return t * t * (3 - 2 * t)


def limb_weights(root, mid, end, mask):
    root, mid, end = (np.asarray(v, np.float64) for v in (root, mid, end))
    u1 = (mid - root) / np.linalg.norm(mid - root)
    u2 = (end - mid) / np.linalg.norm(end - mid)
    nb = (u1 + u2) / np.linalg.norm(u1 + u2)
    dt = cv2.distanceTransform(mask.astype(np.uint8), cv2.DIST_L2, 5)
    r = float(dt[int(round(mid[1])), int(round(mid[0]))]) or 20.0
    t = (xs - mid[0]) * nb[0] + (ys - mid[1]) * nb[1]
    w_low = smooth(t, -0.35 * r, 0.35 * r)
    # the piece is whole up to its round top: no share with the body, it turns rigidly there
    w = np.dstack([np.zeros_like(w_low), 1 - w_low, w_low]).astype(np.float32)
    return w


LIMB = {"armF": ("shoulderL", "elbowL", "armLowerFront", ["torso", "armUpperFront", "armLowerFront"]),
        "armB": ("shoulderR", "elbowR", "armLowerBack", ["torso", "armUpperBack", "armLowerBack"]),
        "legF": ("hipL", "kneeL", "legLowerFront", ["hips", "legUpperFront", "legLowerFront"]),
        "legB": ("hipR", "kneeR", "legLowerBack", ["hips", "legUpperBack", "legLowerBack"])}
W = {}
for g, (kr, km, lower, bl) in LIMB.items():
    end = far_end(lower, j[km])
    W[g] = (limb_weights(j[kr], j[km], end, parts[g][..., 3] > 128), bl, lower)

# --- a long skirt / apron / coat: the torso piece bends at the hips and the knees -----------------
# Like the separate hem piece of Gacha Life sheets, but cut from the same picture so there is no seam:
# the torso stays rigid above the hips, the lap follows the thigh, the rest hangs from the knees.
hem = None
hip_c = (np.asarray(j["hipL"]) + np.asarray(j["hipR"])) / 2
knee_c = (np.asarray(j["kneeL"]) + np.asarray(j["kneeR"])) / 2
thigh_len = float(knee_c[1] - hip_c[1])
ty = np.nonzero(parts["torso"][..., 3] > 128)[0]
if len(ty) and ty.max() > hip_c[1] + 0.6 * thigh_len:
    b_hip, b_knee = 0.22 * thigh_len, 0.18 * thigh_len
    u = smooth(ys, hip_c[1] - b_hip, hip_c[1] + b_hip)
    low = smooth(ys, knee_c[1] - b_knee, knee_c[1] + b_knee)
    W["torso"] = (np.dstack([1 - u, u - low, low]).astype(np.float32), ["torso", "hemUpper", "hemLower"], "torso")
    mid_y = int(round((hip_c[1] + knee_c[1]) / 2))

    def width_at(img, y):
        xs_ = np.nonzero(img[y, :, 3] > 128)[0]
        return float(xs_.max() - xs_.min()) if len(xs_) else 0.0

    leg_w = max(width_at(parts["legF"], mid_y), width_at(parts["legB"], mid_y))
    squash = float(np.clip(1.1 * leg_w / max(width_at(parts["torso"], mid_y), 1.0), 0.35, 1.0))
    hem = {"hip": [round(float(v), 2) for v in hip_c], "knee": [round(float(v), 2) for v in knee_c],
           "squash": round(squash, 3), "squash_pow": 2.0, "balance": True}
    print("hem: torso reaches %.0f px below the hips (thigh %.0f px), bends at hips and knees" % (ty.max() - hip_c[1], thigh_len))

# --- seat: the cloth over the hip caps stays put ------------------------------------------------------
# When the lap swings forward, the hips under it would be bare and the round thigh tops show (dark
# tights next to the apron). The skirt's own pixels over the two hip disks are kept as a rigid layer
# on the torso, under the bending skirt: at rest it is hidden exactly, when sitting it is the seat.
seat = None
if hem and HIP_R:
    disk = np.zeros((size, size), np.uint8)
    for jn, r in HIP_R.items():
        cv2.circle(disk, (int(round(j[jn][0])), int(round(j[jn][1]))), int(round(r + 5)), 1, -1)
    t_solid = (parts["torso"][..., 3] > 128).astype(np.uint8)
    region = disk & t_solid & (ys > hip_c[1] - 0.22 * thigh_len).astype(np.uint8)
    inner = cv2.distanceTransform(region, cv2.DIST_L2, 5)
    soft = np.clip(inner / 1.5, 0, 1)
    seat = parts["torso"].astype(np.float32)
    seat[..., 3] *= soft
    # its own ink where the cut runs through the cloth (the torso's outer edge already has one)
    t_inner = cv2.erode(t_solid, np.ones((7, 7), np.uint8)) > 0
    band = (np.clip(1.0 - np.abs(inner - 2.5) / 2.0, 0, 1) * t_inner)[..., None]
    seat[..., :3] = seat[..., :3] * (1 - band) + ink_of(parts["torso"]) * band
    seat = np.clip(seat, 0, 255).astype(np.uint8)
    print("seat: %d px of skirt kept over the hips" % (region.sum()))

# --- the front hand both ways round ---------------------------------------------------------------
# A Gacha hand is drawn for hanging: raised to wave, its thumb is on the wrong side. The AI may also
# draw it the other way round from the template. The pack keeps the forearm both ways: the one that
# matches the template's hand is used hanging, its mirror when the forearm points up.
ALT_UP = {}
for g, (kr, km, lower, _) in (("armF", LIMB["armF"]),):
    mir, info = mirror_forearm(parts[g], j[km])
    if mir is None:
        print("%s: no mirrored hand (%s)" % (g, info))
        continue
    tmask = pup._silhouette(lower)
    end = far_end(lower, j[km])
    sk = skin_mask(parts[g])
    yy, xx = np.nonzero(sk)
    dd = np.hypot(xx - j[km][0], yy - j[km][1])
    sel = dd > np.percentile(dd, 90)
    ai_end = np.array([xx[sel].mean(), yy[sel].mean()])
    flipped, cost = drawn_mirrored(parts[g], tmask, j[km], ai_end, end)
    if flipped:
        parts[g], up = mir, parts[g]
        print("%s: the AI drew the hand the other way round (fit as drawn %.3f, mirrored %.3f): mirrored for hanging, as drawn when raised" % (g, *cost))
    else:
        up = mir
        print("%s: hand as in the template (fit %s): mirrored when raised" % (g, cost))
    ALT_UP[g] = (up, [round(float(v), 2) for v in (end - np.asarray(j[km]))])

# --- face: the head piece of each edit, against the base head ----------------------------------
head = parts["head"]
base = head.copy()
empty = np.zeros((size, size, 4), np.uint8)
eyes = {"open": [("eye1", empty)]}
mouths = {"closed": [("mouth", empty)]}
talk, blink_name = None, None


def template_zone(prefixes):
    m = np.zeros((size, size), bool)
    for layer in pup.layers:
        if layer["bone"] == "head" and str(layer["name"]).startswith(prefixes):
            m |= pup._image(layer["file"])[..., 3] > 0.1
    yy, xx = np.nonzero(m)
    return (xx.min(), yy.min(), xx.max(), yy.max()) if len(xx) else None


if variants:
    ez = template_zone(("eye", "pupil", "highlight", "eyebrow"))
    mz = template_zone(("mouth",))
    split_y = (ez[3] + mz[1]) / 2.0
    eye_mid = (ez[1] + ez[3]) / 2.0
    inner = cv2.erode((head[..., 3] > 128).astype(np.uint8), np.ones((9, 9), np.uint8)) > 0
    zone_eyes = inner & (xs >= ez[0] - 45) & (xs <= ez[2] + 45) & (ys >= ez[1] - 40) & (ys < split_y)
    zone_mouth = inner & (xs >= mz[0] - 60) & (xs <= mz[2] + 60) & (ys >= split_y - 10) & (ys <= mz[3] + 45)
    zone_lower = inner & (xs >= ez[0] - 45) & (xs <= ez[2] + 45) & (ys > eye_mid + 4) & (ys <= mz[3] + 45)
    lab_base = cv2.cvtColor(head[..., :3], cv2.COLOR_BGR2LAB).astype(np.float32)
    g0 = cv2.cvtColor(head[..., :3], cv2.COLOR_BGR2GRAY).astype(np.float32)
    hmask = (cv2.dilate((head[..., 3] > 128).astype(np.uint8), np.ones((15, 15), np.uint8)) * 255).astype(np.uint8)

    def patch(im, zone, below=None):
        diff = np.linalg.norm(cv2.cvtColor(im, cv2.COLOR_BGR2LAB).astype(np.float32) - lab_base, axis=2)
        ch = (diff > 22) & zone
        ch = cv2.morphologyEx(ch.astype(np.uint8), cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        ch = cv2.morphologyEx(ch, cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
        n_, cl, st_, cent = cv2.connectedComponentsWithStats(ch, 8)
        keep_ = np.zeros_like(ch)
        for i in range(1, n_):
            if st_[i, cv2.CC_STAT_AREA] >= 40 and (below is None or cent[i][1] > below):
                keep_[cl == i] = 1
        if keep_.sum() == 0:
            return None, 0
        grown = cv2.dilate(keep_, np.ones((9, 9), np.uint8)).astype(np.float32) * zone
        soft = cv2.GaussianBlur(grown, (7, 7), 2.0) * (head[..., 3] / 255.0)
        p = np.dstack([im, (np.clip(soft, 0, 1) * 255).astype(np.uint8)])
        p[p[..., 3] == 0] = 0
        return p, int(keep_.sum())

    for stem, path in variants.items():
        rgb_v, a_v, sh_v = lift(read_sheet(path))["head"]
        hv = to_canvas("head", rgb_v, a_v, sh_v)
        g1 = cv2.cvtColor(hv[..., :3], cv2.COLOR_BGR2GRAY).astype(np.float32)
        warp = np.eye(2, 3, dtype=np.float32)
        try:
            _, warp = cv2.findTransformECC(g0, g1, warp, cv2.MOTION_AFFINE,
                                           (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 200, 1e-5), hmask, 5)
        except cv2.error:
            print("warning: %s could not be aligned" % stem)
        im = cv2.warpAffine(hv[..., :3], warp, (size, size), flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP,
                            borderMode=cv2.BORDER_REPLICATE)
        if stem.startswith("mouth_"):
            p, n_px = patch(im, zone_lower | zone_mouth, below=split_y)
            if p is not None:
                mouths[stem[6:]] = [("mouth", p)]
        elif stem == "eyes_closed":
            p, n_px = patch(im, zone_eyes)
            if p is not None:
                eyes["closed"] = [("eye1", p)]
                blink_name = "closed"
        else:
            p, n_px = patch(im, zone_eyes)
            q, m_px = patch(im, zone_mouth)
            if p is not None:
                eyes[stem] = [("eye1", p)]
            if q is not None:
                mouths[stem] = [("mouth", q)]
            n_px += m_px
        print("face %-14s changed %d px" % (stem, n_px))
    if all(k in mouths for k in ("small", "mid", "wide")):
        talk = ["closed", "small", "mid", "wide"]

# --- write -------------------------------------------------------------------------------------
if (out / "faces").exists():
    shutil.rmtree(out / "faces")
if (out / "parts").exists():
    shutil.rmtree(out / "parts")
for sub in ["parts", "faces"]:
    (out / sub).mkdir(parents=True, exist_ok=True)


def save(rel, image):
    (out / rel).parent.mkdir(parents=True, exist_ok=True)
    cv2.imencode(".png", image)[1].tofile(str(out / rel))


def bounds(image):
    yy, xx = np.nonzero(image[..., 3] > 0)
    return [int(xx.min()), int(yy.min()), int(xx.max()), int(yy.max())] if len(xx) else None


layers, order = [], 0
shadow = next((l for l in tdoc["layers"] if l["bone"] == "ground"), None)
if shadow:
    rel = "parts/00-shadow.png"
    shutil.copyfile(Path(template) / shadow["file"], out / rel)
    layers.append({"order": order, "name": "shadow", "file": rel, "bone": "ground", "bounds": shadow.get("bounds")})
    order += 1
for g in ORDER[:-1]:
    if g == "torso" and seat is not None:
        rel = "parts/%02d-seat.png" % (order + 1)
        save(rel, seat)
        layers.append({"order": order, "name": "seat", "file": rel, "bone": "torso", "bounds": bounds(seat)})
        order += 1
    rel = "parts/%02d-%s.png" % (order + 1, g)
    save(rel, parts[g])
    L = {"order": order, "name": g, "file": rel, "bounds": bounds(parts[g])}
    if g in W:
        w, bl, tag = W[g]
        wrel = "parts/%02d-%s.weights.png" % (order + 1, g)
        save(wrel, (w * 255 + 0.5).astype(np.uint8))
        L.update({"bone": tag, "skin": bl, "weights": wrel})
        if g in ALT_UP:
            arel = "parts/%02d-%s.up.png" % (order + 1, g)
            save(arel, ALT_UP[g][0])
            L["alt_up"] = {"file": arel, "forearm": ALT_UP[g][1]}
    else:
        L["bone"] = "torso"
    layers.append(L)
    order += 1
for name, image in [("headbase", base), ("mouth", empty)] + eyes["open"]:
    rel = "parts/%02d-%s.png" % (order + 1, name)
    save(rel, image)
    layers.append({"order": order, "name": name, "file": rel, "bone": "head", "bounds": bounds(image)})
    order += 1


def atlas_entries(kind, table):
    entries = []
    for value, items in table.items():
        files = []
        for lname, image in items:
            rel = "faces/%s/%s/%s.png" % (kind, value, lname)
            save(rel, image)
            files.append({"name": lname, "file": rel})
        entries.append({"value": value, "layers": files})
    return entries


eye_entries = atlas_entries("eyes", eyes)
mouth_entries = atlas_entries("mouths", mouths)
print("eyes:", list(eyes), "| mouths:", list(mouths), "| talk:", talk, "| blink:", blink_name)
joints = {k: [round(float(v[0]), 2), round(float(v[1]), 2)] for k, v in j.items()}
doc = {"formatVersion": 1, "slug": slug, "kind": "ai-parts",
       "description": "AI repaint of the template's exploded parts, on the template's Gacha rig (built by _claude_tmp/aipack/build_parts_pack.py)",
       "canvas": {"size": size},
       "provenance": {"source": str(pics["sheet"]), "template": template,
                      "selectors": {"eyes1x1": {"value": "open"}, "mouth1": {"value": "closed"}}},
       "joints": joints, "rig": tdoc["rig"], "layers": layers}
if hem:
    doc["hem"] = hem
(out / "layers.json").write_text(json.dumps(doc, ensure_ascii=False, indent=1), encoding="utf-8")
faces = {"formatVersion": 1, "slug": slug, "eyes": eye_entries, "mouths": mouth_entries,
         "verified": [{"eyes": "open", "mouth": "closed"}]}
if talk:
    faces["talk"] = talk
if blink_name:
    faces["blink"] = blink_name
(out / "faces" / "faces.json").write_text(json.dumps(faces, ensure_ascii=False, indent=1), encoding="utf-8")
ref = np.zeros((size, size, 4), np.float32)
for g in ORDER:
    p = parts[g].astype(np.float32) / 255
    ref[..., :3] = p[..., :3] * p[..., 3:4] + ref[..., :3] * (1 - p[..., 3:4])
    ref[..., 3:4] = p[..., 3:4] + ref[..., 3:4] * (1 - p[..., 3:4])
save("reference.png", (ref * 255).astype(np.uint8))
print("written", out)
