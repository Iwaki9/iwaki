"""Template bones of each sheet piece (default_boy Gacha rig)."""
GROUPS = {"head": ["head"], "torso": ["torso", "hips", "root"], "armF": ["armUpperFront", "armLowerFront"],
          "armB": ["armUpperBack", "armLowerBack"], "legF": ["legUpperFront", "legLowerFront"],
          "legB": ["legUpperBack", "legLowerBack"]}
