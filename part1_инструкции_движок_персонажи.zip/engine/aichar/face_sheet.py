"""Contact sheet of a character's faces: the head piece of sheet + every face edit, labelled.
    python face_sheet.py <char_dir> <out.jpg>"""
import sys
from pathlib import Path

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gen_check as gc

d, out = Path(sys.argv[1]), sys.argv[2]
G = gc.template_geometry()
base = gc.find = None
pics = sorted(p for p in d.iterdir() if p.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp")
              and p.stem not in ("A", "body", "arms"))
pics.sort(key=lambda p: (p.stem != "sheet", p.stem))
sheet = gc.square(gc.imread(pics[0]))
hb = gc.piece_masks(gc.fg_mask(sheet), G["labels"])[1]
x, y, w, h = cv2.boundingRect(hb.astype(np.uint8))
# the face: lower 60% of the head box
y0 = y + int(h * 0.35)
tiles = []
for p in pics:
    im = gc.square(gc.imread(p))
    t = cv2.resize(im[y0:y + h + 10, x:x + w], None, fx=0.75, fy=0.75)
    cv2.putText(t, p.stem, (6, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 4)
    cv2.putText(t, p.stem, (6, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    tiles.append(t)
cols = 4
while len(tiles) % cols:
    tiles.append(np.zeros_like(tiles[0]))
rows = [np.hstack(tiles[i:i + cols]) for i in range(0, len(tiles), cols)]
cv2.imencode(".jpg", np.vstack(rows))[1].tofile(out)
print("written", out)
