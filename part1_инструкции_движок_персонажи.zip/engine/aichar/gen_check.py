"""Automatic checks of Nano Banana pictures, so bad ones are thrown away without anyone looking.

    python gen_check.py sheet <sheet.png>                      body sheet against шаблон_детали
    python gen_check.py face <base_sheet> <edit> [kind]        face edit against its base sheet

kind: mouth_small / mouth_mid / mouth_wide / eyes_closed / base_<x> (a new base sheet with the
mouth uncovered, e.g. a mask pulled down) / any other name = emotion
(by default the stem of <edit>).

Every check returns {"level": 0 ok | 1 usable | 2 bad, "notes": [...], ...}.
The sheet check is the same code as the browser userscript (sheetcheck/core.js, run by node).
The face check aligns the edit to the base like build_parts_pack.py does and measures what
changed: the face must change in the right zone, the hair, the head outline and the other
pieces must not.
"""
import json
import subprocess
import sys
import tempfile
from functools import lru_cache
from pathlib import Path

import cv2
import numpy as np

HERE = Path(__file__).resolve().parent
ENGINE = HERE.parent
HORROR = ENGINE.parent
SHEETCHECK = HERE / "sheetcheck"
LAYOUT = HORROR / "ai_chars" / "шаблон_детали.json"
TEMPLATE_PACK = HORROR / "anim" / "default_boy"
PIECE_RU = {"head": "голова", "torso": "тело", "armF": "рука передняя", "armB": "рука задняя",
            "legF": "нога передняя", "legB": "нога задняя"}
LEVEL_RU = ["ок", "можно", "брак"]
MIN_MOUTH_COVERED = 150     # mouth-zone change that counts as "drew a mouth" on a covered base


def imread(path):
    im = cv2.imdecode(np.fromfile(str(path), np.uint8), cv2.IMREAD_COLOR)
    if im is None:
        raise ValueError("не читается картинка: %s" % path)
    return im


def square(im, size=1024):
    """Pad to a square with the corner colour and scale, like the builder's read_sheet."""
    h, w = im.shape[:2]
    if h != w:
        s = max(h, w)
        pad = np.full((s, s, 3), im[2, 2], np.uint8)
        pad[(s - h) // 2:(s - h) // 2 + h, (s - w) // 2:(s - w) // 2 + w] = im
        im = pad
    if im.shape[0] != size:
        im = cv2.resize(im, (size, size), interpolation=cv2.INTER_AREA if im.shape[0] > size else cv2.INTER_CUBIC)
    return im


def fg_mask(im):
    f = im.astype(np.int16)
    key = f[..., 1] - np.maximum(f[..., 0], f[..., 2])
    return key < 60


# --- body sheet ---------------------------------------------------------------------------------
def sheet_check(path):
    T = json.loads((SHEETCHECK / "template.json").read_text(encoding="utf-8"))
    small = square(imread(path), T["N"])
    rgba = np.dstack([small[..., ::-1], np.full(small.shape[:2], 255, np.uint8)])
    with tempfile.NamedTemporaryFile(suffix=".rgba", delete=False) as f:
        f.write(rgba.tobytes())
        tmp = f.name
    try:
        out = subprocess.run(["node", str(SHEETCHECK / "check_cli.js"), tmp], capture_output=True,
                             text=True, encoding="utf-8", timeout=120)
    finally:
        Path(tmp).unlink(missing_ok=True)
    if out.returncode != 0:
        raise RuntimeError("sheetcheck failed: " + out.stderr[-500:])
    r = json.loads(out.stdout)
    notes = list(r["global"])
    for p in r["pieces"]:
        if p["level"] > 0:
            notes.append("%s: %s" % (PIECE_RU[p["name"]], "; ".join(p["notes"])))
    r["notes"] = notes or ["все детали на месте"]
    return r


# --- face edit ----------------------------------------------------------------------------------
@lru_cache(maxsize=1)
def template_geometry():
    """Template piece labels on the 1024 sheet and the eye/mouth zones of the head (sheet px)."""
    T = json.loads((SHEETCHECK / "template.json").read_text(encoding="utf-8"))
    sys.path.insert(0, str(SHEETCHECK))
    N = T["N"]
    lab = np.zeros(N * N, np.uint8)
    i = 0
    for tok in T["rle"].split(","):
        c = int(tok[1:], 36)
        lab[i:i + c] = int(tok[0])
        i += c
    lab = cv2.resize(lab.reshape(N, N), (1024, 1024), interpolation=cv2.INTER_NEAREST)
    layout = json.loads(LAYOUT.read_text(encoding="utf-8"))
    sc = layout["scale"]
    ox, oy = layout["parts"]["head"]["canvas_origin"]
    px, py = layout["parts"]["head"]["sheet_origin"]
    sys.path.insert(0, str(ENGINE))
    from puppet import Animations, Puppet
    pup = Puppet(str(TEMPLATE_PACK), Animations(ENGINE / "anims"))

    def zone(prefixes):
        m = None
        for layer in pup.layers:
            if layer["bone"] == "head" and str(layer["name"]).startswith(prefixes):
                a = pup._image(layer["file"])[..., 3] > 0.1
                m = a if m is None else (m | a)
        yy, xx = np.nonzero(m)
        x0, y0, x1, y1 = xx.min(), yy.min(), xx.max(), yy.max()
        return ((x0 - ox) * sc + px, (y0 - oy) * sc + py, (x1 - ox) * sc + px, (y1 - oy) * sc + py)

    return {"labels": lab, "names": T["names"], "scale": sc,
            "eyes": zone(("eye", "pupil", "highlight", "eyebrow")), "mouth": zone(("mouth",))}


def piece_masks(fg, lab):
    """Each foreground pixel goes to the nearest template piece."""
    dists = []
    for k in range(1, 7):
        d = cv2.distanceTransform((lab != k).astype(np.uint8), cv2.DIST_L2, 5)
        dists.append(d)
    owner = np.argmin(np.stack(dists), 0) + 1
    near = np.min(np.stack(dists), 0) < 80
    return {k: fg & near & (owner == k) for k in range(1, 7)}


def ecc(g0, g1, mask, mode=cv2.MOTION_AFFINE, scale=0.5):
    """warp so that g1(warp(x)) ~ g0(x), estimated at a reduced scale."""
    a = cv2.resize(g0, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    b = cv2.resize(g1, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    m = cv2.resize(mask.astype(np.uint8) * 255, None, fx=scale, fy=scale, interpolation=cv2.INTER_NEAREST)
    warp = np.eye(2, 3, dtype=np.float32)
    try:
        _, warp = cv2.findTransformECC(a, b, warp, mode,
                                       (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 200, 1e-5), m, 5)
    except cv2.error:
        return None
    warp[:, 2] /= scale
    return warp


def tolerant_diff(lab_base, lab_edit, r=2):
    """Per pixel Lab distance to the best match within +-r px (lines redrawn a pixel off are not changes)."""
    best = None
    pad = np.pad(lab_base, ((r, r), (r, r), (0, 0)), mode="edge")
    h, w = lab_edit.shape[:2]
    for dy in range(-r, r + 1):
        for dx in range(-r, r + 1):
            d = np.linalg.norm(pad[r + dy:r + dy + h, r + dx:r + dx + w] - lab_edit, axis=2)
            best = d if best is None else np.minimum(best, d)
    return best


def clean(mask, open_k=3, min_area=25):
    m = cv2.morphologyEx(mask.astype(np.uint8), cv2.MORPH_OPEN, np.ones((open_k, open_k), np.uint8))
    n, cl, st, _ = cv2.connectedComponentsWithStats(m, 8)
    keep = np.zeros(mask.shape, bool)
    for i in range(1, n):
        if st[i, cv2.CC_STAT_AREA] >= min_area:
            keep |= cl == i
    return keep


def mouth_skin(im, head):
    """Share of skin-coloured pixels around the template's mouth spot: ~0.8-1 on a bare face,
    ~0 when a mask, scarf or collar covers the mouth (then a mouth edit has nothing to open)."""
    G = template_geometry()
    mz, s = G["mouth"], G["scale"]
    ys, xs = np.mgrid[0:1024, 0:1024]
    inner = cv2.erode(head.astype(np.uint8), np.ones((9, 9), np.uint8)) > 0
    cx, cy = (mz[0] + mz[2]) / 2, (mz[1] + mz[3]) / 2
    ring = inner & (np.hypot((xs - cx) / (40 * s), (ys - cy) / (22 * s)) < 1)
    if ring.sum() < 50:
        return 0.0
    hsv = cv2.cvtColor(im, cv2.COLOR_BGR2HSV).astype(np.float32)
    h, sat, v = hsv[..., 0] * 2, hsv[..., 1] / 255, hsv[..., 2] / 255
    skin = ((h < 40) | (h > 340)) & (sat > 0.07) & (sat < 0.65) & (v > 0.45)
    return float(skin[ring].mean())


def base_mouth_visible(base_path):
    """(ok, share): can mouth edits be made on this base sheet at all?"""
    G = template_geometry()
    base = square(imread(base_path))
    share = mouth_skin(base, piece_masks(fg_mask(base), G["labels"])[1])
    return share >= 0.4, share


def face_check(base_path, edit_path, kind=None, debug=None):
    kind = kind or Path(edit_path).stem
    G = template_geometry()
    lab_t, sc = G["labels"], G["scale"]
    base = square(imread(base_path))
    edit0 = square(imread(edit_path))
    fg_b = fg_mask(base)
    notes, lvl = [], 0

    def up(level, msg):
        nonlocal lvl
        lvl = max(lvl, level)
        notes.append(msg)

    # 1. whole sheet: align (the builder re-aligns pieces itself, so a shift only costs a note)
    gb = cv2.cvtColor(base, cv2.COLOR_BGR2GRAY).astype(np.float32)
    ge = cv2.cvtColor(edit0, cv2.COLOR_BGR2GRAY).astype(np.float32)
    warp = ecc(gb, ge, cv2.dilate(fg_b.astype(np.uint8), np.ones((15, 15), np.uint8)) > 0)
    if warp is None:
        warp = np.eye(2, 3, dtype=np.float32)
        up(2, "лист не совмещается с исходным (перерисован целиком?)")
    sx = float(np.hypot(*warp[:, 0]))
    shift = float(np.hypot(*warp[:, 2]))
    if abs(sx - 1) > 0.06:
        up(2, "лист изменил размер на %d%%" % round((sx - 1) * 100))
    elif abs(sx - 1) > 0.025 or shift > 25:
        up(1, "лист сдвинут на %d px / масштаб %+d%% (сборщик выровняет)" % (shift, round((sx - 1) * 100)))
    edit = cv2.warpAffine(edit0, warp, (1024, 1024), flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP,
                          borderMode=cv2.BORDER_REPLICATE)
    fg_e = fg_mask(edit)
    pm_b, pm_e = piece_masks(fg_b, lab_t), piece_masks(fg_e, lab_t)
    L_b = cv2.cvtColor(base, cv2.COLOR_BGR2LAB).astype(np.float32)
    L_e = cv2.cvtColor(edit, cv2.COLOR_BGR2LAB).astype(np.float32)
    diff = tolerant_diff(L_b, L_e)
    changed = diff > 28

    # 2. other pieces must stay the same: outline and paint
    body = {}
    for k, name in enumerate(G["names"], 1):
        a, b = pm_b[k], pm_e[k]
        iou = (a & b).sum() / max((a | b).sum(), 1)
        body[name] = {"iou": round(float(iou), 3)}
        if name == "head":
            continue
        ch = clean(changed & (a | b)).sum() / max(a.sum(), 1)
        body[name]["changed"] = round(float(ch), 3)
        if iou < 0.88 or ch > 0.12:
            up(2, "деталь «%s» перерисована (контур %.2f, изменилось %d%%)" % (PIECE_RU[name], iou, ch * 100))
        elif iou < 0.94 or ch > 0.05:
            up(1, "деталь «%s» немного изменилась (контур %.2f, изменилось %d%%)" % (PIECE_RU[name], iou, ch * 100))

    # 3. the head on its own: align like the builder (affine on the head), then zones
    hb = pm_b[1]
    if hb.sum() < 2000:
        return {"level": 2, "notes": ["на исходном листе не найдена голова"], "kind": kind}
    hmask = cv2.dilate(hb.astype(np.uint8), np.ones((15, 15), np.uint8)) > 0
    hwarp = ecc(gb, cv2.cvtColor(edit, cv2.COLOR_BGR2GRAY).astype(np.float32), hmask, scale=1.0)
    if hwarp is not None and np.hypot(*hwarp[:, 2]) < 30:
        edit_h = cv2.warpAffine(edit, hwarp, (1024, 1024), flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP,
                                borderMode=cv2.BORDER_REPLICATE)
        L_eh = cv2.cvtColor(edit_h, cv2.COLOR_BGR2LAB).astype(np.float32)
        hd = tolerant_diff(L_b, L_eh)
        he = piece_masks(fg_mask(edit_h), lab_t)[1]
    else:
        edit_h, L_eh, hd, he = edit, L_e, diff, pm_e[1]
    head_iou = (hb & he).sum() / max((hb | he).sum(), 1)
    if head_iou < 0.9:
        up(2, "контур головы другой (%.2f): причёска/убор изменились" % head_iou)
    elif head_iou < 0.95:
        up(1, "контур головы чуть изменился (%.2f)" % head_iou)

    ez, mz = G["eyes"], G["mouth"]
    ys, xs = np.mgrid[0:1024, 0:1024]
    inner = cv2.erode(hb.astype(np.uint8), np.ones((9, 9), np.uint8)) > 0
    split_y = (ez[3] + mz[1]) / 2.0
    eye_mid = (ez[1] + ez[3]) / 2.0
    s = sc
    zone_eyes = inner & (xs >= ez[0] - 45 * s) & (xs <= ez[2] + 45 * s) & (ys >= ez[1] - 40 * s) & (ys < split_y)
    zone_mouth = inner & (xs >= mz[0] - 60 * s) & (xs <= mz[2] + 60 * s) & (ys >= split_y - 10 * s) & (ys <= mz[3] + 45 * s)
    zone_lower = inner & (xs >= ez[0] - 45 * s) & (xs <= ez[2] + 45 * s) & (ys > eye_mid + 4 * s) & (ys <= mz[3] + 45 * s)
    zone_m = (zone_mouth | zone_lower) & (ys > split_y)
    face = zone_eyes | zone_mouth | zone_lower
    rest = inner & ~cv2.dilate(face.astype(np.uint8), np.ones((21, 21), np.uint8)).astype(bool)

    ch_h = hd > 26
    n_eyes = int(clean(ch_h & zone_eyes).sum())
    n_mouth = int(clean(ch_h & zone_m).sum())
    rest_ch = clean(ch_h & rest, min_area=40).sum() / max(rest.sum(), 1)
    if rest_ch > 0.10:
        up(2, "на голове вне лица изменилось %d%% (волосы/убор)" % (rest_ch * 100))
    elif rest_ch > 0.04:
        up(1, "на голове вне лица изменилось %d%%" % (rest_ch * 100))

    # skin colour = median of the lower face in the base; "not skin" = eyes, mouth, lines
    skin_px = L_b[zone_lower & ~(hd > 26)]
    skin = np.median(skin_px, 0) if len(skin_px) > 50 else np.median(L_b[inner], 0)

    def not_skin(L, zone):
        return int(((np.linalg.norm(L - skin, axis=2) > 30) & zone).sum())

    # dark (eyes, mouth, lines) inside the changed area only: the bangs over the eye zone do not count
    ch_e = cv2.dilate(clean(ch_h & zone_eyes).astype(np.uint8), np.ones((5, 5), np.uint8)).astype(bool) & zone_eyes
    ch_m = cv2.dilate(clean(ch_h & zone_m).astype(np.uint8), np.ones((5, 5), np.uint8)).astype(bool) & zone_m
    eye_ns_b, eye_ns_e = not_skin(L_b, ch_e), not_skin(L_eh, ch_e)
    m_ns_b, m_ns_e = not_skin(L_b, ch_m), not_skin(L_eh, ch_m)
    # skin colour of the whole face must stay: the builder pastes only the eye/mouth zones, so a
    # recoloured face would show as a patch
    hsv = cv2.cvtColor(base, cv2.COLOR_BGR2HSV).astype(np.float32)
    hh, ss, vv = hsv[..., 0] * 2, hsv[..., 1] / 255, hsv[..., 2] / 255
    skin_b = inner & ((hh < 40) | (hh > 340)) & (ss > 0.07) & (ss < 0.65) & (vv > 0.45)
    skin_shift = 0.0
    if skin_b.sum() > 300:
        skin_shift = float(np.linalg.norm(np.median(L_eh[skin_b], 0) - np.median(L_b[skin_b], 0)))
        if skin_shift > 12:
            up(2, "цвет кожи лица изменился (%.0f): в паке будет заплатка" % skin_shift)
        elif skin_shift > 6:
            up(1, "цвет кожи чуть изменился (%.0f)" % skin_shift)
    # a mouth or jaw drawn past the chin: the builder clips it at the old outline
    below = he & ~cv2.dilate(hb.astype(np.uint8), np.ones((7, 7), np.uint8)).astype(bool) & (ys > split_y) \
        & (xs >= mz[0] - 80 * s) & (xs <= mz[2] + 80 * s)
    n_below = int(clean(below, min_area=30).sum())
    if n_below > 600:
        up(2, "рот/челюсть вылезли за контур лица (%d px)" % n_below)
    elif n_below > 150:
        up(1, "рот чуть заходит за контур лица (%d px, сборщик обрежет)" % n_below)
    sk_b, sk_e = mouth_skin(base, hb), mouth_skin(edit_h, he)
    if kind.startswith("base_"):
        # a new base for faces (mask pulled down etc.): the mouth must come out, the rest as usual
        if sk_e < 0.4:
            up(2, "рот так и не открылся (кожи вокруг рта %.2f)" % sk_e)
    elif sk_b < 0.4 and (kind.startswith("mouth_") or n_mouth > MIN_MOUTH_COVERED):
        up(2, "на исходном листе рот закрыт (маска/шарф): рот рисуется поверх неё")
    if sk_e - sk_b > 0.3 and not kind.startswith("base_"):
        up(2, "вокруг рта появилась кожа (кожа %.2f -> %.2f): убрана маска/шарф/воротник" % (sk_b, sk_e))
    MIN = 60
    info = {"n_eyes": n_eyes, "n_mouth": n_mouth, "rest": round(float(rest_ch), 3), "head_iou": round(float(head_iou), 3),
            "eye_dark": [eye_ns_b, eye_ns_e], "mouth_dark": [m_ns_b, m_ns_e], "shift": round(shift, 1),
            "scale": round(sx, 3), "pieces": body, "mouth_skin": [round(sk_b, 2), round(sk_e, 2)], "skin_shift": round(skin_shift, 1)}
    # how wide the mouth opened = area of the changed mouth region with its holes filled (teeth and a
    # pink tongue look like pale skin, so counting dark pixels failed on light characters)
    mm = cv2.morphologyEx(clean(ch_h & zone_m).astype(np.uint8), cv2.MORPH_CLOSE, np.ones((9, 9), np.uint8))
    cnts, _ = cv2.findContours(mm, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    filled = np.zeros_like(mm)
    cv2.drawContours(filled, cnts, -1, 1, -1)
    mouth_area = int(filled.sum())
    if kind.startswith("mouth_"):
        if n_mouth < MIN:
            up(2, "рот не изменился")
        if n_eyes > max(400, 1.5 * n_mouth):
            up(1, "глаза тоже изменились (сборщик возьмёт только рот)")
    elif kind == "eyes_closed":
        if n_eyes < MIN:
            up(2, "глаза не изменились")
        elif eye_ns_e > 0.65 * eye_ns_b:
            up(2, "глаза не закрылись (тёмного в глазах %d -> %d px)" % (eye_ns_b, eye_ns_e))
        if n_mouth > max(300, n_eyes):
            up(1, "рот тоже изменился (сборщик возьмёт только глаза)")
    else:
        if n_eyes + n_mouth < MIN:
            up(2, "лицо не изменилось")
    info["open"] = mouth_area

    if debug:
        vis = np.hstack([base, edit_h])
        ov = edit_h.copy()
        ov[ch_h & face] = (0, 0, 255)
        ov[changed & ~hmask & (fg_b | fg_e)] = (255, 0, 255)
        ov[ch_h & rest] = (0, 200, 255)
        for z, c in ((zone_eyes, (255, 200, 0)), (zone_m, (0, 255, 255))):
            cnts, _ = cv2.findContours(z.astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            cv2.drawContours(ov, cnts, -1, c, 1)
        x0, y0, x1, y1 = cv2.boundingRect(hb.astype(np.uint8))
        crop = lambda im: cv2.resize(im[y0:y0 + y1, x0:x0 + x1], None, fx=1.5, fy=1.5)
        vis = np.hstack([crop(base), crop(edit_h), crop(ov)])
        cv2.imencode(".jpg", vis)[1].tofile(str(debug))

    return {"level": lvl, "notes": notes or ["меняется только лицо"], "kind": kind, **info}


def bg_check(path):
    """A background: only the technical side can be checked (the choice of variant is by eye)."""
    im = imread(path)
    h, w = im.shape[:2]
    notes, lvl = [], 0
    ar = w / h
    if abs(ar - 16 / 9) > 0.12:
        lvl = 2
        notes.append("не 16:9 (%dx%d)" % (w, h))
    if w < 1200:
        lvl = max(lvl, 1)
        notes.append("маленькое разрешение %dx%d" % (w, h))
    small = cv2.resize(im, (160, 90), interpolation=cv2.INTER_AREA)
    if small.std() < 8:
        lvl = 2
        notes.append("пустой/однотонный кадр")
    return {"level": lvl, "notes": notes or ["%dx%d" % (w, h)]}


def summary(r):
    return "%s: %s" % (LEVEL_RU[r["level"]], "; ".join(r["notes"]))


if __name__ == "__main__":
    a = sys.argv[1:]
    if a and a[0] == "sheet":
        for p in a[1:]:
            r = sheet_check(p)
            print("%s  score %s  %s" % (Path(p).name, r["score"], summary(r)))
    elif a and a[0] == "face":
        dbg = None
        if "--debug" in a:
            i = a.index("--debug")
            dbg = a[i + 1]
            a = a[:i] + a[i + 2:]
        r = face_check(a[1], a[2], a[3] if len(a) > 3 else None, debug=dbg)
        print(json.dumps({k: v for k, v in r.items() if k != "pieces"}, ensure_ascii=False))
        print(Path(a[2]).name, summary(r))
    else:
        sys.exit(__doc__)
