"""Still grid of poses for packs: rows = packs, cols = modes.
python pose_grid.py <pack[,pack...]> <out.jpg> [mode,mode,...]"""
import sys
from pathlib import Path

import cv2
import numpy as np

ENGINE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ENGINE))
from puppet import Animations, Puppet, translate

anims = Animations(ENGINE / "anims")
packs = [Puppet(p, anims) for p in sys.argv[1].split(",")]
out = sys.argv[2]
modes = (sys.argv[3].split(",") if len(sys.argv) > 3 else
         ["idle", "walk", "wave", "thinking", "cover_face", "arms_crossed", "crouch", "sit_chair", "fall_knees"])
CW, CH = 300, 460
img = np.full((CH * len(packs), CW * len(modes), 3), 0.42, np.float32)
for r, pup in enumerate(packs):
    for c, mode in enumerate(modes):
        t = 0.6
        pose = anims.sample(mode, t)
        af = anims.arm_front(mode, t) or abs(pose[anims.keys.index("armL")]) > 25 or abs(pose[anims.keys.index("foreL")]) > 35
        S = CH * 0.8 / (pup.floor - pup.top)
        view = translate(CW / 2 - pup.center_x * S, CH * 0.93 - pup.floor * S) @ np.diag([S, S, 1.0])
        drawn = pup.render(pose, anims.keys, view, (CW, CH), arm_front=af, mode=mode)
        cell = img[r * CH:(r + 1) * CH, c * CW:(c + 1) * CW]
        if drawn:
            roi, x, y = drawn
            x0, y0 = max(x, 0), max(y, 0)
            rr = roi[y0 - y:CH - y, x0 - x:CW - x]
            reg = cell[y0:y0 + rr.shape[0], x0:x0 + rr.shape[1]]
            reg[:] = rr[..., :3] + reg * (1 - rr[..., 3:4])
o = (np.clip(img, 0, 1) * 255).astype(np.uint8)
for c, mode in enumerate(modes):
    cv2.putText(o, mode, (c * CW + 8, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1, cv2.LINE_AA)
cv2.imencode(".jpg", o)[1].tofile(out)
print("written", out)
