"""Real-ESRGAN x2 upscale of backgrounds.

    python upscale.py <out_dir> <in.jpg> [...]

Blends a little of the Lanczos-resized original back in, so the photo keeps some
of its own grain instead of the waxy ESRGAN look.
"""
import sys
from pathlib import Path

import cv2
import numpy as np
import torch
from spandrel import ModelLoader

WEIGHTS = "E:/.cache/upscale/RealESRGAN_x2plus.pth"
BLEND = 0.25   # share of the plain Lanczos image
TILE, PAD = 512, 24

out_dir = Path(sys.argv[1])
out_dir.mkdir(parents=True, exist_ok=True)
model = ModelLoader().load_from_file(WEIGHTS).cuda().eval().half()
scale = model.scale


@torch.no_grad()
def upscale(img):
    h, w = img.shape[:2]
    x = torch.from_numpy(img[..., ::-1].copy()).permute(2, 0, 1)[None].float().div(255).cuda().half()
    out = torch.zeros((1, 3, h * scale, w * scale), device="cuda", dtype=torch.half)
    for y0 in range(0, h, TILE):
        for x0 in range(0, w, TILE):
            y1, x1 = min(y0 + TILE, h), min(x0 + TILE, w)
            py0, px0 = max(y0 - PAD, 0), max(x0 - PAD, 0)
            py1, px1 = min(y1 + PAD, h), min(x1 + PAD, w)
            tile = model(x[..., py0:py1, px0:px1])
            oy, ox = (y0 - py0) * scale, (x0 - px0) * scale
            out[..., y0 * scale:y1 * scale, x0 * scale:x1 * scale] = \
                tile[..., oy:oy + (y1 - y0) * scale, ox:ox + (x1 - x0) * scale]
    res = out[0].float().clamp(0, 1).mul(255).permute(1, 2, 0).cpu().numpy()[..., ::-1]
    return res


for path in sys.argv[2:]:
    img = cv2.imdecode(np.fromfile(path, np.uint8), cv2.IMREAD_COLOR)
    up = upscale(img)
    lan = cv2.resize(img, (up.shape[1], up.shape[0]), interpolation=cv2.INTER_LANCZOS4).astype(np.float32)
    res = np.clip(up * (1 - BLEND) + lan * BLEND, 0, 255).astype(np.uint8)
    cv2.imencode(".jpg", res, [cv2.IMWRITE_JPEG_QUALITY, 95])[1].tofile(str(out_dir / Path(path).name))
    print(Path(path).name, img.shape[1], "->", res.shape[1], flush=True)
