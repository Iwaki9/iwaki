"""Mirror a forearm (with its hand, bandage, strips) about its own axis: the thumb goes to the other side.

The AI sometimes draws a hand the other way round from the template's: then it looks right raised
(waving) and wrong hanging, or the reverse. The pack keeps both and the engine picks by the pose.

Used by build_parts_pack.py; runnable alone to look at the result:
    python mirror_hand.py <arm.png> <elbow_x> <elbow_y> <out.png>
"""
import sys

import cv2
import numpy as np


def mirror_forearm(img, elbow):
    """img: HxWx4 uint8 arm piece on the canvas; elbow: (x, y). Returns (image, info) or (None, why)."""
    a = img[..., 3] > 128
    ys, xs = np.nonzero(a)
    ex, ey = float(elbow[0]), float(elbow[1])
    d = np.hypot(xs - ex, ys - ey)
    far = d > np.percentile(d, 97)
    end = np.array([xs[far].mean(), ys[far].mean()])
    L = float(np.linalg.norm(end - (ex, ey)))
    u = (end - (ex, ey)) / L
    n = np.array([-u[1], u[0]])
    H, W = a.shape
    gy, gx = np.mgrid[0:H, 0:W].astype(np.float32)
    along = (gx - ex) * u[0] + (gy - ey) * u[1]
    across = (gx - ex) * n[0] + (gy - ey) * n[1]

    # bare skin rows of the forearm: reddish-pink hue or very light, no dark sleeve/bandage
    hsv = cv2.cvtColor(img[..., :3], cv2.COLOR_BGR2HSV).astype(np.int32)
    h, s, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
    skin = a & (((h <= 14) | (h >= 160)) & (v >= 70) | ((s < 60) & (v > 200)))
    rows = []
    for t in range(0, int(L)):
        band = (np.abs(along - t) < 0.5) & a
        if band.sum() < 6:
            continue
        frac = (band & skin).sum() / band.sum()
        acr = across[band]
        rows.append((t, frac, acr.min(), acr.max()))
    bare = [r for r in rows if r[1] > 0.9 and r[0] < 0.97 * L]
    if len(bare) < 6:
        return None, "no bare forearm to cut through"
    # the longest run of bare rows: cut a few px into it, axis = centre line fitted over it
    runs, cur = [], [bare[0]]
    for r in bare[1:]:
        if r[0] - cur[-1][0] <= 2:
            cur.append(r)
        else:
            runs.append(cur)
            cur = [r]
    runs.append(cur)
    run = max(runs, key=len)
    if len(run) < 6:
        return None, "bare forearm too short"
    t_arr = np.array([r[0] for r in run], float)
    hand_only = False
    if t_arr[-1] < 0.75 * L:
        # bare forearm between sleeve and cuff/bandage: cut through it, axis = its centre line
        c_arr = np.array([(r[2] + r[3]) / 2 for r in run], float)
        cut = float(t_arr[0] + 0.3 * (t_arr[-1] - t_arr[0]))
        k, b = np.polyfit(t_arr, c_arr, 1)
    else:
        # the sleeve reaches the wrist and the bare run is the hand itself: cut at the cuff,
        # axis = the sleeve's centre line (a hand is not symmetric, a sleeve is)
        cuff = [r[0] for r in rows if r[0] < t_arr[0] and r[1] < 0.15]
        cut = float(cuff[-1]) + 1.0 if cuff else float(t_arr[0]) - 6.0
        hand_only = True
        sl = [r for r in rows if 0.3 * L <= r[0] <= t_arr[0] - 4]
        if len(sl) < 4:
            return None, "no sleeve to take the axis from"
        k, b = np.polyfit([r[0] for r in sl], [(r[2] + r[3]) / 2 for r in sl], 1)
    # reflect about the line across = k * along + b (nearly along u)
    axis_c = k * along + b
    src_across = 2 * axis_c - across
    mx = ex + along * u[0] + src_across * n[0]
    my = ey + along * u[1] + src_across * n[1]
    f = img.astype(np.float32)
    f[..., :3] *= f[..., 3:4] / 255.0
    mirrored = cv2.remap(f, mx.astype(np.float32), my.astype(np.float32), cv2.INTER_LINEAR,
                         borderMode=cv2.BORDER_CONSTANT, borderValue=0)
    w = np.clip((along - cut) / 3.0 + 0.5, 0, 1)[..., None]
    if hand_only:
        # only the skin turns over; the cuff stays and covers the wrist
        # the hand with its thin outer rim, but not the cuff's own line just under the cut
        # the hand = its skin (from a little above the cut, so no crumbs stay under the cuff) grown
        # by its thin rim, but not into anything coloured like the sleeve (the cuff's slanted line)
        lab = cv2.cvtColor(img[..., :3], cv2.COLOR_BGR2LAB).astype(np.float32)
        sample = lab[a & ~skin & (along > cut - 30) & (along <= cut - 2)]
        if len(sample) > 1500:
            sample = sample[np.random.default_rng(0).choice(len(sample), 1500, replace=False)]
        core = skin & (along > cut - 6)
        grown = (cv2.dilate(core.astype(np.uint8), np.ones((7, 7), np.uint8)) > 0) & (img[..., 3] > 0) & ~core
        gy_, gx_ = np.nonzero(grown & (along < cut + 30))
        if len(sample) and len(gy_):
            dist = np.min(np.linalg.norm(lab[gy_, gx_][:, None, :] - sample[None, :, :], axis=2), axis=1)
            grown[gy_[dist < 20], gx_[dist < 20]] = False
        hand = core | grown
        sk = hand.astype(np.float32)[..., None] * w
        msk = cv2.remap(f * sk, mx.astype(np.float32), my.astype(np.float32), cv2.INTER_LINEAR,
                        borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        keep = f * (1 - sk)
        keep[(along > cut) & (keep[..., 3] < 128)] = 0      # the hand's faint antialiased fringe
        out = keep + msk * (1 - keep[..., 3:4] / 255.0)
    else:
        out = f * (1 - w) + mirrored * w
    al = out[..., 3:4]
    out[..., :3] = np.where(al > 1e-3, out[..., :3] / np.maximum(al / 255.0, 1e-3), 0)
    return np.clip(out, 0, 255).astype(np.uint8), {"cut": round(cut, 1), "L": round(L, 1), "tilt": round(float(k), 3)}


def skin_mask(img):
    hsv = cv2.cvtColor(img[..., :3], cv2.COLOR_BGR2HSV).astype(np.int32)
    h, s, v = hsv[..., 0], hsv[..., 1], hsv[..., 2]
    a = img[..., 3] > 128
    return a & (((h <= 14) | (h >= 160)) & (v >= 70) | ((s < 60) & (v > 200)))


def hand_profile(mask, elbow, end, fracs=np.linspace(0.62, 0.95, 24), body=None):
    """Left/right edge of the hand (mask) at fractions of elbow->end, against the forearm's centre
    line, in units of the forearm's width. Bandages and strips are not in a skin mask."""
    e, end = np.asarray(elbow, float), np.asarray(end, float)
    L = np.linalg.norm(end - e)
    u = (end - e) / L
    n = np.array([-u[1], u[0]])
    by, bx = np.nonzero(mask if body is None else body)
    bt = (bx - e[0]) * u[0] + (by - e[1]) * u[1]
    bc = (bx - e[0]) * n[0] + (by - e[1]) * n[1]
    ys, xs = np.nonzero(mask)
    t = (xs - e[0]) * u[0] + (ys - e[1]) * u[1]
    c = (xs - e[0]) * n[0] + (ys - e[1]) * n[1]
    cen, wid, tt = [], [], []
    for f in np.linspace(0.15, 0.5, 12):
        sel = np.abs(bt - f * L) < 1.5
        if sel.sum() > 3:
            tt.append(f)
            cen.append((bc[sel].min() + bc[sel].max()) / 2)
            wid.append(bc[sel].max() - bc[sel].min())
    if len(tt) < 4:
        return None
    k, b = np.polyfit(tt, cen, 1)
    w = max(float(np.median(wid)), 1.0)
    out = []
    for f in fracs:
        sel = np.abs(t - f * L) < 1.5
        if sel.sum() < 2:
            out.append((np.nan, np.nan))
            continue
        mid = k * f + b
        out.append(((c[sel].min() - mid) / w, (c[sel].max() - mid) / w))
    return np.array(out)


def drawn_mirrored(ai_img, tmpl_mask, elbow, ai_end, t_end):
    """True when the AI's hand is the template's mirror image (thumb on the other side)."""
    pa = hand_profile(skin_mask(ai_img), elbow, ai_end, body=ai_img[..., 3] > 128)
    pt = hand_profile(tmpl_mask, elbow, t_end)
    if pa is None or pt is None:
        return None, None
    same = np.nanmean((pa[:, 0] - pt[:, 0]) ** 2 + (pa[:, 1] - pt[:, 1]) ** 2)
    flip = np.nanmean((-pa[:, 1] - pt[:, 0]) ** 2 + (-pa[:, 0] - pt[:, 1]) ** 2)
    return bool(flip < same), (round(float(same), 3), round(float(flip), 3))


if __name__ == "__main__":
    im = cv2.imdecode(np.fromfile(sys.argv[1], np.uint8), cv2.IMREAD_UNCHANGED)
    res, info = mirror_forearm(im, (float(sys.argv[2]), float(sys.argv[3])))
    print(info)
    if res is not None:
        cv2.imencode(".png", res)[1].tofile(sys.argv[4])
