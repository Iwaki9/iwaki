"""Generate character pictures through the panel API (ImgCreatorAI / Nano Banana 2) and keep only
the ones that pass the automatic check; bad ones are regenerated, up to --tries times each.

Faces (edits of the character's body sheet; the sheet must be the one the pack is built from):
    python banana_gen.py face <char_dir> mouth_small mouth_mid mouth_wide eyes_closed scared
    python banana_gen.py face <char_dir> talk blink scared         talk = 3 mouths, blink = eyes_closed
    python banana_gen.py face <char_dir> angry="Angry: eyebrows lowered ..."     own emotion text

Body sheet from a text description (шаблон_детали.png is edited into the character):
    python banana_gen.py sheet <char_dir> "young man about 25, messy light brown hair, ..."

Options: --tries N (default 4)   --model nano-banana-2 (Pro there needs a login)   --base <file in char_dir>
         --strict (accept only "ок", not "можно")   --site imgcreatorai

Every attempt goes to <char_dir>/_gen/ with its check (log.txt, and for faces a *_check.jpg
showing base | edit | what changed). A passing picture is copied to <char_dir>/<name>.<ext>.
If nothing passes, the script says so and exits with code 1: then try by hand.
Password: E:/Gacha Nebula Windows 1.7/banana_pass.txt (or env BANANA_PASS / BANANA_PASS_FILE).
"""
import argparse
import base64
import json
import os
import shutil
import sys
import time
from pathlib import Path

import requests
import urllib3

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gen_check as gc

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
API = os.environ.get("BANANA_API", "https://172-245-185-22.nip.io/api")
PASS_FILE = Path(os.environ.get("BANANA_PASS_FILE", gc.HORROR.parent / "banana_pass.txt"))
TEMPLATE_SHEET = gc.HORROR / "ai_chars" / "шаблон_детали.png"
IMAGE_EXT = (".png", ".jpg", ".jpeg", ".webp")

SHEET_PROMPT = """Edit this image. It is a sprite sheet of a 2D cut-out puppet: six separate pieces of one boy - the head, the torso without arms and head, the front arm, the back arm, the front leg and the back leg. Redraw every piece as the new character described below, so that the pieces put together make that character.
Keep the sheet layout exactly: every piece stays in the same place, at the same size and angle, separate from the others with green between them. Do not join the pieces, do not add or remove pieces, do not draw arms, legs or a head on the torso, do not draw a body on the head.
Each piece gets only its own part of the character: hair and face on the head piece; the clothes of the body on the torso piece, with no sleeves; the sleeves with the hands on the arm pieces, keeping their rounded top end; the trousers with the shoes on the leg pieces. A long coat, dress or apron hangs down from the torso piece into the free space below it.
Keep the shapes of the pieces: each hand keeps the same pose, the same side towards the viewer and the thumb on the same side as in this image; each leg keeps the same length, the same slight bend and the foot pointing the same way.
Keep the Gacha Club chibi art style of this image: clean thick dark outlines, flat colours, soft cell shading, same proportions. The face is neutral, the mouth closed and clearly visible.
Solid flat pure green background (#00FF00), no shadows, no text, no frame. Do not use green anywhere on the character.
Character: """

FACE_HEAD = ("Edit this image. Change ONLY the face on the head piece as described below. Keep everything else "
             "exactly as it is: all pieces, their places and sizes, hair, clothes, colours and the flat green "
             "background. Do not move, crop or redraw anything else.\n")
FACES = {
    "mouth_small": "The mouth is slightly open, as if in the middle of saying a word. Eyes unchanged.",
    "mouth_mid": "The mouth is open, as if speaking clearly. Eyes unchanged.",
    "mouth_wide": ('The mouth is wide open, as if shouting "A": a big open mouth, much bigger than in normal '
                   'speech, the tongue and the upper teeth visible, but still inside the face, above the chin '
                   'line. Eyes unchanged.'),
    "eyes_closed": "The eyes are gently closed, calm. Mouth unchanged.",
    "scared": "Scared: eyes wide open with small pupils, eyebrows raised and pulled together, mouth slightly open.",
    # a full scream always ran past the chin or greyed the face: horror is in the eyes, the mouth stays
    # small (combine eyes "horror" with mouth "wide" in a scene for a scream)
    "horror": ("Pure horror: eyes extremely wide open, tiny shaking pupils, eyebrows raised high and pulled "
               "together, the mouth a small open 'O', no bigger than when talking. Same skin colour, nothing "
               "drawn below the chin."),
    "sad": "Sad: eyebrows raised in the middle, eyes looking down, corners of the mouth down.",
    "angry": "Angry: eyebrows lowered and pulled together, eyes narrowed, lips pressed.",
    "stern": "Stern cold look: eyebrows lowered, eyes narrowed, lips pressed into a thin line.",
    "pain": "Pain: eyes squeezed shut, eyebrows pulled together, teeth clenched and visible.",
    "tired": "Tired: heavy half-closed eyelids, eyebrows relaxed, mouth closed.",
    "calm": "Calm cold look: eyes half-lidded and looking straight ahead, mouth closed in a flat line.",
}
GROUPS = {"talk": ["mouth_small", "mouth_mid", "mouth_wide"], "blink": ["eyes_closed"]}


# --- API ----------------------------------------------------------------------------------------
class Panel:
    def __init__(self, site, model):
        pw = os.environ.get("BANANA_PASS") or PASS_FILE.read_text(encoding="utf-8").strip()
        self.s = requests.Session()
        self.s.auth = ("manga", pw)
        self.s.verify = False
        self.site, self.model = site, model

    def _req(self, method, path, **kw):
        for i in range(5):
            try:
                r = self.s.request(method, API + path, timeout=kw.pop("timeout", 120), **kw)
                if r.status_code >= 500:
                    raise requests.RequestException("HTTP %d %s" % (r.status_code, r.text[:200]))
                return r
            except requests.RequestException as e:
                if i == 4:
                    raise
                print("   сеть: %s, повтор через 10 с" % e)
                time.sleep(10)

    def submit(self, base, image_path, prompt):
        data = Path(image_path).read_bytes()
        ext = Path(image_path).suffix.lower().lstrip(".").replace("jpg", "jpeg")
        body = {"image": "data:image/%s;base64,%s" % (ext, base64.b64encode(data).decode()),
                "prompt": prompt, "base": base, "overwrite": True}
        r = self._req("POST", "/reference", json=body)
        j = r.json()
        if not j.get("ok"):
            raise RuntimeError("reference не принят: %s" % r.text[:300])
        return j["base"]

    def run(self, base, prefix=False, opts=None):
        """Start the worker on this job (or, with prefix, on every job whose name starts with base).
        The panel runs one worker per site: while it is busy the answer is 'already running'
        (HTTP 200), and then we just try again later. opts: t2i / ratio / res for this run."""
        body = {"site": self.site, "model": self.model, **(opts or {})}
        if prefix:
            body["prefix"] = True
        r = self._req("POST", "/reference/run?base=" + base, json=body)
        if prefix and r.status_code == 404:
            return None                     # panel without prefix runs
        if r.status_code != 200:
            raise RuntimeError("run не принят: %s" % r.text[:300])
        started = r.json().get("started") or []
        errs = [x.get("error") for x in started if x.get("error")]
        if any(e == "already running" for e in errs):
            return False
        if errs:
            raise RuntimeError("run: %s" % errs)
        return True

    def busy(self):
        try:
            return bool(self._req("GET", "/state").json()["sites"][self.site].get("running"))
        except Exception:
            return True

    def results(self):
        items = self._req("GET", "/references").json()["items"]
        return {it["base"]: it.get("results", {}).get(self.site) for it in items}

    @staticmethod
    def _whole(b):
        if b[:4] == b"\x89PNG":
            return b"IEND" in b[-16:]
        if b[:3] == b"\xff\xd8\xff":
            return b"\xff\xd9" in b[-32:]
        if b[8:12] == b"WEBP":
            return len(b) >= int.from_bytes(b[4:8], "little") + 8
        return True

    def download(self, base, dest_stem):
        # the download through nginx was cut off now and then (32 KB of a 2 MB png): check and fetch again
        for k in range(5):
            r = self._req("GET", "/dl?site=%s&base=%s" % (self.site, base), timeout=300)
            if r.status_code != 200 or len(r.content) < 1000:
                raise RuntimeError("не скачался результат %s: HTTP %d" % (base, r.status_code))
            cl = int(r.headers.get("Content-Length") or 0)
            if (not cl or len(r.content) >= cl) and self._whole(r.content):
                break
            print("   %s: скачалось не целиком (%d из %s байт), ещё раз" % (base, len(r.content), cl or "?"))
            time.sleep(3)
        else:
            raise RuntimeError("результат %s не скачивается целиком" % base)
        head = r.content[:12]
        ext = ".png" if head.startswith(b"\x89PNG") else ".jpg" if head[:3] == b"\xff\xd8\xff" else \
            ".webp" if head[8:12] == b"WEBP" else ".png"
        out = Path(str(dest_stem) + ext)
        out.write_bytes(r.content)
        return out

    def why(self, base):
        """The worker's log lines about this job (the API only says 'limit retries exhausted')."""
        try:
            t = self._req("GET", "/log?site=" + self.site).text
            lines = [l for l in t.splitlines() if base in l and "compr" not in l]
            return lines[-1].split(": ", 1)[-1][:300] if lines else ""
        except Exception:
            return ""

    def delete(self, base):
        try:
            self._req("DELETE", "/reference?base=" + base, json={"confirm": True})
        except Exception as e:
            print("   не удалилось задание %s: %s" % (base, e))


MID_OPEN = {}


def mouth_order(n, base, chk):
    """small < mid < wide: the AI often gives a 'wide' mouth smaller than the 'mid' one."""
    if n not in ("mouth_small", "mouth_wide") or chk["level"] == 2:
        return chk
    char_dir = Path(base).parent
    if char_dir not in MID_OPEN:
        mid = find_image(char_dir, "mouth_mid")
        MID_OPEN[char_dir] = gc.face_check(base, mid, "mouth_mid")["open"] if mid else None
    m = MID_OPEN[char_dir]
    if not m or m <= 0:
        return chk
    o = chk.get("open", 0)
    bad = None
    if n == "mouth_wide" and o < 1.25 * m:
        bad = "рот открыт не шире, чем в mouth_mid (%d против %d)" % (o, m)
    if n == "mouth_small" and o > m / 1.25:
        bad = "рот открыт не меньше, чем в mouth_mid (%d против %d)" % (o, m)
    if bad:
        chk["level"] = 2
        chk["notes"] = [x for x in chk["notes"] if x != "меняется только лицо"] + [bad]
    return chk


# --- jobs ---------------------------------------------------------------------------------------
class Job:
    def __init__(self, name, prompt, image, check, opts=None, group="a"):
        self.name, self.prompt, self.image, self.check = name, prompt, image, check
        self.tries, self.fails, self.base, self.sent = 0, 0, None, 0
        self.done, self.result, self.attempts = False, None, []
        self.after = None           # name of a job that must be finished first
        self.opts, self.group = opts or {}, group    # run options; jobs of one group start together
        self.keep = False           # True: a passing picture stays in _gen (variants to choose from)


# --- backgrounds from план.md -------------------------------------------------------------------
def parse_plan(plan):
    """[{code, title, prompt, edit_of, optional}] from the background list of план.md."""
    import re
    text = plan.read_text(encoding="utf-8")
    lines = text.splitlines()
    tails, items = {}, []

    def block_after(i):
        while i < len(lines) and not lines[i].startswith("```"):
            i += 1
        j = i + 1
        while j < len(lines) and not lines[j].startswith("```"):
            j += 1
        return " ".join(l.strip() for l in lines[i + 1:j]).strip()

    for i, l in enumerate(lines):
        m = re.match(r"\*\*Хвост для (\S+)", l)
        if m:
            tails[m.group(1).lower()] = block_after(i + 1)
        m = re.match(r"\*\*([★☆])\s*(✎\s*)?(H\d+)\s*[—-]\s*(.+?)\*\*(.*)", l)
        if m:
            e = re.search(r"правка (H\d+)", m.group(5))
            items.append({"code": m.group(3), "title": m.group(4).strip(), "optional": m.group(1) == "☆",
                          "edit_of": e.group(1) if e else None, "prompt": block_after(i + 1)})
    for it in items:
        it["prompt"] = re.sub(r"\[хвост для (\S+?)\]",
                              lambda m: tails.get(m.group(1).lower(), next((v for k, v in tails.items()
                                                                            if k.startswith(m.group(1).lower()[:6])), "")),
                              it["prompt"])
    return items


def bg_sheet(paths, out):
    import cv2
    import numpy as np
    tiles = []
    for p in paths:
        im = gc.imread(p)
        t = cv2.resize(im, (480, int(480 * im.shape[0] / im.shape[1])))
        t = cv2.copyMakeBorder(t[:270], 0, 270 - t[:270].shape[0], 0, 0, cv2.BORDER_CONSTANT)
        for c, w in (((0, 0, 0), 4), ((255, 255, 255), 2)):
            cv2.putText(t, p.stem, (8, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.8, c, w)
        tiles.append(t)
    cols = 3
    while len(tiles) % cols:
        tiles.append(np.zeros_like(tiles[0]))
    cv2.imencode(".jpg", np.vstack([np.hstack(tiles[i:i + cols]) for i in range(0, len(tiles), cols)]),
                 [cv2.IMWRITE_JPEG_QUALITY, 85])[1].tofile(str(out))


def find_image(char_dir, stem):
    for e in IMAGE_EXT:
        if (char_dir / (stem + e)).exists():
            return char_dir / (stem + e)
    return None


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("mode", choices=["face", "sheet", "bg", "pick"])
    ap.add_argument("char_dir", help="character folder (face, sheet) or project folder (bg, pick)")
    ap.add_argument("what", nargs="*")
    ap.add_argument("--variants", type=int, default=2, help="bg: pictures per background")
    ap.add_argument("--res", default="1K", help="bg: 1K (2K/4K need a login on imgcreatorai; pick upscales)")
    ap.add_argument("--all", action="store_true", help="bg: also the optional (☆) ones")
    ap.add_argument("--tries", type=int, default=4)
    ap.add_argument("--model", default="nano-banana-2")
    ap.add_argument("--site", default="imgcreatorai")
    ap.add_argument("--base", default="sheet", help="base sheet in char_dir for faces (stem or file name)")
    ap.add_argument("--strict", action="store_true")
    ap.add_argument("--timeout", type=float, default=15, help="minutes to wait for one picture")
    ap.add_argument("--overwrite", action="store_true", help="regenerate even if <name>.png already exists")
    a = ap.parse_args()

    char_dir = Path(a.char_dir)
    bgdir = gc.HORROR / "bg"
    if a.mode == "pick":
        # banana_gen.py pick projects/<p> H01=2 H03=1  ->  bg/H01.jpg from bg_gen/H01_v2.*
        # the guest API gives 1376x768 (2K needs a login): pictures under 2000 px wide are upscaled x2
        # with Real-ESRGAN (upscale.py) to the 2752x1536 of the other backgrounds; the 1K original
        # goes to bg/_1k/ like before
        import subprocess
        import cv2
        small = bgdir / "_1k"
        small.mkdir(exist_ok=True)
        todo = []
        for w in a.what:
            code, k = w.split("=")
            src = find_image(char_dir / "bg_gen", "%s_v%s" % (code, k))
            if not src:
                sys.exit("нет %s_v%s в %s" % (code, k, char_dir / "bg_gen"))
            dst = bgdir / (code + ".jpg")
            if dst.exists():
                dst.rename(char_dir / "bg_gen" / ("%s_old_%s.jpg" % (code, time.strftime("%m%d%H%M%S"))))
            im = gc.imread(src)
            if im.shape[1] < 2000:
                cv2.imencode(".jpg", im, [cv2.IMWRITE_JPEG_QUALITY, 95])[1].tofile(str(small / dst.name))
                todo.append(str(small / dst.name))
            else:
                cv2.imencode(".jpg", im, [cv2.IMWRITE_JPEG_QUALITY, 95])[1].tofile(str(dst))
            print(src.name, "->", dst)
        if todo:
            subprocess.run([sys.executable, str(Path(__file__).parent / "upscale.py"), str(bgdir)] + todo, check=True)
        return
    char_dir.mkdir(parents=True, exist_ok=True)
    gen = char_dir / ("bg_gen" if a.mode == "bg" else "_gen")
    gen.mkdir(exist_ok=True)
    lock = gen / "running.pid"
    if lock.exists():
        try:
            other = int(lock.read_text().strip())
            alive = other != os.getpid() and str(other) in os.popen(
                'tasklist /FI "PID eq %d" /NH' % other if os.name == "nt" else "ps -p %d -o pid=" % other).read()
        except ValueError:
            alive = False
        if alive:
            sys.exit("для %s уже работает генератор (pid %d). Остановить: taskkill /F /PID %d" % (char_dir, other, other))
    lock.write_text(str(os.getpid()))
    import atexit
    atexit.register(lambda: lock.unlink(missing_ok=True))
    accept = 0 if a.strict else 1
    jobs = []
    if a.mode == "bg":
        import cv2
        import numpy as np
        items = parse_plan(char_dir / "план.md")
        if not items:
            sys.exit("в %s нет списка фонов (**★ Hxx — ...** + блок с промтом)" % (char_dir / "план.md"))
        want = set(a.what)
        blank = gen / "_t2i_blank.png"          # t2i jobs still need a picture file; the worker ignores it
        cv2.imencode(".png", np.full((90, 160, 3), 128, np.uint8))[1].tofile(str(blank))
        for it in items:
            if want and it["code"] not in want:
                continue
            if not want and it["optional"] and not a.all:
                continue
            if not want and (bgdir / (it["code"] + ".jpg")).exists():
                print("%-6s уже есть в bg/, пропуск" % it["code"])
                continue
            if it["edit_of"]:
                src = bgdir / (it["edit_of"] + ".jpg")
                if not src.exists():
                    print("%-6s правка %s: сначала выберите %s (pick), пропуск" % (it["code"], it["edit_of"], it["edit_of"]))
                    continue
                image, opts, group = src, {"ratio": "16:9", "res": a.res}, "e"
            else:
                image, opts, group = blank, {"t2i": True, "ratio": "16:9", "res": a.res}, "t"
            for k in range(1, a.variants + 1):
                j = Job("%s_v%d" % (it["code"], k), it["prompt"], image, gc.bg_check, opts, group)
                j.keep = True
                jobs.append(j)
            print("%-6s %s%s" % (it["code"], it["title"], "  (правка %s)" % it["edit_of"] if it["edit_of"] else ""))
        if not jobs:
            sys.exit("нечего генерировать")
    elif a.mode == "sheet":
        desc = " ".join(a.what).strip()
        if Path(desc).is_file():
            desc = Path(desc).read_text(encoding="utf-8").strip()
        if desc.lower().startswith("character:"):
            desc = desc[10:].strip()
        jobs.append(Job("sheet", SHEET_PROMPT + desc, TEMPLATE_SHEET, lambda p: gc.sheet_check(p)))
    else:
        base = char_dir / a.base if (char_dir / a.base).is_file() else find_image(char_dir, a.base)
        if base is None:
            sys.exit("нет базового листа %s в %s" % (a.base, char_dir))
        names = []
        for w in a.what:
            if "=" in w:
                n, text = w.split("=", 1)
                FACES[n] = text
                names.append(n)
            else:
                names += GROUPS.get(w, [w])
        for n in names:
            if n not in FACES:
                sys.exit("нет готового текста для «%s»: передайте его как %s=\"...\"" % (n, n))
            jobs.append(Job(n, FACE_HEAD + FACES[n], base,
                            lambda p, n=n, base=base: mouth_order(n, base, gc.face_check(
                                base, p, n, debug=gen / (Path(p).stem + "_check.jpg")))))
        # mouth_mid is the yardstick: small and wide are made after it and checked against it
        for j in jobs:
            if j.name in ("mouth_small", "mouth_wide") and "mouth_mid" in names:
                j.after = "mouth_mid"
        print("базовый лист:", base)
        ok, share = gc.base_mouth_visible(base)
        mouthy = [n for n in names if n.startswith("mouth_")]
        if not ok and mouthy:
            sys.exit("На листе %s рот закрыт (маска/шарф, кожи вокруг рта %.0f%%): рты %s рисовать не на чем.\n"
                     "Сначала сделайте базу с открытым ртом, например:\n  banana_gen.py face %s nomask=\"...\" "
                     "и соберите пак из неё." % (base.name, share * 100, ", ".join(mouthy), char_dir))
    if not a.overwrite:
        for j in jobs:
            if j.keep:
                # a background whose prompt changed in план.md is made again; old variants go to _old/
                code = j.name.split("_v")[0]
                pf = gen / (code + ".prompt.txt")
                old_prompt = pf.read_text(encoding="utf-8") if pf.exists() else None
                if old_prompt is not None and old_prompt != j.prompt:
                    have = find_image(gen, j.name)
                    if have:
                        (gen / "_old").mkdir(exist_ok=True)
                        have.replace(gen / "_old" / ("%s_%s%s" % (j.name, time.strftime("%m%d%H%M%S"), have.suffix)))
                        print("%-12s промт изменился - делаю заново" % j.name)
                pf.write_text(j.prompt, encoding="utf-8")
            have = find_image(gen if j.keep else char_dir, j.name)
            if have:
                print("%-12s уже есть (%s), пропуск; --overwrite чтобы сделать заново" % (j.name, have.name))
                j.done, j.result = True, have
    panel = Panel(a.site, a.model)
    log = open(gen / "log.txt", "a", encoding="utf-8")

    def note(msg):
        line = time.strftime("%H:%M:%S ") + msg
        print(line, flush=True)
        log.write(line + "\n")
        log.flush()

    tag = "hz_%s_%s_" % (char_dir.name, time.strftime("%H%M%S"))   # common start of this run's jobs
    prefix_ok = [True]

    def send(j):
        j.tries += 1
        j.base = "%s%s_%s_%s_%d" % (tag, j.group, j.name, time.strftime("%m%d%H%M%S"), j.tries)
        panel.submit(j.base, j.image, j.prompt)
        j.sent = 0
        note("%-12s попытка %d/%d в очереди (%s, %s)" % (j.name, j.tries, a.tries, a.model, j.base))

    def start_waiting():
        """One worker per site: start the queued jobs when the worker is free, one group (same run
        options) at a time, the whole group in one worker run."""
        waiting = [j for j in jobs if not j.done and j.base and not j.sent]
        if not waiting or panel.busy():
            return
        grp = [j for j in waiting if j.group == waiting[0].group]
        if len(grp) > 1 and prefix_ok[0]:
            started = panel.run(tag + grp[0].group + "_", prefix=True, opts=grp[0].opts)
            if started is None:
                prefix_ok[0] = False
            elif started:
                for j in grp:
                    j.sent = time.time()
                note("запущены разом: %s" % ", ".join(j.name for j in grp))
                return
            else:
                return
        j = waiting[0]
        if panel.run(j.base, opts=j.opts):
            j.sent = time.time()
            note("%-12s попытка %d запущена" % (j.name, j.tries))

    def give_up(j):
        j.done = True
        best = sorted(j.attempts, key=lambda t: (t[1]["level"], -t[1].get("score", 0)))
        if best:
            note("%-12s НЕ ВЫШЛО за %d попыток. Лучшая: %s (%s) - проверьте глазами или генерируйте вручную"
                 % (j.name, j.tries, best[0][0].name, gc.summary(best[0][1])))
        else:
            note("%-12s НЕ ВЫШЛО: сервис не отдал ни одной картинки" % j.name)

    def ready_to_send():
        for j in jobs:
            if not j.done and j.base is None and (not j.after or next(x for x in jobs if x.name == j.after).done):
                send(j)

    ready_to_send()
    start_waiting()
    while any(not j.done for j in jobs):
        time.sleep(10)
        res = panel.results()
        for j in jobs:
            if j.done:
                continue
            if not j.sent:
                continue
            r = res.get(j.base)
            if not r:
                if time.time() - j.sent > a.timeout * 60:
                    note("%-12s ждали %d мин - не дождались" % (j.name, a.timeout))
                    panel.delete(j.base)
                    j.fails += 1
                    if j.tries < a.tries and j.fails < 3:
                        send(j)
                    else:
                        give_up(j)
                continue
            if not r.get("ok"):
                note("%-12s сервис ответил ошибкой: %s %s" % (j.name, r.get("err"), panel.why(j.base)))
                panel.delete(j.base)
                j.fails += 1
                j.tries -= 1            # the picture was not made: does not count as a try
                if j.fails < 3:
                    send(j)
                else:
                    give_up(j)
                continue
            path = panel.download(j.base, gen / ("%s_%d" % (j.name, j.tries)))
            panel.delete(j.base)
            try:
                chk = j.check(path)
            except Exception as e:
                chk = {"level": 2, "notes": ["проверка упала: %s" % e]}
            j.attempts.append((path, chk))
            note("%-12s попытка %d: %s%s" % (j.name, j.tries, gc.summary(chk),
                                              "  (score %s)" % chk["score"] if "score" in chk else ""))
            if chk["level"] <= accept and j.keep:
                keep = gen / (j.name + path.suffix)
                path.replace(keep)
                j.done, j.result = True, keep
                note("%-12s ГОТОВО -> %s" % (j.name, keep))
            elif chk["level"] <= accept:
                final = char_dir / (j.name + path.suffix)
                for e in IMAGE_EXT:
                    old = char_dir / (j.name + e)
                    if old.exists() and old != final:
                        old.rename(gen / ("%s_old_%s%s" % (j.name, time.strftime("%m%d%H%M%S"), e)))
                shutil.copyfile(path, final)
                j.done, j.result = True, final
                note("%-12s ГОТОВО -> %s" % (j.name, final))
            elif j.tries < a.tries:
                send(j)
            else:
                give_up(j)
        ready_to_send()
        start_waiting()
    if a.mode == "bg":
        import re
        codes = {j.name.split("_v")[0] for j in jobs}
        got = sorted((p for p in gen.iterdir() if p.suffix.lower() in IMAGE_EXT
                      and re.fullmatch(r"H\d+_v\d+", p.stem) and p.stem.split("_v")[0] in codes),
                     key=lambda p: p.stem)
        if got:
            sheet = gen / ("_выбор_%s.jpg" % time.strftime("%m%d_%H%M"))
            bg_sheet(got, sheet)
            note("лист для выбора: %s  ->  потом: banana_gen.py pick %s H01=1 ..." % (sheet, char_dir))
    bad = [j.name for j in jobs if j.result is None]
    note("итог: готово %d из %d%s" % (len(jobs) - len(bad), len(jobs), ("; не вышло: " + ", ".join(bad)) if bad else ""))
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
