"""Motion test of packs side by side: modes, talking, blinks, emotions.
python demo_video.py <pack[,pack...]> <out.mp4>"""
import subprocess
import sys
from pathlib import Path

import cv2
import numpy as np

ENGINE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ENGINE))
from puppet import Animations, Puppet, translate

pack, out = sys.argv[1], sys.argv[2]
anims = Animations(ENGINE / "anims")
packs = [Puppet(p, anims) for p in pack.split(",")]
W, H, FPS = 1280, 720, 30
# (mode, seconds, talk, face)  face: None or "emotions" (cycle every eyes/mouth state the pack has)
plan = [("idle", 3, True, None), ("idle", 6, False, "emotions"), ("walk", 3, False, None), ("run", 2, False, None),
        ("wave", 3, True, None), ("point", 2, True, None), ("thinking", 3, True, None), ("shiver", 2, False, None),
        ("look_around", 3, False, None), ("cover_face", 3, False, None), ("arms_crossed", 2, True, None),
        ("hug", 2, False, None), ("recoil", 2, False, None), ("back_away", 2, False, None), ("crouch", 2, False, None),
        ("sit_chair", 3, True, None), ("fall_knees", 2, False, None), ("lie_down", 2, False, None),
        ("knockdown", 3, False, None)]


def states(pup):
    """Named face states a pack has beyond open/closed: (label, eyes, mouth)."""
    if not pup.atlas:
        return []
    ev = [e["value"] for e in pup.atlas["eyes"] if isinstance(e["value"], str)]
    mv = [m["value"] for m in pup.atlas["mouths"] if isinstance(m["value"], str)]
    names = [n for n in ev if n not in ("open",)] + [n for n in mv if n not in ev and n not in ("closed",) + tuple(pup.talk_mouths or ())]
    return [(n, n if n in ev else None, n if n in mv else None) for n in names]


ff = subprocess.Popen(["ffmpeg", "-y", "-loglevel", "error", "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", "%dx%d" % (W, H),
                       "-r", str(FPS), "-i", "-", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "20", out],
                      stdin=subprocess.PIPE)
for mode, secs, talk, face in plan:
    n_frames = int(secs * FPS)
    for f in range(n_frames):
        t = f / FPS
        frame = np.full((H, W, 3), 0.42, np.float32)
        frame[int(H * 0.86):] = 0.33
        pose = anims.sample(mode, t)
        af = anims.arm_front(mode, t) or abs(pose[anims.keys.index("armL")]) > 25 or abs(pose[anims.keys.index("foreL")]) > 35
        labels = []
        for n, pup in enumerate(packs):
            S = H * 0.78 / (pup.floor - pup.top)
            cx = W * (n + 1) / (len(packs) + 1)
            view = translate(cx - pup.center_x * S, H * 0.92 - pup.floor * S) @ np.diag([S, S, 1.0])
            eyes, mouth, label = None, None, mode
            if talk and pup.talk_mouths:
                level = (np.sin(t * 17) * 0.5 + 0.5) * (np.sin(t * 5.3) * 0.5 + 0.5)
                mouth = pup.talk_mouths[min(int(level * 4), 3)]
            if face == "emotions":
                st = states(pup)
                if st:
                    label, eyes, mouth = st[min(int(f / n_frames * len(st)), len(st) - 1)]
            blink = 1.0 if (t % 2.7) < 0.12 and face is None else 0.0
            drawn = pup.render(pose, anims.keys, view, (W, H), eyes=eyes, mouth=mouth, blink=blink, arm_front=af, mode=mode)
            if drawn:
                roi, x, y = drawn
                x0, y0 = max(x, 0), max(y, 0)
                r = roi[y0 - y:H - y, x0 - x:W - x]
                reg = frame[y0:y0 + r.shape[0], x0:x0 + r.shape[1]]
                reg[:] = r[..., :3] + reg * (1 - r[..., 3:4])
            labels.append((int(cx), label))
        img = (np.clip(frame, 0, 1) * 255).astype(np.uint8)
        for cx, label in labels:
            cv2.putText(img, label, (cx - 60, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 255, 255), 2, cv2.LINE_AA)
        ff.stdin.write(img.tobytes())
ff.stdin.close()
ff.wait()
print("written", out)
