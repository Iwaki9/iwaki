"""Template data for the browser sheet checker: piece label map at N x N (RLE) + a small ghost image.
python make_template_data.py <шаблон_детали.png> <шаблон_детали.json> <out.json>"""
import base64
import json
import sys

import cv2
import numpy as np

N = 256
NAMES = ["head", "torso", "armF", "armB", "legF", "legB"]
img = cv2.imdecode(np.fromfile(sys.argv[1], np.uint8), cv2.IMREAD_COLOR)
layout = json.loads(open(sys.argv[2], encoding="utf-8").read())
S = img.shape[0]
f = img.astype(np.float32)
key = f[..., 1] - np.maximum(f[..., 0], f[..., 2])
fg = key < 60
n, cl, st, cen = cv2.connectedComponentsWithStats(fg.astype(np.uint8), 8)
labels = np.zeros((S, S), np.uint8)
for i in range(1, n):
    if st[i, cv2.CC_STAT_AREA] < 30:
        continue
    cx, cy = cen[i]
    for k, g in enumerate(NAMES):
        x0, y0, x1, y1 = layout["parts"][g]["box"]
        if x0 - 20 <= cx <= x1 + 20 and y0 - 20 <= cy <= y1 + 20:
            labels[cl == i] = k + 1
            break
small = np.zeros((N, N), np.uint8)
for k in range(1, 7):
    m = cv2.resize((labels == k).astype(np.float32), (N, N), interpolation=cv2.INTER_AREA) > 0.5
    small[m] = k
flat = small.ravel()
runs, prev, cnt = [], flat[0], 0
for v in flat:
    if v == prev:
        cnt += 1
    else:
        runs.append("%d%s" % (prev, np.base_repr(cnt, 36).lower()))
        prev, cnt = v, 1
runs.append("%d%s" % (prev, np.base_repr(cnt, 36).lower()))
ghost = cv2.resize(img, (384, 384), interpolation=cv2.INTER_AREA)
ok, jpg = cv2.imencode(".jpg", ghost, [cv2.IMWRITE_JPEG_QUALITY, 70])
data = {"N": N, "names": NAMES, "rle": ",".join(runs),
        "ghost": "data:image/jpeg;base64," + base64.b64encode(jpg.tobytes()).decode()}
open(sys.argv[3], "w", encoding="utf-8").write(json.dumps(data))
print("pieces:", [int((small == k).sum()) for k in range(1, 7)], "rle tokens:", len(runs), "ghost KB:", len(jpg) // 1024)
