// node check_cli.js <sheet.rgba>  - the browser checker's analysis on an N x N RGBA dump, as JSON
const fs = require("fs");
const path = require("path");
const {analyzeSheet, decodeLabels} = require("./core.js");
const T = JSON.parse(fs.readFileSync(path.join(__dirname, "template.json"), "utf8"));
T.labels = decodeLabels(T);
const px = new Uint8ClampedArray(fs.readFileSync(process.argv[2]));
const r = analyzeSheet(px, T);
const r3 = v => Math.round(v * 1000) / 1000;
console.log(JSON.stringify({
  level: r.level, score: r.score, global: r.global,
  pieces: r.pieces.map(p => p.missing ? {name: p.name, level: p.level, notes: p.notes, missing: true} :
    {name: p.name, level: p.level, notes: p.notes, iou: r3(p.iou), shape: r3(p.shape), shift: Math.round(p.shift), w: r3(p.w), h: r3(p.h)}),
}));
