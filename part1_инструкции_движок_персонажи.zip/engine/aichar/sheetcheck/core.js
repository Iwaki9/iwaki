// ---- analysis core (shared by the userscript and the node test) ------------------------------------
const PIECE_RU = {head: "Голова", torso: "Тело", armF: "Рука передняя", armB: "Рука задняя", legF: "Нога передняя", legB: "Нога задняя"};

function decodeLabels(T) {
  const out = new Uint8Array(T.N * T.N);
  let i = 0;
  for (const tok of T.rle.split(",")) {
    const v = +tok[0], c = parseInt(tok.slice(1), 36);
    out.fill(v, i, i + c);
    i += c;
  }
  return out;
}

// px: RGBA N*N*4 (the sheet scaled to N x N, padded square); T: template data with .labels decoded
function analyzeSheet(px, T) {
  const N = T.N, NN = N * N, K = 1024 / N;            // K: sheet pixels per cell
  const lab = T.labels, names = T.names;
  // 1. key out the green
  const fg = new Uint8Array(NN);
  let semi = 0, bgCount = 0;
  for (let i = 0; i < NN; i++) {
    const r = px[i * 4], g = px[i * 4 + 1], b = px[i * 4 + 2], a = px[i * 4 + 3];
    const key = g - Math.max(r, b);
    if (a < 128 || key >= 60) { bgCount++; if (key < 140 && a >= 128) semi++; } else fg[i] = 1;
  }
  // 2. connected pieces (8-neighbour)
  const comp = new Int32Array(NN).fill(-1), comps = [];
  const stack = new Int32Array(NN);
  for (let s = 0; s < NN; s++) {
    if (!fg[s] || comp[s] >= 0) continue;
    const id = comps.length, c = {id, n: 0, sx: 0, sy: 0, over: new Array(7).fill(0), pix: []};
    let sp = 0; stack[sp++] = s; comp[s] = id;
    while (sp) {
      const p = stack[--sp], x = p % N, y = (p / N) | 0;
      c.n++; c.sx += x; c.sy += y; c.over[lab[p]]++; c.pix.push(p);
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        const xx = x + dx, yy = y + dy;
        if (xx < 0 || yy < 0 || xx >= N || yy >= N) continue;
        const q = yy * N + xx;
        if (fg[q] && comp[q] < 0) { comp[q] = id; stack[sp++] = q; }
      }
    }
    comps.push(c);
  }
  // template piece stats
  const tp = names.map(() => ({n: 0, sx: 0, sy: 0, x0: N, y0: N, x1: -1, y1: -1}));
  for (let i = 0; i < NN; i++) {
    const k = lab[i] - 1;
    if (k < 0) continue;
    const t = tp[k], x = i % N, y = (i / N) | 0;
    t.n++; t.sx += x; t.sy += y;
    t.x0 = Math.min(t.x0, x); t.y0 = Math.min(t.y0, y); t.x1 = Math.max(t.x1, x); t.y1 = Math.max(t.y1, y);
  }
  // 3. which piece each blob belongs to; blobs that cover two pieces = pieces stuck together
  const owner = new Int8Array(comps.length).fill(-1), merged = [], strays = [];
  for (const c of comps) {
    if (c.n < 4) continue;                                  // jpeg specks
    const ov = c.over.slice(1).map((v, k) => [v, k]).sort((a, b) => b[0] - a[0]);
    if (ov[0][0] > 0) {
      owner[c.id] = ov[0][1];
      if (ov[1][0] > Math.max(6, 0.08 * c.n) && ov[1][0] > 0.15 * tp[ov[1][1]].n * 0.3) merged.push([ov[0][1], ov[1][1]]);
    } else {
      // not on any template piece: near one (a long apron, a hand drawn a bit off) or a stray bit
      const cx = c.sx / c.n, cy = c.sy / c.n;
      let best = -1, bd = 1e9;
      tp.forEach((t, k) => {
        const dx = Math.max(t.x0 - cx, 0, cx - t.x1), dy = Math.max(t.y0 - cy, 0, cy - t.y1);
        const d = Math.hypot(dx, dy);
        if (d < bd) { bd = d; best = k; }
      });
      if (bd * K < 60) owner[c.id] = best;
      else if (c.n * K * K > 400) strays.push({x: cx * K, y: cy * K, area: Math.round(c.n * K * K)});
    }
  }
  // 4. each piece against the template
  const pieces = names.map((name, k) => {
    const t = tp[k], res = {name, ru: PIECE_RU[name], k};
    const pix = [];
    comps.forEach(c => { if (owner[c.id] === k) for (const p of c.pix) pix.push(p); });
    res.mask = pix;
    if (!pix.length) { res.missing = true; return res; }
    // a long coat/dress/apron hangs below the torso into the free space: judge the torso above
    // the template's bottom, and report how far it hangs
    let use = pix, extra = 0;
    if (name === "torso") {
      use = pix.filter(p => ((p / N) | 0) <= t.y1 + 1);
      let maxY = 0;
      for (const p of pix) maxY = Math.max(maxY, (p / N) | 0);
      extra = Math.max(0, maxY - t.y1) * K;
      if (!use.length) use = pix;
    }
    let inter = 0, sx = 0, sy = 0, x0 = N, y0 = N, x1 = -1, y1 = -1;
    for (const p of use) {
      const x = p % N, y = (p / N) | 0;
      if (lab[p] === k + 1) inter++;
      sx += x; sy += y;
      x0 = Math.min(x0, x); y0 = Math.min(y0, y); x1 = Math.max(x1, x); y1 = Math.max(y1, y);
    }
    res.iou = inter / (use.length + t.n - inter);
    res.dx = (sx / use.length - t.sx / t.n) * K;
    res.dy = (sy / use.length - t.sy / t.n) * K;
    res.shift = Math.hypot(res.dx, res.dy);
    // shape alone: the piece moved onto the template's centre (the builder aligns limbs anyway)
    const ox = Math.round(res.dx / K), oy = Math.round(res.dy / K);
    let inter2 = 0;
    for (const p of use) {
      const x = p % N - ox, y = ((p / N) | 0) - oy;
      if (x >= 0 && y >= 0 && x < N && y < N && lab[y * N + x] === k + 1) inter2++;
    }
    res.shape = inter2 / (use.length + t.n - inter2);
    res.w = (x1 - x0 + 1) / (t.x1 - t.x0 + 1);
    res.h = (y1 - y0 + 1) / (t.y1 - t.y0 + 1);
    res.extra = extra;
    return res;
  });
  // 5. verdicts. The builder re-aligns arms and legs (a small shift is free, a big one is fitted
  // by box and is less exact); the head and torso are taken where they are (neck, hips on joints).
  for (const p of pieces) {
    const notes = [];
    let lvl = 0;
    const up = (l, msg) => { lvl = Math.max(lvl, l); notes.push(msg); };
    if (p.missing) { p.level = 2; p.notes = ["нет детали"]; continue; }
    const limb = p.name.startsWith("arm") || p.name.startsWith("leg");
    if (limb) {
      if (p.shift > 40) up(1, "сдвинута на " + Math.round(p.shift) + " px, подгонится по рамке");
      else if (p.shift > 16) up(0, "сдвиг " + Math.round(p.shift) + " px, выровняется");
      if (Math.abs(p.h - 1) > 0.25 || Math.abs(p.w - 1) > 0.45) up(2, "другой размер");
      else if (Math.abs(p.h - 1) > 0.08) up(1, (p.h > 1 ? "длиннее" : "короче") + " на " + Math.round(Math.abs(p.h - 1) * 100) + "%");
      if (p.shape < 0.45) up(2, "форма сильно другая");
      else if (p.shape < 0.65) up(1, "форма отличается");
    } else if (p.name === "head") {
      if (p.shift > 40) up(2, "сдвинута на " + Math.round(p.shift) + " px: шея уедет");
      else if (p.shift > 20) up(1, "сдвиг " + Math.round(p.shift) + " px");
      if (p.shape < 0.4) up(2, "форма сильно другая");
      else if (p.shape < 0.55) up(1, "форма отличается (причёска?)");
      if (Math.abs(p.h - 1) > 0.3) up(1, "другой размер");
    } else {
      if (p.shift > 30) up(2, "сдвинуто на " + Math.round(p.shift) + " px: шея и бёдра уедут");
      else if (p.shift > 14) up(1, "сдвиг " + Math.round(p.shift) + " px");
      if (p.shape < 0.45) up(2, "форма сильно другая");
      else if (p.shape < 0.62) up(1, "форма отличается");
      if (p.extra > 70) notes.push("длинная одежда ниже на " + Math.round(p.extra) + " px (подол согнётся)");
    }
    p.level = lvl;
    p.notes = notes.length ? notes : ["ок"];
  }
  const global = [];
  let glvl = 0;
  const seen = new Set();
  for (const [a, b] of merged) {
    const key = [a, b].sort().join();
    if (seen.has(key)) continue;
    seen.add(key);
    glvl = 2;
    global.push("слиплись: " + PIECE_RU[names[a]] + " + " + PIECE_RU[names[b]]);
    pieces[a].level = pieces[b].level = 2;
  }
  if (strays.length) { glvl = Math.max(glvl, 1); global.push("лишние куски на листе: " + strays.length); }
  const semiFrac = semi / Math.max(bgCount, 1);
  if (semiFrac > 0.03) { glvl = Math.max(glvl, 1); global.push("фон неровный (тени/градиент): " + Math.round(semiFrac * 100) + "%"); }
  const worst = Math.max(glvl, ...pieces.map(p => p.level));
  const score = Math.round(100 * pieces.reduce((s, p) => s + (p.missing ? 0 : Math.min(1, p.iou / 0.85)), 0) / pieces.length);
  return {pieces, global, strays, level: worst, score, fg, comp, owner};
}

if (typeof module !== "undefined") module.exports = {analyzeSheet, decodeLabels, PIECE_RU};
