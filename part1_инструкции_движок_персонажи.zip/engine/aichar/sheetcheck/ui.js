// ==UserScript==
// @name         Gacha: проверка листа деталей
// @namespace    horror-gacha
// @version      1.0
// @description  Сравнивает сгенерированный лист деталей (Nano Banana) с шаблоном: места, размеры, слипшиеся детали, фон.
// @match        https://gemini.google.com/*
// @match        https://aistudio.google.com/*
// @match        https://lmarena.ai/*
// @grant        GM_xmlhttpRequest
// @connect      *
// @run-at       document-idle
// ==/UserScript==

(function () {
  "use strict";
  const T = /*DATA*/null;
  /*CORE*/

  T.labels = decodeLabels(T);
  const N = T.N;
  const COLORS = {head: "#e91e63", torso: "#ff9800", armF: "#03a9f4", armB: "#7c4dff", legF: "#8bc34a", legB: "#00bfa5"};
  const LEVEL_COLOR = ["#2e7d32", "#f9a825", "#c62828"];
  const LEVEL_TEXT = ["✅ Отлично — можно собирать", "🟡 Можно собирать, но есть отличия", "🔴 Лучше перегенерировать"];

  // ---- DOM helpers (no innerHTML: Gemini enforces Trusted Types) ---------------------------------
  function el(tag, attrs, ...kids) {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) {
      if (k === "style") e.style.cssText = v;
      else if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
      else e.setAttribute(k, v);
    }
    for (const k of kids) if (k != null) e.append(k.nodeType ? k : document.createTextNode(String(k)));
    return e;
  }

  const host = el("div", {style: "position:fixed;right:16px;bottom:16px;z-index:2147483647;"});
  const root = host.attachShadow({mode: "open"});
  root.append(el("style", {}, `
    * { box-sizing: border-box; font-family: system-ui, Segoe UI, Arial, sans-serif; }
    .fab { background:#222; color:#fff; border:1px solid #555; border-radius:22px; padding:9px 14px; cursor:pointer;
           font-size:14px; box-shadow:0 2px 10px rgba(0,0,0,.4); }
    .fab:hover { background:#333; }
    .panel { position:fixed; right:16px; bottom:64px; width:min(560px, calc(100vw - 32px)); max-height:calc(100vh - 90px);
             overflow:auto; background:#1b1b1b; color:#eee; border:1px solid #444; border-radius:10px; padding:12px;
             box-shadow:0 6px 30px rgba(0,0,0,.6); font-size:13px; }
    .row { display:flex; gap:6px; flex-wrap:wrap; margin-bottom:8px; align-items:center; }
    button.b { background:#2d2d2d; color:#eee; border:1px solid #555; border-radius:6px; padding:6px 10px; cursor:pointer; font-size:13px; }
    button.b:hover { background:#3a3a3a; } button.b.on { background:#0b5394; border-color:#3d85c6; }
    .drop { border:2px dashed #555; border-radius:8px; padding:10px; text-align:center; color:#aaa; margin-bottom:8px; }
    .drop.over { border-color:#3d85c6; color:#fff; }
    .verdict { font-size:15px; font-weight:600; padding:8px 10px; border-radius:6px; margin:6px 0; color:#fff; }
    canvas { width:100%; height:auto; border-radius:6px; background:#555; display:block; }
    table { width:100%; border-collapse:collapse; margin-top:8px; }
    td, th { border-bottom:1px solid #333; padding:4px 5px; text-align:left; vertical-align:top; }
    th { color:#aaa; font-weight:500; }
    .dot { display:inline-block; width:10px; height:10px; border-radius:50%; margin-right:5px; }
    .muted { color:#999; } .close { float:right; cursor:pointer; color:#aaa; font-size:18px; line-height:14px; }
    .hint { position:fixed; left:50%; top:12px; transform:translateX(-50%); background:#0b5394; color:#fff; padding:8px 14px;
            border-radius:8px; font-size:14px; box-shadow:0 2px 12px rgba(0,0,0,.5); }
  `));
  const fab = el("button", {class: "fab", title: "Проверить лист деталей"}, "🧩 Лист");
  const panel = el("div", {class: "panel", style: "display:none"});
  root.append(panel, fab);
  document.documentElement.append(host);

  const status = el("div", {class: "muted"}, "Выбери картинку листа на странице, перетащи файл сюда или вставь Ctrl+V.");
  const out = el("div");
  const drop = el("div", {class: "drop"}, "Перетащи сюда sheet.png / jpg или нажми Ctrl+V");
  let view = {ghost: false, outlines: true, tint: true};
  let last = null;           // {bitmap, result}

  const btnPick = el("button", {class: "b", onclick: startPick}, "🎯 Выбрать картинку");
  const btnLast = el("button", {class: "b", onclick: checkLatest}, "⤓ Последняя большая");
  panel.append(
    el("div", {}, el("span", {class: "close", title: "Закрыть", onclick: () => (panel.style.display = "none")}, "×"),
       el("b", {}, "Проверка листа деталей")),
    el("div", {class: "row", style: "margin-top:8px"}, btnPick, btnLast),
    drop, status, out);
  fab.addEventListener("click", () => { panel.style.display = panel.style.display === "none" ? "block" : "none"; });

  // ---- getting the picture ---------------------------------------------------------------------
  drop.addEventListener("dragover", e => { e.preventDefault(); drop.classList.add("over"); });
  drop.addEventListener("dragleave", () => drop.classList.remove("over"));
  drop.addEventListener("drop", e => {
    e.preventDefault(); drop.classList.remove("over");
    const f = [...e.dataTransfer.files].find(f => f.type.startsWith("image/"));
    if (f) runOnBlob(f, f.name);
    else {
      const url = e.dataTransfer.getData("text/uri-list") || e.dataTransfer.getData("text/plain");
      if (url) runOnUrl(url.trim());
    }
  });
  document.addEventListener("paste", e => {
    if (panel.style.display === "none") return;
    const item = [...(e.clipboardData || {}).items || []].find(i => i.type.startsWith("image/"));
    if (item) { e.preventDefault(); runOnBlob(item.getAsFile(), "из буфера"); }
  });

  function gmBlob(url) {
    return new Promise((resolve, reject) => {
      if (typeof GM_xmlhttpRequest !== "function") return reject(new Error("нет GM_xmlhttpRequest"));
      GM_xmlhttpRequest({method: "GET", url, responseType: "blob",
        onload: r => (r.status >= 200 && r.status < 300 && r.response) ? resolve(r.response) : reject(new Error("HTTP " + r.status)),
        onerror: () => reject(new Error("сеть")), ontimeout: () => reject(new Error("таймаут"))});
    });
  }
  async function urlToBlob(url) {
    if (url.startsWith("blob:") || url.startsWith("data:")) return (await fetch(url)).blob();
    try { return await gmBlob(url); } catch (e) {
      return (await fetch(url, {credentials: "include"})).blob();
    }
  }
  async function runOnUrl(url) {
    status.textContent = "Загружаю картинку…";
    try { runOnBlob(await urlToBlob(url), url.slice(0, 60)); }
    catch (e) { status.textContent = "Не удалось скачать картинку: " + e.message + ". Сохрани её и перетащи файлом."; }
  }
  async function runOnImgElement(img) {
    // a full-size version when the page shows a preview (googleusercontent "=s..." / "=w...-h..." suffix)
    let url = img.currentSrc || img.src;
    if (/googleusercontent\.com/.test(url)) url = url.replace(/=[swh][0-9][^/?#]*$/, "=s0");
    if (!url) { status.textContent = "У этого элемента нет картинки."; return; }
    try { await runOnBlob(await urlToBlob(url), "со страницы"); }
    catch (e) {
      try { await runOnBlob(await urlToBlob(img.currentSrc || img.src), "со страницы (превью)"); }
      catch (e2) { status.textContent = "Не удалось взять картинку: " + e2.message + ". Сохрани её и перетащи файлом."; }
    }
  }

  function candidates() {
    return [...document.images].filter(i => {
      const r = i.getBoundingClientRect();
      return i.naturalWidth >= 300 && Math.abs(i.naturalWidth / i.naturalHeight - 1) < 0.2 && r.width > 120 && !host.contains(i);
    });
  }
  function checkLatest() {
    const c = candidates();
    if (!c.length) { status.textContent = "Не нашёл на странице квадратной картинки. Выбери вручную или перетащи файл."; return; }
    const img = c[c.length - 1];
    img.scrollIntoView({block: "center", behavior: "smooth"});
    status.textContent = "Проверяю последнюю картинку…";
    runOnImgElement(img);
  }

  let picking = null;
  function startPick() {
    if (picking) return stopPick();
    const hint = el("div", {class: "hint"}, "Щёлкни по картинке листа (Esc — отмена)");
    root.append(hint);
    btnPick.classList.add("on");
    let hovered = null;
    const over = e => {
      const img = e.target.closest ? e.target.closest("img") : null;
      if (hovered && hovered !== img) { hovered.style.outline = hovered._o || ""; hovered = null; }
      if (img && !host.contains(img)) { hovered = img; img._o = img.style.outline; img.style.outline = "3px solid #3d85c6"; }
    };
    const click = e => {
      const img = e.target.closest ? e.target.closest("img") : null;
      if (!img || host.contains(img)) return;
      e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
      stopPick();
      status.textContent = "Проверяю…";
      runOnImgElement(img);
    };
    const key = e => { if (e.key === "Escape") stopPick(); };
    document.addEventListener("mouseover", over, true);
    document.addEventListener("click", click, true);
    document.addEventListener("keydown", key, true);
    picking = () => {
      document.removeEventListener("mouseover", over, true);
      document.removeEventListener("click", click, true);
      document.removeEventListener("keydown", key, true);
      if (hovered) hovered.style.outline = hovered._o || "";
      hint.remove(); btnPick.classList.remove("on");
    };
  }
  function stopPick() { if (picking) { picking(); picking = null; } }

  // ---- analysis ---------------------------------------------------------------------------------
  function squareCanvas(bmp) {
    // pad to a square with the corner colour, like the builder does, then halve down to N
    const S = Math.max(bmp.width, bmp.height);
    let c = document.createElement("canvas");
    c.width = c.height = S;
    let x = c.getContext("2d");
    const probe = document.createElement("canvas"); probe.width = probe.height = 1;
    const px = probe.getContext("2d");
    px.drawImage(bmp, 2, 2, 1, 1, 0, 0, 1, 1);
    const d = px.getImageData(0, 0, 1, 1).data;
    x.fillStyle = `rgb(${d[0]},${d[1]},${d[2]})`;
    x.fillRect(0, 0, S, S);
    x.drawImage(bmp, (S - bmp.width) / 2, (S - bmp.height) / 2);
    let size = S;
    while (size / 2 >= N) {
      const n = document.createElement("canvas");
      size = Math.max(N, Math.round(size / 2));
      n.width = n.height = size;
      const nx = n.getContext("2d");
      nx.imageSmoothingQuality = "high";
      nx.drawImage(c, 0, 0, size, size);
      c = n;
    }
    if (size !== N) {
      const n = document.createElement("canvas"); n.width = n.height = N;
      const nx = n.getContext("2d"); nx.imageSmoothingQuality = "high"; nx.drawImage(c, 0, 0, N, N); c = n;
    }
    return {small: c, full: (() => { const f = document.createElement("canvas"); f.width = f.height = S;
      const fx = f.getContext("2d"); fx.fillStyle = `rgb(${d[0]},${d[1]},${d[2]})`; fx.fillRect(0, 0, S, S);
      fx.drawImage(bmp, (S - bmp.width) / 2, (S - bmp.height) / 2); return f; })()};
  }

  async function runOnBlob(blob, label) {
    try {
      const bmp = await createImageBitmap(blob);
      const {small, full} = squareCanvas(bmp);
      const px = small.getContext("2d").getImageData(0, 0, N, N).data;
      const result = analyzeSheet(px, T);
      last = {full, result, label, w: bmp.width, h: bmp.height};
      render();
    } catch (e) {
      status.textContent = "Ошибка: " + e.message;
      console.error(e);
    }
  }

  let ghostBmp = null;
  async function ghost() {
    if (ghostBmp) return ghostBmp;
    const b64 = T.ghost.split(",")[1], bin = atob(b64), u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) u[i] = bin.charCodeAt(i);
    ghostBmp = await createImageBitmap(new Blob([u], {type: "image/jpeg"}));
    return ghostBmp;
  }

  async function render() {
    if (!last) return;
    const {full, result, label, w, h} = last;
    out.textContent = "";
    status.textContent = `Картинка: ${label}, ${w}×${h}` + (w !== h ? " (не квадрат — дополнена)" : "") + `. Совпадение: ${result.score}%`;
    out.append(el("div", {class: "verdict", style: `background:${LEVEL_COLOR[result.level]}`}, LEVEL_TEXT[result.level]));
    for (const g of result.global) out.append(el("div", {style: "color:#ffb74d;margin:2px 0"}, "• " + g));

    const toggles = el("div", {class: "row"});
    const tg = (key, text) => {
      const b = el("button", {class: "b" + (view[key] ? " on" : ""), onclick: () => { view[key] = !view[key]; render(); }}, text);
      toggles.append(b);
    };
    tg("outlines", "Контуры шаблона"); tg("tint", "Подсветка деталей"); tg("ghost", "Шаблон поверх");
    out.append(toggles);

    const S = 512, cv = el("canvas", {width: S, height: S});
    const cx = cv.getContext("2d");
    cx.drawImage(full, 0, 0, S, S);
    const sc = S / N;
    if (view.tint) {
      // generated pixels of each piece, tinted by its verdict
      const img = cx.getImageData(0, 0, S, S), d = img.data;
      const lvlOf = result.pieces.map(p => p.level);
      for (let i = 0; i < N * N; i++) {
        const c = result.comp[i];
        if (c < 0) continue;
        const k = result.owner[c];
        const col = k < 0 ? [255, 0, 255] : [[46, 125, 50], [249, 168, 37], [198, 40, 40]][lvlOf[k]];
        const x0 = (i % N) * sc, y0 = ((i / N) | 0) * sc;
        for (let yy = 0; yy < sc; yy++) for (let xx = 0; xx < sc; xx++) {
          const j = ((y0 + yy) * S + x0 + xx) * 4;
          d[j] = d[j] * 0.75 + col[0] * 0.25; d[j + 1] = d[j + 1] * 0.75 + col[1] * 0.25; d[j + 2] = d[j + 2] * 0.75 + col[2] * 0.25;
        }
      }
      cx.putImageData(img, 0, 0);
    }
    if (view.ghost) { cx.globalAlpha = 0.45; cx.drawImage(await ghost(), 0, 0, S, S); cx.globalAlpha = 1; }
    if (view.outlines) {
      const lab = T.labels;
      for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
        const v = lab[y * N + x];
        if (!v) continue;
        const edge = x === 0 || y === 0 || x === N - 1 || y === N - 1 || lab[y * N + x - 1] !== v || lab[y * N + x + 1] !== v ||
                     lab[(y - 1) * N + x] !== v || lab[(y + 1) * N + x] !== v;
        if (!edge) continue;
        cx.fillStyle = COLORS[T.names[v - 1]];
        cx.fillRect(x * sc, y * sc, sc, sc);
      }
    }
    for (const s of result.strays) {
      cx.strokeStyle = "#ff00ff"; cx.lineWidth = 3;
      cx.beginPath(); cx.arc(s.x / 1024 * S, s.y / 1024 * S, 14, 0, 7); cx.stroke();
    }
    out.append(cv);
    out.append(el("div", {class: "muted", style: "margin-top:4px"},
      "Цветные линии — где деталь должна быть по шаблону. Подсветка: зелёный — ок, жёлтый — отличия, красный — плохо, фиолетовый — лишнее."));

    const tb = el("table", {}, el("tr", {}, el("th", {}, "Деталь"), el("th", {}, "Форма"), el("th", {}, "Сдвиг"), el("th", {}, "Размер"), el("th", {}, "")));
    for (const p of result.pieces) {
      const dot = el("span", {class: "dot", style: `background:${LEVEL_COLOR[p.level]}`});
      const name = el("td", {}, dot, el("span", {style: `border-bottom:2px solid ${COLORS[p.name]}`}, p.ru));
      if (p.missing) { tb.append(el("tr", {}, name, el("td", {colspan: 4}, "не найдена"))); continue; }
      tb.append(el("tr", {}, name,
        el("td", {}, Math.round(p.shape * 100) + "%"),
        el("td", {}, Math.round(p.shift) + " px"),
        el("td", {}, `${Math.round(p.w * 100)}×${Math.round(p.h * 100)}%`),
        el("td", {}, p.notes.join("; "))));
    }
    out.append(tb);
    out.append(el("div", {class: "muted", style: "margin-top:6px"},
      "Форма — насколько силуэт детали совпадает с шаблоном после совмещения. Сдвиг — в пикселях листа 1024. " +
      "Руки и ноги сборщик сам выравнивает; голову и тело — нет, им важно стоять на месте."));
  }
})();
