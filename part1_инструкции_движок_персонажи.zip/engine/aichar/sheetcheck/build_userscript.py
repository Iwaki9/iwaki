"""Assemble the Tampermonkey script: ui.js + core.js + template data.
python build_userscript.py <out.user.js>
Rebuild after changing шаблон_детали.png (run make_template_data.py first)."""
import sys
from pathlib import Path

here = Path(__file__).parent
ui = (here / "ui.js").read_text(encoding="utf-8")
core = (here / "core.js").read_text(encoding="utf-8")
data = (here / "template.json").read_text(encoding="utf-8")
assert "/*DATA*/null" in ui and "/*CORE*/" in ui
out = ui.replace("/*DATA*/null", data).replace("/*CORE*/", core)
Path(sys.argv[1]).write_text(out, encoding="utf-8")
print("written", sys.argv[1], len(out) // 1024, "KB")
