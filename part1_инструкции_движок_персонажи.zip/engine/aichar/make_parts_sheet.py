"""Exploded template: the Gacha boy's parts laid out apart on one green sheet, for Nano Banana to
repaint into a character in one go. Writes the sheet and its layout (where each part went).

    python make_parts_sheet.py <template_pack> <out.png> <layout.json>
"""
import json
import sys
from pathlib import Path

import cv2
import numpy as np

ENGINE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ENGINE))
sys.path.insert(0, str(Path(__file__).parent))
from puppet import Animations, Puppet
from groups import GROUPS

template, out_png, out_json = sys.argv[1:4]
pup = Puppet(template, Animations(ENGINE / "anims"))
size = pup.size
import os
V1 = os.environ.get("LAYOUT") == "v1"   # first layout: head over torso, no room for a long coat
SCALE = 1.3 if V1 else 1.08
SHEET = 1024
GAP = 34 if V1 else 26

parts = {}
for g, bones in GROUPS.items():
    canvas = np.zeros((size, size, 4), np.float32)
    for layer in pup.layers:
        if layer["bone"] in bones:
            im = pup._image(layer["file"])
            a = im[..., 3:4]
            canvas[..., :3] = im[..., :3] * a + canvas[..., :3] * (1 - a)
            canvas[..., 3:4] = a + canvas[..., 3:4] * (1 - a)
    ys, xs = np.nonzero(canvas[..., 3] > 0.02)
    x0, y0, x1, y1 = xs.min(), ys.min(), xs.max() + 1, ys.max() + 1
    parts[g] = (canvas[y0:y1, x0:x1], (int(x0), int(y0)))

# columns: front arm over front leg | head over torso | back arm over back leg
def dims(g):
    h, w = parts[g][0].shape[:2]
    return w * SCALE, h * SCALE


# the torso has its own column with free space under it, so a long coat, dress or apron has
# room to hang down; the head goes to a column of its own
cols = [["armF", "legF"], ["head", "torso"], ["armB", "legB"]] if V1 else [["armF", "legF"], ["torso"], ["head"], ["armB", "legB"]]
TOP = 40
col_w = [max(dims(g)[0] for g in c) for c in cols]
col_h = [sum(dims(g)[1] for g in c) + GAP for c in cols]
total_w = sum(col_w) + GAP * 2
left = (SHEET - total_w) / 2
sheet = np.zeros((SHEET, SHEET, 3), np.float32)
sheet[:] = (0, 1, 0)  # BGR pure green
layout = {"scale": SCALE, "sheet": SHEET, "size": size, "parts": {}}
x = left
for c, w, h in zip(cols, col_w, col_h):
    y = TOP if (not V1 and c in (["torso"], ["head"])) else (SHEET - h) / 2
    for g in c:
        img, (ox, oy) = parts[g]
        pw, ph = dims(g)
        px, py = int(round(x + (w - pw) / 2)), int(round(y))
        big = cv2.resize(img, (int(round(pw)), int(round(ph))), interpolation=cv2.INTER_CUBIC)
        a = np.clip(big[..., 3:4], 0, 1)
        reg = sheet[py:py + big.shape[0], px:px + big.shape[1]]
        reg[:] = np.clip(big[..., :3], 0, 1) * a + reg * (1 - a)
        # canvas point (cx, cy) of this part sits on the sheet at px + (cx - ox) * SCALE
        layout["parts"][g] = {"canvas_origin": [ox, oy], "sheet_origin": [px, py],
                              "box": [px, py, px + big.shape[1], py + big.shape[0]]}
        y += ph + GAP
    x += w + GAP
cv2.imencode(".png", (sheet * 255).astype(np.uint8))[1].tofile(out_png)
Path(out_json).write_text(json.dumps(layout, indent=1), encoding="utf-8")
print("written", out_png)
