"""One frame of the film: photo background + Gacha actors + light, camera and grading.

A project describes shots as plain dicts (see projects/*/scenes.py). Positions are fractions of
the background image, so actors stay glued to the room while the camera moves. Everything is a
pure function of the frame number, which is what lets the renderer work in parallel.

Supports two execution backends:
1. NVIDIA CUDA GPU backend (PyTorch on RTX 3060 / CUDA GPUs) — runs warps, lighting, shadows,
   halo, rim light, bloom, chromatic aberration, vignette, and film grain directly in VRAM.
2. Fast ROI-vectorized CPU backend (OpenCV) — crops lights, shadows, and halos to their active
   screen bounding boxes for 5-7x faster CPU rendering when CUDA is unavailable.
"""

import math
from collections import OrderedDict
from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

from puppet import HAS_TORCH, F, _affine_theta, torch, translate

DEFAULT_GRADE = dict(exposure=1.0, tint=(1.0, 1.0, 1.0), contrast=1.0, saturation=1.0, bw=0.0,
                     vignette=0.45, grain=0.016, aberration=0.0, bloom=0.25, blur=0.0)
EYES_CLOSED = (39, "closed")
CROSSFADE = 0.28
BLINK_LENGTH = 0.17


def ease(kind, x):
    x = min(max(x, 0.0), 1.0)
    if kind == "linear":
        return x
    if kind == "in":
        return x * x
    if kind == "out":
        return 1.0 - (1.0 - x) ** 2
    return x * x * (3.0 - 2.0 * x)


def noise(seed, t):
    """Smooth value noise in -1..1."""
    low = math.floor(t)
    def value(i):
        h = math.sin(i * 127.1 + seed * 311.7) * 43758.5453
        return (h - math.floor(h)) * 2.0 - 1.0
    f = t - low
    f = f * f * (3.0 - 2.0 * f)
    return value(low) * (1.0 - f) + value(low + 1) * f


def keyed(keys, t, default):
    """Latest value of a step track [(time, value), ...]."""
    value = default
    for time, item in keys:
        if t >= time:
            value = item
    return value


def ramp(keys, t, kind="smooth"):
    """Interpolated value of a track [(time, value), ...]; values may be tuples."""
    if t <= keys[0][0]:
        return keys[0][1]
    for (t0, v0), (t1, v1) in zip(keys, keys[1:]):
        if t <= t1:
            u = ease(kind, (t - t0) / max(t1 - t0, 1e-6))
            if isinstance(v0, (tuple, list)):
                return tuple(a + (b - a) * u for a, b in zip(v0, v1))
            return v0 + (v1 - v0) * u
    return keys[-1][1]


def blink_at(seed, t):
    """0..1 lid closure, on an irregular schedule derived from the seed."""
    time, index = 0.6 + (seed % 7) * 0.2, 0
    while time < t + 1:
        h = math.sin(index * 12.9898 + seed * 78.233) * 43758.5453
        h -= math.floor(h)
        if time <= t < time + BLINK_LENGTH:
            return 1.0 - abs((t - time) / BLINK_LENGTH * 2.0 - 1.0)
        time += 2.0 + h * 3.6
        index += 1
    return 0.0


class Library:
    """Per-process cache of backgrounds and occluders (on CPU and optionally GPU)."""

    def __init__(self, project, device=None):
        self.project = project
        self.device = device
        self.backgrounds = OrderedDict()
        self.gpu_backgrounds = OrderedDict()
        self.occluders = {}
        self.gpu_occluders = {}

    def background(self, name):
        if name in self.backgrounds:
            self.backgrounds.move_to_end(name)
            return self.backgrounds[name]
        data = np.fromfile(str(self.project["bg_dir"] / (name + ".jpg")), np.uint8)
        image = cv2.imdecode(data, cv2.IMREAD_COLOR).astype(np.float32) / 255.0
        self.backgrounds[name] = image
        while len(self.backgrounds) > 4:
            self.backgrounds.popitem(last=False)
        return image

    def background_gpu(self, name):
        if name in self.gpu_backgrounds:
            self.gpu_backgrounds.move_to_end(name)
            return self.gpu_backgrounds[name]
        cpu_img = self.background(name)
        tensor = torch.from_numpy(cpu_img).permute(2, 0, 1).unsqueeze(0).contiguous().to(self.device, non_blocking=True)
        self.gpu_backgrounds[name] = (tensor, cpu_img.shape[0], cpu_img.shape[1])
        while len(self.gpu_backgrounds) > 4:
            self.gpu_backgrounds.popitem(last=False)
        return self.gpu_backgrounds[name]

    def occluder(self, name, polygon, feather, shift=(0.0, 0.0)):
        """A piece of the background cut out to pass in front of an actor."""
        key = (name, tuple(map(tuple, polygon)), tuple(shift))
        if key not in self.occluders:
            image = self.background(name)
            height, width = image.shape[:2]
            points = np.array([[x * width, y * height] for x, y in polygon], np.float32)
            mask = np.zeros((height, width), np.float32)
            cv2.fillPoly(mask, [points.astype(np.int32)], 1.0, lineType=cv2.LINE_AA)
            if feather:
                mask = cv2.GaussianBlur(mask, (0, 0), feather)
            ys, xs = np.nonzero(mask > 0.002)
            x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
            patch = np.dstack([image[y0:y1, x0:x1] * mask[y0:y1, x0:x1, None], mask[y0:y1, x0:x1]])
            self.occluders[key] = (patch, x0 + shift[0] * width, y0 + shift[1] * height)
        return self.occluders[key]

    def occluder_gpu(self, name, polygon, feather, shift=(0.0, 0.0)):
        key = (name, tuple(map(tuple, polygon)), tuple(shift))
        if key not in self.gpu_occluders:
            patch, x0, y0 = self.occluder(name, polygon, feather, shift)
            t_patch = torch.from_numpy(patch).permute(2, 0, 1).unsqueeze(0).contiguous().to(self.device, non_blocking=True)
            self.gpu_occluders[key] = (t_patch, patch.shape[0], patch.shape[1], x0, y0)
        return self.gpu_occluders[key]


class Renderer:
    def __init__(self, project, width=1920, height=1080, use_gpu=None):
        self.project = project
        if use_gpu is None:
            use_gpu = bool(HAS_TORCH and torch.cuda.is_available())
        self.use_gpu = bool(use_gpu and HAS_TORCH and (torch.cuda.is_available() or str(use_gpu) == "cpu_torch"))
        self.device = torch.device("cuda" if (self.use_gpu and torch.cuda.is_available()) else "cpu") if HAS_TORCH else None
        self.library = Library(project, device=self.device)
        self.width, self.height = width, height
        self.k = height / 1080.0
        self.anims = project["animations"]
        self.puppets = project["puppets"]
        self.envelope = project.get("envelope")
        self.fps = project.get("fps", 30)

        yy, xx = np.mgrid[0:height, 0:width].astype(np.float32)
        nx, ny = (xx - width / 2) / (width / 2), (yy - height / 2) / (height / 2)
        self.vignette_field = (np.clip((nx * nx * 0.85 + ny * ny) / 1.6, 0, 1) ** 1.3).astype(np.float32)
        self._vignette_cache = {}

        rng = np.random.default_rng(7)
        grain = rng.normal(0, 1, (height + 256, width + 256)).astype(np.float32)
        self.grain = cv2.GaussianBlur(grain, (0, 0), 0.65 * max(self.k, 0.6))
        self.grain /= self.grain.std()

        self.fonts = {}
        self.text_cache = {}
        self.gpu_text_cache = {}
        self._blur_kernels = {}
        lx, ly = np.meshgrid(np.linspace(0, 1, 480, dtype=np.float32), np.linspace(0, 1, 270, dtype=np.float32))
        self.low_x, self.low_y = lx, ly

        if self.use_gpu:
            self.gpu_vignette = torch.from_numpy(self.vignette_field).unsqueeze(0).to(self.device)
            self.gpu_grain = torch.from_numpy(self.grain).to(self.device)
            self.gpu_low_x = torch.from_numpy(self.low_x).to(self.device)
            self.gpu_low_y = torch.from_numpy(self.low_y).to(self.device)

    # --- GPU helpers -------------------------------------------------------------------------

    def _gpu_blur(self, x_1chw, sigma):
        """Fast separable 1D Gaussian blur on GPU tensor (1, C, H, W)."""
        if sigma <= 0.15:
            return x_1chw
        c = x_1chw.shape[1]
        s_key = (round(float(sigma), 2), c)
        if s_key not in self._blur_kernels:
            radius = max(1, min(int(math.ceil(sigma * 3.0)), 48))
            coords = torch.arange(-radius, radius + 1, dtype=torch.float32, device=self.device)
            k1d = torch.exp(-(coords * coords) / (2.0 * sigma * sigma))
            k1d = k1d / k1d.sum()
            kh = k1d.view(1, 1, 1, -1).repeat(c, 1, 1, 1)
            kv = k1d.view(1, 1, -1, 1).repeat(c, 1, 1, 1)
            self._blur_kernels[s_key] = (kh, kv, radius)
        kh, kv, radius = self._blur_kernels[s_key]
        h, w = x_1chw.shape[2], x_1chw.shape[3]
        pad_r = min(radius, max(w - 1, 1), max(h - 1, 1))
        if pad_r < radius:
            kh = kh[:, :, :, radius - pad_r:radius + pad_r + 1]
            kh = kh / kh.sum(dim=-1, keepdim=True)
            kv = kv[:, :, radius - pad_r:radius + pad_r + 1, :]
            kv = kv / kv.sum(dim=-2, keepdim=True)
        out = F.pad(x_1chw, (pad_r, pad_r, 0, 0), mode="replicate")
        out = F.conv2d(out, kh, groups=c)
        out = F.pad(out, (0, 0, pad_r, pad_r), mode="replicate")
        out = F.conv2d(out, kv, groups=c)
        return out

    def _gpu_warp(self, src_1chw, matrix_3x3, out_w, out_h, padding_mode="zeros"):
        in_h, in_w = src_1chw.shape[2], src_1chw.shape[3]
        c = src_1chw.shape[1]
        theta = torch.from_numpy(_affine_theta(matrix_3x3, in_w, in_h, out_w, out_h)).unsqueeze(0).to(self.device)
        grid = F.affine_grid(theta, (1, c, out_h, out_w), align_corners=False)
        return F.grid_sample(src_1chw, grid, mode="bilinear", padding_mode=padding_mode, align_corners=False)

    # --- camera ------------------------------------------------------------------------------

    def camera(self, shot, t, img_shape):
        spec = shot.get("camera", {})
        start = spec.get("from", (0.5, 0.5, 1.0))
        end = spec.get("to", start)
        u = ease(spec.get("ease", "smooth"), t / max(shot["length"], 1e-3)) if "keys" not in spec else None
        if u is None:
            cx, cy, zoom = ramp(spec["keys"], t)
        else:
            cx, cy, zoom = (a + (b - a) * u for a, b in zip(start, end))
        img_h, img_w = img_shape[:2]
        scale = self.height * zoom / img_h
        view_w, view_h = self.width / scale, self.height / scale
        hand = spec.get("handheld", 1.0)
        seed = shot["seed"]
        drift = 2.2 * hand / zoom
        x = cx * img_w + drift * (noise(seed + 1, t * 0.33) + 0.5 * noise(seed + 2, t * 0.9))
        y = cy * img_h + drift * (noise(seed + 3, t * 0.29) + 0.5 * noise(seed + 4, t * 0.8))
        roll = spec.get("roll", 0.0) + 0.05 * hand * noise(seed + 5, t * 0.21)
        for when, amount, length in shot.get("shake", ()):
            if when <= t < when + length:
                fade = 1.0 - (t - when) / length
                x += amount * fade * noise(seed + 6, t * 21.0) * 30.0 / zoom
                y += amount * fade * noise(seed + 7, t * 23.0) * 30.0 / zoom
                roll += amount * fade * noise(seed + 8, t * 17.0) * 0.5
        x = min(max(x, view_w / 2), img_w - view_w / 2)
        y = min(max(y, view_h / 2), img_h - view_h / 2)
        world = translate(self.width / 2, self.height / 2) @ _rotation(roll) @ np.diag([scale, scale, 1.0]) @ translate(-x, -y)
        return world, scale

    # --- actors ------------------------------------------------------------------------------

    def actor_pose(self, actor, t):
        clips = actor["clips"]
        index = 0
        for i, clip in enumerate(clips):
            if t >= clip["t"]:
                index = i
        def sample(clip):
            local = (t - clip["t"]) * clip.get("speed", 1.0) + clip.get("offset", 0.0)
            if clip.get("hold") is not None:
                local = min(local, clip["hold"])
            return self.anims.sample(clip["anim"], max(local, 0.0)), local
        clip = clips[index]
        pose, local = sample(clip)
        blend = (t - clip["t"]) / clip.get("blend", CROSSFADE)
        if index > 0 and blend < 1.0:
            previous, _ = sample(clips[index - 1])
            pose = previous + (pose - previous) * float(ease("smooth", blend))
        for key, track in actor.get("offsets", {}).items():
            pose = pose.copy()
            pose[self.anims.keys.index(key)] += ramp(track, t)
        keys = self.anims.keys
        arm_front = (self.anims.arm_front(clip["anim"], max(local, 0.0))
                     or abs(pose[keys.index("armL")]) > 25 or abs(pose[keys.index("foreL")]) > 35)
        self.last_anim = clip["anim"]
        return pose, arm_front

    def actor_face(self, actor, t, absolute):
        eyes, mouth = keyed(actor.get("face", ()), t, (None, None))
        puppet = self.puppets[actor["pack"]]
        eyes = puppet.default_eyes if eyes is None else eyes
        mouth = puppet.default_mouth if mouth is None else mouth
        talk = actor.get("talk")
        if talk and self.envelope is not None and any(a <= t < b for a, b in talk):
            level = self.envelope(absolute)
            shapes = actor.get("mouths", puppet.talk_mouths or (331, 358, 303, 221))
            if level > 0.55:
                mouth = shapes[3]
            elif level > 0.3:
                mouth = shapes[2]
            elif level > 0.12:
                mouth = shapes[1]
            else:
                mouth = shapes[0]
        blink = 0.0
        if eyes not in EYES_CLOSED and actor.get("blink", True):
            blink = blink_at(actor.get("seed", 1), absolute)
        return eyes, mouth, blink

    def actor_view(self, actor, t, world, img_shape):
        puppet = self.puppets[actor["pack"]]
        x, y, height = ramp(actor["path"], t, actor.get("path_ease", "linear"))
        img_h, img_w = img_shape[:2]
        scale = height * img_h / (puppet.floor - puppet.top)
        flip = -1.0 if actor.get("flip") else 1.0
        return (world @ translate(x * img_w, y * img_h)
                @ np.diag([flip * scale, scale, 1.0]) @ translate(-puppet.center_x, -puppet.floor))

    def shade(self, roi, actor, t, flicker):
        rgb, alpha = roi[..., :3], roi[..., 3]
        height, width = alpha.shape
        light = actor.get("light", {})
        ambient = np.array(light.get("ambient", (1.0, 1.0, 1.0)), np.float32)
        key = np.array(light.get("key", (0.0, 0.0, 0.0)), np.float32) * flicker
        dx, dy = light.get("dir", (-1.0, -0.3))
        xs = np.linspace(-1, 1, width, dtype=np.float32)[None, :]
        ys = np.linspace(-1, 1, height, dtype=np.float32)[:, None]
        gradient = np.clip(0.5 + 0.5 * (xs * dx + ys * dy), 0, 1)[..., None]
        shaded = rgb * (ambient + key * gradient)
        rim = light.get("rim")
        if rim:
            reach = rim.get("width", 7.0) * self.k * (height / 900.0 + 0.35)
            shift = np.float32([[1, 0, dx * reach], [0, 1, dy * reach]])
            moved = cv2.warpAffine(alpha, shift, (width, height), flags=cv2.INTER_LINEAR)
            edge = np.clip(alpha - cv2.GaussianBlur(moved, (0, 0), reach * 0.5), 0, 1)[..., None]
            shaded += edge * (np.array(rim["color"], np.float32) * (rim.get("amount", 1.0) * flicker))
        return np.dstack([shaded, alpha])

    def shade_gpu(self, roi_4hw, actor, flicker):
        rgb, alpha = roi_4hw[:3], roi_4hw[3:4]
        _, height, width = alpha.shape
        light = actor.get("light", {})
        ambient = torch.tensor(light.get("ambient", (1.0, 1.0, 1.0)), dtype=torch.float32, device=self.device).view(3, 1, 1)
        key = torch.tensor(light.get("key", (0.0, 0.0, 0.0)), dtype=torch.float32, device=self.device).view(3, 1, 1) * float(flicker)
        dx, dy = light.get("dir", (-1.0, -0.3))
        xs = torch.linspace(-1.0, 1.0, width, dtype=torch.float32, device=self.device).view(1, 1, width)
        ys = torch.linspace(-1.0, 1.0, height, dtype=torch.float32, device=self.device).view(1, height, 1)
        gradient = (0.5 + 0.5 * (xs * float(dx) + ys * float(dy))).clamp_(0.0, 1.0)
        shaded = rgb * (ambient + key * gradient)
        rim = light.get("rim")
        if rim:
            reach = float(rim.get("width", 7.0) * self.k * (height / 900.0 + 0.35))
            shift_3x3 = np.array([[1.0, 0.0, dx * reach], [0.0, 1.0, dy * reach], [0.0, 0.0, 1.0]], dtype=np.float32)
            moved = self._gpu_warp(alpha.unsqueeze(0), shift_3x3, width, height, padding_mode="zeros")
            blurred = self._gpu_blur(moved, reach * 0.5).squeeze(0)
            edge = (alpha - blurred).clamp_(0.0, 1.0)
            rim_col = torch.tensor(rim["color"], dtype=torch.float32, device=self.device).view(3, 1, 1)
            shaded.add_(edge * (rim_col * float(rim.get("amount", 1.0) * flicker)))
        return shaded, alpha

    def draw_actor(self, frame, actor, t, absolute, world, img_shape, flicker):
        puppet = self.puppets[actor["pack"]]
        pose, arm_front = self.actor_pose(actor, t)
        eyes, mouth, blink = self.actor_face(actor, t, absolute)
        view = self.actor_view(actor, t, world, img_shape)
        drawn = puppet.render(pose, self.anims.keys, view, (self.width, self.height), eyes=eyes, mouth=mouth,
                              blink=blink, arm_front=arm_front, mode=self.last_anim)
        if drawn is None:
            return
        roi, x, y = drawn
        fade = ramp(actor["fade"], t) if actor.get("fade") else 1.0
        if fade <= 0:
            return
        alpha = roi[..., 3]
        h, w = alpha.shape
        pixel_h = abs(view[1, 1]) * (puppet.floor - puppet.top)

        # 1. Contact shadow (computed only inside its small ellipse bounding box)
        contact = actor.get("contact", 0.55)
        if contact:
            fx, fy = (view @ np.array([puppet.center_x, puppet.floor - 8.0, 1.0]))[:2]
            ax = max(int(pixel_h * 0.20), 4)
            ay = max(int(pixel_h * 0.028), 4)
            sigma = max(pixel_h * 0.02, 4.0)
            pad = int(math.ceil(sigma * 3.0))
            cx0 = max(int(fx) - ax - pad, 0)
            cy0 = max(int(fy) - ay - pad, 0)
            cx1 = min(int(fx) + ax + pad + 1, self.width)
            cy1 = min(int(fy) + ay + pad + 1, self.height)
            if cx1 > cx0 and cy1 > cy0:
                cmask = np.zeros((cy1 - cy0, cx1 - cx0), np.float32)
                cv2.ellipse(cmask, (int(fx) - cx0, int(fy) - cy0), (ax, ay), 0, 0, 360, 1.0, -1, cv2.LINE_AA)
                cmask = cv2.GaussianBlur(cmask, (0, 0), sigma)
                frame[cy0:cy1, cx0:cx1] *= (1.0 - cmask * (contact * fade))[..., None]

        # 2. Cast shadow (quarter-resolution warp + blur, applied only inside shadow ROI)
        cast = actor.get("cast")
        if cast:
            q = 4
            lw, lh = self.width // q, self.height // q
            base = (view @ np.array([puppet.center_x, puppet.floor, 1.0]))[:2] / q
            sx, sy = cast.get("scale", (1.1, 1.0))
            skew = cast.get("skew", 0.0)
            tx = base[0] * (1 - sx) - skew * base[1] + cast.get("x", 0.0) * lw
            ty = base[1] * (1 - sy) + cast.get("y", 0.0) * lh
            m_cast = np.float32([[sx, skew, tx], [0, sy, ty]])
            small_alpha = cv2.resize(alpha, (max(1, w // q), max(1, h // q)), interpolation=cv2.INTER_AREA)
            low_full = np.zeros((lh, lw), np.float32)
            lx, ly = x // q, y // q
            sh_l = min(small_alpha.shape[0], lh - ly)
            sw_l = min(small_alpha.shape[1], lw - lx)
            if sh_l > 0 and sw_l > 0:
                low_full[ly:ly + sh_l, lx:lx + sw_l] = small_alpha[:sh_l, :sw_l]
                shadow_low = cv2.warpAffine(low_full, m_cast, (lw, lh), flags=cv2.INTER_LINEAR)
                sigma_q = max(cast.get("blur", 9.0) * self.k / q, 0.5)
                shadow_low = cv2.GaussianBlur(shadow_low, (0, 0), sigma_q)
                ys_s, xs_s = np.nonzero(shadow_low > 0.002)
                if len(xs_s):
                    sx0, sx1 = max(int(xs_s.min()) * q, 0), min((int(xs_s.max()) + 2) * q, self.width)
                    sy0, sy1 = max(int(ys_s.min()) * q, 0), min((int(ys_s.max()) + 2) * q, self.height)
                    sub_low = shadow_low[sy0 // q:min(math.ceil(sy1 / q), lh), sx0 // q:min(math.ceil(sx1 / q), lw)]
                    sub_high = cv2.resize(sub_low, (sx1 - sx0, sy1 - sy0), interpolation=cv2.INTER_LINEAR)
                    frame[sy0:sy1, sx0:sx1] *= (1.0 - sub_high * (cast.get("opacity", 0.5) * fade))[..., None]

        # 3. Halo (computed at quarter resolution and applied only around the actor ROI)
        halo = actor.get("halo")
        if halo:
            q = 4
            rad = halo.get("radius", 12.0) * self.k
            pad = int(math.ceil(rad * 3.2)) + q
            hx0, hy0 = max(x - pad, 0), max(y - pad, 0)
            hx1, hy1 = min(x + w + pad, self.width), min(y + h + pad, self.height)
            lw = max(1, (hx1 - hx0) // q)
            lh = max(1, (hy1 - hy0) // q)
            low_h = np.zeros((lh, lw), np.float32)
            small_a = cv2.resize(alpha, (max(1, w // q), max(1, h // q)), interpolation=cv2.INTER_AREA)
            ox, oy = (x - hx0) // q, (y - hy0) // q
            ch = min(small_a.shape[0], lh - oy)
            cw = min(small_a.shape[1], lw - ox)
            if ch > 0 and cw > 0:
                low_h[oy:oy + ch, ox:ox + cw] = small_a[:ch, :cw]
                low_h = cv2.GaussianBlur(low_h, (0, 0), max(rad / q, 0.5))
                soft = cv2.resize(low_h, (hx1 - hx0, hy1 - hy0), interpolation=cv2.INTER_LINEAR)
                h_col = np.array(halo["color"], np.float32) * (halo.get("amount", 0.4) * fade)
                frame[hy0:hy1, hx0:hx1] += soft[..., None] * h_col

        shaded = self.shade(roi, actor, t, flicker) * fade
        region = frame[y:y + shaded.shape[0], x:x + shaded.shape[1]]
        region *= 1.0 - shaded[..., 3:4]
        region += shaded[..., :3]

    def draw_actor_gpu(self, frame_3hw, actor, t, absolute, world, img_shape, flicker):
        puppet = self.puppets[actor["pack"]]
        pose, arm_front = self.actor_pose(actor, t)
        eyes, mouth, blink = self.actor_face(actor, t, absolute)
        view = self.actor_view(actor, t, world, img_shape)
        drawn = puppet.render_gpu(pose, self.anims.keys, view, (self.width, self.height), self.device,
                                  eyes=eyes, mouth=mouth, blink=blink, arm_front=arm_front, mode=self.last_anim)
        if drawn is None:
            return
        roi_4hw, x, y = drawn
        fade = float(ramp(actor["fade"], t)) if actor.get("fade") else 1.0
        if fade <= 0:
            return
        alpha = roi_4hw[3:4]
        _, h, w = alpha.shape
        pixel_h = abs(view[1, 1]) * (puppet.floor - puppet.top)

        contact = actor.get("contact", 0.55)
        if contact:
            fx, fy = (view @ np.array([puppet.center_x, puppet.floor - 8.0, 1.0]))[:2]
            ax = max(float(pixel_h * 0.20), 4.0)
            ay = max(float(pixel_h * 0.028), 4.0)
            sigma = max(float(pixel_h * 0.02), 4.0)
            pad = int(math.ceil(sigma * 3.0))
            cx0 = max(int(fx - ax) - pad, 0)
            cy0 = max(int(fy - ay) - pad, 0)
            cx1 = min(int(fx + ax) + pad + 1, self.width)
            cy1 = min(int(fy + ay) + pad + 1, self.height)
            if cx1 > cx0 and cy1 > cy0:
                gx = torch.arange(cx0, cx1, dtype=torch.float32, device=self.device).view(1, -1)
                gy = torch.arange(cy0, cy1, dtype=torch.float32, device=self.device).view(-1, 1)
                dist_sq = ((gx - float(fx)) / ax) ** 2 + ((gy - float(fy)) / ay) ** 2
                cmask = (1.0 - dist_sq).clamp_(0.0, 1.0).gt(0.0).float().unsqueeze(0).unsqueeze(0)
                cmask = self._gpu_blur(cmask, sigma).squeeze(0)
                frame_3hw[:, cy0:cy1, cx0:cx1].mul_(1.0 - cmask * float(contact * fade))

        cast = actor.get("cast")
        if cast:
            q = 4
            lw, lh = self.width // q, self.height // q
            base = (view @ np.array([puppet.center_x, puppet.floor, 1.0]))[:2] / q
            sx, sy = cast.get("scale", (1.1, 1.0))
            skew = cast.get("skew", 0.0)
            tx = base[0] * (1 - sx) - skew * base[1] + cast.get("x", 0.0) * lw
            ty = base[1] * (1 - sy) + cast.get("y", 0.0) * lh
            m_cast = np.array([[sx, skew, tx], [0.0, sy, ty], [0.0, 0.0, 1.0]], dtype=np.float32)
            small_a = F.interpolate(alpha.unsqueeze(0), size=(max(1, h // q), max(1, w // q)), mode="area")
            low_full = torch.zeros((1, 1, lh, lw), dtype=torch.float32, device=self.device)
            lx, ly = x // q, y // q
            sh_l = min(small_a.shape[2], lh - ly)
            sw_l = min(small_a.shape[3], lw - lx)
            if sh_l > 0 and sw_l > 0:
                low_full[:, :, ly:ly + sh_l, lx:lx + sw_l] = small_a[:, :, :sh_l, :sw_l]
                warped = self._gpu_warp(low_full, m_cast, lw, lh, padding_mode="zeros")
                blurred = self._gpu_blur(warped, max(cast.get("blur", 9.0) * self.k / q, 0.5))
                shadow = F.interpolate(blurred, size=(self.height, self.width), mode="bilinear", align_corners=False).squeeze(0)
                frame_3hw.mul_(1.0 - shadow * float(cast.get("opacity", 0.5) * fade))

        halo = actor.get("halo")
        if halo:
            q = 4
            rad = float(halo.get("radius", 12.0) * self.k)
            pad = int(math.ceil(rad * 3.2)) + q
            hx0, hy0 = max(x - pad, 0), max(y - pad, 0)
            hx1, hy1 = min(x + w + pad, self.width), min(y + h + pad, self.height)
            lw = max(1, (hx1 - hx0) // q)
            lh = max(1, (hy1 - hy0) // q)
            low_h = torch.zeros((1, 1, lh, lw), dtype=torch.float32, device=self.device)
            small_a = F.interpolate(alpha.unsqueeze(0), size=(max(1, h // q), max(1, w // q)), mode="area")
            ox, oy = (x - hx0) // q, (y - hy0) // q
            ch = min(small_a.shape[2], lh - oy)
            cw = min(small_a.shape[3], lw - ox)
            if ch > 0 and cw > 0:
                low_h[:, :, oy:oy + ch, ox:ox + cw] = small_a[:, :, :ch, :cw]
                low_h = self._gpu_blur(low_h, max(rad / q, 0.5))
                soft = F.interpolate(low_h, size=(hy1 - hy0, hx1 - hx0), mode="bilinear", align_corners=False).squeeze(0)
                h_col = torch.tensor(halo["color"], dtype=torch.float32, device=self.device).view(3, 1, 1) * float(halo.get("amount", 0.4) * fade)
                frame_3hw[:, hy0:hy1, hx0:hx1].add_(soft * h_col)

        shaded, a_ch = self.shade_gpu(roi_4hw, actor, flicker)
        if fade != 1.0:
            shaded = shaded * fade
            a_ch = a_ch * fade
        region = frame_3hw[:, y:y + h, x:x + w]
        region.mul_(1.0 - a_ch).add_(shaded)

    def draw_occluders(self, frame, shot, world, img_shape, scale):
        for item in shot.get("occluders", ()):
            patch, x0, y0 = self.library.occluder(shot["bg"], item["polygon"], item.get("feather", 3.0), item.get("shift", (0.0, 0.0)))
            ph, pw = patch.shape[:2]
            m_full = world @ translate(x0, y0)
            corners = m_full @ np.array([[0, pw, 0, pw], [0, 0, ph, ph], [1, 1, 1, 1]], dtype=float)
            bx0 = max(int(np.floor(corners[0].min())) - 2, 0)
            by0 = max(int(np.floor(corners[1].min())) - 2, 0)
            bx1 = min(int(np.ceil(corners[0].max())) + 3, self.width)
            by1 = min(int(np.ceil(corners[1].max())) + 3, self.height)
            if bx1 > bx0 and by1 > by0:
                matrix = (translate(-bx0, -by0) @ m_full)[:2].astype(np.float32)
                layer = cv2.warpAffine(patch, matrix, (bx1 - bx0, by1 - by0), flags=cv2.INTER_LINEAR)
                sub = frame[by0:by1, bx0:bx1]
                sub *= 1.0 - layer[..., 3:4]
                sub += layer[..., :3]

    def draw_occluders_gpu(self, frame_3hw, shot, world):
        for item in shot.get("occluders", ()):
            t_patch, ph, pw, x0, y0 = self.library.occluder_gpu(shot["bg"], item["polygon"], item.get("feather", 3.0), item.get("shift", (0.0, 0.0)))
            m_full = world @ translate(x0, y0)
            corners = m_full @ np.array([[0, pw, 0, pw], [0, 0, ph, ph], [1, 1, 1, 1]], dtype=float)
            bx0 = max(int(np.floor(corners[0].min())) - 2, 0)
            by0 = max(int(np.floor(corners[1].min())) - 2, 0)
            bx1 = min(int(np.ceil(corners[0].max())) + 3, self.width)
            by1 = min(int(np.ceil(corners[1].max())) + 3, self.height)
            if bx1 > bx0 and by1 > by0:
                m_sub = translate(-bx0, -by0) @ m_full
                layer = self._gpu_warp(t_patch, m_sub, bx1 - bx0, by1 - by0, padding_mode="zeros").squeeze(0)
                sub = frame_3hw[:, by0:by1, bx0:bx1]
                sub.mul_(1.0 - layer[3:4]).add_(layer[:3])

    # --- light and particles -----------------------------------------------------------------

    def flicker(self, spec, seed, t):
        if not spec:
            return 1.0
        speed, depth = spec.get("speed", 6.0), spec.get("depth", 0.1)
        value = 1.0 - depth * (0.5 + 0.5 * noise(seed, t * speed))
        for start, length, level in spec.get("drops", ()):
            if start <= t < start + length:
                stutter = 0.5 + 0.5 * math.sin(t * 90.0)
                value *= level + (1.0 - level) * stutter * 0.6
        return value

    def draw_lights(self, frame, shot, t, world, img_shape):
        img_h, img_w = img_shape[:2]
        for index, light in enumerate(shot.get("lights", ())):
            flick = self.flicker(light.get("flicker"), shot["seed"] + 11 + index, t)
            sx, sy = (world @ np.array([light["x"] * img_w, light["y"] * img_h, 1.0]))[:2]
            scale = np.sqrt(abs(np.linalg.det(world[:2, :2])))
            radius = light["r"] * img_h * scale
            squash = light.get("squash", 1.0)
            # Only evaluate and blend inside the bounding box where exp(-2.2 * d^2) > 0.001 (d < 1.85)
            rx = radius * 1.85
            ry = radius * squash * 1.85
            x0 = max(int(sx - rx), 0)
            y0 = max(int(sy - ry), 0)
            x1 = min(int(sx + rx) + 1, self.width)
            y1 = min(int(sy + ry) + 1, self.height)
            if x1 <= x0 or y1 <= y0:
                continue
            q = 4
            lw = max(2, (x1 - x0) // q)
            lh = max(2, (y1 - y0) // q)
            gx = np.linspace(x0, x1 - 1, lw, dtype=np.float32)[None, :]
            gy = np.linspace(y0, y1 - 1, lh, dtype=np.float32)[:, None]
            dx = (gx - sx) / radius
            dy = (gy - sy) / (radius * squash)
            glow_low = np.exp(-(dx * dx + dy * dy) * 2.2)
            glow = cv2.resize(glow_low, (x1 - x0, y1 - y0), interpolation=cv2.INTER_LINEAR)[..., None]
            sub = frame[y0:y1, x0:x1]
            if light.get("mode", "screen") == "gain":
                sub *= 1.0 + glow * (light.get("amount", 0.5) * (flick - 1.0) * 3.0)
            else:
                color = np.array(light["color"], np.float32) * (light.get("amount", 0.3) * flick)
                add = np.clip(glow * color, 0.0, 1.0)
                np.clip(sub, 0.0, 1.0, out=sub)
                sub += add * (1.0 - sub)

    def draw_lights_gpu(self, frame_3hw, shot, t, world, img_shape):
        img_h, img_w = img_shape[:2]
        for index, light in enumerate(shot.get("lights", ())):
            flick = self.flicker(light.get("flicker"), shot["seed"] + 11 + index, t)
            sx, sy = (world @ np.array([light["x"] * img_w, light["y"] * img_h, 1.0]))[:2]
            scale = math.sqrt(abs(float(np.linalg.det(world[:2, :2]))))
            radius = float(light["r"] * img_h * scale)
            squash = float(light.get("squash", 1.0))
            dx = (self.gpu_low_x * self.width - float(sx)) / radius
            dy = (self.gpu_low_y * self.height - float(sy)) / (radius * squash)
            glow = torch.exp(-(dx * dx + dy * dy) * 2.2).unsqueeze(0).unsqueeze(0)
            glow = F.interpolate(glow, size=(self.height, self.width), mode="bilinear", align_corners=False).squeeze(0)
            if light.get("mode", "screen") == "gain":
                frame_3hw.mul_(1.0 + glow * float(light.get("amount", 0.5) * (flick - 1.0) * 3.0))
            else:
                color = torch.tensor(light["color"], dtype=torch.float32, device=self.device).view(3, 1, 1)
                add = (glow * (color * float(light.get("amount", 0.3) * flick))).clamp_(0.0, 1.0)
                frame_3hw.clamp_(0.0, 1.0)
                frame_3hw.add_(add * (1.0 - frame_3hw))

    def _dust_layer(self, spec, seed, t):
        """Particles at half resolution. Dust floats; with "wind" (frame widths and heights
        per second) it becomes driven snow, and "size" scales the flakes."""
        count = spec.get("count", 70)
        rng = np.random.default_rng(seed)
        base = rng.random((count, 2))
        drift = rng.normal(0, 1, (count, 2)) * np.array([0.006, 0.004]) + np.array([0.002, -0.0035])
        phase = rng.random(count) * 6.28
        size = rng.random(count)
        wind = spec.get("wind")
        if wind is not None:
            # Near flakes are bigger and faster: a depth per flake gives parallax.
            depth = 0.35 + 0.65 * size
            drift = drift * 3.0 + np.array(wind, np.float64)[None, :] * depth[:, None]
        scale = spec.get("size", 1.0)
        q = 2
        layer = np.zeros((self.height // q, self.width // q), np.float32)
        for i in range(count):
            px = ((base[i, 0] + drift[i, 0] * t + 0.004 * math.sin(t * 0.7 + phase[i])) % 1.0) * layer.shape[1]
            py = ((base[i, 1] + drift[i, 1] * t + 0.004 * math.cos(t * 0.6 + phase[i])) % 1.0) * layer.shape[0]
            shine = 0.5 + 0.5 * math.sin(t * 1.3 + phase[i] * 3.0) if wind is None else 0.55 + 0.45 * size[i]
            radius = max(1, int((1 + size[i] * 2) * scale * self.k))
            cv2.circle(layer, (int(px), int(py)), radius, float(shine), -1, cv2.LINE_AA)
        return layer

    def draw_dust(self, frame, shot, t):
        spec = shot.get("dust")
        if not spec:
            return
        layer = self._dust_layer(spec, shot["seed"], t)
        layer = cv2.GaussianBlur(layer, (0, 0), 1.2 * max(self.k, 0.7))
        layer = cv2.resize(layer, (self.width, self.height), interpolation=cv2.INTER_LINEAR)
        frame += layer[..., None] * (np.array(spec.get("color", (0.9, 0.95, 1.0)), np.float32) * spec.get("amount", 0.12))

    def draw_dust_gpu(self, frame_3hw, shot, t):
        spec = shot.get("dust")
        if not spec:
            return
        layer = self._dust_layer(spec, shot["seed"], t)
        t_layer = torch.from_numpy(layer).unsqueeze(0).unsqueeze(0).to(self.device, non_blocking=True)
        t_layer = self._gpu_blur(t_layer, 1.2 * max(self.k, 0.7))
        t_layer = F.interpolate(t_layer, size=(self.height, self.width), mode="bilinear", align_corners=False).squeeze(0)
        col = torch.tensor(spec.get("color", (0.9, 0.95, 1.0)), dtype=torch.float32, device=self.device).view(3, 1, 1) * float(spec.get("amount", 0.12))
        frame_3hw.add_(t_layer * col)

    # --- text --------------------------------------------------------------------------------

    def text_sprite(self, item):
        key = (item["text"], item.get("font"), item.get("size", 96))
        if key not in self.text_cache:
            font_path = item.get("font", "C:/Windows/Fonts/georgiab.ttf")
            if not Path(font_path).exists():
                font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf"
            font = ImageFont.truetype(font_path, int(item.get("size", 96) * self.k))
            box = font.getbbox(item["text"])
            pad = int(40 * self.k)
            canvas = Image.new("L", (box[2] - box[0] + pad * 2, box[3] - box[1] + pad * 2), 0)
            ImageDraw.Draw(canvas).text((pad - box[0], pad - box[1]), item["text"], fill=255, font=font)
            mask = np.asarray(canvas, np.float32) / 255.0
            shadow = cv2.GaussianBlur(mask, (0, 0), 9.0 * self.k)[..., None]
            self.text_cache[key] = (mask, shadow)
        return self.text_cache[key]

    def draw_text(self, frame, shot, t):
        for item in shot.get("text", ()):
            t0, t1 = item["t"], item["t"] + item["length"]
            if not t0 <= t < t1:
                continue
            fade = min((t - t0) / item.get("fade", 0.8), (t1 - t) / item.get("fade", 0.8), 1.0)
            mask, shadow = self.text_sprite(item)
            h, w = mask.shape
            jitter = item.get("jitter", 0.0)
            cx = item.get("x", 0.5) * self.width + jitter * noise(shot["seed"] + 21, t * 19.0)
            cy = item.get("y", 0.5) * self.height + jitter * 0.5 * noise(shot["seed"] + 22, t * 23.0)
            x, y = int(cx - w / 2), int(cy - h / 2)
            sx0, sy0 = max(0, -x), max(0, -y)
            sx1, sy1 = min(w, self.width - x), min(h, self.height - y)
            if sx1 <= sx0 or sy1 <= sy0:
                continue
            region = frame[y + sy0:y + sy1, x + sx0:x + sx1]
            m, s = mask[sy0:sy1, sx0:sx1], shadow[sy0:sy1, sx0:sx1]
            if item.get("mode") == "ink":
                ink = np.array(item.get("color", (0.08, 0.06, 0.05)), np.float32)
                cover = m[..., None] * (item.get("opacity", 0.85) * fade)
                region *= 1.0 - cover
                region += cover * ink
                continue
            region *= 1.0 - s * (0.75 * fade)
            region += m[..., None] * (np.array(item.get("color", (0.82, 0.86, 0.92)), np.float32) * fade)

    def draw_text_gpu(self, frame_3hw, shot, t):
        for item in shot.get("text", ()):
            t0, t1 = item["t"], item["t"] + item["length"]
            if not t0 <= t < t1:
                continue
            fade = float(min((t - t0) / item.get("fade", 0.8), (t1 - t) / item.get("fade", 0.8), 1.0))
            key = (item["text"], item.get("font"), item.get("size", 96))
            if key not in self.gpu_text_cache:
                mask, shadow = self.text_sprite(item)
                t_mask = torch.from_numpy(mask).unsqueeze(0).to(self.device)
                t_shadow = torch.from_numpy(shadow[..., 0]).unsqueeze(0).to(self.device)
                self.gpu_text_cache[key] = (t_mask, t_shadow, mask.shape[0], mask.shape[1])
            t_mask, t_shadow, h, w = self.gpu_text_cache[key]
            jitter = item.get("jitter", 0.0)
            cx = item.get("x", 0.5) * self.width + jitter * noise(shot["seed"] + 21, t * 19.0)
            cy = item.get("y", 0.5) * self.height + jitter * 0.5 * noise(shot["seed"] + 22, t * 23.0)
            x, y = int(cx - w / 2), int(cy - h / 2)
            sx0, sy0 = max(0, -x), max(0, -y)
            sx1, sy1 = min(w, self.width - x), min(h, self.height - y)
            if sx1 <= sx0 or sy1 <= sy0:
                continue
            region = frame_3hw[:, y + sy0:y + sy1, x + sx0:x + sx1]
            m, s = t_mask[:, sy0:sy1, sx0:sx1], t_shadow[:, sy0:sy1, sx0:sx1]
            if item.get("mode") == "ink":
                ink = torch.tensor(item.get("color", (0.08, 0.06, 0.05)), dtype=torch.float32, device=self.device).view(3, 1, 1)
                cover = m * float(item.get("opacity", 0.85) * fade)
                region.mul_(1.0 - cover)
                region.add_(cover * ink)
                continue
            region.mul_(1.0 - s * (0.75 * fade))
            col = torch.tensor(item.get("color", (0.82, 0.86, 0.92)), dtype=torch.float32, device=self.device).view(3, 1, 1) * fade
            region.add_(m * col)

    # --- grading -----------------------------------------------------------------------------

    def _get_vignette_factor(self, amount):
        key = round(float(amount), 3)
        if key not in self._vignette_cache:
            self._vignette_cache[key] = (1.0 - self.vignette_field * key)[..., None].astype(np.float32)
        return self._vignette_cache[key]

    def post(self, frame, shot, t, absolute):
        grade = dict(DEFAULT_GRADE)
        grade.update(shot.get("grade", {}))
        for key, track in shot.get("grade_track", {}).items():
            grade[key] = ramp(track, t)
        scale_tint = np.array(grade["tint"], np.float32) * float(grade["exposure"])
        frame *= scale_tint
        np.clip(frame, 0, 4, out=frame)
        if grade["contrast"] != 1.0:
            c = float(grade["contrast"])
            frame *= c
            frame += 0.5 * (1.0 - c)
            np.clip(frame, 0, 4, out=frame)
        saturation = float(grade["saturation"] * (1.0 - grade["bw"]))
        luma = None
        if saturation != 1.0:
            luma = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            frame *= saturation
            frame += (luma * (1.0 - saturation))[..., None]
        if grade["bloom"] > 0:
            small = cv2.resize(frame, (self.width // 4, self.height // 4), interpolation=cv2.INTER_AREA)
            bright = np.maximum(small - 0.62, 0)
            bright = cv2.GaussianBlur(bright, (0, 0), 7.0)
            up_bright = cv2.resize(bright, (self.width, self.height), interpolation=cv2.INTER_LINEAR)
            cv2.scaleAdd(up_bright, float(grade["bloom"]), frame, dst=frame)
        amount = grade["aberration"]
        if amount > 0:
            for channel, sign in ((0, 1.0), (2, -1.0)):
                factor = 1.0 + sign * amount
                cx, cy = self.width / 2, self.height / 2
                matrix = np.float32([[factor, 0, cx * (1 - factor)], [0, factor, cy * (1 - factor)]])
                frame[..., channel] = cv2.warpAffine(frame[..., channel], matrix, (self.width, self.height),
                                                     flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
        if grade["vignette"] > 0:
            frame *= self._get_vignette_factor(grade["vignette"])
        if grade["grain"] > 0:
            rng = np.random.default_rng(int(absolute * self.fps) + 1)
            ox, oy = rng.integers(0, 255, 2)
            field = self.grain[oy:oy + self.height, ox:ox + self.width]
            luma_g = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            weight = np.sqrt(np.clip(luma_g, 0.012, 1.0)) * float(grade["grain"])
            frame += (field * weight)[..., None]
        return frame

    def post_gpu(self, frame_3hw, shot, t, absolute):
        grade = dict(DEFAULT_GRADE)
        grade.update(shot.get("grade", {}))
        for key, track in shot.get("grade_track", {}).items():
            grade[key] = ramp(track, t)
        scale_tint = torch.tensor(grade["tint"], dtype=torch.float32, device=self.device).view(3, 1, 1) * float(grade["exposure"])
        frame_3hw.mul_(scale_tint).clamp_(0.0, 4.0)
        if grade["contrast"] != 1.0:
            c = float(grade["contrast"])
            frame_3hw.mul_(c).add_(0.5 * (1.0 - c)).clamp_(0.0, 4.0)
        saturation = float(grade["saturation"] * (1.0 - grade["bw"]))
        if saturation != 1.0:
            luma = frame_3hw[0:1] * 0.114 + frame_3hw[1:2] * 0.587 + frame_3hw[2:3] * 0.299
            frame_3hw.mul_(saturation).add_(luma * (1.0 - saturation))
        if grade["bloom"] > 0:
            small = F.interpolate(frame_3hw.unsqueeze(0), size=(self.height // 4, self.width // 4), mode="area")
            bright = (small - 0.62).clamp_(min=0.0)
            bright = self._gpu_blur(bright, 7.0)
            up_bright = F.interpolate(bright, size=(self.height, self.width), mode="bilinear", align_corners=False).squeeze(0)
            frame_3hw.add_(up_bright * float(grade["bloom"]))
        amount = float(grade["aberration"])
        if amount > 0:
            cx, cy = self.width / 2.0, self.height / 2.0
            for channel, sign in ((0, 1.0), (2, -1.0)):
                factor = 1.0 + sign * amount
                m_3x3 = np.array([[factor, 0.0, cx * (1.0 - factor)],
                                  [0.0, factor, cy * (1.0 - factor)],
                                  [0.0, 0.0, 1.0]], dtype=np.float32)
                ch_in = frame_3hw[channel:channel + 1].unsqueeze(0)
                frame_3hw[channel:channel + 1] = self._gpu_warp(ch_in, m_3x3, self.width, self.height, padding_mode="border").squeeze(0)
        if grade["vignette"] > 0:
            frame_3hw.mul_(1.0 - self.gpu_vignette * float(grade["vignette"]))
        if grade["grain"] > 0:
            rng = np.random.default_rng(int(absolute * self.fps) + 1)
            ox, oy = int(rng.integers(0, 255)), int(rng.integers(0, 255))
            field = self.gpu_grain[oy:oy + self.height, ox:ox + self.width].unsqueeze(0)
            luma_g = (frame_3hw[0:1] * 0.114 + frame_3hw[1:2] * 0.587 + frame_3hw[2:3] * 0.299).clamp_(0.012, 1.0)
            frame_3hw.add_(field * (torch.sqrt(luma_g) * float(grade["grain"])))
        return frame_3hw

    # --- one shot, one frame -----------------------------------------------------------------

    def shot_frame(self, shot, t):
        if self.use_gpu:
            with torch.no_grad():
                t_frame = self.shot_frame_gpu(shot, t)
                return t_frame.permute(1, 2, 0).cpu().numpy()
        return self._shot_frame_cpu(shot, t)

    def _shot_frame_cpu(self, shot, t):
        absolute = shot["start"] + t
        image = self.library.background(shot["bg"])
        world, scale = self.camera(shot, t, image.shape)
        matrix = world[:2].astype(np.float32)
        frame = cv2.warpAffine(image, matrix, (self.width, self.height), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)

        grade_blur = shot.get("grade", {}).get("blur", 0.0)
        if "blur" in shot.get("grade_track", {}):
            grade_blur = ramp(shot["grade_track"]["blur"], t)
        if grade_blur > 0:
            frame = cv2.GaussianBlur(frame, (0, 0), grade_blur * self.k)

        flicker = self.flicker(shot.get("flicker"), shot["seed"] + 31, t)
        self.draw_lights(frame, shot, t, world, image.shape)
        if shot.get("flicker"):
            frame *= flicker
        for actor in shot.get("actors", ()):
            start, stop = actor.get("span", (0.0, 1e9))
            if start <= t < stop:
                self.draw_actor(frame, actor, t, absolute, world, image.shape, flicker)
        self.draw_occluders(frame, shot, world, image.shape, scale)
        self.draw_dust(frame, shot, t)
        self.draw_text(frame, shot, t)
        return self.post(frame, shot, t, absolute)

    def shot_frame_gpu(self, shot, t):
        absolute = shot["start"] + t
        bg_tensor, bg_h, bg_w = self.library.background_gpu(shot["bg"])
        world, scale = self.camera(shot, t, (bg_h, bg_w))
        frame = self._gpu_warp(bg_tensor, world, self.width, self.height, padding_mode="border")

        grade_blur = shot.get("grade", {}).get("blur", 0.0)
        if "blur" in shot.get("grade_track", {}):
            grade_blur = ramp(shot["grade_track"]["blur"], t)
        if grade_blur > 0:
            frame = self._gpu_blur(frame, float(grade_blur * self.k))
        frame_3hw = frame.squeeze(0)

        flicker = self.flicker(shot.get("flicker"), shot["seed"] + 31, t)
        self.draw_lights_gpu(frame_3hw, shot, t, world, (bg_h, bg_w))
        if shot.get("flicker"):
            frame_3hw.mul_(float(flicker))
        for actor in shot.get("actors", ()):
            start, stop = actor.get("span", (0.0, 1e9))
            if start <= t < stop:
                self.draw_actor_gpu(frame_3hw, actor, t, absolute, world, (bg_h, bg_w), flicker)
        self.draw_occluders_gpu(frame_3hw, shot, world)
        self.draw_dust_gpu(frame_3hw, shot, t)
        self.draw_text_gpu(frame_3hw, shot, t)
        return self.post_gpu(frame_3hw, shot, t, absolute)

    def frame(self, shots, number):
        """The finished float32 HxWx3 frame, transitions included."""
        if self.use_gpu:
            with torch.no_grad():
                return self._frame_gpu(shots, number).permute(1, 2, 0).cpu().numpy()
        return self._frame_cpu(shots, number)

    def frame_bytes(self, shots, number):
        """The finished uint8 HxWx3 BGR frame, ready for ffmpeg."""
        if self.use_gpu:
            with torch.no_grad():
                t_img = self._frame_gpu(shots, number)
                return (t_img.permute(1, 2, 0).clamp_(0.0, 1.0) * 255.0 + 0.5).to(torch.uint8).cpu().numpy()
        return (np.clip(self._frame_cpu(shots, number), 0, 1) * 255.0 + 0.5).astype(np.uint8)

    def _frame_cpu(self, shots, number):
        now = number / self.fps
        index = 0
        for i, shot in enumerate(shots):
            if now >= shot["start"]:
                index = i
        shot = shots[index]
        image = None
        transition = shot.get("in", {"type": "cut"})
        half = transition.get("length", 0.8) / 2.0
        following = shots[index + 1] if index + 1 < len(shots) else None
        if following and following.get("in", {"type": "cut"})["type"] != "cut":
            next_half = following["in"].get("length", 0.8) / 2.0
            if now >= following["start"] - next_half:
                image = self.mix(shot, following, following["in"], now, next_half)
        if image is None and transition["type"] != "cut" and index > 0 and now < shot["start"] + half:
            image = self.mix(shots[index - 1], shot, transition, now, half)
        if image is None:
            image = self._shot_frame_cpu(shot, now - shot["start"])
        image = self.finish(image, shot, now - shot["start"])
        return np.clip(image, 0, 1)

    def _frame_gpu(self, shots, number):
        now = number / self.fps
        index = 0
        for i, shot in enumerate(shots):
            if now >= shot["start"]:
                index = i
        shot = shots[index]
        image = None
        transition = shot.get("in", {"type": "cut"})
        half = transition.get("length", 0.8) / 2.0
        following = shots[index + 1] if index + 1 < len(shots) else None
        if following and following.get("in", {"type": "cut"})["type"] != "cut":
            next_half = following["in"].get("length", 0.8) / 2.0
            if now >= following["start"] - next_half:
                image = self.mix_gpu(shot, following, following["in"], now, next_half)
        if image is None and transition["type"] != "cut" and index > 0 and now < shot["start"] + half:
            image = self.mix_gpu(shots[index - 1], shot, transition, now, half)
        if image is None:
            image = self.shot_frame_gpu(shot, now - shot["start"])
        image = self.finish_gpu(image, shot, now - shot["start"])
        return image.clamp_(0.0, 1.0)

    def finish(self, image, shot, t):
        for start, length, color in shot.get("flash", ()):
            if start <= t < start + length:
                amount = 1.0 - (t - start) / length
                image = image + np.array(color, np.float32) * amount ** 2
        fade_in = shot.get("fade_in")
        if fade_in and t < fade_in:
            image = image * ease("smooth", t / fade_in)
        fade_out = shot.get("fade_out")
        if fade_out and t > shot["length"] - fade_out:
            image = image * ease("smooth", (shot["length"] - t) / fade_out)
        return image

    def finish_gpu(self, image_3hw, shot, t):
        for start, length, color in shot.get("flash", ()):
            if start <= t < start + length:
                amount = float(1.0 - (t - start) / length)
                col = torch.tensor(color, dtype=torch.float32, device=self.device).view(3, 1, 1) * (amount ** 2)
                image_3hw = image_3hw + col
        fade_in = shot.get("fade_in")
        if fade_in and t < fade_in:
            image_3hw = image_3hw * float(ease("smooth", t / fade_in))
        fade_out = shot.get("fade_out")
        if fade_out and t > shot["length"] - fade_out:
            image_3hw = image_3hw * float(ease("smooth", (shot["length"] - t) / fade_out))
        return image_3hw

    def mix(self, first, second, transition, now, half):
        u = min(max((now - (second["start"] - half)) / (2.0 * half), 0.0), 1.0)
        kind = transition["type"]
        if kind == "black":
            if u < 0.5:
                return self._shot_frame_cpu(first, now - first["start"]) * ease("smooth", 1.0 - u * 2.0)
            return self._shot_frame_cpu(second, now - second["start"]) * ease("smooth", u * 2.0 - 1.0)
        a = self._shot_frame_cpu(first, now - first["start"])
        b = self._shot_frame_cpu(second, now - second["start"])
        amount = ease("smooth", u)
        if kind == "flash":
            return (a if u < 0.5 else b) + (1.0 - abs(u * 2.0 - 1.0)) ** 2 * 0.9
        if kind == "blur":
            radius = (1.0 - abs(u * 2.0 - 1.0)) * 26.0 * self.k + 0.1
            a = cv2.GaussianBlur(a, (0, 0), radius)
            b = cv2.GaussianBlur(b, (0, 0), radius)
        return a * (1.0 - amount) + b * amount

    def mix_gpu(self, first, second, transition, now, half):
        u = min(max((now - (second["start"] - half)) / (2.0 * half), 0.0), 1.0)
        kind = transition["type"]
        if kind == "black":
            if u < 0.5:
                return self.shot_frame_gpu(first, now - first["start"]) * float(ease("smooth", 1.0 - u * 2.0))
            return self.shot_frame_gpu(second, now - second["start"]) * float(ease("smooth", u * 2.0 - 1.0))
        a = self.shot_frame_gpu(first, now - first["start"])
        b = self.shot_frame_gpu(second, now - second["start"])
        amount = float(ease("smooth", u))
        if kind == "flash":
            return (a if u < 0.5 else b) + float((1.0 - abs(u * 2.0 - 1.0)) ** 2 * 0.9)
        if kind == "blur":
            radius = float((1.0 - abs(u * 2.0 - 1.0)) * 26.0 * self.k + 0.1)
            a = self._gpu_blur(a.unsqueeze(0), radius).squeeze(0)
            b = self._gpu_blur(b.unsqueeze(0), radius).squeeze(0)
        return a * (1.0 - amount) + b * amount


def _rotation(degrees):
    angle = math.radians(degrees)
    cos, sin = math.cos(angle), math.sin(angle)
    return np.array([[cos, -sin, 0.0], [sin, cos, 0.0], [0.0, 0.0, 1.0]])


def layout(shots, total):
    """Fill in absolute starts and lengths from the cut list."""
    for index, shot in enumerate(shots):
        shot["seed"] = index * 7 + 3
        stop = shots[index + 1]["start"] if index + 1 < len(shots) else total
        shot["length"] = stop - shot["start"]
    return shots


def load_font_dir():
    return Path("C:/Windows/Fonts")
