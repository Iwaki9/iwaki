"""Narration through Edge TTS, with a time stamp for every word.

    python tts.py <story.txt> <out_dir> --paragraphs 1-4 [--voice ru-RU-DmitryNeural] [--rate -8%]

Writes narration.wav and words.json (word, start, end, paragraph) in <out_dir>. Stress marks are
removed: Edge returns no audio for text that contains them. The service also refuses requests at
random, so text goes sentence by sentence, each with retries, and finished sentences are kept in
<out_dir>/cache and not requested twice.
"""
import argparse
import asyncio
import hashlib
import json
import re
import subprocess
import unicodedata
from pathlib import Path

import edge_tts
import numpy as np
from scipy.io import wavfile

SENTENCE_PAUSE = 0.16
PARAGRAPH_PAUSE = 0.6
SAMPLE_RATE = 48000
RETRIES = 12


def plain(text):
    decomposed = unicodedata.normalize("NFD", text)
    return unicodedata.normalize("NFC", "".join(c for c in decomposed if c != "́"))


async def speak(text, voice, rate):
    words, audio = [], bytearray()
    communicate = edge_tts.Communicate(text, voice, rate=rate, boundary="WordBoundary")
    async for chunk in communicate.stream():
        if chunk["type"] == "audio":
            audio += chunk["data"]
        elif chunk["type"] == "WordBoundary":
            words.append({"word": chunk["text"], "start": chunk["offset"] / 1e7,
                          "end": (chunk["offset"] + chunk["duration"]) / 1e7})
    return bytes(audio), words


async def sentence_audio(text, voice, rate, cache):
    key = hashlib.sha1(("%s|%s|%s" % (voice, rate, text)).encode("utf-8")).hexdigest()[:16]
    audio_path, words_path = cache / (key + ".mp3"), cache / (key + ".json")
    if audio_path.is_file() and words_path.is_file():
        return audio_path, json.loads(words_path.read_text(encoding="utf-8"))
    for attempt in range(RETRIES):
        try:
            audio, words = await speak(text, voice, rate)
            audio_path.write_bytes(audio)
            words_path.write_text(json.dumps(words, ensure_ascii=False), encoding="utf-8")
            return audio_path, words
        except (edge_tts.exceptions.NoAudioReceived, OSError) as error:
            print("  retry %d: %s" % (attempt + 1, type(error).__name__), flush=True)
            await asyncio.sleep(1.5 + attempt * 1.5)
    raise RuntimeError("Edge TTS refused: " + text)


def duration(path):
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(path)],
                         capture_output=True, text=True)
    return float(out.stdout.strip())


async def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("story")
    parser.add_argument("out")
    parser.add_argument("--paragraphs", default="1-4")
    parser.add_argument("--voice", default="ru-RU-DmitryNeural")
    parser.add_argument("--rate", default="-8%")
    parser.add_argument("--parallel", type=int, default=5)
    args = parser.parse_args()

    paragraphs = [plain(line).strip() for line in Path(args.story).read_text(encoding="utf-8").splitlines() if line.strip()]
    first, last = (int(v) for v in args.paragraphs.split("-"))
    out = Path(args.out)
    cache = out / "cache"
    cache.mkdir(parents=True, exist_ok=True)

    def split(number):
        return re.split(r"(?<=[.!?…»])\s+(?=[А-ЯЁ«—])", paragraphs[number - 1])

    # Fetch everything first, several requests at a time: one Edge request takes ~6 s, and a
    # refusal only holds up its own slot. Results land in the cache, the assembly below reads them.
    # Since late 2026 Edge returns no audio for any rate other than +0%, so speech is fetched at the
    # normal rate and slowed here with atempo (pitch kept); word stamps are stretched to match.
    tempo = 1.0 + float(args.rate.strip("%")) / 100.0
    slots = asyncio.Semaphore(args.parallel)
    todo = [s for n in range(first, last + 1) for s in split(n)]
    done = [0]

    failed = []

    async def fetch(sentence):
        async with slots:
            try:
                await sentence_audio(sentence, args.voice, "+0%", cache)
            except RuntimeError:
                failed.append(sentence)
                return
            done[0] += 1
            if done[0] % 20 == 0 or done[0] == len(todo):
                print("fetched", done[0], "/", len(todo), flush=True)

    await asyncio.gather(*(fetch(s) for s in todo))
    if failed:
        # Everything fetched so far is cached: running the same command again picks up from here.
        print("Edge refused %d sentences; run again to fetch the rest" % len(failed), flush=True)
        raise SystemExit(2)

    all_words, pieces, clock = [], [], 0.0
    for number in range(first, last + 1):
        sentences = split(number)
        for sentence in sentences:
            path, words = await sentence_audio(sentence, args.voice, "+0%", cache)
            decoded = subprocess.run(["ffmpeg", "-v", "error", "-i", str(path), "-af", "atempo=%.4f" % tempo,
                                      "-f", "s16le", "-ac", "1", "-ar", str(SAMPLE_RATE), "-"],
                                     capture_output=True, check=True).stdout
            samples = np.frombuffer(decoded, np.int16)
            for word in words:
                all_words.append({"word": word["word"], "start": round(word["start"] / tempo + clock, 3),
                                  "end": round(word["end"] / tempo + clock, 3), "paragraph": number})
            pieces.append((samples, clock))
            clock += len(samples) / SAMPLE_RATE + SENTENCE_PAUSE
        print("paragraph", number, "ends at", round(clock, 2), "s", flush=True)
        clock += PARAGRAPH_PAUSE

    # Each sentence lands on its exact sample, so the word stamps above stay true to the audio.
    track = np.zeros(int(clock * SAMPLE_RATE) + SAMPLE_RATE, np.int16)
    for samples, start in pieces:
        first_sample = int(start * SAMPLE_RATE)
        track[first_sample:first_sample + len(samples)] = samples
    wavfile.write(str(out / "narration.wav"), SAMPLE_RATE, track)
    (out / "words.json").write_text(json.dumps(all_words, ensure_ascii=False, indent=0), encoding="utf-8")
    print("total", round(clock, 2), "s", len(all_words), "words", round(len(track) / SAMPLE_RATE, 2))


asyncio.run(main())
