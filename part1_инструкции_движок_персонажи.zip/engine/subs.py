"""Subtitles (.srt) from words.json, with the story's own punctuation and no stress marks.

    python engine/subs.py история.txt projects/01_domovyata/audio/words.json out.srt [--chars 42] [--offset 6]

Cues break at sentence ends, prefer commas/dashes when a line gets long, and never exceed
two lines of --chars characters. Each cue lasts from its first word's start to its last word's end
(held a bit longer if the next cue is far away).
"""
import argparse
import json
from pathlib import Path

from align import norm, plain


def tokens(story, paragraphs):
    lines = [plain(line).strip() for line in Path(story).read_text(encoding="utf-8").splitlines() if line.strip()]
    out = []
    for number in paragraphs:
        pending = ""
        for token in lines[number - 1].split():
            word = token.strip("«»“”\"—–-.,!?…:;()")
            if norm(word):
                out.append(pending + token)
                pending = ""
            elif token in ("—", "–", "-"):
                pending += token + " "  # a dialogue dash opens the next line
            elif out:
                out[-1] += " " + token
    return out


def stamp(t):
    ms = int(round(t * 1000))
    return "%02d:%02d:%02d,%03d" % (ms // 3600000, ms // 60000 % 60, ms // 1000 % 60, ms % 1000)


def wrap(text, width):
    if len(text) <= width:
        return text
    words = text.split()
    best = None
    for i in range(1, len(words)):
        a, b = " ".join(words[:i]), " ".join(words[i:])
        score = max(len(a), len(b)) - (6 if a.endswith((",", "—", ":", ";")) else 0)
        if best is None or score < best[0]:
            best = (score, a + "\n" + b)
    return best[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("story")
    parser.add_argument("words")
    parser.add_argument("out")
    parser.add_argument("--chars", type=int, default=42)
    parser.add_argument("--offset", type=float, default=0.0, help="seconds before the first word in the video (scenes.py OFFSET)")
    args = parser.parse_args()

    words = json.loads(Path(args.words).read_text(encoding="utf-8"))
    paragraphs = sorted({w["paragraph"] for w in words})
    toks = tokens(args.story, paragraphs)
    assert len(toks) == len(words), (len(toks), len(words))

    limit = 2 * args.chars
    cues, cur = [], []
    for i, (tok, w) in enumerate(zip(toks, words)):
        cur.append((tok, w))
        text = " ".join(t for t, _ in cur)
        last = i == len(toks) - 1
        end_sentence = tok.rstrip("»”\")").endswith((".", "!", "?", "…"))
        nxt = len(text) + 1 + len(toks[i + 1]) if not last else 0
        soft = tok.endswith((",", "—", ":", ";")) and len(text) > args.chars
        new_par = not last and words[i + 1]["paragraph"] != w["paragraph"]
        pause = not last and words[i + 1]["start"] - w["end"] > 0.6 and len(text) > 15
        if last or end_sentence or soft or new_par or pause or nxt > limit:
            cues.append(cur)
            cur = []

    out = []
    for n, cue in enumerate(cues):
        start = cue[0][1]["start"]
        end = cue[-1][1]["end"]
        next_start = cues[n + 1][0][1]["start"] if n + 1 < len(cues) else end + 1.0
        end = min(max(end + 0.3, start + 1.0), next_start - 0.05)
        text = wrap(" ".join(t for t, _ in cue), args.chars)
        out.append("%d\n%s --> %s\n%s\n" % (n + 1, stamp(start + args.offset), stamp(end + args.offset), text))
    Path(args.out).write_text("\n".join(out), encoding="utf-8-sig")
    print("cues", len(out), "->", args.out)


if __name__ == "__main__":
    main()
