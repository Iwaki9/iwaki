"""Fix Whisper's word timings with another subtitle file and the audio itself.

    python engine/refine.py projects/01_domovyata/audio other.srt [--dry]

Whisper (align.py) is accurate in calm narration but can run up to a second late in fast shouted
lines. An .srt from the voice service (ElevenLabs etc.) has the right sentence order but its cue
starts sit anywhere in the pause before the sentence. Here every cue start is turned into an
anchor: the cue's first word starts where the pause around that time ends in narration.wav. The
words between two anchors keep Whisper's relative timing, stretched to fit. Writes words.json
(the old one is kept as words_whisper.json).
"""
import argparse
import json
import re
import shutil
from pathlib import Path

import numpy as np
from scipy.io import wavfile

from align import norm, plain

FRAME = 0.01
STRIP = "«»“”\"—–-.,!?…:;()"


def srt_cues(path):
    text = Path(path).read_text(encoding="utf-8-sig")
    out = []
    for block in text.strip().split("\n\n"):
        lines = block.strip().split("\n")
        stamp = next((l for l in lines if "-->" in l), None)
        if not stamp:
            continue
        h, m, s, ms = (int(v) for v in re.match(r"(\d+):(\d+):(\d+)[,.](\d+)", stamp).groups())
        body = plain(" ".join(lines[lines.index(stamp) + 1:]))
        toks = [norm(t.strip(STRIP)) for t in body.split() if norm(t.strip(STRIP))]
        out.append((h * 3600 + m * 60 + s + ms / 1000, toks))
    return out


def silences(wav, min_len=0.1):
    sr, x = wavfile.read(str(wav))
    x = x.astype(np.float64)
    n = int(FRAME * sr)
    frames = x[: len(x) // n * n].reshape(-1, n)
    db = 20 * np.log10(np.sqrt((frames ** 2).mean(axis=1)) + 1)
    threshold = np.median(db[db > 20]) - 22
    quiet = db < threshold
    gaps, start = [], None
    for i, q in enumerate(np.append(quiet, False)):
        if q and start is None:
            start = i
        elif not q and start is not None:
            if (i - start) * FRAME >= min_len:
                gaps.append((start * FRAME, i * FRAME))
            start = None
    return gaps, threshold


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("audio_dir")
    parser.add_argument("srt")
    parser.add_argument("--max-shift", type=float, default=1.5)
    parser.add_argument("--dry", action="store_true")
    args = parser.parse_args()
    audio = Path(args.audio_dir)
    source = audio / "words_whisper.json"
    if not source.exists():
        shutil.copy(audio / "words.json", source)
    words = json.loads(source.read_text(encoding="utf-8"))
    gaps, threshold = silences(audio / "narration.wav")
    print("threshold %.1f dB, %d pauses" % (threshold, len(gaps)))

    # 1. Each cue's first word index (cues follow the story word by word).
    anchors, idx, skipped = {}, 0, 0
    for t, toks in srt_cues(args.srt):
        if not toks:
            continue
        if idx >= len(words) or norm(words[idx]["word"]) != toks[0]:
            raise SystemExit("srt drifts from words.json at cue %.1f s (%s)" % (t, " ".join(toks[:5])))
        # Snap to the end of the pause that holds t; no pause there means no anchor.
        holding = [g for g in gaps if g[0] - 0.1 <= t <= g[1] + 0.1]
        best_gap = min(holding, key=lambda g: abs(g[1] - t)) if holding else None
        new = best_gap[1] if holding else None
        if new is not None and abs(new - words[idx]["start"]) <= args.max_shift:
            anchors[idx] = (new, len(toks), best_gap)
        else:
            skipped += 1
        idx += len(toks)

    # 2. Only the anchored cue's own words move (Whisper's slips are local); a neighbour that now
    #    overlaps is trimmed, and a cue that would run into the next word is squeezed.
    old = [(w["start"], w["end"]) for w in words]
    new = [list(t) for t in old]
    for k, (start, count, gap) in sorted(anchors.items()):
        shift = start - old[k][0]
        last = min(k + count, len(words))
        for i in range(k, last):
            new[i] = [old[i][0] + shift, old[i][1] + shift]
        limit = new[last][0] - 0.02 if last < len(words) else None
        if limit is not None and new[last - 1][1] > limit:
            span = new[last - 1][1] - start
            scale = max(limit - start, 0.05 * count) / span if span > 0 else 1.0
            for i in range(k, last):
                new[i] = [start + (new[i][0] - start) * scale, start + (new[i][1] - start) * scale]
        # Words before the anchor end where the pause starts.
        i = k - 1
        while i >= 0 and new[i][1] > gap[0]:
            new[i][1] = max(gap[0], new[i][0] + 0.05)
            if new[i][0] < gap[0] - 0.05:
                break
            new[i][0] = new[i][1] - 0.05
            i -= 1

    moved = [abs(n[0] - o[0]) for n, o in zip(new, old)]
    print("anchors %d (skipped %d), median move %.2f s, max %.2f s"
          % (len(anchors), skipped, float(np.median(moved)), max(moved)))
    for i in sorted(range(len(words)), key=lambda i: -moved[i])[:8]:
        print("  %-16s %.2f -> %.2f" % (words[i]["word"], old[i][0], new[i][0]))
    if args.dry:
        return
    for w, (s, e) in zip(words, new):
        w["start"], w["end"] = round(s, 3), round(max(e, s + 0.03), 3)
    (audio / "words.json").write_text(json.dumps(words, ensure_ascii=False, indent=0), encoding="utf-8")
    print("words.json updated")


if __name__ == "__main__":
    main()
