# Пакет персонажа `default_boy`

Это **собранный персонаж**: слои, которые игра рисует сама, и суставы, которые игра сама
задаёт. Ничего не нарисовано и не додумано — это снимки движка, разложенные по глубине.

## Что внутри

| файл | что это |
|---|---|
| `layers.json` | порядок слоёв, их кость, измеренный сустав, измеренные границы, палитра кадра |
| `parts/NN-имя.png` | сам слой, 1024×1024, общий холст, прозрачный фон |
| `reference.png` | кадр, из которого всё снято (эталон сборки) |
| `README.ru.md` | этот файл |
| `faces/` | измеренные эмоции: 13 форм глаз × 15 форм рта = 195 |

Холст общий: `gameToCanvas` = `{"c": 0, "a": 2.7705627705627704, "b": 0, "ty": -271.5497835497835, "d": 2.7705627705627704, "tx": -336.4848484848485}`. Слои **уже** в пикселях холста, складывать их
нужно просто по порядку `order` (по возрастанию), без матриц.

Проверка сборки: если сложить все слои без единого преобразования, получается
`reference.png`. Замер: расходится 1349 пикселей из 1048576 (>1.0% канала) —
это ошибка alpha-наложения, а не геометрии.

## Суставы

`pivot` — это origin игрового узла, переведённый в пиксели холста. Не оценка: игра
ставит конечность именно вокруг этой точки.

| кость | родитель | узел игры | сустав (x, y) |
|---|---|---|---|
| `ground` | — | `static ground plane; never transformed, so the cast shadow stays put` | 0.0, 0.0 |
| `root` | — | `silhouette bottom centre of the measured reference frame` | 504.0, 933.0 |
| `hips` | `root` | `midpoint(thigh, backthigh)` | 517.5, 664.6 |
| `torso` | `hips` | `body` | 515.5, 493.8 |
| `head` | `torso` | `head` | 503.7, 394.8 |
| `armUpperFront` | `torso` | `shoulder` | 441.4, 475.8 |
| `armLowerFront` | `armUpperFront` | `handx` | 401.2, 584.6 |
| `armUpperBack` | `torso` | `backshoulder` | 561.9, 477.9 |
| `armLowerBack` | `armUpperBack` | `backhand` | 604.8, 578.3 |
| `legUpperFront` | `hips` | `thigh` | 473.9, 671.1 |
| `legLowerFront` | `legUpperFront` | `foot` | 464.9, 815.2 |
| `legUpperBack` | `hips` | `backthigh` | 561.2, 658.0 |
| `legLowerBack` | `legUpperBack` | `backfoot` | 572.3, 806.9 |

`hips` — середина двух измеренных тазобедренных суставов, `root` — низ силуэта
эталонного кадра (центр по x), `ground` — статичная плоскость (тень не двигается).

## Слои

| # | слой | кость | цепочка узлов | пиксели (x0,y0,x1,y1) |
|---|---|---|---|---|
| 0 | `shadow` | `ground` | `shadow/shadow` | 403, 886, 643, 928 |
| 1 | `skinc` | `armUpperBack` | `backshoulder/skinc` | 525, 408, 603, 549 |
| 2 | `sleeves` | `armUpperBack` | `backshoulder/sleeves` | 524, 406, 606, 542 |
| 3 | `handx-channels-000` | `armLowerBack` | `backhand/handx/c1` | 556, 504, 661, 680 |
| 4 | `sleeves` | `armLowerBack` | `backhand/handx/sleevewrist/sleeves` | — |
| 5 | `skinc` | `legUpperBack` | `backthigh/skinc` | 515, 568, 604, 767 |
| 6 | `socks` | `legUpperBack` | `backthigh/socks` | — |
| 7 | `pants` | `legUpperBack` | `backthigh/pants` | 508, 565, 614, 771 |
| 8 | `skinc` | `legLowerBack` | `backfoot/skinc` | 521, 716, 619, 911 |
| 9 | `socks` | `legLowerBack` | `backfoot/socks` | 533, 827, 624, 913 |
| 10 | `pants` | `legLowerBack` | `backfoot/pants` | 503, 712, 620, 765 |
| 11 | `shoe` | `legLowerBack` | `backfoot/shoe` | 530, 837, 632, 925 |
| 12 | `skinc` | `torso` | `body/skinc` | 439, 346, 596, 640 |
| 13 | `pants` | `torso` | `body/pants` | 437, 575, 598, 644 |
| 14 | `shirt` | `torso` | `body/shirt` | 440, 398, 599, 598 |
| 15 | `skinc` | `legUpperFront` | `thigh/skinc` | 425, 576, 517, 779 |
| 16 | `socks` | `legUpperFront` | `thigh/socks` | — |
| 17 | `pants` | `legUpperFront` | `thigh/pants` | 411, 573, 520, 782 |
| 18 | `skinc` | `legLowerFront` | `foot/skinc` | 417, 724, 511, 919 |
| 19 | `socks` | `legLowerFront` | `foot/socks` | 420, 835, 504, 921 |
| 20 | `pants` | `legLowerFront` | `foot/pants` | 402, 720, 524, 773 |
| 21 | `shoe` | `legLowerFront` | `foot/shoe` | 412, 845, 512, 933 |
| 22 | `shirt` | `torso` | `belt/shirt` | 421, 520, 614, 622 |
| 23 | `skinc` | `armUpperFront` | `shoulder/skinc` | 403, 405, 478, 548 |
| 24 | `sleeves` | `armUpperFront` | `shoulder/sleeves` | 402, 399, 483, 535 |
| 25 | `handx-channels-000` | `armLowerFront` | `handx/handx/c1` | 343, 507, 450, 680 |
| 26 | `wrist` | `armLowerFront` | `handx/handx/sleevewrist/wrist` | 359, 586, 414, 611 |
| 27 | `sleeves` | `armLowerFront` | `handx/handx/sleevewrist/sleeves` | — |
| 28 | `scarf1` | `torso` | `scarf/scarf1` | 530, 436, 558, 464 |
| 29 | `skinc` | `head` | `head/head/skinc` | 392, 139, 618, 390 |
| 30 | `blush` | `head` | `head/head/blush` | 447, 308, 618, 342 |
| 31 | `mouth` | `head` | `head/head/mouth` | 523, 363, 562, 372 |
| 32 | `eye2-channels-000` | `head` | `head/head/eye2/eye2/c4` | 559, 302, 601, 325 |
| 33 | `pupil` | `head` | `head/head/eye2/eye2/pupil/pupil` | 568, 303, 581, 325 |
| 34 | `eye2-channels-005` | `head` | `head/head/eye2/eye2/instance3921` | 556, 288, 613, 338 |
| 35 | `highlight2` | `head` | `head/head/eye2/highlight2` | 578, 303, 581, 307 |
| 36 | `nose` | `head` | `head/head/nose` | 540, 326, 559, 348 |
| 37 | `eye1-channels-000` | `head` | `head/head/eye1/eye1/c4` | 450, 302, 532, 325 |
| 38 | `pupil` | `head` | `head/head/eye1/eye1/pupil/pupil` | 489, 303, 515, 325 |
| 39 | `eye1-channels-005` | `head` | `head/head/eye1/eye1/instance2687` | 424, 288, 538, 338 |
| 40 | `highlight1` | `head` | `head/head/eye1/highlight1` | 492, 303, 497, 307 |
| 41 | `rearhair` | `head` | `head/head/rearhair` | 345, 128, 665, 337 |
| 42 | `accessory1` | `head` | `head/head/accessory1` | 431, 250, 608, 365 |
| 43 | `fronthair` | `head` | `head/head/fronthair/fronthair/fronthair` | 409, 88, 653, 364 |
| 44 | `eyebrow1` | `head` | `head/head/eyebrow1/eyebrow1` | 478, 256, 533, 282 |
| 45 | `eyebrow2` | `head` | `head/head/eyebrow2/eyebrow2` | 552, 257, 589, 283 |
| 46 | `ahoge` | `head` | `head/head/ahoge/ahoge` | 467, 112, 486, 137 |

Пустые слои (`—` в границах) — измеренные пустые группы глубины, это не ошибка.

## Как собрать кадр

Матрица кости = произведение по цепочке родителей: `world(кость) = world(родитель) @ R(сустав, угол)`.
Слой рисуется своей `world`-матрицей, слои накладываются по `order`.

Готовый код: `character-export/tools/anim/riglib.py`
(`forward()` — прямая кинематика, `compose()` — сборка, `blink()` — моргание,
`face_set()`/`splice_face()` — измеренная эмоция).

## Эмоции

`faces/` — измеренные формы глаз и рта из игры, независимые друг от друга:
13 значений глаз (`eyes1x`/`eyes2x`) и 15 значений рта (`mouth`), всего комбинаций: 195.
Один кадр с выбранным выражением:

```powershell
python character-export\tools\anim\render_face.py --package character-export\anim\default_boy `
  --eyes <значение> --mouth <значение> --out face.png
```

Своими руками это `face_set()` + `splice_face()` + `compose()` из `riglib.py`.
Таблицы значений, превью-сетки и подбор по ситуации — `faces/README.ru.md`.

## Чего здесь нет

- Нет синтетической деформации кожи: каждый слой — жёсткая картинка, вращается целиком.
  Поэтому на широком повороте видно стык у сустава — это предел жёстких слоёв, а не баг.
- Нет сустава стопы: `foot` — это голень + ботинок, вращается вокруг колена.
- **Нет анимации.** Пакет — это кукла, её слои и измеренные суставы; циклы, физика,
  интерполяция и монтаж остаются принимающей системе. Здесь только персонаж и его
  измеренные эмоции.

## Откуда снято

- прогон: `E:\Gacha Nebula Windows 1.7\Gacha Nebula Windows 1.7\character-export\experiments\native-controls\output\default_boy-parts-001`
- сэмпл: `00-baseline`
- форма рецепта: `paste`
- рецепт: `E:\Gacha Nebula Windows 1.7\Gacha Nebula Windows 1.7\character-export\inputs\default_boy.txt`
- sha256 рецепта: `None`
- селекторы кадра: `{"pose1": {"value": 1, "type": "number"}, "eyes1x1": {"value": 145, "type": "number"}, "facepreset1": {"value": 1, "type": "number"}, "mouth1": {"value": 277, "type": "number"}, "eyes2x1": {"value": 145, "type": "number"}}`
