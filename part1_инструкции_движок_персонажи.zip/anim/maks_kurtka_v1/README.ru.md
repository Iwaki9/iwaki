# Пакет персонажа `maks_kurtka_v1`

Это **собранный персонаж**: слои, которые игра рисует сама, и суставы, которые игра сама
задаёт. Ничего не нарисовано и не додумано — это снимки движка, разложенные по глубине.

## Что внутри

| файл | что это |
|---|---|
| `layers.json` | порядок слоёв, их кость, измеренный сустав, измеренные границы, палитра кадра |
| `parts/NN-имя.png` | сам слой, 1024×1024, общий холст, прозрачный фон |
| `reference.png` | кадр, из которого всё снято (эталон сборки) |
| `README.ru.md` | этот файл |
| `faces/` | измеренные эмоции: 12 форм глаз × 14 форм рта = 168 |

Холст общий: `gameToCanvas` = `{"c": 0, "a": 2.7988338192419824, "b": 0, "ty": -275.1720116618076, "d": 2.7988338192419824, "tx": -340.7696793002915}`. Слои **уже** в пикселях холста, складывать их
нужно просто по порядку `order` (по возрастанию), без матриц.

Проверка сборки: если сложить все слои без единого преобразования, получается
`reference.png`. Замер: расходится 123 пикселей из 1048576 (>1.0% канала) —
это ошибка alpha-наложения, а не геометрии.

## Суставы

`pivot` — это origin игрового узла, переведённый в пиксели холста. Не оценка: игра
ставит конечность именно вокруг этой точки.

| кость | родитель | узел игры | сустав (x, y) |
|---|---|---|---|
| `ground` | — | `static ground plane; never transformed, so the cast shadow stays put` | 0.0, 0.0 |
| `root` | — | `silhouette bottom centre of the measured reference frame` | 501.0, 937.0 |
| `hips` | `root` | `midpoint(thigh, backthigh)` | 524.1, 669.1 |
| `torso` | `hips` | `body` | 511.5, 495.9 |
| `head` | `torso` | `head` | 498.2, 396.5 |
| `armUpperFront` | `torso` | `shoulder` | 428.9, 476.3 |
| `armLowerFront` | `armUpperFront` | `handx` | 390.4, 584.8 |
| `armUpperBack` | `torso` | `backshoulder` | 558.4, 478.4 |
| `armLowerBack` | `armUpperBack` | `backhand` | 603.8, 578.5 |
| `legUpperFront` | `hips` | `thigh` | 477.2, 675.0 |
| `legLowerFront` | `legUpperFront` | `foot` | 459.7, 820.6 |
| `legUpperBack` | `hips` | `backthigh` | 571.0, 663.1 |
| `legLowerBack` | `legUpperBack` | `backfoot` | 592.6, 813.6 |

`hips` — середина двух измеренных тазобедренных суставов, `root` — низ силуэта
эталонного кадра (центр по x), `ground` — статичная плоскость (тень не двигается).

## Слои

| # | слой | кость | цепочка узлов | пиксели (x0,y0,x1,y1) |
|---|---|---|---|---|
| 0 | `shadow` | `ground` | `shadow/shadow` | 406, 894, 649, 937 |
| 1 | `skinc` | `armUpperBack` | `backshoulder/skinc` | 519, 409, 601, 551 |
| 2 | `sleeves` | `armUpperBack` | `backshoulder/sleeves` | 516, 408, 592, 551 |
| 3 | `handx-channels-000` | `armLowerBack` | `backhand/handx/c1` | 553, 505, 662, 681 |
| 4 | `sleeves` | `armLowerBack` | `backhand/handx/sleevewrist/sleeves` | 541, 502, 643, 624 |
| 5 | `skinc` | `legUpperBack` | `backthigh/skinc` | 519, 571, 621, 773 |
| 6 | `socks` | `legUpperBack` | `backthigh/socks` | — |
| 7 | `pants` | `legUpperBack` | `backthigh/pants` | 518, 570, 622, 775 |
| 8 | `skinc` | `legLowerBack` | `backfoot/skinc` | 537, 721, 644, 919 |
| 9 | `socks` | `legLowerBack` | `backfoot/socks` | 554, 833, 649, 921 |
| 10 | `pants` | `legLowerBack` | `backfoot/pants` | 534, 720, 641, 887 |
| 11 | `shoe` | `legLowerBack` | `backfoot/shoe` | 540, 805, 647, 925 |
| 12 | `skinc` | `torso` | `body/skinc` | 438, 347, 596, 644 |
| 13 | `pants` | `torso` | `body/pants` | 435, 576, 598, 648 |
| 14 | `shirt` | `torso` | `body/shirt` | 438, 401, 598, 601 |
| 15 | `skinc` | `legUpperFront` | `thigh/skinc` | 427, 579, 521, 784 |
| 16 | `socks` | `legUpperFront` | `thigh/socks` | — |
| 17 | `pants` | `legUpperFront` | `thigh/pants` | 424, 577, 522, 785 |
| 18 | `skinc` | `legLowerFront` | `foot/skinc` | 409, 728, 514, 925 |
| 19 | `socks` | `legLowerFront` | `foot/socks` | 410, 839, 491, 928 |
| 20 | `pants` | `legLowerFront` | `foot/pants` | 396, 727, 515, 894 |
| 21 | `shoe` | `legLowerFront` | `foot/shoe` | 403, 810, 497, 930 |
| 22 | `shirt` | `torso` | `belt/shirt` | 419, 521, 615, 626 |
| 23 | `skinc` | `armUpperFront` | `shoulder/skinc` | 386, 409, 471, 548 |
| 24 | `sleeves` | `armUpperFront` | `shoulder/sleeves` | 398, 404, 478, 545 |
| 25 | `handx-channels-000` | `armLowerFront` | `handx/handx/c1` | 337, 506, 435, 683 |
| 26 | `wrist` | `armLowerFront` | `handx/handx/sleevewrist/wrist` | 349, 587, 405, 615 |
| 27 | `sleeves` | `armLowerFront` | `handx/handx/sleevewrist/sleeves` | 352, 504, 446, 624 |
| 28 | `scarf2` | `torso` | `scarf/scarf2` | 399, 366, 625, 627 |
| 29 | `scarf1` | `torso` | `scarf/scarf1` | 391, 399, 626, 581 |
| 30 | `skinc` | `head` | `head/head/skinc` | 388, 138, 617, 392 |
| 31 | `blush` | `head` | `head/head/blush` | 442, 308, 616, 343 |
| 32 | `mouth` | `head` | `head/head/mouth` | 515, 372, 536, 379 |
| 33 | `eye2-channels-000` | `head` | `head/head/eye2/eye2/instance1996` | 562, 286, 603, 332 |
| 34 | `pupil` | `head` | `head/head/eye2/eye2/pupil/pupil` | 567, 291, 584, 327 |
| 35 | `eye2-channels-005` | `head` | `head/head/eye2/eye2/c3` | 562, 282, 609, 323 |
| 36 | `highlight2` | `head` | `head/head/eye2/highlight2` | 575, 307, 579, 310 |
| 37 | `nose` | `head` | `head/head/nose` | 539, 337, 547, 347 |
| 38 | `eye1-channels-000` | `head` | `head/head/eye1/eye1/instance2011` | 452, 283, 515, 329 |
| 39 | `pupil` | `head` | `head/head/eye1/eye1/pupil/pupil` | 482, 288, 509, 324 |
| 40 | `eye1-channels-005` | `head` | `head/head/eye1/eye1/c3` | 441, 279, 517, 318 |
| 41 | `highlight1` | `head` | `head/head/eye1/highlight1` | 488, 304, 494, 307 |
| 42 | `rearhair` | `head` | `head/head/rearhair` | 341, 127, 665, 340 |
| 43 | `accessory1` | `head` | `head/head/accessory1` | 426, 253, 605, 366 |
| 44 | `fronthair` | `head` | `head/head/fronthair/fronthair/fronthair` | 407, 89, 654, 364 |
| 45 | `eyebrow1` | `head` | `head/head/eyebrow1/eyebrow1` | 462, 257, 505, 273 |
| 46 | `eyebrow2` | `head` | `head/head/eyebrow2/eyebrow2` | 568, 261, 597, 276 |
| 47 | `ahoge` | `head` | `head/head/ahoge/ahoge` | 470, 111, 489, 136 |

Пустые слои (`—` в границах) — измеренные пустые группы глубины, это не ошибка.

## Как собрать кадр

Матрица кости = произведение по цепочке родителей: `world(кость) = world(родитель) @ R(сустав, угол)`.
Слой рисуется своей `world`-матрицей, слои накладываются по `order`.

Готовый код: `character-export/tools/anim/riglib.py`
(`forward()` — прямая кинематика, `compose()` — сборка, `blink()` — моргание,
`face_set()`/`splice_face()` — измеренная эмоция).

## Эмоции

`faces/` — измеренные формы глаз и рта из игры, независимые друг от друга:
12 значений глаз (`eyes1x`/`eyes2x`) и 14 значений рта (`mouth`), всего комбинаций: 168.
Один кадр с выбранным выражением:

```powershell
python character-export\tools\anim\render_face.py --package character-export\anim\maks_kurtka_v1 `
  --eyes <значение> --mouth <значение> --out face.png
```

Своими руками это `face_set()` + `splice_face()` + `compose()` из `riglib.py`.
Таблицы значений, превью-сетки и подбор по ситуации — `faces/README.ru.md`.

## Чего здесь нет

- Нет синтетической деформации кожи: каждый слой — жёсткая картинка, вращается целиком.
  Поэтому на широком повороте видно стык у сустава — это предел жёстких слоёв, а не баг.
- Нет сустава стопы: `foot` — это голень + ботинок, вращается вокруг колена.
- **Нет анимации.** Пакет — это кукла, её слои и измеренные суставы; циклы, физика,
  интерполяция и монтаж остаются принимающей системе. Здесь только персонаж и его
  измеренные эмоции.

## Откуда снято

- прогон: `E:\Gacha Nebula Windows 1.7\Gacha Nebula Windows 1.7\character-export\experiments\native-controls\output\maks_kurtka_v1-parts-001`
- сэмпл: `00-baseline`
- форма рецепта: `paste`
- рецепт: `E:\Gacha Nebula Windows 1.7\Gacha Nebula Windows 1.7\character-export\inputs\maks_kurtka_v1.txt`
- sha256 рецепта: `ed902e07adc76d264b4defbf8b07b6de7c3e9ce2d0ad68873b10a4106829541d`
- селекторы кадра: `{"mouth1": {"value": 1, "type": "number"}, "eyes2x1": {"value": 1, "type": "number"}, "pose1": {"value": 3, "type": "number"}, "eyes1x1": {"value": 1, "type": "number"}, "facepreset1": {"value": 1, "type": "number"}}`


## Происхождение и соответствие плану (сеанс «Три дня до рассвета»)

Пак снят с офлайн-кода `character-export/characters/maks_kurtka_v1/code.txt`
(1113 полей, 4042 байта, sha256
`ed902e07adc76d264b4defbf8b07b6de7c3e9ce2d0ad68873b10a4106829541d`). Код собран из
текстового описания `specs/descriptions/maks_kurtka_v1.txt` цепочкой
`compose.py → author.py`, без числовых ID ассетов: только named-образцы каталога.

- Лицо: архетип `dobryi-otkrytyi` из `catalogue/face-archetypes.json` — не клон
  `default_boy`. Базовый кадр: `pose=3`, `eyes1x=eyes2x=1`, `mouth=1`.
- Куртка: `scarf1x=83` + `scarf2x=88` + `sleeves1x/sleeves2x=94`, палитра
  `FF6A00` / `F2600A` / `FF7118`. Лучшее из промеренного, но **не точная копия**
  `друг.jpg`: в движке нет тонкой вертикальной молнии и диагональных карманов на
  молнии, воротник получается пышнее стойки, на груди остаются горизонтальные
  полосы-«лесенка».
- По `план.md` это «живой» Макс: автобус, тропа, окно — 4 мелких плана. Макс у
  колодца — не этот пак, а фото из Nano Banana.

Атлас эмоций: `faces/` — 12 глаз × 14 ртов = 168 комбинаций,
`faces/situations.json` содержит 8 ситуаций под эти планы. Проверка
`verify_package.py`: `verified`, 9/9.
