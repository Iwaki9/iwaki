# Персонаж с эмоциями — пакет для экспорта

Здесь лежит **собранный персонаж и его измеренные эмоции**: слои, которые игра рисует сама,
суставы, которые игра сама задаёт, и формы глаз и рта из самой игры. Ничего не нарисовано и
не додумано — это снимки движка, разложенные по глубине, плюс снятые с него же формы лица.

**Анимации здесь нет и не будет.** Пакет — это кукла и её данные: циклы, физика, интерполяция
и монтаж делаются там, куда персонаж экспортируется. Здесь только то, что нельзя выдумать:
слои, суставы, измеренные суставы и формы лица.

## Готовые пакеты

Числа ниже считаны напрямую из `layers.json` и `faces/faces.json` каждого пака, а не вписаны
от руки. Три пака каста «Три дня до рассвета» — `lesnik_tulup_v1`, `maks_kurtka_v1`,
`rasskazchik_street_v3` (последний переиспользуется без правок, согласно `план.md`).
Два пака каста «Час осмотра» — `medsestra_halat_v1` и `igor_vetrovka_v1`; рассказчик
для этой истории берётся из `rasskazchik_street_v3` без экспорта.

| персонаж | пакет | слоёв | костей | базовый кадр | эмоции |
|---|---|---:|---:|---|---|
| `chubbzee` (paste-форма) | `anim/chubbzee/` | 39 | 13 | `pose=3`, `eyes=70/70`, `mouth=277` | 12 × 15 = 180 |
| `soft_helen` (share-code) | `anim/soft_helen/` | 43 | 13 | `pose=33`, `eyes=71/71`, `mouth=131` | 13 × 14 = 182 |
| `default_boy` | `anim/default_boy/` | 47 | 13 | `pose=1`, `eyes=145/145`, `mouth=277` | 13 × 15 = 195 |
| `galina_home_v3` | `anim/galina_home_v3/` | 43 | 13 | `pose=1`, `eyes=66/66`, `mouth=277` | 13 × 15 = 195 |
| `kollega_office_v7` | `anim/kollega_office_v7/` | 44 | 13 | `pose=1`, `eyes=81/81`, `mouth=277` | 13 × 15 = 195 |
| `margarita_home_v5` | `anim/margarita_home_v5/` | 45 | 13 | `pose=1`, `eyes=66/66`, `mouth=277` | 13 × 15 = 195 |
| `rasskazchik_home_v7` | `anim/rasskazchik_home_v7/` | 47 | 13 | `pose=1`, `eyes=66/66`, `mouth=277` | 13 × 15 = 195 |
| `stepan_work_v1` | `anim/stepan_work_v1/` | 44 | 13 | `pose=1`, `eyes=81/81`, `mouth=277` | 13 × 15 = 195 |
| **`rasskazchik_street_v3`** | `anim/rasskazchik_street_v3/` | 47 | 13 | `pose=1`, `eyes=66/66`, `mouth=277` | 13 × 15 = 195 |
| **`lesnik_tulup_v1`** (новый) | `anim/lesnik_tulup_v1/` | 53 | 13 | `pose=1`, `eyes=134/134`, `mouth=331` | 12 × 14 = 168 |
| **`maks_kurtka_v1`** (новый) | `anim/maks_kurtka_v1/` | 48 | 13 | `pose=3`, `eyes=1/1`, `mouth=1` | 12 × 14 = 168 |
| **`medsestra_halat_v1`** (новый) | `anim/medsestra_halat_v1/` | 57 | 13 | `pose=3`, `eyes=66/66`, `mouth=277` | 13 × 15 = 195 |
| **`igor_vetrovka_v1`** (новый) | `anim/igor_vetrovka_v1/` | 48 | 13 | `pose=3`, `eyes=191/191`, `mouth=358` | 12 × 14 = 168 |

У четырёх новых паков `verify_package.py` перезапущен после сборки: `verified`, **9/9**, включая
`identity-render`. Нативные прогоны тоже прошли независимого ревьюера: `maks_kurtka_v1-parts-001`
(41 проверка), `maks_kurtka_v1-faces-parts-001` (281), `lesnik_tulup_v1-parts-002` (41),
`lesnik_tulup_v1-faces-parts-003` (281), `igor_vetrovka_v1-parts-001` (41),
`igor_vetrovka_v1-faces-parts-001` (281), `medsestra_halat_v1-parts-002` (41),
`medsestra_halat_v1-faces-parts-001` (301). В `faces/situations.json` — по 8 ситуаций у паков
«Трёх дней», 8 у медсестры и 6 у Игоря; подробности и честные пределы — в их `README.ru.md`.

**Важно про медсестру:** марля `acc4x=120` сдвинута на `acc4ypos=20`. При 0 и 10 она закрывает
рот, при 20 лежит на шее и все 15 форм рта читаются, при 30+ сползает на грудь. Порог измерен
прогоном `medsestra-mask-ypos-001`. Это не косметика: по `план.md` медсестра говорит в девяти
планах, и атлас рта без сдвига был бы бесполезен — та же ловушка, что с бородой Лесника.
Необязательный `medsestra_maska_v1` (маска на лице) не собран: это тот же рецепт с `acc4ypos=0`,
сохранённый как `character-export/inputs/medsestra_halat_v1-mask0.txt`.

**Важно про Лесника:** пак собран с `acc5ypos=15`. Без этого сдвига слой бороды (`acc5`,
глубина 51) рисуется поверх рта (глубина 34), и 13 из 14 форм рта попиксельно совпадают с
базой — первый прогон атласа был забракован ревьюером. Из-за сдвига борода в
`reference.png` выглядит чуть опущенной (под щеками видна светлая щель): это осознанная
плата за работающий атлас рта, а не ошибка съёмки. Порог резкий: при сдвигах 11–14 видны
лишь 1–2 формы рта из 13, при 15 — все 14; `acc5sizey>0` возвращает бороду к щекам, но
снова закрывает рот. Все 282 формы `acc5x` просмотрены — бороды с прорезью под рот в
движке нет. Для статичного кадра, где анимация рта не нужна, можно взять код
`character-export/characters/lesnik_v3c_face/code.txt` (сдвиг 0, борода «на месте»).

## Что внутри пакета

```
anim/<slug>/
  layers.json        порядок слоёв, кость, измеренный сустав, границы, холст, провенанс
  parts/NN-*.png     сами слои, 1024×1024 RGBA, прозрачный фон
  reference.png      кадр, из которого всё снято (эталон сборки)
  README.ru.md       таблицы суставов и слоёв именно этого персонажа
  faces/             измеренные эмоции:
    faces.json         значения селекторов, файлы слоёв, sha256 каждого файла
    eyes/NNN/*.png     слои одной формы глаз
    mouths/NNN/*.png   слои одной формы рта
    preview-eyes.png   сетка превью всех значений глаз, подписи под плитками
    preview-mouth.png  сетка превью всех значений рта
    situations.json    исходник таблицы «ситуация → глаза/рот»
    README.ru.md       значения, превью, подбор по ситуации, проверка
```

Рядом:

- `HANDOFF-TASK.ru.md` — задание для системы, которая забирает персонажа и делает по нему
  анимацию;
- `anim.zip` — вся эта папка одним архивом;
- `character-export/archive-walk/` — отклонённые попытки анимации ходьбы (в пакет не входят,
  оставлены как история; см. последний раздел).

## Откуда взято (это важно)

Слои — **нативные рендеры** групп глубины, которые делает сама игра, а не вырезка из итоговой
картинки:

- прогоны `chubbzee-parts-001` и `soft_helen-parts-001`, флаг `-PartsCapture`;
- ревьюер (`review-tools/verify_native_controls.py`) проверяет каждый прогон, в том числе
  проверкой `sample-parts`: он **сам** складывает присланные слои в порядке глубины и сравнивает
  с кадром прогона. Оба прогона: `verified`, 41 проверка.

Суставы — не оценка: `pivot` каждой кости равен origin соответствующего игрового узла
(`thigh`, `foot`, `shoulder`, `handx`, …), переведённому в пиксели холста. Таз (`hips`) —
середина двух измеренных тазобедренных суставов. В `layers.json` записаны 13 костей.

Сборка без преобразований воспроизводит эталон: расхождение **222** пикселя из 1 048 576 у
`chubbzee` и **97** у `soft_helen` (ошибка alpha-наложения, не геометрии). Это проверяет
`verify_package.py`, проверка `identity-render`.

## Как устроен кадр

`layers.json`:

```json
{
  "canvas": {"size": 1024, "matrix": {...}},
  "rig": {"order": ["ground","root","hips","torso","head","armUpperFront", ...],
          "bones": {"legUpperFront": {"parent": "hips", "node": "thigh", "pivot": [485.4, 690.3]}, ...}},
  "layers": [{"order": 0, "name": "shadow", "file": "parts/01-shadow.png",
              "chain": ["shadow","shadow"], "bone": "ground", "eye": false,
              "bounds": [424,888,632,927], "pivot": [0.0,0.0]}, ...]
}
```

Правило сборки:

1. Для каждой кости: `world = world(родитель) @ R(pivot, угол)`, где `R` — поворот вокруг
   `pivot` (плюс, если нужно, сдвиг/масштаб). Порядок родителей — в `rig.order`.
2. Каждый слой рисуется матрицей своей кости.
3. Наложение — строго по `order` (0 → N-1), обычный alpha-over.
4. Всё уже в пикселях общего холста: никаких дополнительных матриц не нужно.

Это весь контракт. Принимающей системе не нужен наш код: достаточно `layers.json`, `parts/`
и этого правила.

Готовый код — `tools/anim/riglib.py`: `forward(rig, pose)` (кинематика),
`compose(layers, package, transforms, layer_transforms=...)` (сборка), `blink(...)`,
`face_set(...)`/`splice_face(...)` (эмоция).

## Эмоции (измеренные глаза и рот)

Лицо персонажа игра меняет двумя целыми селекторами: `eyes1x`/`eyes2x` (форма глаз) и `mouth`
(форма рта). Слои лица привязаны к голове, поэтому эмоцию можно менять на любом кадре, не
трогая позу, скины и остальные слои.

| персонаж | формы глаз | формы рта | комбинаций |
|---|---:|---:|---:|
| `chubbzee` | 12 | 15 | 180 |
| `soft_helen` | 13 | 14 | 182 |
| `lesnik_tulup_v1`, `maks_kurtka_v1`, `igor_vetrovka_v1` | 12 | 14 | 168 |
| `medsestra_halat_v1`, остальные паки | 13 | 15 | 195 |

Глаза и рот независимы: берётся любой измеренный глаз и любой измеренный рот. Нос, румянец,
брови, кожа и волосы остаются слоями пакета. Значения вне таблицы инструмент отвергает.

**Выбор по картинке.** В каждом пакете лежат две сетки: `faces/preview-eyes.png` (все значения
глаз, рот зафиксирован на базовом) и `faces/preview-mouth.png` (все значения рта). Каждая
плитка — тот же кадр, что отрисует `render_face.py`, с подписью-значением под плиткой.

**Выбор по ситуации.** `faces/situations.json` и раздел «Подбор по ситуации» в
`faces/README.ru.md`: ситуация → пара `eyes`/`mouth`. Это рекомендация (подписи — чтение
сеток), а не измерение; значения в ней проверяются против атласа при сборке README.

**Один кадр с эмоцией:**

```powershell
python character-export\tools\anim\render_face.py `
  --package character-export\anim\chubbzee `
  --eyes 42 --mouth 160 --out character-export\anim\chubbzee\face-sad.png
```

`--eyes` / `--mouth` — значения из таблицы; если задать только одно, второе берётся из
базового кадра пакета. `--blink 0..1` закрывает глаза (0 — открыто, 1 — закрыто),
`--background white` кладёт кадр на белый фон вместо прозрачного.

Моргание работает с любой формой глаз: оно сжимает глазные слои (`eye1`, `eye2`, `pupil`,
`highlight`) по вертикали вокруг измеренного центра глаз, а не подменяет картинку.

У `soft_helen` смена глаз тянет за собой брови и часть румянца (расхождение задевает полосу
y 435..490 и низ лица до y 658) — это измеренное поведение игры, а не дорисовка. У `chubbzee`
смена глаз меняет только полосу глаз.

## Инструменты

Всё в `character-export/tools/anim/`:

| файл | что делает |
|---|---|
| `riglib.py` | библиотека: слои, суставы, прямая кинематика, сборка, моргание, эмоции, сравнение кадров |
| `render_face.py` | **один кадр персонажа с выбранной измеренной эмоцией** — инструмент экспорта |
| `verify_package.py` | независимая проверка пакета: порядок слоёв, наличие файлов, суставы, identity-рендер |
| `build_rig.py` | из прогона с `-PartsCapture` собирает пакет `anim/<slug>/` и сразу проверяет сборку |
| `build_faces.py` | собирает атлас эмоций `faces/` из прогона с `-PartsCapture` и проверяет его сплайсом |
| `make_face_previews.py` | сетки-превью `faces/preview-eyes.png` и `preview-mouth.png` |
| `write_package_readme.py` | пересобирает `README.ru.md` пакета из `layers.json` |
| `write_faces_readme.py` | пересобирает `faces/README.ru.md` из `faces.json` и `faces/situations.json` |
| `test_anim.py` | тесты: порядок слоёв, суставы, кинематика, моргание, атлас, превью, рендер кадра |

Команды:

```powershell
cd "E:\Gacha Nebula Windows 1.7\Gacha Nebula Windows 1.7"

# проверка пакета (ничего не меняет)
python character-export\tools\anim\verify_package.py --package character-export\anim\chubbzee

# один кадр с эмоцией
python character-export\tools\anim\render_face.py --package character-export\anim\chubbzee `
  --eyes 60 --mouth 200 --out character-export\anim\chubbzee\face-love.png

# сетки-превью эмоций в faces/ пакета (--force нужен, только чтобы перезаписать)
python character-export\tools\anim\make_face_previews.py --package character-export\anim\chubbzee

# тесты
cd character-export\tools\anim; python test_anim.py
```

## Проверки

- `verify_package.py`: `"status": "verified"`, 9 проверок у `chubbzee` и `soft_helen`,
  а также у двух новых паков «Три дня до рассвета», включая `identity-render`.
- Атлас эмоций: каждый из 27 измеренных кадров собран заново (слои пакета + лицо кадра) и
  сравнён с кадром прогона. Худшее расхождение — 0.0251% пикселей (alpha-округление);
  подробности в `faces/README.ru.md` пакета.
- `test_anim.py`: 23 теста, все проходят.

## Чего здесь нет (честные пределы)

- **Нет анимации.** Ни циклов, ни физики, ни интерполяции между позами — это работа
  принимающей системы. Здесь персонаж, его суставы и измеренные эмоции.
- **Нет скиннинга.** Каждый слой — жёсткая картинка и вращается целиком; на очень широком
  повороте видно, что бедро и голень — два жёстких куска.
- **Нет отдельной кости носка:** `foot` — это голень + ботинок, сгиба пальцев внутри нет.
- **Один базовый кадр на пакет.** Пакет с другой позой снимается тем же флагом; суставы при
  этом тоже меняются, поэтому смешивать пакеты разных поз нужно осторожно.
- **Персонаж стоит на месте:** тело и тень не переносятся по холсту.

## Как снять пакет для нового персонажа

1. Список кадров (достаточно базовой позы и возврата к ней):

```powershell
# inputs/<Character>.parts.json — {"formatVersion":1,"samples":[{"id":"00-baseline","patch":{}},
#                                                     {"id":"01-restored","patch":{}}]}
```

2. Прогон игры (новое `-Name`, старые каталоги не трогаются):

```powershell
cd character-export\experiments\native-controls
powershell -ExecutionPolicy Bypass -NoProfile -File Run-Native-Controls.ps1 -Name <character>-parts-001 `
  -RecipePath "E:\Gacha Nebula Windows 1.7\Gacha Nebula Windows 1.7\character-export\inputs\<Character>.txt" `
  -DeriveBaseline -UseVerifiedHomeCompatibility `
  -SamplesFile "E:\Gacha Nebula Windows 1.7\Gacha Nebula Windows 1.7\character-export\inputs\<Character>.parts.json" `
  -PartsCapture -TimeoutSeconds 3600
```

Для share-code персонажа добавляется `-RecipeShape share-code` (как у `soft_helen`).

3. Ревьюер, пакет, эмоции, превью, проверка:

```powershell
cd review-tools; python verify_native_controls.py ..\output\<character>-parts-001
cd ..\..\..\..\..
python character-export\tools\anim\build_rig.py --run character-export\experiments\native-controls\output\<character>-parts-001 `
  --sample 00-baseline --out character-export\anim\<slug> --slug <slug>
python character-export\tools\anim\build_faces.py --run character-export\experiments\native-controls\output\<character>-faces-parts-001 `
  --package character-export\anim\<slug>
python character-export\tools\anim\write_package_readme.py --package character-export\anim\<slug>
python character-export\tools\anim\write_faces_readme.py --package character-export\anim\<slug>
python character-export\tools\anim\make_face_previews.py --package character-export\anim\<slug>
```

`build_rig.py` и `build_faces.py` сами завершатся с ошибкой, если слои или лицо не собираются
в измеренный кадр.

## Что стало с ходьбой

Четыре попытки цикла ходьбы (`walk-cycle-002…005`), движок `walkik.py`, старый `render_walk.py`
и рендер по плану кадров (`render_poses.py`) **вынесены** в `character-export/archive-walk/`.
Приёмки они не получили: механика (измеренные суставы, IK на неподвижную стопу) рабочая, но
движение читалось плохо, и задача ушла к другим исполнителям. В пакете и в `anim.zip` их нет.
Архив остаётся рабочим: `archive-walk/tools/test_walk.py` проходит.
