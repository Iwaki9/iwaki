# Пакет персонажа `lesnik_tulup_v1`

Это **собранный персонаж**: слои, которые игра рисует сама, и суставы, которые игра сама
задаёт. Ничего не нарисовано и не додумано — это снимки движка, разложенные по глубине.

## Что внутри

| файл | что это |
|---|---|
| `layers.json` | порядок слоёв, их кость, измеренный сустав, измеренные границы, палитра кадра |
| `parts/NN-имя.png` | сам слой, 1024×1024, общий холст, прозрачный фон |
| `reference.png` | кадр, из которого всё снято (эталон сборки) |
| `README.ru.md` | этот файл |
| `faces/` | измеренные эмоции: 12 форм глаз × 14 форм рта = 168 |

Холст общий: `gameToCanvas` = `{"c": 0, "a": 2.5876010781671157, "b": 0, "ty": -191.50404312668456, "d": 2.5876010781671157, "tx": -280.4528301886792}`. Слои **уже** в пикселях холста, складывать их
нужно просто по порядку `order` (по возрастанию), без матриц.

Проверка сборки: если сложить все слои без единого преобразования, получается
`reference.png`. Замер: расходится 243 пикселей из 1048576 (>1.0% канала) —
это ошибка alpha-наложения, а не геометрии.

## Суставы

`pivot` — это origin игрового узла, переведённый в пиксели холста. Не оценка: игра
ставит конечность именно вокруг этой точки.

| кость | родитель | узел игры | сустав (x, y) |
|---|---|---|---|
| `ground` | — | `static ground plane; never transformed, so the cast shadow stays put` | 0.0, 0.0 |
| `root` | — | `silhouette bottom centre of the measured reference frame` | 508.5, 936.0 |
| `hips` | `root` | `midpoint(thigh, backthigh)` | 516.9, 664.0 |
| `torso` | `hips` | `body` | 513.9, 491.6 |
| `head` | `torso` | `head` | 502.9, 392.0 |
| `armUpperFront` | `torso` | `shoulder` | 439.5, 473.5 |
| `armLowerFront` | `armUpperFront` | `handx` | 398.8, 582.8 |
| `armUpperBack` | `torso` | `backshoulder` | 561.8, 475.4 |
| `armLowerBack` | `armUpperBack` | `backhand` | 604.5, 577.0 |
| `legUpperFront` | `hips` | `thigh` | 472.5, 670.2 |
| `legLowerFront` | `legUpperFront` | `foot` | 463.5, 815.7 |
| `legUpperBack` | `hips` | `backthigh` | 561.2, 657.9 |
| `legLowerBack` | `legUpperBack` | `backfoot` | 572.2, 808.0 |

`hips` — середина двух измеренных тазобедренных суставов, `root` — низ силуэта
эталонного кадра (центр по x), `ground` — статичная плоскость (тень не двигается).

## Слои

| # | слой | кость | цепочка узлов | пиксели (x0,y0,x1,y1) |
|---|---|---|---|---|
| 0 | `shadow` | `ground` | `shadow/shadow` | 400, 888, 643, 931 |
| 1 | `skinc` | `armUpperBack` | `backshoulder/skinc` | 524, 406, 603, 548 |
| 2 | `sleeves` | `armUpperBack` | `backshoulder/sleeves` | 521, 404, 593, 549 |
| 3 | `handx-channels-000` | `armLowerBack` | `backhand/handx/c1` | 555, 503, 661, 680 |
| 4 | `sleeves` | `armLowerBack` | `backhand/handx/sleevewrist/sleeves` | 543, 501, 643, 621 |
| 5 | `skinc` | `legUpperBack` | `backthigh/skinc` | 514, 567, 604, 768 |
| 6 | `socks` | `legUpperBack` | `backthigh/socks` | — |
| 7 | `pants` | `legUpperBack` | `backthigh/pants` | 511, 564, 608, 773 |
| 8 | `skinc` | `legLowerBack` | `backfoot/skinc` | 520, 716, 619, 913 |
| 9 | `socks` | `legLowerBack` | `backfoot/socks` | 532, 828, 624, 916 |
| 10 | `pants` | `legLowerBack` | `backfoot/pants` | 505, 713, 641, 908 |
| 11 | `shoe` | `legLowerBack` | `backfoot/shoe` | 487, 765, 657, 928 |
| 12 | `skinc` | `torso` | `body/skinc` | 437, 343, 596, 640 |
| 13 | `pants` | `torso` | `body/pants` | 434, 575, 598, 644 |
| 14 | `shirt` | `torso` | `body/shirt` | 434, 385, 597, 600 |
| 15 | `skinc` | `legUpperFront` | `thigh/skinc` | 422, 575, 516, 780 |
| 16 | `socks` | `legUpperFront` | `thigh/socks` | — |
| 17 | `pants` | `legUpperFront` | `thigh/pants` | 419, 572, 520, 784 |
| 18 | `skinc` | `legLowerFront` | `foot/skinc` | 415, 724, 510, 921 |
| 19 | `socks` | `legLowerFront` | `foot/socks` | 418, 836, 502, 923 |
| 20 | `pants` | `legLowerFront` | `foot/pants` | 384, 721, 522, 915 |
| 21 | `shoe` | `legLowerFront` | `foot/shoe` | 378, 773, 537, 936 |
| 22 | `belt2` | `torso` | `belt/belt2` | 430, 572, 599, 636 |
| 23 | `shirt` | `torso` | `belt/shirt` | 423, 532, 609, 629 |
| 24 | `jacket1` | `torso` | `belt/jacket1` | — |
| 25 | `jacket` | `torso` | `belt/jacket` | 335, 376, 682, 808 |
| 26 | `skinc` | `armUpperFront` | `shoulder/skinc` | 400, 403, 477, 547 |
| 27 | `sleeves` | `armUpperFront` | `shoulder/sleeves` | 412, 397, 483, 544 |
| 28 | `handx-channels-000` | `armLowerFront` | `handx/handx/c1` | 340, 506, 448, 680 |
| 29 | `wrist` | `armLowerFront` | `handx/handx/sleevewrist/wrist` | 356, 585, 412, 611 |
| 30 | `sleeves` | `armLowerFront` | `handx/handx/sleevewrist/sleeves` | 359, 503, 459, 624 |
| 31 | `scarf1` | `torso` | `scarf/scarf1` | 453, 392, 586, 548 |
| 32 | `skinc` | `head` | `head/head/skinc` | 390, 135, 618, 387 |
| 33 | `blush` | `head` | `head/head/blush` | 462, 320, 598, 332 |
| 34 | `mouth` | `head` | `head/head/mouth` | 510, 365, 543, 374 |
| 35 | `eye2-channels-000` | `head` | `head/head/eye2/eye2/c4` | 560, 296, 609, 322 |
| 36 | `pupil` | `head` | `head/head/eye2/eye2/pupil/pupil` | 572, 297, 582, 317 |
| 37 | `eye2-channels-005` | `head` | `head/head/eye2/eye2/c3` | 554, 286, 620, 310 |
| 38 | `highlight2` | `head` | `head/head/eye2/highlight2` | 577, 300, 581, 304 |
| 39 | `nose` | `head` | `head/head/nose` | 541, 323, 567, 341 |
| 40 | `eye1-channels-000` | `head` | `head/head/eye1/eye1/c4` | 452, 296, 521, 322 |
| 41 | `pupil` | `head` | `head/head/eye1/eye1/pupil/pupil` | 490, 297, 505, 317 |
| 42 | `eye1-channels-005` | `head` | `head/head/eye1/eye1/c3` | 437, 286, 530, 310 |
| 43 | `highlight1` | `head` | `head/head/eye1/highlight1` | 490, 300, 495, 304 |
| 44 | `rearhair` | `head` | `head/head/rearhair` | 341, 123, 665, 334 |
| 45 | `accessory1` | `head` | `head/head/accessory1` | 429, 246, 608, 362 |
| 46 | `glasses` | `head` | `head/head/glasses` | 429, 180, 623, 283 |
| 47 | `fronthair` | `head` | `head/head/fronthair/fronthair/fronthair` | 406, 83, 653, 362 |
| 48 | `eyebrow1` | `head` | `head/head/eyebrow1/eyebrow1` | 442, 241, 522, 279 |
| 49 | `eyebrow2` | `head` | `head/head/eyebrow2/eyebrow2` | 558, 242, 610, 278 |
| 50 | `ahoge` | `head` | `head/head/ahoge/ahoge` | 465, 108, 485, 133 |
| 51 | `acc5` | `head` | `head/head/acc5` | 402, 338, 622, 506 |
| 52 | `glasses2` | `head` | `head/head/glasses2` | 431, 180, 621, 283 |

Пустые слои (`—` в границах) — измеренные пустые группы глубины, это не ошибка.

## Как собрать кадр

Матрица кости = произведение по цепочке родителей: `world(кость) = world(родитель) @ R(сустав, угол)`.
Слой рисуется своей `world`-матрицей, слои накладываются по `order`.

Готовый код: `character-export/tools/anim/riglib.py`
(`forward()` — прямая кинематика, `compose()` — сборка, `blink()` — моргание,
`face_set()`/`splice_face()` — измеренная эмоция).

## Эмоции

`faces/` — измеренные формы глаз и рта из игры, независимые друг от друга:
12 значений глаз (`eyes1x`/`eyes2x`) и 14 значений рта (`mouth`), всего комбинаций: 168.
Один кадр с выбранным выражением:

```powershell
python character-export\tools\anim\render_face.py --package character-export\anim\lesnik_tulup_v1 `
  --eyes <значение> --mouth <значение> --out face.png
```

Своими руками это `face_set()` + `splice_face()` + `compose()` из `riglib.py`.
Таблицы значений, превью-сетки и подбор по ситуации — `faces/README.ru.md`.

## Чего здесь нет

- Нет синтетической деформации кожи: каждый слой — жёсткая картинка, вращается целиком.
  Поэтому на широком повороте видно стык у сустава — это предел жёстких слоёв, а не баг.
- Нет сустава стопы: `foot` — это голень + ботинок, вращается вокруг колена.
- **Нет анимации.** Пакет — это кукла, её слои и измеренные суставы; циклы, физика,
  интерполяция и монтаж остаются принимающей системе. Здесь только персонаж и его
  измеренные эмоции.

## Откуда снято

- прогон: `E:\Gacha Nebula Windows 1.7\Gacha Nebula Windows 1.7\character-export\experiments\native-controls\output\lesnik_tulup_v1-parts-002`
- сэмпл: `00-baseline`
- форма рецепта: `paste`
- рецепт: `E:\Gacha Nebula Windows 1.7\Gacha Nebula Windows 1.7\character-export\inputs\lesnik_v3d_beard.txt`
- sha256 рецепта: `1ef2c01ff516cfc6635b7dc6b5a8c914835ff27a2278be665cade86d10e8d3f8`
- селекторы кадра: `{"mouth1": {"value": 331, "type": "number"}, "eyes2x1": {"value": 134, "type": "number"}, "pose1": {"value": 1, "type": "number"}, "eyes1x1": {"value": 134, "type": "number"}, "facepreset1": {"value": 1, "type": "number"}}`


## Происхождение и соответствие плану (сеанс «Три дня до рассвета»)

**Имя пакета взято из `план.md` / `раскадровка.md`, содержимое — не v1.** Снято с
финального рецепта `character-export/characters/lesnik_v3d_beard/code.txt`
(1113 полей, 4053 байта, sha256
`1ef2c01ff516cfc6635b7dc6b5a8c914835ff27a2278be665cade86d10e8d3f8`), а не с
первого `lesnik_tulup_v1` в коротком жилете/фартуке. Имя сохранено, чтобы
раскадровка (`Л — лесник (lesnik_tulup_v1)`) находила пак без правок.

- **`acc5ypos=15` — обязательное поле.** Слой бороды `acc5` рисуется на глубине 51,
  ПОСЛЕ рта (глубина 34). Без сдвига 13 из 14 форм рта попиксельно совпадают с
  базовым кадром, и первый прогон `lesnik_tulup_v1-faces-parts-002` был забракован
  ревьюером: `frame is pixel-identical to baseline`. Пробами `acc5ypos` найден
  минимальный сдвиг 15: все 14 ртов видны, борода остаётся большой седой. При
  20–25 борода превращается в козлиную бородку/воротник, при ≥30 старик перестаёт
  читаться. В словаре каталога это named-образец `сдвиг_бороды: рот_открыт`.
- Лицо: архетип `surovyi-starik`, но `pupil1x/pupil2x` переопределены обратно на
  `101`: штатный `pupil=160` архетипа красит «выцветшие светлые глаза» из истории
  в янтарь. Базовый кадр: `pose=1`, `eyes1x=eyes2x=134`, `mouth=331`.
- Одежда: `shirtex=117` (длинное тёмное пальто), `acc5x=38` (лохматая седая
  борода), `glasses/glasses2x=47` (круглые тёмные очки), `sleeves1x/2x=94`,
  `scarf1x=88`, `belt2x=34`. Очки подняты на лоб строковыми смещениями
  `glassesypos="-30"` и `glasses2ypos="-30"`.
- Чего нет: настоящего мехового воротника/опушки, пояса поверх длинного пальто
  (его перекрывает `shirtex=117`) и ножен с ножом. Это предел измеренных ассетов,
  а не недосмотр сборки.

По `план.md` это главный второй герой: 20 планов, около 2,5 минут в кадре.
Атлас эмоций: `faces/` — 12 глаз × 14 ртов = 168 комбинаций,
`faces/situations.json` содержит 8 ситуаций. Проверка `verify_package.py`:
`verified`, 9/9; нативные прогоны `lesnik_tulup_v1-parts-002` (41 проверка) и
`lesnik_tulup_v1-faces-parts-003` (281 проверка) — PASS.
