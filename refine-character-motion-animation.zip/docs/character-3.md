# Character 3

The third preset uses the existing Animator and modes without altering the
first two characters. Its artwork has no black outline, bare elbows, patterned
socks, a separate ponytail and two jacket panels.

## Calibration

- Assembled reference: `https://github.com/Iwaki9/iwaki/blob/master/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA%20%D1%8D%D0%BA%D1%80%D0%B0%D0%BD%D0%B0%202026-10-28%20205131.png`
- Parts sheet: `https://github.com/Iwaki9/iwaki/blob/master/%D0%A1%D0%BD%D0%B8%D0%BC%D0%BE%D0%BA%20%D1%8D%D0%BA%D1%80%D0%B0%D0%BD%D0%B0%202026-10-28%20205204.png`
- Source sheet: 1704 x 975; reference: 717 x 813.
- `src/rig/char3Images.ts` contains extracted, alpha-cleaned PNG sprites. The
  jacket panels are composited with their reference spacing, not sheet spacing.
- `src/rig/char3Data.ts` contains independently registered sprite geometry and
  joint pivots. Reference coordinates are translated by (40, 37) into rig space
  to align the soles with the existing ground plane. Sprite aspect ratios are
  preserved; no first-character recoloring or replacement art is used.
- Geometry and joints are selected by character in `src/rig/rigData.ts` and
  `src/rig/kinematics.ts`.

## Joint Materials

`src/components/MaterialLimb.tsx` rounds only the overlapping cut of the lower
segment. It does not paint a long solid bridge over the stripes or add a black
outline to the skin. The original sprites are unchanged in the zero pose.
SVG clip IDs are instance-local. Existing outlined limbs keep their previous
rendering path, masks, colors and calibration.

The calibration controls affect only the selected character. For the third
preset, the elbow color is skin (#FFE2D4), and the knee connector is white
(#FFFFFF). The hood option is not applicable. The reference-pose button freezes
the rig at all-zero angles without changing the animation clips.

This is a reusable two-segment cutout rig, not automatic retargeting of arbitrary
art. Different proportions require per-character pivots and geometry; patterned
clothes require texture-preserving joints rather than flat-color seam patches.

## Verification

Run `node scripts/check-rig.mjs`, `npx tsc --noEmit`, and `npm run build`.
The regression check includes the original two characters' sampled matrices and
asset hashes, all three characters' finite transforms, shared-pivot continuity,
and valid embedded PNGs. Browser checks cover the reference pose, mode and
character switching, wave variants, calibration reset and close-up views.