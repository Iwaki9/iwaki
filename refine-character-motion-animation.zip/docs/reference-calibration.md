# Reference-Guided Assembly

## What Changed

Previously, the application only consumed pre-calibrated sprite rectangles and
joint positions. The character-3 preparation scripts were one-off tools, not an
automatic assembly algorithm available to the user.

The application now has a reference editor and a reproducible registration CLI.
These are geometric tools; neither calls a neural-network API nor guarantees
perfect assembly of arbitrary generated artwork.

## Editor

Open the assembly editor, choose a part, and drag it over the reference. Position,
size, aspect lock and rotation are editable numerically. The reference has its
own transform, opacity and upload control. Transparent PNGs work best.

- Overlay, difference, reference-only and assembly-only views.
- Separate draggable joints and numeric joint coordinates.
- Undo/redo, per-item reset and full preset reset.
- Local draft saving, explicit application to animation, and JSON import/export.
- Per-part PNG/JPEG/WebP replacement without changing the bundled artwork.
- The same Animator previews walking, running, idle and waving.

The local fit button searches only near the selected part: up to 12 rig pixels,
4 degrees and 5 percent uniform scale. It accepts only lower image-loss results.
It does not identify body parts, infer hidden shapes, or reposition joints.
Cancel leaves the document unchanged. Rest-position metrics do not certify that
the character will bend correctly.

The silhouette value is foreground-mask intersection over union. Color error
is mean absolute premultiplied RGB difference over the foreground union, on a
half-resolution canvas. Opaque backgrounds, overlapping limbs and different
artwork can make these metrics misleading. A high silhouette overlap is not an
anatomical quality score.

## Reproducible CLI

Install the image-processing dependencies in your Python environment:

```sh
python -m pip install -r scripts/calibration-requirements.txt
python scripts/calibrate-character.py \
  --manifest scripts/character-4.json \
  --sheet /path/to/213235.png \
  --reference /path/to/213316.png \
  --out /path/to/output \
  --passes 2
```

The fourth source pair is supplied by Iwaki9 in the iwaki repository:
- Sheet filename: screenshot dated 2026-10-28, 213235.png (1081 x 959).
- Assembled reference: screenshot dated 2026-10-28, 213316.png (658 x 792).

The manifest explicitly labels crop rectangles, approximate positions, draw
order and joint anchors. Those inputs still need a human or a separate detector.
The tool extracts the green-screen parts, decontaminates edges, then optimizes
translation, rotation and uniform scale against the complete, occluded assembly.
It keeps a previous solution if an optimization stage makes the loss worse.

Output includes transparent parts, an assembled preview, an aligned reference,
an error report, and an editor-compatible `calibration.json` containing embedded
artwork and joints. Choose the matching character slot before importing JSON.
The green-screen extraction assumes the supplied green background; green
foregrounds too close to that color cannot be recovered reliably.

## Limits

Matching a static reference does not determine every joint or hidden surface.
Parts generated independently may differ in shape, perspective, texture or
proportion. A similarity transform cannot repair a different face or invent a
missing elbow. Those cases need corrected source art, masks, or mesh deformation.

For consistent results, generate one assembled source, derive the cutouts from
it, provide overlap around joints, and keep accessories on appropriate bones.
The current rig has fixed humanoid slots and front/back relationships. This is
not a general mesh editor or an automatic anatomical detector. Large edits to
the older outlined presets may also require adapting their existing seam masks.

The original four built-in presets are not mutated. Applying changes stores a
separate per-character calibration; resetting restores the built-in geometry.

## Checks

```sh
node scripts/check-rig.mjs
npx tsc --noEmit
npm run build
```

The browser suite uses Playwright (install it and its Chromium browser in your
test environment). With a Vite server running, use:

```sh
PLAYWRIGHT_MODULE=/path/to/playwright/index.mjs \
CALIBRATION_FILE=/path/to/output/calibration.json \
node scripts/check-editor.mjs
```

`PLAYWRIGHT_MODULE` is optional if `playwright` is installed locally.
`CALIBRATION_FILE` additionally checks importing the CLI output. `BASE_URL`
defaults to `http://localhost:5173` and may point to the production preview.
The suite deliberately misplaces the head, verifies that fitting improves the
image comparison, and checks dragging, undo/redo, joints, image replacement,
JSON validation, persistence, cancellation and mobile layout.