import { CHARACTER_IMAGES } from './characterAssets';
import { CHARACTER_REFERENCES } from './referenceImages';
import { CHAR2_HOOD_IMAGES } from './char2Images';
import { CHAR2_HOOD_GEOM, PART_ORDER, VIEW, type PartGeom, type PartKey } from './rigData';
import type { CalibrationDocument } from './calibration';

const imageCache = new Map<string, Promise<HTMLImageElement>>();
export function loadImage(src: string): Promise<HTMLImageElement> {
  let result = imageCache.get(src);
  if (!result) {
    result = new Promise((resolve, reject) => {
      const im = new Image();
      im.onload = () => resolve(im);
      im.onerror = () => { imageCache.delete(src); reject(new Error('Не удалось прочитать изображение.')); };
      im.src = src;
    });
    if (imageCache.size > 96) imageCache.delete(imageCache.keys().next().value!);
    imageCache.set(src, result);
  }
  return result;
}

export interface DrawItem { key: string; source: string; geometry: PartGeom; part?: PartKey; }
export function drawItems(doc: CalibrationDocument): DrawItem[] {
  const sources = { ...CHARACTER_IMAGES[doc.character], ...doc.rig.images };
  const items: DrawItem[] = PART_ORDER
    .filter(part => doc.rig.geometry[part].w > 1 || doc.rig.geometry[part].h > 1 || doc.rig.images?.[part])
    .map(part => ({ key: part, part, source: sources[part], geometry: doc.rig.geometry[part] }));
  if (doc.character === 'char2') {
    items.splice(items.findIndex(i => i.part === 'torso'), 0, { key: 'hoodR', source: CHAR2_HOOD_IMAGES.hoodR, geometry: CHAR2_HOOD_GEOM.hoodR });
    items.splice(items.findIndex(i => i.part === 'head'), 0, { key: 'hoodL', source: CHAR2_HOOD_IMAGES.hoodL, geometry: CHAR2_HOOD_GEOM.hoodL });
  }
  return items;
}

function draw(ctx: CanvasRenderingContext2D, im: HTMLImageElement, g: PartGeom) {
  ctx.save(); ctx.translate(g.cx, g.cy); ctx.rotate(g.rot * Math.PI / 180);
  ctx.drawImage(im, -g.w/2, -g.h/2, g.w, g.h); ctx.restore();
}

async function prepare(doc: CalibrationDocument) {
  const items = drawItems(doc);
  const images = await Promise.all(items.map(i => loadImage(i.source)));
  const reference = await loadImage(doc.reference.source ?? CHARACTER_REFERENCES[doc.character]);
  const canvas = document.createElement('canvas');
  canvas.width = VIEW.w / 2; canvas.height = VIEW.h / 2;
  const ctx = canvas.getContext('2d', { willReadFrequently: true })!;
  const reset = () => {
    ctx.setTransform(1,0,0,1,0,0); ctx.clearRect(0,0,canvas.width,canvas.height);
    ctx.setTransform(.5,0,0,.5,-VIEW.x/2,-VIEW.y/2);
  };
  reset(); draw(ctx, reference, doc.reference.geometry);
  const target = ctx.getImageData(0,0,canvas.width,canvas.height).data;
  const render = (part?: PartKey, geometry?: PartGeom) => {
    reset();
    items.forEach((item, i) => draw(ctx, images[i], item.part === part && geometry ? geometry : item.geometry));
    return ctx.getImageData(0,0,canvas.width,canvas.height).data;
  };
  return { target, render };
}

function compare(a: Uint8ClampedArray, b: Uint8ClampedArray) {
  let intersection = 0, union = 0, error = 0, loss = 0, count = 0;
  for (let i=0;i<a.length;i+=4) {
    const aa = a[i+3]/255, ba = b[i+3]/255;
    if (aa > .2 || ba > .2) {
      union++; if (aa > .2 && ba > .2) intersection++;
      for (let c=0;c<3;c++) {
        const delta = a[i+c]*aa-b[i+c]*ba;
        error += Math.abs(delta); loss += delta*delta; count++;
      }
      loss += (aa-ba)**2 * 255**2;
    }
  }
  return { silhouette: union ? intersection/union*100 : 0, colorError: count ? error/count : 0,
    loss: loss/(a.length/4), pixels: union };
}

export async function measureAssembly(doc: CalibrationDocument) {
  const { target, render } = await prepare(doc);
  return compare(target, render());
}

// Bounded local refinement of one labelled, approximately placed part. Not an anatomical solver.
export async function fitPart(doc: CalibrationDocument, part: PartKey, signal: AbortSignal, progress: (n: number) => void) {
  const { target, render } = await prepare(doc);
  const initial = doc.rig.geometry[part];
  let best = { ...initial }, score = compare(target, render(part, best)).loss;
  const before = score;
  let evaluations = 0;
  for (const step of [4, 2, 1, .5]) {
    for (let pass=0;pass<2;pass++) {
      for (const field of ['cx', 'cy', 'rot', 'scale'] as const) {
        for (const direction of [-1,1]) {
          if (signal.aborted) throw new DOMException('Отменено', 'AbortError');
          const g = { ...best };
          if (field === 'scale') {
            const factor = 1 + direction*step*.003;
            g.w *= factor; g.h *= factor;
          } else g[field] += direction * step * (field === 'rot' ? .35 : 1);
          if (Math.abs(g.cx-initial.cx)>12 || Math.abs(g.cy-initial.cy)>12 || Math.abs(g.rot-initial.rot)>4 || g.w/initial.w<.95 || g.w/initial.w>1.05) continue;
          const candidate = compare(target, render(part, g)).loss;
          if (candidate < score - .00001) { best = g; score = candidate; }
          evaluations++;
        }
        progress(Math.min(99, evaluations/64*100));
        await new Promise<void>(resolve => requestAnimationFrame(() => resolve()));
      }
    }
  }
  return { geometry: best, before, after: score };
}