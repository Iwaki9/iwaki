import { CHARACTER_GEOMETRY, CHARACTER_JOINTS, PART_ORDER, VIEW,
  type CharacterId, type JointKey, type PartGeom, type RigCalibration } from './rigData';

export interface CalibrationDocument {
  version: 1;
  character: CharacterId;
  rig: RigCalibration;
  reference: { source?: string; geometry: PartGeom };
}

export const PART_LABELS: Record<(typeof PART_ORDER)[number], string> = {
  head: 'Голова', tuft: 'Хвост / задние волосы', torso: 'Торс', hem: 'Подол',
  upperArmL: 'Ближнее плечо', foreArmL: 'Ближнее предплечье',
  upperArmR: 'Дальнее плечо', foreArmR: 'Дальнее предплечье',
  thighL: 'Ближнее бедро', shinL: 'Ближняя голень', thighR: 'Дальнее бедро', shinR: 'Дальняя голень',
};
export const JOINT_LABELS: Record<JointKey, string> = {
  shoulderL: 'Ближнее плечо', elbowL: 'Ближний локоть', hipL: 'Ближний тазобедренный', kneeL: 'Ближнее колено',
  shoulderR: 'Дальнее плечо', elbowR: 'Дальний локоть', hipR: 'Дальний тазобедренный', kneeR: 'Дальнее колено',
  neck: 'Шея', waist: 'Пояс', tuft: 'Крепление хвоста',
};

export function createCalibration(character: CharacterId): CalibrationDocument {
  return {
    version: 1, character,
    rig: {
      geometry: structuredClone(CHARACTER_GEOMETRY[character]),
      joints: structuredClone(CHARACTER_JOINTS[character]),
    },
    reference: { geometry: { cx: VIEW.x + VIEW.w / 2, cy: VIEW.y + VIEW.h / 2, w: VIEW.w, h: VIEW.h, rot: 0 } },
  };
}

function record(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('Ожидался объект JSON.');
  return value as Record<string, unknown>;
}
function num(v: unknown, min: number, max: number): number {
  if (typeof v !== 'number' || !Number.isFinite(v) || v < min || v > max) throw new Error('Некорректное значение координаты или размера.');
  return v;
}
function geom(v: unknown): PartGeom {
  const g = record(v);
  return { cx: num(g.cx, -2000, 4000), cy: num(g.cy, -2000, 4000),
    w: num(g.w, .1, 2500), h: num(g.h, .1, 2500), rot: num(g.rot, -360, 360) };
}
function image(v: unknown): string {
  if (typeof v !== 'string' || v.length > 3_000_000 || !/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(v)) {
    throw new Error('Поддерживаются только встроенные PNG, JPEG или WebP.');
  }
  return v;
}

export function parseCalibration(value: unknown, character?: CharacterId): CalibrationDocument {
  const o = record(value);
  if (o.version !== 1 || !['char1', 'char2', 'char3', 'char4'].includes(String(o.character))) throw new Error('Неизвестный формат калибровки.');
  if (character && o.character !== character) throw new Error('Этот JSON относится к другому персонажу. Сначала выберите его.');
  const result = createCalibration(o.character as CharacterId);
  const rig = record(o.rig), geometry = record(rig.geometry), joints = record(rig.joints);
  if (Object.keys(geometry).some(key => !PART_ORDER.includes(key as (typeof PART_ORDER)[number]))) {
    throw new Error('В JSON есть дополнительные детали. Этот риг поддерживает только существующие слоты.');
  }
  if (Object.keys(joints).some(key => !Object.keys(JOINT_LABELS).includes(key))) throw new Error('Дополнительные суставы пока не поддерживаются.');
  for (const key of PART_ORDER) result.rig.geometry[key] = geom(geometry[key]);
  for (const key of Object.keys(JOINT_LABELS) as JointKey[]) {
    const p = record(joints[key]);
    result.rig.joints[key] = { x: num(p.x, -2000, 4000), y: num(p.y, -2000, 4000) };
  }
  if (rig.images) {
    const sources = record(rig.images);
    if (Object.keys(sources).some(key => !PART_ORDER.includes(key as (typeof PART_ORDER)[number]))) throw new Error('Неизвестный слот изображения.');
    result.rig.images = {};
    for (const key of PART_ORDER) if (sources[key] !== undefined) result.rig.images[key] = image(sources[key]);
  }
  if (o.reference) {
    const reference = record(o.reference);
    result.reference.geometry = geom(reference.geometry);
    if (reference.source !== undefined) result.reference.source = image(reference.source);
  }
  return result;
}

export function readCalibration(character: CharacterId, applied = false): CalibrationDocument | undefined {
  try {
    const raw = localStorage.getItem(`motion-rig.v1.${applied ? 'applied' : 'draft'}.${character}`);
    return raw ? parseCalibration(JSON.parse(raw), character) : undefined;
  } catch { return undefined; }
}

export function saveCalibration(doc: CalibrationDocument, applied = false): boolean {
  try {
    localStorage.setItem(`motion-rig.v1.${applied ? 'applied' : 'draft'}.${doc.character}`, JSON.stringify(doc));
    return true;
  } catch { return false; }
}