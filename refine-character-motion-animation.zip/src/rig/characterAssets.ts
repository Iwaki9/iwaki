import { PART_IMAGES } from './partImages';
import { CHAR2_PART_IMAGES } from './char2Images';
import { CHAR3_PART_IMAGES } from './char3Images';
import { CHAR4_PART_IMAGES } from './char4Images';
import type { CharacterId, PartKey } from './rigData';

export const CHARACTER_IMAGES: Record<CharacterId, Record<PartKey, string>> = {
  char1: PART_IMAGES,
  char2: CHAR2_PART_IMAGES,
  char3: CHAR3_PART_IMAGES,
  char4: CHAR4_PART_IMAGES,
};