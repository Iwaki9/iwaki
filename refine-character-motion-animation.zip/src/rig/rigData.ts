// AUTO-GENERATED & CALIBRATED geometry. All numbers are in the coordinate space
// of the reference picture where the character is shown whole (rest pose).
import { CHAR3_GEOM, CHAR3_JOINTS } from './char3Data';
import { CHAR4_GEOM, CHAR4_JOINTS } from './char4Data';

export type PartKey =
  | 'tuft'
  | 'thighL'
  | 'thighR'
  | 'shinL'
  | 'shinR'
  | 'upperArmR'
  | 'foreArmR'
  | 'torso'
  | 'hem'
  | 'upperArmL'
  | 'foreArmL'
  | 'head';

export type CharacterId = 'char1' | 'char2' | 'char3' | 'char4';

// Back-to-front drawing order. The back arm (upperArmR/foreArmR) sits behind
// the legs so it tucks cleanly behind the left leg during walking and running,
// while the viewer-left leg stays in front of the viewer-right leg.
export const PART_ORDER: PartKey[] = [
  'tuft',
  'upperArmR',
  'foreArmR',
  'thighR',
  'shinR',
  'thighL',
  'shinL',
  'torso',
  'hem',
  'upperArmL',
  'foreArmL',
  'head',
];

export interface PartGeom {
  w: number;
  h: number;
  cx: number;
  cy: number;
  rot: number;
}

// Character 1 (Green sweater, ponytail) geometry
export const GEOM: Record<PartKey, PartGeom> = {
  tuft: { w: 125, h: 146, cx: 243.0, cy: 236.5, rot: -0.0 },
  thighL: { w: 60, h: 123, cx: 346.0, cy: 620.5, rot: 0.5 },
  thighR: { w: 58, h: 121, cx: 401.0, cy: 608.5, rot: -0.0 },
  shinL: { w: 62, h: 121, cx: 342.5, cy: 696.5, rot: -0.0 },
  shinR: { w: 65, h: 119, cx: 406.5, cy: 691.5, rot: -0.0 },
  upperArmR: { w: 56, h: 88, cx: 404.5, cy: 505.5, rot: 6.0 },
  foreArmR: { w: 61, h: 92, cx: 426.5, cy: 554.5, rot: 0.5 },
  torso: { w: 102, h: 173, cx: 375.0, cy: 505.5, rot: -0.0 },
  hem: { w: 114, h: 61, cx: 373.0, cy: 566.5, rot: -0.0 },
  upperArmL: { w: 55, h: 89, cx: 329.0, cy: 494.5, rot: -0.0 },
  foreArmL: { w: 60, h: 93, cx: 306.0, cy: 556.5, rot: -0.0 },
  head: { w: 310, h: 292, cx: 355.0, cy: 324.0, rot: -0.0 },
};

// Character 2 (Grey open hoodie, short brown hair) geometry
export const CHAR2_GEOM: Record<PartKey, PartGeom> = {
  tuft: { w: 1, h: 1, cx: 243.0, cy: 236.5, rot: -0.0 },
  thighL: { w: 60, h: 123, cx: 346.0, cy: 620.5, rot: 0.5 },
  thighR: { w: 58, h: 121, cx: 401.0, cy: 608.5, rot: -0.0 },
  shinL: { w: 62, h: 121.85, cx: 342.5, cy: 696.93, rot: -0.0 },
  shinR: { w: 68.38, h: 120.68, cx: 408.19, cy: 692.34, rot: -0.0 },
  upperArmR: { w: 56, h: 88, cx: 404.5, cy: 505.5, rot: 6.0 },
  foreArmR: { w: 61, h: 94.49, cx: 426.5, cy: 555.74, rot: 0.5 },
  torso: { w: 102, h: 173, cx: 375.0, cy: 505.5, rot: -0.0 },
  hem: { w: 114, h: 61, cx: 373.0, cy: 566.5, rot: -0.0 },
  upperArmL: { w: 55, h: 89, cx: 329.0, cy: 494.5, rot: -0.0 },
  foreArmL: { w: 60, h: 93, cx: 306.0, cy: 556.5, rot: -0.0 },
  head: { w: 312.53, h: 262.38, cx: 357.95, cy: 323.58, rot: -0.0 },
};

// Separated hood crescents for Character 2 (in world rest-pose coordinates)
export const CHAR2_HOOD_GEOM = {
  hoodL: { w: 67.03, h: 95.85, cx: 335.88, cy: 491.08, rot: -0.0 },
  hoodR: { w: 68.06, h: 95.69, cx: 398.02, cy: 500.96, rot: 6.0 },
} as const;

export const CHARACTER_GEOMETRY: Record<CharacterId, Record<PartKey, PartGeom>> = {
  char1: GEOM,
  char2: CHAR2_GEOM,
  char3: CHAR3_GEOM,
  char4: CHAR4_GEOM,
};

export interface Pt {
  x: number;
  y: number;
}

// Joint pivots in rest-pose coordinates.
export const JOINTS = {
  shoulderL: { x: 341.1, y: 462.9 },
  elbowL: { x: 318.2, y: 522.4 },
  hipL: { x: 337.5, y: 575.6 },
  kneeL: { x: 343.2, y: 655.0 },
  shoulderR: { x: 394.1, y: 471.8 },
  elbowR: { x: 414.4, y: 529.2 },
  hipR: { x: 391.5, y: 564.4 },
  kneeR: { x: 402.0, y: 643.5 },
  neck: { x: 366.3, y: 433.6 },
  waist: { x: 372.5, y: 544.0 },
  tuft: { x: 276.7, y: 282.9 },
} as const;

export const CHARACTER_JOINTS: Record<CharacterId, Record<keyof typeof JOINTS, Pt>> = {
  char1: JOINTS,
  char2: JOINTS,
  char3: CHAR3_JOINTS,
  char4: CHAR4_JOINTS,
};

export type JointKey = keyof typeof JOINTS;
export interface RigCalibration {
  geometry: Record<PartKey, PartGeom>;
  joints: Record<JointKey, Pt>;
  images?: Partial<Record<PartKey, string>>;
}

export interface RigTuning {
  /** Interior color of the sleeve used to mask the black outline inside the elbow */
  sleeveColor: string;
  /** Interior color of the pants used to mask the black outline inside the knee */
  pantsColor: string;
  /** Lock hood/shoulder pads to torso instead of rotating with upper arms */
  lockHoodToTorso: boolean;
  /** Split torso pelvis behind thighs so open jacket hems don't show a pelvis seam over legs */
  splitPelvisLayer: boolean;
  /** Multiplier for the interior joint bridge width (0 = off / raw outlines, 1 = calibrated) */
  jointBridgeScale: number;
  /** Fine-tuning offset for front elbow pivot (px) */
  elbowOffsetX: number;
  elbowOffsetY: number;
  /** Fine-tuning offset for knee pivots (px) */
  kneeOffsetX: number;
  kneeOffsetY: number;
  /** Vertical adjustment for head placement on neck (px) */
  headOffsetY: number;
  /** Vertical adjustment for jacket/sweater hem (px) */
  hemOffsetY: number;
}

export const DEFAULT_TUNING: Record<CharacterId, RigTuning> = {
  char1: {
    sleeveColor: '#006B37',
    pantsColor: '#3D3E62',
    lockHoodToTorso: true,
    splitPelvisLayer: true,
    jointBridgeScale: 1,
    elbowOffsetX: 0,
    elbowOffsetY: 0,
    kneeOffsetX: 0,
    kneeOffsetY: 0,
    headOffsetY: 0,
    hemOffsetY: 0,
  },
  char2: {
    sleeveColor: '#646D7B',
    pantsColor: '#3D3E62',
    lockHoodToTorso: true,
    splitPelvisLayer: true,
    jointBridgeScale: 1,
    elbowOffsetX: 0,
    elbowOffsetY: 0,
    kneeOffsetX: 0,
    kneeOffsetY: 0,
    headOffsetY: 0,
    hemOffsetY: 0,
  },
  char3: {
    sleeveColor: '#FFE2D4',
    pantsColor: '#FFFFFF',
    lockHoodToTorso: true,
    splitPelvisLayer: false,
    jointBridgeScale: 1,
    elbowOffsetX: 0,
    elbowOffsetY: 0,
    kneeOffsetX: 0,
    kneeOffsetY: 0,
    headOffsetY: 0,
    hemOffsetY: 0,
  },
  char4: {
    sleeveColor: '#FFE2D4',
    pantsColor: '#FFE2D4',
    lockHoodToTorso: true,
    splitPelvisLayer: false,
    jointBridgeScale: 1,
    elbowOffsetX: 0,
    elbowOffsetY: 0,
    kneeOffsetX: 0,
    kneeOffsetY: 0,
    headOffsetY: 0,
    hemOffsetY: 0,
  },
};

// Visible region of the rig (shadow and wave/run overshoot included).
export const VIEW = { x: 122, y: 138, w: 500, h: 642 };
// Contact shadow under the feet (taken from the reference picture).
export const SHADOW = { cx: 379, cy: 747, rx: 78, ry: 11 };
