import {
  CHAR2_HOOD_GEOM,
  CHARACTER_GEOMETRY,
  CHARACTER_JOINTS,
  DEFAULT_TUNING,
  PART_ORDER,
  type CharacterId,
  type PartGeom,
  type PartKey,
  type RigTuning,
  type RigCalibration,
} from './rigData';
import { mul, rotateAbout, translate, type M } from './affine';

/**
 * Pose of the character. Every angle is in degrees, clockwise-positive
 * (CSS convention) and *relative* to the rest pose shown in the reference
 * picture, so an all-zero pose reproduces the original whole character.
 *
 * "L" / "R" follow the reference sheet: L = the arm/leg on the viewer's left.
 * The character faces to the viewer's right.
 */
export interface Pose {
  bob: number; // vertical shift of the whole body (px, +down)
  sway: number; // horizontal shift of the whole body (px)
  torso: number; // lean/twist around the waist
  head: number; // head tilt around the neck (relative to torso)
  tuft: number; // ponytail swing around its root (relative to head)
  armL: number; // upper arm around the shoulder (relative to torso)
  foreL: number; // forearm around the elbow (relative to upper arm)
  armR: number;
  foreR: number;
  thighL: number; // thigh around the hip
  shinL: number; // shin around the knee (relative to thigh)
  thighR: number;
  shinR: number;
}

export const POSE_KEYS = [
  'bob',
  'sway',
  'torso',
  'head',
  'tuft',
  'armL',
  'foreL',
  'armR',
  'foreR',
  'thighL',
  'shinL',
  'thighR',
  'shinR',
] as const satisfies readonly (keyof Pose)[];

export function zeroPose(): Pose {
  return {
    bob: 0,
    sway: 0,
    torso: 0,
    head: 0,
    tuft: 0,
    armL: 0,
    foreL: 0,
    armR: 0,
    foreR: 0,
    thighL: 0,
    shinL: 0,
    thighR: 0,
    shinR: 0,
  };
}

function buildLocalMap(geomMap: Record<PartKey, PartGeom>): Record<PartKey, M> {
  const out = {} as Record<PartKey, M>;
  for (const k of PART_ORDER) {
    const g = geomMap[k];
    out[k] = mul(
      translate(g.cx, g.cy),
      mul(rotateAbout(g.rot, 0, 0), translate(-g.w / 2, -g.h / 2)),
    );
  }
  return out;
}

const LOCAL_BY_CHAR: Record<CharacterId, Record<PartKey, M>> = {
  char1: buildLocalMap(CHARACTER_GEOMETRY.char1),
  char2: buildLocalMap(CHARACTER_GEOMETRY.char2),
  char3: buildLocalMap(CHARACTER_GEOMETRY.char3),
  char4: buildLocalMap(CHARACTER_GEOMETRY.char4),
};

const editedLocal = new WeakMap<RigCalibration['geometry'], Record<PartKey, M>>();
function calibrationLocal(geometry: RigCalibration['geometry']) {
  let local = editedLocal.get(geometry);
  if (!local) {
    local = buildLocalMap(geometry);
    editedLocal.set(geometry, local);
  }
  return local;
}

const HOOD_LOCAL = {
  hoodL: mul(
    translate(CHAR2_HOOD_GEOM.hoodL.cx, CHAR2_HOOD_GEOM.hoodL.cy),
    mul(
      rotateAbout(CHAR2_HOOD_GEOM.hoodL.rot, 0, 0),
      translate(-CHAR2_HOOD_GEOM.hoodL.w / 2, -CHAR2_HOOD_GEOM.hoodL.h / 2),
    ),
  ),
  hoodR: mul(
    translate(CHAR2_HOOD_GEOM.hoodR.cx, CHAR2_HOOD_GEOM.hoodR.cy),
    mul(
      rotateAbout(CHAR2_HOOD_GEOM.hoodR.rot, 0, 0),
      translate(-CHAR2_HOOD_GEOM.hoodR.w / 2, -CHAR2_HOOD_GEOM.hoodR.h / 2),
    ),
  ),
};

export interface SolvedRig {
  parts: Record<PartKey, M>;
  hoodL: M;
  hoodR: M;
}

/** Forward kinematics: pose -> world matrix of every sprite + hood layers. */
export function solveRig(
  p: Pose,
  character: CharacterId = 'char1',
  tuning: RigTuning = DEFAULT_TUNING[character],
  calibration?: RigCalibration,
): SolvedRig {
  const local = calibration ? calibrationLocal(calibration.geometry) : LOCAL_BY_CHAR[character];
  const J = calibration?.joints ?? CHARACTER_JOINTS[character];
  const root = translate(p.sway, p.bob);

  const torso = mul(root, rotateAbout(p.torso, J.waist.x, J.waist.y));
  const headParent = mul(
    torso,
    mul(translate(0, tuning.headOffsetY), rotateAbout(p.head, J.neck.x, J.neck.y)),
  );
  const tuft = mul(headParent, rotateAbout(p.tuft, J.tuft.x, J.tuft.y));
  const hemParent = mul(torso, translate(0, tuning.hemOffsetY));

  const elbowLX = J.elbowL.x + tuning.elbowOffsetX;
  const elbowLY = J.elbowL.y + tuning.elbowOffsetY;
  const kneeLX = J.kneeL.x + tuning.kneeOffsetX;
  const kneeLY = J.kneeL.y + tuning.kneeOffsetY;
  const kneeRX = J.kneeR.x + tuning.kneeOffsetX;
  const kneeRY = J.kneeR.y + tuning.kneeOffsetY;

  const upL = mul(torso, rotateAbout(p.armL, J.shoulderL.x, J.shoulderL.y));
  const foL = mul(upL, rotateAbout(p.foreL, elbowLX, elbowLY));
  const upR = mul(torso, rotateAbout(p.armR, J.shoulderR.x, J.shoulderR.y));
  const foR = mul(upR, rotateAbout(p.foreR, J.elbowR.x, J.elbowR.y));

  const thL = mul(root, rotateAbout(p.thighL, J.hipL.x, J.hipL.y));
  const shL = mul(thL, rotateAbout(p.shinL, kneeLX, kneeLY));
  const thR = mul(root, rotateAbout(p.thighR, J.hipR.x, J.hipR.y));
  const shR = mul(thR, rotateAbout(p.shinR, kneeRX, kneeRY));

  const hoodLParent = tuning.lockHoodToTorso ? torso : upL;
  const hoodRParent = tuning.lockHoodToTorso ? torso : upR;

  return {
    parts: {
      tuft: mul(tuft, local.tuft),
      head: mul(headParent, local.head),
      torso: mul(torso, local.torso),
      hem: mul(hemParent, local.hem),
      upperArmL: mul(upL, local.upperArmL),
      foreArmL: mul(foL, local.foreArmL),
      upperArmR: mul(upR, local.upperArmR),
      foreArmR: mul(foR, local.foreArmR),
      thighL: mul(thL, local.thighL),
      shinL: mul(shL, local.shinL),
      thighR: mul(thR, local.thighR),
      shinR: mul(shR, local.shinR),
    },
    hoodL: mul(hoodLParent, HOOD_LOCAL.hoodL),
    hoodR: mul(hoodRParent, HOOD_LOCAL.hoodR),
  };
}

export function solve(p: Pose): Record<PartKey, M> {
  return solveRig(p, 'char1').parts;
}

export const REST_MATRICES = solve(zeroPose());
