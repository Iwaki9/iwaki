import { useEffect, useState } from 'react';
import Stage from './components/Stage';
import AssemblyEditor from './components/AssemblyEditor';
import { readCalibration, saveCalibration } from './rig/calibration';
import type { Mode, WaveVariant } from './rig/animator';
import { DEFAULT_TUNING, type CharacterId, type RigTuning, type RigCalibration } from './rig/rigData';

const MODES: { id: Mode; label: string; emoji: string; hint: string }[] = [
  { id: 'idle', label: 'Покой', emoji: '🙂', hint: '1' },
  { id: 'walk', label: 'Ходьба', emoji: '🚶', hint: '2' },
  { id: 'run', label: 'Бег', emoji: '🏃', hint: '3' },
  { id: 'wave', label: 'Махание рукой', emoji: '👋', hint: '4' },
];

const CHARACTERS: {
  id: CharacterId;
  name: string;
  subtitle: string;
  badge: string;
}[] = [
  {
    id: 'char4',
    name: 'Персонаж 4 (Белая куртка)',
    subtitle: 'Кошачьи уши, короткие рукава и рваные джинсы',
    badge: 'Новый',
  },
  {
    id: 'char3',
    name: 'Персонаж 3 (Синяя куртка)',
    subtitle: 'Голубой хвост, короткие рукава и полосатые гольфы',
    badge: 'Добавлен',
  },
  {
    id: 'char2',
    name: 'Персонаж 2 (Серое худи)',
    subtitle: 'Расстёгнутая куртка, капюшон на плечах, короткая стрижка',
    badge: 'Добавлен',
  },
  {
    id: 'char1',
    name: 'Персонаж 1 (Зелёный свитер)',
    subtitle: 'Исходный ассет: закрытый свитер, хвост на макушке',
    badge: 'Базовый',
  },
];

const WAVE_VARIANTS: {
  id: WaveVariant;
  title: string;
  desc: string;
}[] = [
  {
    id: 'seamless',
    title: 'Вариант 1: Бесшовный рукав',
    desc: 'Чёрная обводка внутри сустава полностью скрыта, рукав и колени сгибаются как цельная деталь',
  },
  {
    id: 'crease',
    title: 'Вариант 2: Живая складка',
    desc: 'Без круговой обводки в суставе + аккуратная складка ткани во внутреннем сгибе локтя и колена',
  },
  {
    id: 'tailored',
    title: 'Вариант 3: Широкий взмах + шов',
    desc: 'Бесшовный локоть с двойной складкой кроя и более широкой приветственной дугой руки',
  },
  {
    id: 'softCap',
    title: 'Вариант 4: Мягкий шарнир',
    desc: 'Скруглённый срез предплечья с приглушённым контуром внутри и деликатным взмахом',
  },
];

const CHAR3_WAVE_LABELS: Record<WaveVariant, { title: string; desc: string }> = {
  seamless: {
    title: 'Вариант 1: Бесшовный сгиб',
    desc: 'Ровные стыки кожи и сохранённый рисунок одежды',
  },
  crease: {
    title: 'Вариант 2: Выразительный взмах',
    desc: 'Более выразительный взмах без добавления чёрных линий на кожу',
  },
  tailored: {
    title: 'Вариант 3: Широкий взмах',
    desc: 'Более широкая дуга с участием плеча, рисунок одежды сохраняется',
  },
  softCap: {
    title: 'Вариант 4: Мягкий взмах',
    desc: 'Небольшая амплитуда и более спокойное движение предплечья',
  },
};

function initialMode(): Mode {
  const h = window.location.hash.replace('#', '');
  return (MODES.find((m) => m.id === h)?.id ?? 'wave') as Mode;
}

export default function App() {
  const [character, setCharacter] = useState<CharacterId>('char4');
  const [tunings, setTunings] = useState<Record<CharacterId, RigTuning>>({
    char1: { ...DEFAULT_TUNING.char1 },
    char2: { ...DEFAULT_TUNING.char2 },
    char3: { ...DEFAULT_TUNING.char3 },
    char4: { ...DEFAULT_TUNING.char4 },
  });
  const [mode, setMode] = useState<Mode>(initialMode);
  const [waveVariant, setWaveVariant] = useState<WaveVariant>('seamless');
  const [zoomElbow, setZoomElbow] = useState(false);
  const [zoomKnees, setZoomKnees] = useState(false);
  const [armOnly, setArmOnly] = useState(false);
  const [showCalibration, setShowCalibration] = useState(true);
  const [referencePose, setReferencePose] = useState(false);
  const [editorOpen, setEditorOpen] = useState(false);
  const [calibrations, setCalibrations] = useState<Partial<Record<CharacterId, RigCalibration>>>(() => {
    const result: Partial<Record<CharacterId, RigCalibration>> = {};
    for (const id of ['char1', 'char2', 'char3', 'char4'] as const) {
      const saved = readCalibration(id, true);
      if (saved) result[id] = saved.rig;
    }
    return result;
  });

  const activeTuning = tunings[character];

  const updateTuning = <K extends keyof RigTuning>(key: K, value: RigTuning[K]) => {
    setTunings((prev) => ({
      ...prev,
      [character]: {
        ...prev[character],
        [key]: value,
      },
    }));
  };

  const resetTuning = () => {
    setTunings((prev) => ({
      ...prev,
      [character]: { ...DEFAULT_TUNING[character] },
    }));
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (editorOpen || /INPUT|SELECT|TEXTAREA/.test((e.target as HTMLElement).tagName) || (e.target as HTMLElement).isContentEditable) return;
      const found = MODES.find((m) => m.hint === e.key);
      if (found) {
        setReferencePose(false);
        setMode(found.id);
        if (found.id !== 'wave') {
          setZoomElbow(false);
          setArmOnly(false);
        }
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [editorOpen]);

  const handleModeSelect = (nextMode: Mode) => {
    setReferencePose(false);
    setMode(nextMode);
    if (nextMode !== 'wave') {
      setZoomElbow(false);
      setArmOnly(false);
    }
  };

  const materialCharacter = character === 'char3' || character === 'char4';
  const variants = materialCharacter
    ? WAVE_VARIANTS.map((v) => ({ ...v, ...CHAR3_WAVE_LABELS[v.id] }))
    : WAVE_VARIANTS;
  const activeVariantInfo = variants.find((v) => v.id === waveVariant) ?? variants[0];

  return (
    <div className="min-h-screen w-full bg-[radial-gradient(ellipse_at_top,_#3a2d63_0%,_#1a1430_55%,_#0d0a1a_100%)] text-white flex flex-col items-center">
      <header className={`w-full max-w-4xl px-5 ${editorOpen ? 'pt-5 pb-2' : 'pt-7 pb-4'} text-center`}>
        <h1 className={`${editorOpen ? 'text-2xl' : 'text-3xl sm:text-4xl'} font-extrabold tracking-tight bg-gradient-to-r from-pink-300 via-rose-200 to-amber-200 bg-clip-text text-transparent`}>
          Анимация и сборка персонажа
        </h1>
        {!editorOpen && <p className="mt-2.5 text-sm sm:text-base text-violet-200/80 max-w-2xl mx-auto">
          Сравнивайте сборку с референсом, подгоняйте детали
          и проверяйте общие анимации на разных персонажах.
        </p>}
      </header>

      <main className={`w-full ${editorOpen ? 'max-w-6xl' : 'max-w-4xl'} px-4 sm:px-6 pb-12 flex flex-col items-center gap-5`}>
        {/* Переключатель персонажей */}
        {editorOpen ? <label className="flex flex-wrap items-center gap-3 text-sm text-violet-200">
          Персонаж
          <select aria-label="Персонаж в редакторе" value={character} onChange={e => setCharacter(e.target.value as CharacterId)}
            className="max-w-full bg-[#241d39] border border-white/20 rounded-lg px-3 py-2 text-white">
            {CHARACTERS.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </label> : <div className="w-full max-w-4xl grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {CHARACTERS.map((c) => {
            const active = character === c.id;
            return (
              <button
                key={c.id}
                type="button"
                onClick={() => {
                  setCharacter(c.id);
                  setReferencePose(false);
                }}
                aria-pressed={active}
                className={`text-left rounded-2xl p-3.5 border transition-all cursor-pointer ${
                  active
                    ? 'bg-gradient-to-r from-pink-500/25 via-rose-400/20 to-amber-400/20 border-amber-300/80 shadow-lg shadow-pink-500/15'
                    : 'bg-white/[0.04] border-white/10 hover:bg-white/[0.08] hover:border-white/25'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-bold text-sm sm:text-base text-white">
                    {c.name}
                  </span>
                  <span
                    className={`rounded-full px-2.5 py-0.5 text-[11px] font-bold ${
                      active
                        ? 'bg-amber-300 text-slate-900'
                        : 'bg-white/10 text-violet-200'
                    }`}
                  >
                    {c.badge}
                  </span>
                </div>
                <p className="mt-1 text-xs text-violet-200/75 leading-snug">
                  {c.subtitle}
                </p>
              </button>
            );
          })}
        </div>}

        <div className="flex items-center gap-2" role="group" aria-label="Режим работы">
          <button type="button" aria-pressed={!editorOpen} onClick={() => setEditorOpen(false)}
            className={`rounded-full px-5 py-2 border text-sm cursor-pointer transition-colors ${!editorOpen ? 'bg-white/15 border-amber-200/60 text-amber-100' : 'border-white/15 hover:bg-white/10 text-violet-200'}`}>Анимация</button>
          <button type="button" aria-pressed={editorOpen} onClick={() => setEditorOpen(true)}
            className={`rounded-full px-5 py-2 border text-sm cursor-pointer transition-colors ${editorOpen ? 'bg-white/15 border-amber-200/60 text-amber-100' : 'border-white/15 hover:bg-white/10 text-violet-200'}`}>Редактор сборки</button>
        </div>

        {editorOpen ? <AssemblyEditor key={character} character={character} tuning={activeTuning}
          onBack={() => setEditorOpen(false)} onApply={doc => {
            const draftSaved = saveCalibration(doc);
            const appliedSaved = saveCalibration(doc, true);
            setCalibrations(prev => ({ ...prev, [character]: doc.rig }));
            if (draftSaved && appliedSaved) setEditorOpen(false);
            return draftSaved && appliedSaved;
          }} /> : <>

        <Stage
          mode={mode}
          character={character}
          tuning={activeTuning}
          waveVariant={waveVariant}
          zoomElbow={zoomElbow}
          zoomKnees={zoomKnees}
          armOnly={armOnly}
          referencePose={referencePose}
          calibration={calibrations[character]}
        />

        {/* Кнопки режимов движения */}
        <div className="flex flex-wrap items-center justify-center gap-3">
          {MODES.map((m) => {
            const active = !referencePose && mode === m.id;
            return (
              <button
                key={m.id}
                onClick={() => handleModeSelect(m.id)}
                aria-pressed={active}
                className={`flex items-center gap-2 rounded-full px-5 py-2.5 text-sm sm:text-base font-semibold border transition-all cursor-pointer ${
                  active
                    ? 'bg-gradient-to-r from-pink-500 to-amber-400 text-slate-900 border-transparent shadow-lg shadow-pink-500/30 scale-105'
                    : 'bg-white/5 border-white/15 text-violet-100 hover:bg-white/10 hover:border-white/30'
                }`}
              >
                <span className="text-lg leading-none">{m.emoji}</span>
                {m.label}
                <kbd
                  className={`hidden sm:inline rounded px-1.5 text-[11px] font-mono ${
                    active ? 'bg-black/15' : 'bg-white/10 text-violet-300'
                  }`}
                >
                  {m.hint}
                </kbd>
              </button>
            );
          })}
        </div>

        {materialCharacter && (
          <div className="flex flex-wrap items-center justify-center gap-3 text-xs text-violet-200/80">
            <button
              type="button"
              aria-pressed={referencePose}
              onClick={() => {
                setReferencePose(!referencePose);
                setZoomElbow(false);
                setZoomKnees(false);
                setArmOnly(false);
              }}
              className={`rounded-full border px-4 py-2 font-semibold transition-colors cursor-pointer ${
                referencePose ? 'bg-sky-200 text-slate-900 border-sky-200' : 'border-white/20 hover:bg-white/10'
              }`}
            >
              Поза из примера
            </button>
            <span>Остановить движение и проверить сборку.</span>
          </div>
        )}

        {/* Варианты локтевого/коленного сустава и режим крупного плана */}
        <section className="w-full max-w-3xl rounded-2xl border border-white/15 bg-white/[0.04] p-4 backdrop-blur-sm">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-white/10">
            <div>
              <h2 className="text-sm font-bold text-amber-200">
                Варианты сгиба суставов (локти и колени)
              </h2>
              <p className="text-xs text-violet-200/75 mt-0.5">
                {activeVariantInfo.desc}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  setReferencePose(false);
                  setZoomElbow(false);
                  setArmOnly(false);
                  setZoomKnees((z) => {
                    const next = !z;
                    if (next && (mode === 'idle' || mode === 'wave')) {
                      setMode('walk');
                    }
                    return next;
                  });
                }}
                aria-pressed={zoomKnees}
                className={`rounded-full px-3.5 py-1.5 text-xs font-semibold border transition-all cursor-pointer ${
                  zoomKnees
                    ? 'bg-emerald-300 text-slate-900 border-transparent shadow-md shadow-emerald-400/25'
                    : 'bg-white/5 border-white/15 text-violet-100 hover:bg-white/10'
                }`}
              >
                🔍 Крупный план коленей
              </button>

              <button
                type="button"
                onClick={() => {
                  setReferencePose(false);
                  setZoomKnees(false);
                  setMode('wave');
                  setZoomElbow((z) => {
                    const next = !z;
                    if (!next) setArmOnly(false);
                    return next;
                  });
                }}
                aria-pressed={zoomElbow || armOnly}
                className={`rounded-full px-3.5 py-1.5 text-xs font-semibold border transition-all cursor-pointer ${
                  zoomElbow || armOnly
                    ? 'bg-amber-300 text-slate-900 border-transparent shadow-md shadow-amber-400/25'
                    : 'bg-white/5 border-white/15 text-violet-100 hover:bg-white/10'
                }`}
              >
                🔍 Крупный план локтя
              </button>

              <button
                type="button"
                onClick={() => {
                  setReferencePose(false);
                  setZoomKnees(false);
                  setMode('wave');
                  setArmOnly((only) => {
                    const next = !only;
                    if (next) setZoomElbow(true);
                    return next;
                  });
                }}
                aria-pressed={armOnly}
                className={`rounded-full px-3.5 py-1.5 text-xs font-semibold border transition-all cursor-pointer ${
                  armOnly
                    ? 'bg-pink-400 text-slate-900 border-transparent shadow-md shadow-pink-400/25'
                    : 'bg-white/5 border-white/15 text-violet-100 hover:bg-white/10'
                }`}
              >
                🦾 Только рука (тест)
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-3">
            {variants.map((v) => {
              const selected = waveVariant === v.id;
              return (
                <button
                  key={v.id}
                  type="button"
                  onClick={() => {
                    setReferencePose(false);
                    setWaveVariant(v.id);
                    setMode('wave');
                  }}
                  aria-pressed={selected}
                  className={`text-left rounded-xl px-3.5 py-2.5 border transition-all cursor-pointer ${
                    selected
                      ? 'bg-gradient-to-r from-pink-500/25 to-amber-400/20 border-amber-300/70 text-white shadow-sm'
                      : 'bg-white/[0.03] border-white/10 text-violet-200/85 hover:bg-white/[0.07] hover:border-white/25'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs sm:text-sm font-semibold">
                      {v.title}
                    </span>
                    {selected && (
                      <span className="rounded-full bg-amber-300/20 border border-amber-300/50 px-2 py-0.5 text-[10px] font-bold text-amber-200">
                        Активен
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-violet-200/70 mt-1 leading-snug">
                    {v.desc}
                  </p>
                </button>
              );
            })}
          </div>
        </section>

        {/* Интерактивная панель калибровки для адаптации любого нового персонажа */}
        <section className="w-full max-w-3xl rounded-2xl border border-white/15 bg-white/[0.04] p-4 backdrop-blur-sm">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h2 className="text-sm font-bold text-pink-200">
                ⚙️ Настройки адаптации персонажа (устранение визуальных багов при переносе)
              </h2>
              <p className="text-xs text-violet-200/75 mt-0.5">
                Настройки выбранного персонажа: цвета стыков, слои одежды и точки вращения.
                {character === 'char3' && ' Полосы гольфов сохраняются в исходных изображениях, без однотонной закраски.'}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={resetTuning}
                className="rounded-full px-3 py-1 text-xs font-semibold bg-white/10 hover:bg-white/20 text-violet-100 border border-white/15 cursor-pointer"
              >
                ↺ Сбросить к эталону
              </button>
              <button
                type="button"
                onClick={() => setShowCalibration((s) => !s)}
                className="rounded-full px-3 py-1 text-xs font-semibold bg-white/5 hover:bg-white/15 text-violet-200 border border-white/15 cursor-pointer"
              >
                {showCalibration ? 'Скрыть' : 'Развернуть'}
              </button>
            </div>
          </div>

          {showCalibration && (
            <div className="mt-4 pt-3 border-t border-white/10 space-y-4">
              {/* Переключатели конструктивных особенностей одежды */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <label className="flex items-start gap-3 rounded-xl bg-white/[0.03] border border-white/10 p-3 cursor-pointer hover:bg-white/[0.06]">
                  <input
                    type="checkbox"
                    disabled={materialCharacter}
                    checked={activeTuning.lockHoodToTorso}
                    onChange={(e) => updateTuning('lockHoodToTorso', e.target.checked)}
                    className="mt-1 h-4 w-4 accent-amber-400"
                  />
                  <div>
                    <div className="text-xs font-bold text-white">
                      Закрепить капюшон / наплечники на торсе
                    </div>
                    <p className="text-[11px] text-violet-200/70 mt-0.5 leading-snug">
                      {materialCharacter
                        ? 'У этого персонажа капюшона нет.'
                        : 'На листе ассетов капюшон вырезан вместе с плечом. Если отключить эту опцию, при махании капюшон повернётся на 99° вместе с рукой.'}
                    </p>
                  </div>
                </label>

                <label className="flex items-start gap-3 rounded-xl bg-white/[0.03] border border-white/10 p-3 cursor-pointer hover:bg-white/[0.06]">
                  <input
                    type="checkbox"
                    checked={activeTuning.splitPelvisLayer}
                    onChange={(e) => updateTuning('splitPelvisLayer', e.target.checked)}
                    className="mt-1 h-4 w-4 accent-amber-400"
                  />
                  <div>
                    <div className="text-xs font-bold text-white">
                      Разделить слой таза и расстёгнутой куртки
                    </div>
                    <p className="text-[11px] text-violet-200/70 mt-0.5 leading-snug">
                      Уводит нижнюю чашу таза за бёдра, а грудь и полы куртки оставляет спереди. Без этого в разрезе куртки при беге видна дуга таза поверх ноги.
                    </p>
                  </div>
                </label>
              </div>

              {/* Цвета маскировки внутренней обводки суставов и ширина моста */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="rounded-xl bg-white/[0.03] border border-white/10 p-3">
                  <div className="flex items-center justify-between text-xs font-semibold text-violet-100">
                    <span>{materialCharacter ? 'Цвет кожи (локти)' : 'Цвет рукава (локти)'}</span>
                    <span className="font-mono text-[11px] text-amber-200">
                      {activeTuning.sleeveColor}
                    </span>
                  </div>
                  <div className="mt-2 flex flex-wrap items-center gap-2">
                    <input
                      type="color"
                      value={activeTuning.sleeveColor}
                      onChange={(e) => updateTuning('sleeveColor', e.target.value)}
                      className="h-7 w-10 rounded cursor-pointer bg-transparent border border-white/20"
                    />
                    <button
                      type="button"
                      onClick={() => updateTuning('sleeveColor', DEFAULT_TUNING[character].sleeveColor)}
                      className="px-2 py-1 rounded text-[11px] bg-white/10 hover:bg-white/20 cursor-pointer"
                    >
                      Цвет персонажа
                    </button>
                    <button
                      type="button"
                      onClick={() => updateTuning('sleeveColor', '#006B37')}
                      className="px-2 py-1 rounded text-[11px] bg-white/10 hover:bg-white/20 cursor-pointer"
                    >
                      Зелёный
                    </button>
                  </div>
                </div>

                <div className="rounded-xl bg-white/[0.03] border border-white/10 p-3">
                  <div className="flex items-center justify-between text-xs font-semibold text-violet-100">
                    <span>{character === 'char3' ? 'Цвет стыка гольфов' : character === 'char4' ? 'Цвет кожи (колени)' : 'Цвет штанов (колени)'}</span>
                    <span className="font-mono text-[11px] text-amber-200">
                      {activeTuning.pantsColor}
                    </span>
                  </div>
                  <div className="mt-2 flex items-center gap-2">
                    <input
                      type="color"
                      value={activeTuning.pantsColor}
                      onChange={(e) => updateTuning('pantsColor', e.target.value)}
                      className="h-7 w-10 rounded cursor-pointer bg-transparent border border-white/20"
                    />
                    <button
                      type="button"
                      onClick={() => updateTuning('pantsColor', DEFAULT_TUNING[character].pantsColor)}
                      className="px-2 py-1 rounded text-[11px] bg-white/10 hover:bg-white/20 cursor-pointer"
                    >
                      {character === 'char3' ? 'Белый' : character === 'char4' ? 'Цвет кожи' : 'Тёмно-синий'}
                    </button>
                  </div>
                </div>

                <div className="rounded-xl bg-white/[0.03] border border-white/10 p-3">
                  <div className="flex items-center justify-between text-xs font-semibold text-violet-100">
                    <span>{materialCharacter ? 'Скругление стыков' : 'Скрытие обводки в суставах'}</span>
                    <span className="font-mono text-[11px] text-amber-200">
                      {Math.round(activeTuning.jointBridgeScale * 100)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0}
                    max={materialCharacter ? 1 : 1.15}
                    step={0.05}
                    value={activeTuning.jointBridgeScale}
                    onChange={(e) =>
                      updateTuning('jointBridgeScale', parseFloat(e.target.value))
                    }
                    className="mt-2.5 w-full accent-amber-400 cursor-pointer"
                  />
                  <p className="text-[10px] text-violet-300/70 mt-0.5">
                    {materialCharacter ? '0%: исходные срезы деталей, без скругления' : '0%: показать исходные чёрные швы внутри суставов'}
                  </p>
                </div>
              </div>

              {/* Тонкая подстройка пивотов и посадки частей */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="rounded-xl bg-white/[0.03] border border-white/10 p-2.5">
                  <div className="flex justify-between text-[11px] text-violet-200">
                    <span>Пивот локтя X</span>
                    <span className="font-mono text-amber-200">
                      {activeTuning.elbowOffsetX.toFixed(1)}px
                    </span>
                  </div>
                  <input
                    type="range"
                    min={-6}
                    max={6}
                    step={0.5}
                    value={activeTuning.elbowOffsetX}
                    onChange={(e) =>
                      updateTuning('elbowOffsetX', parseFloat(e.target.value))
                    }
                    className="mt-1.5 w-full accent-pink-400 cursor-pointer"
                  />
                </div>

                <div className="rounded-xl bg-white/[0.03] border border-white/10 p-2.5">
                  <div className="flex justify-between text-[11px] text-violet-200">
                    <span>Пивот локтя Y</span>
                    <span className="font-mono text-amber-200">
                      {activeTuning.elbowOffsetY.toFixed(1)}px
                    </span>
                  </div>
                  <input
                    type="range"
                    min={-6}
                    max={6}
                    step={0.5}
                    value={activeTuning.elbowOffsetY}
                    onChange={(e) =>
                      updateTuning('elbowOffsetY', parseFloat(e.target.value))
                    }
                    className="mt-1.5 w-full accent-pink-400 cursor-pointer"
                  />
                </div>

                <div className="rounded-xl bg-white/[0.03] border border-white/10 p-2.5">
                  <div className="flex justify-between text-[11px] text-violet-200">
                    <span>Посадка головы Y</span>
                    <span className="font-mono text-amber-200">
                      {activeTuning.headOffsetY.toFixed(1)}px
                    </span>
                  </div>
                  <input
                    type="range"
                    min={-15}
                    max={15}
                    step={0.5}
                    value={activeTuning.headOffsetY}
                    onChange={(e) =>
                      updateTuning('headOffsetY', parseFloat(e.target.value))
                    }
                    className="mt-1.5 w-full accent-pink-400 cursor-pointer"
                  />
                </div>

                <div className="rounded-xl bg-white/[0.03] border border-white/10 p-2.5">
                  <div className="flex justify-between text-[11px] text-violet-200">
                    <span>Подол куртки Y</span>
                    <span className="font-mono text-amber-200">
                      {activeTuning.hemOffsetY.toFixed(1)}px
                    </span>
                  </div>
                  <input
                    type="range"
                    min={-10}
                    max={10}
                    step={0.5}
                    value={activeTuning.hemOffsetY}
                    onChange={(e) =>
                      updateTuning('hemOffsetY', parseFloat(e.target.value))
                    }
                    className="mt-1.5 w-full accent-pink-400 cursor-pointer"
                  />
                </div>
              </div>
            </div>
          )}
        </section>

        <p className="text-xs text-violet-300/60 text-center max-w-md">
          Переключать режимы можно клавишами 1–4. Движения плавно перетекают
          друг в друга, а фон прокручивается в такт шагам.
        </p>
        </>}
      </main>
    </div>
  );
}
