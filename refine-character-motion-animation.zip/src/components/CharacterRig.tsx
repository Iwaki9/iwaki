import { forwardRef, useImperativeHandle, useRef } from 'react';
import {
  CHAR2_HOOD_GEOM,
  CHARACTER_GEOMETRY,
  CHARACTER_JOINTS,
  DEFAULT_TUNING,
  PART_ORDER,
  SHADOW,
  VIEW,
  type CharacterId,
  type PartKey,
  type RigTuning,
  type RigCalibration,
} from '../rig/rigData';
import { CHAR2_HOOD_IMAGES } from '../rig/char2Images';
import { CHARACTER_IMAGES } from '../rig/characterAssets';
import MaterialLimb, { type MaterialLimbHandle } from './MaterialLimb';
import { solveRig, zeroPose, type Pose } from '../rig/kinematics';
import { toCss, type M } from '../rig/affine';
import type { WaveVariant } from '../rig/animator';

export interface RigHandle {
  /** Re-pose the character. `armInFront` lifts the waving arm above the head. */
  apply: (
    pose: Pose,
    armInFront: boolean,
    variant?: WaveVariant,
    character?: CharacterId,
    tuning?: RigTuning,
    calibration?: RigCalibration,
  ) => void;
}

interface CharacterRigProps {
  character?: CharacterId;
  tuning?: RigTuning;
  calibration?: RigCalibration;
  /** When true, hides the rest of the body so only the waving arm is shown for joint testing. */
  armOnly?: boolean;
}

const BASE_Z: Record<PartKey, number> = {} as Record<PartKey, number>;
PART_ORDER.forEach((k, i) => {
  BASE_Z[k] = i + 1;
});

const RIG_IMG_PARTS: PartKey[] = ['tuft', 'torso', 'hem', 'head'];

const MATERIAL_LIMBS = [
  { upper: 'upperArmR', lower: 'foreArmR', joint: 'elbowR', bend: 'foreR', radius: 12.35, skin: true },
  { upper: 'thighR', lower: 'shinR', joint: 'kneeR', bend: 'shinR', radius: 24.6, skin: false },
  { upper: 'thighL', lower: 'shinL', joint: 'kneeL', bend: 'shinL', radius: 25.3, skin: false },
  { upper: 'upperArmL', lower: 'foreArmL', joint: 'elbowL', bend: 'foreL', radius: 12.25, skin: true },
] as const;

function toSvgMatrix(m: M): string {
  return `matrix(${m[0].toFixed(5)} ${m[1].toFixed(5)} ${m[2].toFixed(5)} ${m[3].toFixed(5)} ${m[4].toFixed(2)} ${m[5].toFixed(2)})`;
}

const CharacterRig = forwardRef<RigHandle, CharacterRigProps>(function CharacterRig(
  { character = 'char2', tuning = DEFAULT_TUNING[character], armOnly = false, calibration },
  ref,
) {
  const parts = useRef<Partial<Record<PartKey, HTMLImageElement | null>>>({});
  const torsoPelvisEl = useRef<HTMLImageElement | null>(null);
  const hoodRUnderEl = useRef<HTMLImageElement | null>(null);
  const hoodLUnderEl = useRef<HTMLImageElement | null>(null);

  const shadow = useRef<HTMLDivElement | null>(null);
  const materialLimbs = useRef<Partial<Record<PartKey, MaterialLimbHandle | null>>>({});

  // Front arm (L) refs
  const armLSvg = useRef<SVGSVGElement | null>(null);
  const upArmLGroup = useRef<SVGGElement | null>(null);
  const foreArmLGroup = useRef<SVGGElement | null>(null);
  const upBridgeLGroup = useRef<SVGGElement | null>(null);
  const foreBridgeLGroup = useRef<SVGGElement | null>(null);
  const upBridgeLLine = useRef<SVGLineElement | null>(null);
  const foreBridgeLLine = useRef<SVGLineElement | null>(null);
  const creaseArmMainEl = useRef<SVGPathElement | null>(null);
  const creaseArmSubEl = useRef<SVGPathElement | null>(null);

  // Back arm (R) refs
  const upArmRGroup = useRef<SVGGElement | null>(null);
  const foreArmRGroup = useRef<SVGGElement | null>(null);
  const upBridgeRGroup = useRef<SVGGElement | null>(null);
  const foreBridgeRGroup = useRef<SVGGElement | null>(null);
  const upBridgeRLine = useRef<SVGLineElement | null>(null);
  const foreBridgeRLine = useRef<SVGLineElement | null>(null);

  // Left leg (front leg, L) refs
  const thighLGroup = useRef<SVGGElement | null>(null);
  const shinLGroup = useRef<SVGGElement | null>(null);
  const thighBridgeLGroup = useRef<SVGGElement | null>(null);
  const shinBridgeLGroup = useRef<SVGGElement | null>(null);
  const thighBridgeLLine = useRef<SVGLineElement | null>(null);
  const shinBridgeLLine = useRef<SVGLineElement | null>(null);
  const creaseKneeLEl = useRef<SVGPathElement | null>(null);

  // Right leg (back leg, R) refs
  const thighRGroup = useRef<SVGGElement | null>(null);
  const shinRGroup = useRef<SVGGElement | null>(null);
  const thighBridgeRGroup = useRef<SVGGElement | null>(null);
  const shinBridgeRGroup = useRef<SVGGElement | null>(null);
  const thighBridgeRLine = useRef<SVGLineElement | null>(null);
  const shinBridgeRLine = useRef<SVGLineElement | null>(null);
  const creaseKneeREl = useRef<SVGPathElement | null>(null);

  const lastFront = useRef<string | null>(null);

  useImperativeHandle(
    ref,
    () => ({
      apply(
        pose,
        armInFront,
        variant = 'seamless',
        activeChar = character,
        activeTuning = tuning,
        activeCalibration = calibration,
      ) {
        const solved = solveRig(pose, activeChar, activeTuning, activeCalibration);
        const m = solved.parts;

        for (const limb of MATERIAL_LIMBS) {
          materialLimbs.current[limb.upper]?.apply(
            m[limb.upper], m[limb.lower], pose[limb.bend],
            limb.upper === 'upperArmL' && armInFront,
          );
        }

        for (const k of RIG_IMG_PARTS) {
          const el = parts.current[k];
          if (el) el.style.transform = toCss(m[k]);
        }
        if (torsoPelvisEl.current) {
          torsoPelvisEl.current.style.transform = toCss(m.torso);
        }
        if (hoodRUnderEl.current) {
          hoodRUnderEl.current.style.transform = toCss(solved.hoodR);
        }
        if (hoodLUnderEl.current) {
          hoodLUnderEl.current.style.transform = toCss(solved.hoodL);
        }


        // 1. Front arm (upperArmL + foreArmL)
        const upLMat = toSvgMatrix(m.upperArmL);
        const foreLMat = toSvgMatrix(m.foreArmL);
        upArmLGroup.current?.setAttribute('transform', upLMat);
        foreArmLGroup.current?.setAttribute('transform', foreLMat);
        upBridgeLGroup.current?.setAttribute('transform', upLMat);
        foreBridgeLGroup.current?.setAttribute('transform', foreLMat);

        // 2. Back arm (upperArmR + foreArmR)
        const upRMat = toSvgMatrix(m.upperArmR);
        const foreRMat = toSvgMatrix(m.foreArmR);
        upArmRGroup.current?.setAttribute('transform', upRMat);
        foreArmRGroup.current?.setAttribute('transform', foreRMat);
        upBridgeRGroup.current?.setAttribute('transform', upRMat);
        foreBridgeRGroup.current?.setAttribute('transform', foreRMat);

        // 3. Left leg (thighL + shinL)
        const thLMat = toSvgMatrix(m.thighL);
        const shLMat = toSvgMatrix(m.shinL);
        thighLGroup.current?.setAttribute('transform', thLMat);
        shinLGroup.current?.setAttribute('transform', shLMat);
        thighBridgeLGroup.current?.setAttribute('transform', thLMat);
        shinBridgeLGroup.current?.setAttribute('transform', shLMat);

        // 4. Right leg (thighR + shinR)
        const thRMat = toSvgMatrix(m.thighR);
        const shRMat = toSvgMatrix(m.shinR);
        thighRGroup.current?.setAttribute('transform', thRMat);
        shinRGroup.current?.setAttribute('transform', shRMat);
        thighBridgeRGroup.current?.setAttribute('transform', thRMat);
        shinBridgeRGroup.current?.setAttribute('transform', shRMat);

        // Configure joint interior outline masking & fold creases according to active variant and tuning
        const scale = activeTuning.jointBridgeScale;
        const baseOpacity = variant === 'softCap' ? 0.68 : 1;
        const bridgeOpacity = String(scale <= 0.01 ? 0 : baseOpacity);

        if (upBridgeLGroup.current) upBridgeLGroup.current.style.opacity = bridgeOpacity;
        if (foreBridgeLGroup.current) foreBridgeLGroup.current.style.opacity = bridgeOpacity;
        if (upBridgeRGroup.current) upBridgeRGroup.current.style.opacity = bridgeOpacity;
        if (foreBridgeRGroup.current) foreBridgeRGroup.current.style.opacity = bridgeOpacity;
        if (thighBridgeLGroup.current) thighBridgeLGroup.current.style.opacity = bridgeOpacity;
        if (shinBridgeLGroup.current) shinBridgeLGroup.current.style.opacity = bridgeOpacity;
        if (thighBridgeRGroup.current) thighBridgeRGroup.current.style.opacity = bridgeOpacity;
        if (shinBridgeRGroup.current) shinBridgeRGroup.current.style.opacity = bridgeOpacity;

        const showCrease = variant === 'crease' || variant === 'tailored';
        const armBendFactor = Math.max(0, Math.min(1, (pose.foreL - 14) / 30));
        if (creaseArmMainEl.current) {
          creaseArmMainEl.current.style.opacity = showCrease
            ? (armBendFactor * 0.95).toFixed(3)
            : '0';
        }
        if (creaseArmSubEl.current) {
          creaseArmSubEl.current.style.opacity =
            variant === 'tailored' ? (armBendFactor * 0.85).toFixed(3) : '0';
        }

        const kneeLBendFactor = Math.max(0, Math.min(1, (pose.shinL - 12) / 32));
        if (creaseKneeLEl.current) {
          creaseKneeLEl.current.style.opacity = showCrease
            ? (kneeLBendFactor * 0.92).toFixed(3)
            : '0';
        }
        const kneeRBendFactor = Math.max(0, Math.min(1, (pose.shinR - 12) / 32));
        if (creaseKneeREl.current) {
          creaseKneeREl.current.style.opacity = showCrease
            ? (kneeRBendFactor * 0.92).toFixed(3)
            : '0';
        }

        const frontKey = `${activeChar}:${armInFront}`;
        if (lastFront.current !== frontKey) {
          lastFront.current = frontKey;
          if (armLSvg.current) {
            armLSvg.current.style.zIndex = String(armInFront ? 30 : BASE_Z.upperArmL);
          }
        }

        // contact shadow follows the body and shrinks while it is in the air
        if (shadow.current) {
          const air = Math.max(-1, Math.min(1, -pose.bob / 22));
          const shadowScale = 1 - air * 0.22;
          shadow.current.style.transform = `translateX(${(pose.sway * 0.6).toFixed(2)}px) scale(${shadowScale.toFixed(3)})`;
          shadow.current.style.opacity = armOnly ? '0' : String(0.85 - air * 0.3);
        }
      },
    }),
    [armOnly, character, tuning, calibration],
  );

  const activeGeom = calibration?.geometry ?? CHARACTER_GEOMETRY[character];
  const activeImages = { ...CHARACTER_IMAGES[character], ...calibration?.images };
  const texturedLimbs = character === 'char3' || character === 'char4';
  const stretches = (part: PartKey) => {
    const base = CHARACTER_GEOMETRY[character][part];
    const g = activeGeom[part];
    const replacement = calibration?.images?.[part];
    return (!!replacement && replacement !== CHARACTER_IMAGES[character][part])
      || Math.abs((g.w / g.h) / (base.w / base.h) - 1) > 0.000001;
  };
  const restSolved = solveRig(zeroPose(), character, tuning, calibration);
  const restM = restSolved.parts;

  const restUpLMat = toSvgMatrix(restM.upperArmL);
  const restForeLMat = toSvgMatrix(restM.foreArmL);
  const restUpRMat = toSvgMatrix(restM.upperArmR);
  const restForeRMat = toSvgMatrix(restM.foreArmR);
  const restThighLMat = toSvgMatrix(restM.thighL);
  const restShinLMat = toSvgMatrix(restM.shinL);
  const restThighRMat = toSvgMatrix(restM.thighR);
  const restShinRMat = toSvgMatrix(restM.shinR);

  const bScale = Math.max(0.01, tuning.jointBridgeScale);

  return (
    <div
      style={{
        position: 'relative',
        width: VIEW.w,
        height: VIEW.h,
        pointerEvents: 'none',
        userSelect: 'none',
      }}
    >
      {/* everything inside uses the coordinates of the reference picture */}
      <div
        style={{
          position: 'absolute',
          left: 0,
          top: 0,
          width: 0,
          height: 0,
          transform: `translate(${-VIEW.x}px, ${-VIEW.y}px)`,
        }}
      >
        <div
          ref={shadow}
          style={{
            position: 'absolute',
            left: SHADOW.cx - SHADOW.rx,
            top: SHADOW.cy - SHADOW.ry,
            width: SHADOW.rx * 2,
            height: SHADOW.ry * 2,
            borderRadius: '50%',
            background:
              'radial-gradient(ellipse at center, rgba(30,20,60,0.55) 0%, rgba(30,20,60,0.35) 55%, rgba(30,20,60,0) 100%)',
            zIndex: 0,
            opacity: armOnly ? 0 : 0.85,
            transition: 'opacity 180ms ease',
          }}
        />

        {/* Pelvis background layer of torso (sits behind thighs so open jacket hems don't draw a pelvis seam over the legs) */}
        {tuning.splitPelvisLayer && (
          <img
            ref={torsoPelvisEl}
            src={activeImages.torso}
            alt=""
            draggable={false}
            style={{
              position: 'absolute',
              left: 0,
              top: 0,
              width: activeGeom.torso.w,
              height: activeGeom.torso.h,
              transformOrigin: '0 0',
              transform: toCss(restM.torso),
              zIndex: BASE_Z.thighR - 1,
              willChange: 'transform',
              maxWidth: 'none',
              opacity: armOnly ? 0 : 1,
              transition: 'opacity 180ms ease',
            }}
          />
        )}

        {/* Right hood piece for Character 2 */}
        {character === 'char2' && (
          <img
            ref={hoodRUnderEl}
            src={CHAR2_HOOD_IMAGES.hoodR}
            alt=""
            draggable={false}
            style={{
              position: 'absolute',
              left: 0,
              top: 0,
              width: CHAR2_HOOD_GEOM.hoodR.w,
              height: CHAR2_HOOD_GEOM.hoodR.h,
              transformOrigin: '0 0',
              transform: toCss(restSolved.hoodR),
              zIndex: tuning.lockHoodToTorso ? BASE_Z.torso : BASE_Z.upperArmR + 1,
              willChange: 'transform',
              maxWidth: 'none',
              opacity: armOnly ? 0 : 1,
              transition: 'opacity 180ms ease',
            }}
          />
        )}

        {RIG_IMG_PARTS.map((k) => {
          const isSplitTorso = k === 'torso' && tuning.splitPelvisLayer;
          return (
            <img
              key={k}
              ref={(el) => {
                parts.current[k] = el;
              }}
              src={activeImages[k]}
              alt=""
              draggable={false}
              style={{
                position: 'absolute',
                left: 0,
                top: 0,
                width: activeGeom[k].w,
                height: activeGeom[k].h,
                transformOrigin: '0 0',
                transform: toCss(restM[k]),
                zIndex: BASE_Z[k],
                willChange: 'transform',
                maxWidth: 'none',
                clipPath: isSplitTorso ? 'inset(0px 0px 27.5px 0px)' : undefined,
                opacity: armOnly || (character === 'char2' && k === 'tuft') ? 0 : 1,
                transition: 'opacity 180ms ease',
              }}
            />
          );
        })}

        {/* Left hood piece for Character 2 (sits above upperArmL shoulder and under head) */}
        {character === 'char2' && (
          <img
            ref={hoodLUnderEl}
            src={CHAR2_HOOD_IMAGES.hoodL}
            alt=""
            draggable={false}
            style={{
              position: 'absolute',
              left: 0,
              top: 0,
              width: CHAR2_HOOD_GEOM.hoodL.w,
              height: CHAR2_HOOD_GEOM.hoodL.h,
              transformOrigin: '0 0',
              transform: toCss(restSolved.hoodL),
              zIndex: BASE_Z.head - 1,
              willChange: 'transform',
              maxWidth: 'none',
              opacity: armOnly ? 0 : 1,
              transition: 'opacity 180ms ease',
            }}
          />
        )}

        {texturedLimbs && MATERIAL_LIMBS.map((limb) => {
          const joint = (calibration?.joints ?? CHARACTER_JOINTS[character])[limb.joint];
          const dx = limb.skin ? (limb.joint === 'elbowL' ? tuning.elbowOffsetX : 0) : tuning.kneeOffsetX;
          const dy = limb.skin ? (limb.joint === 'elbowL' ? tuning.elbowOffsetY : 0) : tuning.kneeOffsetY;
          return (
            <MaterialLimb
              key={limb.upper}
              ref={(el) => { materialLimbs.current[limb.upper] = el; }}
              upperImage={activeImages[limb.upper]}
              lowerImage={activeImages[limb.lower]}
              upperGeom={activeGeom[limb.upper]}
              lowerGeom={activeGeom[limb.lower]}
              restUpper={restM[limb.upper]}
              restLower={restM[limb.lower]}
              joint={{ x: joint.x + dx, y: joint.y + dy }}
              radius={(character === 'char4' ? (limb.skin ? 13.7 : 25.5) : limb.radius)
                * activeGeom[limb.upper].w / CHARACTER_GEOMETRY[character][limb.upper].w}
              seamWidth={character === 'char4' && limb.skin ? 17 : 0}
              stretch={stretches(limb.upper) || stretches(limb.lower)}
              color={limb.skin ? tuning.sleeveColor : tuning.pantsColor}
              smoothing={tuning.jointBridgeScale}
              zIndex={BASE_Z[limb.upper]}
              hidden={armOnly && limb.upper !== 'upperArmL'}
            />
          );
        })}

        {/* Composite Back Arm (upperArmR + foreArmR, sits behind both legs) */}
        {!texturedLimbs && <svg
          viewBox="0 0 700 800"
          width={700}
          height={800}
          style={{
            position: 'absolute',
            left: 0,
            top: 0,
            overflow: 'visible',
            zIndex: BASE_Z.upperArmR,
            pointerEvents: 'none',
            opacity: armOnly ? 0 : 1,
            transition: 'opacity 180ms ease',
          }}
        >
          <defs>
            <clipPath id="foreRClipSmooth">
              <path d="M 0 22 L 2.2 20.7 A 16.2 16.2 0 0 1 33.4 15.0 L 61 25 L 61 95 L 0 95 Z" />
            </clipPath>
          </defs>
          <g ref={upArmRGroup} transform={restUpRMat}>
            <circle cx="40.3" cy="66.5" r="16.2" fill="#000000" />
            <image
              href={activeImages.upperArmR}
              preserveAspectRatio={stretches('upperArmR') ? 'none' : undefined}
              width={activeGeom.upperArmR.w}
              height={activeGeom.upperArmR.h}
            />
          </g>
          <g ref={foreArmRGroup} transform={restForeRMat} clipPath="url(#foreRClipSmooth)">
            <image
              href={activeImages.foreArmR}
              preserveAspectRatio={stretches('foreArmR') ? 'none' : undefined}
              width={activeGeom.foreArmR.w}
              height={activeGeom.foreArmR.h}
            />
          </g>
          <g ref={upBridgeRGroup} transform={restUpRMat}>
            <line
              ref={upBridgeRLine}
              x1="30.0"
              y1="45.0"
              x2="39.2"
              y2="66.5"
              stroke={tuning.sleeveColor}
              strokeWidth={23.6 * bScale}
              strokeLinecap="round"
            />
          </g>
          <g ref={foreBridgeRGroup} transform={restForeRMat}>
            <line
              ref={foreBridgeRLine}
              x1="18.2"
              y1="20.7"
              x2="25.0"
              y2="39.0"
              stroke={tuning.sleeveColor}
              strokeWidth={23.6 * bScale}
              strokeLinecap="round"
            />
          </g>
        </svg>}

        {/* Composite Right Leg (thighR + shinR, back leg) with seamless knee joint */}
        {!texturedLimbs && <svg
          viewBox="0 0 700 800"
          width={700}
          height={800}
          style={{
            position: 'absolute',
            left: 0,
            top: 0,
            overflow: 'visible',
            zIndex: BASE_Z.thighR,
            pointerEvents: 'none',
            opacity: armOnly ? 0 : 1,
            transition: 'opacity 180ms ease',
          }}
        >
          <defs>
            <clipPath id="shinRClipSmooth">
              <path d="M 0 11.5 L 1.8 11.5 A 26.2 26.2 0 0 1 54.2 11.5 L 69 11.5 L 69 121 L 0 121 Z" />
            </clipPath>
          </defs>
          <g ref={thighRGroup} transform={restThighRMat}>
            <circle cx="30.0" cy="95.5" r="26.2" fill="#000000" />
            <image
              href={activeImages.thighR}
              preserveAspectRatio={stretches('thighR') ? 'none' : undefined}
              width={activeGeom.thighR.w}
              height={activeGeom.thighR.h}
            />
          </g>
          <g ref={shinRGroup} transform={restShinRMat} clipPath="url(#shinRClipSmooth)">
            <image
              href={activeImages.shinR}
              preserveAspectRatio={stretches('shinR') ? 'none' : undefined}
              width={activeGeom.shinR.w}
              height={activeGeom.shinR.h}
            />
          </g>
          <g ref={thighBridgeRGroup} transform={restThighRMat}>
            <line
              ref={thighBridgeRLine}
              x1="29.4"
              y1="62.0"
              x2="30.0"
              y2="95.5"
              stroke={tuning.pantsColor}
              strokeWidth={41.4 * bScale}
              strokeLinecap="round"
            />
          </g>
          <g ref={shinBridgeRGroup} transform={restShinRMat}>
            <line
              ref={shinBridgeRLine}
              x1="28.0"
              y1="11.5"
              x2="29.2"
              y2="45.0"
              stroke={tuning.pantsColor}
              strokeWidth={41.4 * bScale}
              strokeLinecap="round"
            />
            <path
              ref={creaseKneeREl}
              d="M 2.8 12.8 Q 8.5 15.4 12.0 19.0"
              fill="none"
              stroke="#000000"
              strokeWidth="3.5"
              strokeLinecap="round"
              style={{ opacity: 0 }}
            />
          </g>
        </svg>}

        {/* Composite Left Leg (thighL + shinL, front leg) with seamless knee joint */}
        {!texturedLimbs && <svg
          viewBox="0 0 700 800"
          width={700}
          height={800}
          style={{
            position: 'absolute',
            left: 0,
            top: 0,
            overflow: 'visible',
            zIndex: BASE_Z.thighL,
            pointerEvents: 'none',
            opacity: armOnly ? 0 : 1,
            transition: 'opacity 180ms ease',
          }}
        >
          <defs>
            <clipPath id="shinLClipSmooth">
              <path d="M 0 19.0 L 5.2 19.0 A 26.5 26.5 0 0 1 58.2 19.0 L 62 19.0 L 62 122 L 0 122 Z" />
            </clipPath>
          </defs>
          <g ref={thighLGroup} transform={restThighLMat}>
            <circle cx="27.5" cy="96.0" r="26.5" fill="#000000" />
            <image
              href={activeImages.thighL}
              preserveAspectRatio={stretches('thighL') ? 'none' : undefined}
              width={activeGeom.thighL.w}
              height={activeGeom.thighL.h}
            />
          </g>
          <g ref={shinLGroup} transform={restShinLMat} clipPath="url(#shinLClipSmooth)">
            <image
              href={activeImages.shinL}
              preserveAspectRatio={stretches('shinL') ? 'none' : undefined}
              width={activeGeom.shinL.w}
              height={activeGeom.shinL.h}
            />
          </g>
          <g ref={thighBridgeLGroup} transform={restThighLMat}>
            <line
              ref={thighBridgeLLine}
              x1="28.8"
              y1="62.0"
              x2="27.5"
              y2="96.0"
              stroke={tuning.pantsColor}
              strokeWidth={42.2 * bScale}
              strokeLinecap="round"
            />
          </g>
          <g ref={shinBridgeLGroup} transform={restShinLMat}>
            <line
              ref={shinBridgeLLine}
              x1="31.7"
              y1="19.0"
              x2="29.4"
              y2="48.0"
              stroke={tuning.pantsColor}
              strokeWidth={42.2 * bScale}
              strokeLinecap="round"
            />
            <path
              ref={creaseKneeLEl}
              d="M 6.2 20.2 Q 11.8 22.8 15.2 26.5"
              fill="none"
              stroke="#000000"
              strokeWidth="3.5"
              strokeLinecap="round"
              style={{ opacity: 0 }}
            />
          </g>
        </svg>}

        {/* Composite Front Arm (upperArmL + foreArmL) with seamless elbow joint */}
        {!texturedLimbs && <svg
          ref={armLSvg}
          viewBox="0 0 700 800"
          width={700}
          height={800}
          style={{
            position: 'absolute',
            left: 0,
            top: 0,
            overflow: 'visible',
            zIndex: BASE_Z.upperArmL,
            pointerEvents: 'none',
          }}
        >
          <defs>
            {/* Tangential circular cap clip so the top of foreArmL never pokes out at the elbow */}
            <clipPath id="foreClipSmooth">
              <path d="M 18.5 29.0 L 26.85 6.35 A 16.5 16.5 0 0 1 57.55 18.45 L 60 32 L 60 95 L 0 95 L 0 29.0 Z" />
            </clipPath>

          </defs>

          {/* 1. Outlined segments */}
          <g ref={upArmLGroup} transform={restUpLMat}>
            <circle cx="16.7" cy="72.4" r="16.5" fill="#000000" />
            <image
              href={activeImages.upperArmL}
              preserveAspectRatio={stretches('upperArmL') ? 'none' : undefined}
              width={activeGeom.upperArmL.w}
              height={activeGeom.upperArmL.h}
            />
          </g>
          <g ref={foreArmLGroup} transform={restForeLMat} clipPath="url(#foreClipSmooth)">
            <image
              href={activeImages.foreArmL}
              preserveAspectRatio={stretches('foreArmL') ? 'none' : undefined}
              width={activeGeom.foreArmL.w}
              height={activeGeom.foreArmL.h}
            />
          </g>

          {/* 2. Interior sleeve bridge that masks the black outline inside the bent elbow */}
          <g ref={upBridgeLGroup} transform={restUpLMat}>
            <line
              ref={upBridgeLLine}
              x1="27.5"
              y1="45.0"
              x2="16.7"
              y2="72.4"
              stroke={tuning.sleeveColor}
              strokeWidth={24.2 * bScale}
              strokeLinecap="round"
            />
          </g>
          <g ref={foreBridgeLGroup} transform={restForeLMat}>
            <line
              ref={foreBridgeLLine}
              x1="42.2"
              y1="12.4"
              x2="35.4"
              y2="30.0"
              stroke={tuning.sleeveColor}
              strokeWidth={24.4 * bScale}
              strokeLinecap="round"
            />
            <path
              ref={creaseArmSubEl}
              d="M 27.6 11.2 Q 33.8 14.5 37.5 20.2"
              fill="none"
              stroke={character === 'char2' ? '#3D4452' : '#004422'}
              strokeWidth="3.0"
              strokeLinecap="round"
              style={{ opacity: 0 }}
            />
            <path
              ref={creaseArmMainEl}
              d="M 27.4 11.0 Q 31.8 13.4 34.6 16.8"
              fill="none"
              stroke="#000000"
              strokeWidth="3.1"
              strokeLinecap="round"
              style={{ opacity: 0 }}
            />
          </g>


        </svg>}
      </div>
    </div>
  );
});

export default CharacterRig;
