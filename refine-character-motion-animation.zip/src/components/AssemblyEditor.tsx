import { useEffect, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';
import Stage from './Stage';
import { createCalibration, parseCalibration, readCalibration, saveCalibration,
  PART_LABELS, JOINT_LABELS, type CalibrationDocument } from '../rig/calibration';
import { CHARACTER_REFERENCES } from '../rig/referenceImages';
import { drawItems, fitPart, loadImage, measureAssembly } from '../rig/referenceFit';
import { PART_ORDER, VIEW, type CharacterId, type JointKey, type PartGeom, type PartKey, type RigTuning } from '../rig/rigData';
import type { Mode } from '../rig/animator';
import './assembly-editor.css';

interface Props {
  character: CharacterId;
  tuning: RigTuning;
  onApply: (doc: CalibrationDocument) => boolean;
  onBack: () => void;
}
type Target = 'part' | 'joint' | 'reference';
type ViewMode = 'overlay' | 'difference' | 'assembly' | 'reference';
const transform = (g: PartGeom) => `translate(${g.cx} ${g.cy}) rotate(${g.rot}) translate(${-g.w/2} ${-g.h/2})`;
const round = (n: number) => Math.round(n * 100) / 100;

export default function AssemblyEditor({ character, tuning, onApply, onBack }: Props) {
  const [doc, setDoc] = useState<CalibrationDocument>(() => readCalibration(character) ?? readCalibration(character, true) ?? createCalibration(character));
  const docRef = useRef(doc);
  const [past, setPast] = useState<CalibrationDocument[]>([]);
  const [future, setFuture] = useState<CalibrationDocument[]>([]);
  const [target, setTarget] = useState<Target>('part');
  const [part, setPart] = useState<PartKey>('head');
  const [joint, setJoint] = useState<JointKey>('elbowL');
  const [view, setView] = useState<ViewMode>('overlay');
  const [opacity, setOpacity] = useState(.65);
  const [refOpacity, setRefOpacity] = useState(.7);
  const [zoom, setZoom] = useState(1);
  const [showJoints, setShowJoints] = useState(false);
  const [lockAspect, setLockAspect] = useState(true);
  const [preview, setPreview] = useState(false);
  const [previewMode, setPreviewMode] = useState<Mode>('walk');
  const [saved, setSaved] = useState(true);
  const [message, setMessage] = useState('Черновик отдельно от исходного пресета. Проверяйте суставы после подгонки деталей.');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const [metric, setMetric] = useState<Awaited<ReturnType<typeof measureAssembly>> | null>(null);
  const svg = useRef<SVGSVGElement>(null);
  const board = useRef<HTMLDivElement>(null);
  const [boardWidth, setBoardWidth] = useState(600);
  const abort = useRef<AbortController | null>(null);
  const drag = useRef<{ start: CalibrationDocument; x: number; y: number; target: Target; part: PartKey; joint: JointKey; moved: boolean } | null>(null);
  const referenceInput = useRef<HTMLInputElement>(null);
  const partInput = useRef<HTMLInputElement>(null);
  const jsonInput = useRef<HTMLInputElement>(null);

  function replace(next: CalibrationDocument) { docRef.current = next; setDoc(next); }
  function commit(next: CalibrationDocument) {
    const previous = docRef.current;
    setPast(p => [...p.slice(-39), previous]); setFuture([]); replace(next);
  }
  function undo() {
    if (!past.length || busy) return;
    const previous = docRef.current;
    setFuture(f => [previous, ...f]); replace(past[past.length - 1]); setPast(p => p.slice(0, -1));
  }
  function redo() {
    if (!future.length || busy) return;
    const previous = docRef.current;
    setPast(p => [...p, previous]); replace(future[0]); setFuture(f => f.slice(1));
  }

  useEffect(() => { const timer = setTimeout(() => setSaved(saveCalibration(doc)), 300); return () => clearTimeout(timer); }, [doc]);
  useEffect(() => {
    let cancelled = false;
    const timer = setTimeout(() => {
      measureAssembly(doc).then(value => { if (!cancelled) setMetric(value); })
        .catch(() => { if (!cancelled) setMetric(null); });
    }, 250);
    return () => { cancelled = true; clearTimeout(timer); };
  }, [doc]);
  useEffect(() => () => { abort.current?.abort(); saveCalibration(docRef.current); }, []);
  useEffect(() => {
    const el = board.current; if (!el) return;
    const resize = new ResizeObserver(() => setBoardWidth(el.clientWidth));
    resize.observe(el); setBoardWidth(el.clientWidth);
    return () => resize.disconnect();
  }, [preview]);

  function changeGeometry(current: CalibrationDocument, g: PartGeom, which = target, selected = part): CalibrationDocument {
    return which === 'reference'
      ? { ...current, reference: { ...current.reference, geometry: g } }
      : { ...current, rig: { ...current.rig, geometry: { ...current.rig.geometry, [selected]: g } } };
  }
  const geometry = target === 'reference' ? doc.reference.geometry : doc.rig.geometry[part];

  function field(key: keyof PartGeom, value: number) {
    if (!Number.isFinite(value) || busy) return;
    const g = { ...geometry, [key]: key === 'w' || key === 'h' ? Math.max(.1, Math.min(2500, value)) : Math.max(-2000, Math.min(4000, value)) };
    if (key === 'rot') g.rot = Math.max(-360, Math.min(360, value));
    if (lockAspect && key === 'w') g.h = Math.min(2500, g.w * geometry.h / geometry.w);
    if (lockAspect && key === 'h') g.w = Math.min(2500, g.h * geometry.w / geometry.h);
    commit(changeGeometry(docRef.current, g));
  }
  function jointField(axis: 'x' | 'y', value: number) {
    if (!Number.isFinite(value) || busy) return;
    commit({ ...doc, rig: { ...doc.rig, joints: { ...doc.rig.joints,
      [joint]: { ...doc.rig.joints[joint], [axis]: Math.max(-2000, Math.min(4000, value)) } } } });
  }
  function point(e: ReactPointerEvent<SVGElement>) {
    const matrix = svg.current?.getScreenCTM();
    if (!matrix) return { x: 0, y: 0 };
    return new DOMPoint(e.clientX, e.clientY).matrixTransform(matrix.inverse());
  }
  function start(e: ReactPointerEvent<SVGElement>, type: Target, selectedPart = part, selectedJoint = joint) {
    if (busy || e.button !== 0) return;
    e.preventDefault(); e.stopPropagation();
    const p = point(e);
    drag.current = { start: docRef.current, x: p.x, y: p.y, target: type, part: selectedPart, joint: selectedJoint, moved: false };
    setTarget(type); setPart(selectedPart); setJoint(selectedJoint);
    svg.current?.setPointerCapture(e.pointerId); svg.current?.focus();
  }
  function move(e: ReactPointerEvent<SVGSVGElement>) {
    const d = drag.current; if (!d) return;
    const p = point(e), dx = p.x - d.x, dy = p.y - d.y;
    if (Math.abs(dx) + Math.abs(dy) < .01) return;
    d.moved = true;
    if (d.target === 'joint') {
      const j = d.start.rig.joints[d.joint];
      replace({ ...d.start, rig: { ...d.start.rig, joints: { ...d.start.rig.joints,
        [d.joint]: { x: j.x + dx, y: j.y + dy } } } });
    } else {
      const g = d.target === 'reference' ? d.start.reference.geometry : d.start.rig.geometry[d.part];
      replace(changeGeometry(d.start, { ...g, cx: g.cx + dx, cy: g.cy + dy }, d.target, d.part));
    }
  }
  function finish(e: ReactPointerEvent<SVGSVGElement>) {
    const d = drag.current; if (!d) return;
    if (d.moved) { setPast(p => [...p.slice(-39), d.start]); setFuture([]); }
    drag.current = null;
    if (svg.current?.hasPointerCapture(e.pointerId)) svg.current.releasePointerCapture(e.pointerId);
  }
  async function autoFit() {
    if (busy) return;
    const startDoc = docRef.current;
    const controller = new AbortController(); abort.current = controller;
    setBusy(true); setProgress(0); setError('');
    try {
      const result = await fitPart(startDoc, part, controller.signal, setProgress);
      if (controller.signal.aborted) return;
      if (result.after < result.before - .001) {
        commit(changeGeometry(startDoc, result.geometry, 'part', part));
        setMessage('Локальная ошибка уменьшилась. Проверьте силуэт, перекрытия и центры суставов.');
      } else setMessage('Улучшения рядом с текущим положением не найдено. Возможно, деталь перекрыта или уже совмещена.');
    } catch (e) {
      if (!(e instanceof DOMException && e.name === 'AbortError')) setError(e instanceof Error ? e.message : 'Ошибка подгонки.');
      else setMessage('Подгонка отменена. Сборка не изменена.');
    } finally { setBusy(false); abort.current = null; }
  }
  function exportJson() {
    const url = URL.createObjectURL(new Blob([JSON.stringify(docRef.current, null, 2)], { type: 'application/json' }));
    const a = document.createElement('a'); a.href = url; a.download = `${character}-calibration.json`; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    setMessage('JSON экспортирован: геометрия, суставы и пользовательские изображения.');
  }
  async function importJson(file?: File) {
    if (!file) return;
    try {
      if (file.size > 8_000_000) throw new Error('JSON слишком большой: максимум 8 МБ.');
      const imported = parseCalibration(JSON.parse(await file.text()), character);
      const sources = [...Object.values(imported.rig.images ?? {}), imported.reference.source].filter(Boolean) as string[];
      const decoded = await Promise.all(sources.map(loadImage));
      if (decoded.some(im => im.naturalWidth > 8000 || im.naturalHeight > 8000)) throw new Error('Изображение в JSON превышает 8000 px.');
      commit(imported); setError(''); setMessage('Калибровка импортирована. Её можно отменить или проверить в движении.');
    } catch (e) { setError(e instanceof Error ? e.message : 'Не удалось импортировать JSON.'); }
  }
  async function upload(file: File | undefined, type: 'part' | 'reference') {
    if (!file) return;
    try {
      if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type) || file.size > 2_000_000) throw new Error('Выберите PNG, JPEG или WebP до 2 МБ.');
      const source = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader(); reader.onload = () => resolve(String(reader.result)); reader.onerror = reject; reader.readAsDataURL(file);
      });
      const image = await loadImage(source);
      if (image.naturalWidth > 8000 || image.naturalHeight > 8000) throw new Error('Изображение слишком большое: максимум 8000 px по стороне.');
      if (type === 'reference') {
        const scale = Math.min(VIEW.w/image.naturalWidth, VIEW.h/image.naturalHeight);
        commit({ ...docRef.current, reference: { source, geometry: { cx: VIEW.x+VIEW.w/2, cy: VIEW.y+VIEW.h/2,
          w: image.naturalWidth*scale, h: image.naturalHeight*scale, rot: 0 } } });
        setTarget('reference'); setView('overlay');
      } else commit({ ...docRef.current, rig: { ...docRef.current.rig, images: { ...docRef.current.rig.images, [part]: source } } });
      setError(''); setMessage(type === 'reference' ? 'Референс загружен. Совместите его масштаб и положение; прозрачный PNG даёт корректную метрику силуэта.' : 'Изображение детали заменено. Подгоните размер и точки суставов.');
    } catch (e) { setError(e instanceof Error ? e.message : 'Не удалось загрузить файл.'); }
  }
  function resetSelected() {
    const original = createCalibration(character);
    if (target === 'joint') {
      commit({ ...doc, rig: { ...doc.rig, joints: { ...doc.rig.joints, [joint]: original.rig.joints[joint] } } });
    } else if (target === 'reference') commit({ ...doc, reference: original.reference });
    else {
      const images = { ...doc.rig.images }; delete images[part];
      commit({ ...doc, rig: { ...doc.rig, images, geometry: { ...doc.rig.geometry, [part]: original.rig.geometry[part] } } });
    }
  }

  const items = drawItems(doc);
  const activeName = target === 'joint' ? JOINT_LABELS[joint] : target === 'reference' ? 'Референс' : PART_LABELS[part];
  const canvasWidth = Math.min(boardWidth, 600 * VIEW.w / VIEW.h) * zoom;
  return (
    <section className="assembly-editor" aria-label="Редактор сборки" onKeyDown={e => {
      if (busy || /INPUT|SELECT|TEXTAREA/.test((e.target as HTMLElement).tagName)) return;
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); if (e.shiftKey) redo(); else undo(); }
      if (!preview && ['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)) {
        e.preventDefault(); const amount = (e.shiftKey ? 5 : .5) * (['ArrowLeft','ArrowUp'].includes(e.key) ? -1 : 1);
        const horizontal = ['ArrowLeft','ArrowRight'].includes(e.key);
        if (target === 'joint') jointField(horizontal ? 'x' : 'y', doc.rig.joints[joint][horizontal ? 'x' : 'y'] + amount);
        else field(horizontal ? 'cx' : 'cy', geometry[horizontal ? 'cx' : 'cy'] + amount);
      }
    }}>
      <div className="editor-heading">
        <div><h2>Сборка по референсу</h2><p>Совместите детали с примером, затем проверьте сгибы в движении.</p></div>
        <button type="button" onClick={onBack} disabled={busy}>Назад к анимации</button>
      </div>
      <div className="editor-toolbar">
        <div className="editor-tabs">
          <button type="button" aria-pressed={!preview} onClick={() => setPreview(false)}>Сборка</button>
          <button type="button" aria-pressed={preview} onClick={() => setPreview(true)} disabled={busy}>Проверить движение</button>
        </div>
        <div className="editor-history">
          <button type="button" onClick={undo} disabled={!past.length || busy}>Отменить</button>
          <button type="button" onClick={redo} disabled={!future.length || busy}>Повторить</button>
          <button type="button" onClick={exportJson}>Экспорт JSON</button>
          <button type="button" onClick={() => jsonInput.current?.click()} disabled={busy}>Импорт JSON</button>
        </div>
      </div>
      <div className="editor-workspace">
        <div className="editor-view">
          {preview ? <>
            <div className="editor-view-controls"><label>Движение
              <select aria-label="Движение в редакторе" value={previewMode} onChange={e => setPreviewMode(e.target.value as Mode)}>
                <option value="idle">Покой</option><option value="walk">Ходьба</option><option value="run">Бег</option><option value="wave">Махание</option>
              </select></label><span>Тот же аниматор, текущая сборка</span></div>
            <Stage mode={previewMode} character={character} tuning={tuning} calibration={doc.rig} />
          </> : <>
            <div className="editor-view-controls">
              <label>Вид <select aria-label="Режим сравнения" value={view} onChange={e => setView(e.target.value as ViewMode)}>
                <option value="overlay">Наложение</option><option value="difference">Разница</option>
                <option value="assembly">Только сборка</option><option value="reference">Только пример</option>
              </select></label>
              <label>Масштаб {Math.round(zoom*100)}%<input aria-label="Масштаб редактора" type="range" min="0.7" max="2" step="0.1" value={zoom} onChange={e => setZoom(Number(e.target.value))} /></label>
              <label className="editor-check"><input type="checkbox" checked={showJoints} onChange={e => setShowJoints(e.target.checked)} />Суставы</label>
            </div>
            <div className="editor-board" ref={board}>
              <svg ref={svg} tabIndex={0} aria-label="Холст сборки: перетаскивайте детали и суставы"
                viewBox={`${VIEW.x} ${VIEW.y} ${VIEW.w} ${VIEW.h}`} style={{ width: canvasWidth, height: canvasWidth * VIEW.h / VIEW.w }}
                onPointerMove={move} onPointerUp={finish} onPointerCancel={finish}
                onPointerDown={e => { if (target === 'reference') start(e, 'reference'); }}>
                {view !== 'assembly' && <image href={doc.reference.source ?? CHARACTER_REFERENCES[character]}
                  {...{ width: doc.reference.geometry.w, height: doc.reference.geometry.h }} transform={transform(doc.reference.geometry)}
                  opacity={view === 'overlay' ? refOpacity : 1} preserveAspectRatio="none" pointerEvents="none" />}
                {view !== 'reference' && <g opacity={view === 'overlay' ? opacity : 1} style={{ mixBlendMode: view === 'difference' ? 'difference' : 'normal' }}>
                  {items.map(item => <image key={item.key} data-part={item.part} href={item.source} width={item.geometry.w} height={item.geometry.h}
                    transform={transform(item.geometry)} preserveAspectRatio="none"
                    style={{ cursor: target === 'part' ? 'move' : 'default' }} pointerEvents={target === 'part' && item.part ? 'visiblePainted' : 'none'}
                    onPointerDown={e => { if (item.part && target === 'part') start(e, 'part', item.part); }} />)}
                </g>}
                {target === 'part' && <g transform={transform(doc.rig.geometry[part])}>
                  <rect x={0} y={0} width={doc.rig.geometry[part].w} height={doc.rig.geometry[part].h}
                    fill="none" stroke="#ef9d32" strokeWidth="1.5" strokeDasharray="5 3" vectorEffect="non-scaling-stroke"
                    pointerEvents="stroke" onPointerDown={e => start(e, 'part')} />
                  <circle cx={doc.rig.geometry[part].w/2} cy={doc.rig.geometry[part].h/2} r="3" fill="#ef9d32" pointerEvents="none" />
                </g>}
                {(showJoints || target === 'joint') && (Object.keys(JOINT_LABELS) as JointKey[]).map(key =>
                  <circle key={key} cx={doc.rig.joints[key].x} cy={doc.rig.joints[key].y} r={key === joint && target === 'joint' ? 6 : 4.5}
                    fill={key === joint && target === 'joint' ? '#ffb44c' : '#63d8eb'} stroke="#173141" strokeWidth="1.5"
                    style={{ cursor: 'move' }} onPointerDown={e => start(e, 'joint', part, key)}><title>{JOINT_LABELS[key]}</title></circle>)}
              </svg>
            </div>
            <div className="editor-opacity">
              <label>Детали {Math.round(opacity*100)}%<input aria-label="Прозрачность деталей" type="range" min="0" max="1" step="0.05" value={opacity} onChange={e => setOpacity(Number(e.target.value))} disabled={view !== 'overlay'} /></label>
              <label>Референс {Math.round(refOpacity*100)}%<input aria-label="Прозрачность референса" type="range" min="0" max="1" step="0.05" value={refOpacity} onChange={e => setRefOpacity(Number(e.target.value))} disabled={view !== 'overlay'} /></label>
            </div>
          </>}
          <div className="editor-metrics" aria-live="polite">
            <span>Силуэт IoU <b>{metric ? metric.silhouette.toFixed(1)+'%' : '...'}</b></span>
            <span>Ошибка цвета <b>{metric ? metric.colorError.toFixed(1)+' / 255' : '...'}</b></span>
          </div>
          <p className="editor-note">Сравниваются исходные детали в нулевой позе, без анимационных масок. Метрики не оценивают качество сгибов. Чёрное внутри фигуры в режиме «Разница» означает совпадение цветов.</p>
        </div>
        <aside className="editor-inspector">
          <fieldset disabled={busy}>
            <legend>Настройка сборки</legend>
            <div className="editor-targets">
              <button type="button" aria-pressed={target === 'part'} onClick={() => setTarget('part')}>Деталь</button>
              <button type="button" aria-pressed={target === 'joint'} onClick={() => setTarget('joint')}>Сустав</button>
              <button type="button" aria-pressed={target === 'reference'} onClick={() => setTarget('reference')}>Референс</button>
            </div>
            {target === 'part' && <label className="editor-select">Деталь
              <select value={part} onChange={e => setPart(e.target.value as PartKey)}>{PART_ORDER.map(key => <option key={key} value={key}>{PART_LABELS[key]}</option>)}</select>
            </label>}
            {target === 'joint' && <label className="editor-select">Сустав
              <select value={joint} onChange={e => setJoint(e.target.value as JointKey)}>{(Object.keys(JOINT_LABELS) as JointKey[]).map(key => <option key={key} value={key}>{JOINT_LABELS[key]}</option>)}</select>
            </label>}
            <h3>{activeName}</h3>
            {target === 'joint' ? <div className="editor-fields">
              {(['x','y'] as const).map(axis => <label key={axis}>Сустав {axis.toUpperCase()}
                <input type="number" step="0.5" min="-2000" max="4000" value={round(doc.rig.joints[joint][axis])} onChange={e => jointField(axis, Number(e.target.value))} /></label>)}
            </div> : <>
              <div className="editor-fields">
                {(['cx','cy','w','h','rot'] as const).map((key,i) => <label key={key}>{['Центр X','Центр Y','Ширина','Высота','Поворот'][i]}
                  <input type="number" step={key === 'rot' ? .25 : .5} min={key === 'w' || key === 'h' ? .1 : key === 'rot' ? -360 : -2000}
                    max={key === 'w' || key === 'h' ? 2500 : key === 'rot' ? 360 : 4000} value={round(geometry[key])} onChange={e => field(key, Number(e.target.value))} /></label>)}
              </div>
              <label className="editor-check"><input type="checkbox" checked={lockAspect} onChange={e => setLockAspect(e.target.checked)} />Сохранять пропорции</label>
            </>}
            <button className="editor-reset-selected" type="button" onClick={resetSelected}>Вернуть исходное положение</button>
            {target === 'joint' && <p className="editor-tip">В статике перемещается только ось. Чтобы оценить сгиб, откройте «Проверить движение».</p>}
            {target === 'part' && <div className="editor-fit">
              <button type="button" className="editor-primary" onClick={autoFit}>Подогнать деталь по примеру</button>
              <p>Локальный поиск: до 12 px, 4° и 5% масштаба. Нужна примерно верная сборка. Перекрытые участки неоднозначны.</p>
              <button type="button" onClick={() => partInput.current?.click()}>Заменить изображение детали</button>
            </div>}
            <div className="editor-import-ref">
              <button type="button" onClick={() => referenceInput.current?.click()}>Загрузить свой референс</button>
              <p>Прозрачный PNG предпочтительнее. Для фото с фоном метрика силуэта не показательна.</p>
            </div>
          </fieldset>
          {busy && <div className="editor-progress" role="status"><progress max="100" value={progress} /><span>Поиск совпадения...</span><button type="button" onClick={() => abort.current?.abort()}>Остановить поиск</button></div>}
          <p className="editor-tip">Перетащите деталь на холсте или используйте стрелки: 0,5 px, с Shift: 5 px. Положение суставов редактируется отдельно.</p>
          <div className="editor-apply">
            <button type="button" className="editor-primary" disabled={busy} onClick={() => {
              if (!onApply(docRef.current)) setError('Сборка применена в текущем сеансе, но не сохранена: экспортируйте JSON, в браузере недостаточно места.');
            }}>Применить к анимации</button>
            <button type="button" disabled={busy} onClick={() => { commit(createCalibration(character)); setMessage('Пресет восстановлен. Действие можно отменить.'); }}>Сбросить всю сборку</button>
          </div>
        </aside>
      </div>
      <div className="editor-status"><span className={saved ? '' : 'editor-warning'}>{saved ? 'Черновик сохраняется в этом браузере' : 'Черновик не сохранён: экспортируйте JSON'}</span><span role="status">{message}</span></div>
      {error && <p role="alert" className="editor-error">{error}</p>}
      <input ref={referenceInput} type="file" accept="image/png,image/jpeg,image/webp" hidden onChange={e => { void upload(e.target.files?.[0], 'reference'); e.target.value=''; }} />
      <input ref={partInput} type="file" accept="image/png,image/jpeg,image/webp" hidden onChange={e => { void upload(e.target.files?.[0], 'part'); e.target.value=''; }} />
      <input ref={jsonInput} type="file" accept="application/json,.json" hidden onChange={e => { void importJson(e.target.files?.[0]); e.target.value=''; }} />
    </section>
  );
}