import { useEffect, useRef, useState } from 'react';
import CharacterRig, { type RigHandle } from './CharacterRig';
import { LAYERS } from './scenery';
import { Animator, type Mode, type WaveVariant } from '../rig/animator';
import { zeroPose } from '../rig/kinematics';
import { DEFAULT_TUNING, VIEW, type CharacterId, type RigTuning, type RigCalibration } from '../rig/rigData';

interface StageProps {
  mode: Mode;
  character?: CharacterId;
  tuning?: RigTuning;
  waveVariant?: WaveVariant;
  zoomElbow?: boolean;
  zoomKnees?: boolean;
  armOnly?: boolean;
  referencePose?: boolean;
  calibration?: RigCalibration;
}

// distance (rig px) between the soles of the shoes and the bottom of the rig view
const FEET_TO_BOTTOM = VIEW.y + VIEW.h - 752;
const FEET_LEVEL = 0.105; // feet sit at this fraction of the stage height
const REFERENCE_POSE = zeroPose();

export default function Stage({
  mode,
  character = 'char2',
  tuning = DEFAULT_TUNING[character],
  waveVariant = 'seamless',
  zoomElbow = false,
  zoomKnees = false,
  armOnly = false,
  referencePose = false,
  calibration,
}: StageProps) {
  const holder = useRef<HTMLDivElement | null>(null);
  const rig = useRef<RigHandle | null>(null);
  const layerEls = useRef<(HTMLDivElement | null)[]>([]);
  const animator = useRef<Animator>(new Animator());
  const variantRef = useRef<WaveVariant>(waveVariant);
  variantRef.current = waveVariant;
  const charRef = useRef<CharacterId>(character);
  charRef.current = character;
  const tuningRef = useRef<RigTuning>(tuning);
  tuningRef.current = tuning;
  const referenceRef = useRef(referencePose);
  referenceRef.current = referencePose;
  const calibrationRef = useRef(calibration);
  calibrationRef.current = calibration;

  const [size, setSize] = useState({ w: 900, h: 520 });
  const sizeRef = useRef(size);
  sizeRef.current = size;

  useEffect(() => {
    animator.current.setMode(mode);
  }, [mode]);

  useEffect(() => {
    animator.current.setWaveVariant(waveVariant);
  }, [waveVariant]);

  useEffect(() => {
    const el = holder.current;
    if (!el) return;
    const ro = new ResizeObserver(() => {
      setSize({ w: el.clientWidth, h: el.clientHeight });
    });
    ro.observe(el);
    setSize({ w: el.clientWidth, h: el.clientHeight });
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    let travelled = 0;

    const tick = (now: number) => {
      const dt = (now - last) / 1000;
      last = now;
      const frame = animator.current.step(dt);
      const pose = referenceRef.current ? REFERENCE_POSE : frame.pose;
      rig.current?.apply(
        pose,
        // While waving the raised arm is drawn over the body; the run swing
        // keeps its own threshold.
        (!referenceRef.current && frame.wave > 0.5) || pose.armL > 45,
        variantRef.current,
        charRef.current,
        tuningRef.current,
        calibrationRef.current,
      );

      const { h } = sizeRef.current;
      const k = (h * 0.86) / VIEW.h;
      travelled += (referenceRef.current ? 0 : frame.speed) * k * dt;
      LAYERS.forEach((layer, i) => {
        const el = layerEls.current[i];
        if (!el) return;
        const tileW = layer.height * h * layer.aspect;
        el.style.backgroundPositionX = `${-((travelled * layer.factor) % tileW)}px`;
      });

      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, []);

  const k = (size.h * 0.86) / VIEW.h;
  const isElbowCloseUp = zoomElbow || armOnly;
  const effectiveScale = isElbowCloseUp ? k * 2.45 : zoomKnees ? k * 2.15 : k;
  const offsetX = isElbowCloseUp ? 225 * k : zoomKnees ? 0 : 0;
  const offsetY = isElbowCloseUp ? 390 * k : zoomKnees ? 95 * k : 0;

  return (
    <div
      ref={holder}
      className="relative w-full h-[420px] sm:h-[520px] overflow-hidden rounded-[28px] border border-white/15 shadow-2xl shadow-black/50"
      style={{
        background:
          'linear-gradient(180deg, #7fb0ff 0%, #a9c4ff 38%, #f6d2ec 78%, #ffe6cf 100%)',
      }}
    >
      {/* sun */}
      <div
        className="absolute rounded-full"
        style={{
          right: '9%',
          top: '9%',
          width: size.h * 0.17,
          height: size.h * 0.17,
          background:
            'radial-gradient(circle, #fffbe0 0%, #fff0a8 45%, rgba(255,240,168,0) 72%)',
          boxShadow: '0 0 60px 20px rgba(255,244,190,0.45)',
        }}
      />

      {LAYERS.map((layer, i) => (
        <div
          key={layer.key}
          ref={(el) => {
            layerEls.current[i] = el;
          }}
          className="absolute left-0 right-0 transition-opacity duration-200"
          style={{
            bottom: layer.bottom * size.h,
            height: layer.height * size.h,
            backgroundImage: layer.image,
            backgroundRepeat: 'repeat-x',
            backgroundSize: `${layer.height * size.h * layer.aspect}px ${layer.height * size.h}px`,
            backgroundPositionY: 'bottom',
            zIndex: layer.key === 'ground' ? 1 : 0,
            opacity: armOnly ? 0.2 : 1,
          }}
        />
      ))}

      {/* ground colour bands (grass + sandy path) sit under the scrolling details */}
      <div
        className="absolute left-0 right-0 bottom-0 transition-opacity duration-200"
        style={{
          height: '24%',
          background:
            'linear-gradient(180deg, #86d08a 0%, #6fbf73 40%, #ecd2a2 40.5%, #dcb987 100%)',
          zIndex: 0,
          opacity: armOnly ? 0.2 : 1,
        }}
      />

      {/* the character */}
      <div
        className="absolute transition-transform duration-300 ease-out"
        style={{
          left: '50%',
          bottom: FEET_LEVEL * size.h - FEET_TO_BOTTOM * k,
          width: VIEW.w,
          height: VIEW.h,
          transform: `translate(calc(-50% + ${offsetX.toFixed(1)}px), ${offsetY.toFixed(1)}px) scale(${effectiveScale})`,
          transformOrigin: '50% 100%',
          zIndex: 2,
        }}
      >
        <CharacterRig
          ref={rig}
          character={character}
          tuning={tuning}
          armOnly={armOnly}
          calibration={calibration}
        />
      </div>
    </div>
  );
}
