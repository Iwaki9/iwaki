import { forwardRef, useId, useImperativeHandle, useRef } from 'react';
import { type M } from '../rig/affine';
import type { PartGeom, Pt } from '../rig/rigData';

export interface MaterialLimbHandle {
  apply: (upper: M, lower: M, bend: number, inFront?: boolean) => void;
}

interface MaterialLimbProps {
  upperImage: string;
  lowerImage: string;
  upperGeom: PartGeom;
  lowerGeom: PartGeom;
  restUpper: M;
  restLower: M;
  joint: Pt;
  radius: number;
  color: string;
  smoothing: number;
  zIndex: number;
  hidden: boolean;
  seamWidth?: number;
  stretch?: boolean;
}

const matrix = (m: M) => `matrix(${m.join(' ')})`;

function localPoint(m: M, p: Pt): Pt {
  const det = m[0] * m[3] - m[1] * m[2];
  const x = p.x - m[4];
  const y = p.y - m[5];
  return { x: (m[3] * x - m[2] * y) / det, y: (m[0] * y - m[1] * x) / det };
}

// Outline-free joints keep the original texture. Only the overlapping cut is rounded.
const MaterialLimb = forwardRef<MaterialLimbHandle, MaterialLimbProps>(function MaterialLimb(
  { upperImage, lowerImage, upperGeom, lowerGeom, restUpper, restLower, joint, radius, color, smoothing, zIndex, hidden, seamWidth = 0, stretch = false },
  ref,
) {
  const id = useId().replace(/:/g, '');
  const upper = useRef<SVGGElement>(null);
  const lower = useRef<SVGGElement>(null);
  const cap = useRef<SVGCircleElement>(null);
  const svg = useRef<SVGSVGElement>(null);
  const cut = useRef<SVGRectElement>(null);
  const upperBridge = useRef<SVGGElement>(null);
  const lowerBridge = useRef<SVGGElement>(null);
  const upJoint = localPoint(restUpper, joint);
  const lowJoint = localPoint(restLower, joint);

  useImperativeHandle(ref, () => ({
    apply(up, low, bend, inFront = false) {
      upper.current?.setAttribute('transform', matrix(up));
      lower.current?.setAttribute('transform', matrix(low));
      const t = Math.min(1, Math.abs(bend) / 12);
      const blend = t * t * (3 - 2 * t) * Math.min(1, Math.max(0, smoothing));
      if (cap.current) cap.current.style.opacity = String(blend);
      if (upperBridge.current) {
        upperBridge.current.setAttribute('transform', matrix(up));
        upperBridge.current.style.opacity = String(blend);
      }
      if (lowerBridge.current) {
        lowerBridge.current.setAttribute('transform', matrix(low));
        lowerBridge.current.style.opacity = String(blend);
      }
      cut.current?.setAttribute('y', String(lowJoint.y - (1 - blend) * radius * 1.2));
      if (svg.current) svg.current.style.zIndex = String(inFront ? 30 : zIndex);
    },
  }), [lowJoint.y, radius, smoothing, zIndex]);

  function bridgeEnd(p: Pt, g: PartGeom) {
    const dx = g.w / 2 - p.x;
    const dy = g.h / 2 - p.y;
    const len = Math.hypot(dx, dy) || 1;
    return { x: p.x + dx / len * 12, y: p.y + dy / len * 12 };
  }
  const upEnd = bridgeEnd(upJoint, upperGeom);
  const lowEnd = bridgeEnd(lowJoint, lowerGeom);

  return (
    <svg
      ref={svg}
      width={700}
      height={800}
      viewBox="0 0 700 800"
      aria-hidden="true"
      style={{ position: 'absolute', left: 0, top: 0, overflow: 'visible', zIndex,
        pointerEvents: 'none', opacity: hidden ? 0 : 1, transition: 'opacity 180ms ease' }}
    >
      <defs>
        <clipPath id={id} clipPathUnits="userSpaceOnUse">
          <circle cx={lowJoint.x} cy={lowJoint.y} r={radius} />
          <rect ref={cut} x={-100} y={lowJoint.y - radius * 1.2} width={lowerGeom.w + 200} height={lowerGeom.h + 200} />
        </clipPath>
      </defs>
      <g ref={upper} transform={matrix(restUpper)}>
        <circle ref={cap} cx={upJoint.x} cy={upJoint.y} r={radius * 0.96} fill={color} style={{ opacity: 0 }} />
        <image href={upperImage} width={upperGeom.w} height={upperGeom.h} preserveAspectRatio={stretch ? 'none' : undefined} />
      </g>
      <g ref={lower} transform={matrix(restLower)}>
        <image href={lowerImage} width={lowerGeom.w} height={lowerGeom.h} preserveAspectRatio={stretch ? 'none' : undefined} clipPath={`url(#${id})`} />
      </g>
      {seamWidth > 0 && <>
        <g ref={upperBridge} transform={matrix(restUpper)} style={{ opacity: 0 }}>
          <line x1={upJoint.x} y1={upJoint.y} x2={upEnd.x} y2={upEnd.y}
            stroke={color} strokeWidth={seamWidth} strokeLinecap="round" />
        </g>
        <g ref={lowerBridge} transform={matrix(restLower)} style={{ opacity: 0 }}>
          <line x1={lowJoint.x} y1={lowJoint.y} x2={lowEnd.x} y2={lowEnd.y}
            stroke={color} strokeWidth={seamWidth} strokeLinecap="round" />
        </g>
      </>}
    </svg>
  );
});

export default MaterialLimb;