import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { build } from 'esbuild';

const root = fileURLToPath(new URL('../', import.meta.url));
const fixture = JSON.parse(readFileSync(new URL('./rig-baseline.json', import.meta.url), 'utf8'));
const result = await build({
  stdin: {
    contents: `
      export * from './src/rig/rigData';
      export * from './src/rig/kinematics';
      export * from './src/rig/animator';
      export * from './src/rig/affine';
      export { PART_IMAGES } from './src/rig/partImages';
      export { CHAR2_PART_IMAGES } from './src/rig/char2Images';
      export { CHAR3_PART_IMAGES } from './src/rig/char3Images';
      export { CHAR4_PART_IMAGES } from './src/rig/char4Images';
      export * from './src/rig/calibration';
    `,
    resolveDir: root,
    sourcefile: 'rig-check.ts',
  },
  bundle: true,
  write: false,
  platform: 'node',
  format: 'esm',
  target: 'node20',
});
const rig = await import(`data:text/javascript;base64,${Buffer.from(result.outputFiles[0].text).toString('base64')}`);
const { solveRig, zeroPose, Animator, CHARACTER_GEOMETRY, CHARACTER_JOINTS, PART_ORDER, mul } = rig;

for (const [name, hash] of Object.entries(fixture.assets)) {
  assert.equal(createHash('sha256').update(readFileSync(`${root}src/rig/${name}`)).digest('hex'), hash,
    `Existing artwork changed: ${name}`);
}
for (const character of Object.keys(fixture.legacy)) {
  for (const [key, pose] of Object.entries(fixture.poses)) {
    const actual = solveRig(pose, character);
    const expected = fixture.legacy[character][key];
    const flatten = (m) => [...Object.values(m.parts).flat(), ...m.hoodL, ...m.hoodR];
    const a = flatten(actual);
    const b = flatten(expected);
    // Chromium and Node can differ by one floating-point rounding unit.
    assert(a.every((v, i) => Math.abs(v - b[i]) < 1e-10),
      `Legacy calibration changed: ${character}/${key}`);
  }
}

function inverse([a, b, c, d, e, f]) {
  const det = a * d - b * c;
  return [d / det, -b / det, -c / det, a / det, (c * f - d * e) / det, (b * e - a * f) / det];
}
function point(m, p) {
  return { x: m[0] * p.x + m[2] * p.y + m[4], y: m[1] * p.x + m[3] * p.y + m[5] };
}
const limbs = [
  ['upperArmL', 'foreArmL', 'elbowL'], ['upperArmR', 'foreArmR', 'elbowR'],
  ['thighL', 'shinL', 'kneeL'], ['thighR', 'shinR', 'kneeR'],
];
const images = { char1: rig.PART_IMAGES, char2: rig.CHAR2_PART_IMAGES, char3: rig.CHAR3_PART_IMAGES, char4: rig.CHAR4_PART_IMAGES };
let frames = 0;
for (const character of ['char1', 'char2', 'char3', 'char4']) {
  const rest = solveRig(zeroPose(), character).parts;
  for (const key of PART_ORDER) {
    const g = CHARACTER_GEOMETRY[character][key];
    assert(Object.values(g).every(Number.isFinite) && g.w > 0 && g.h > 0);
    const png = Buffer.from(images[character][key].split(',')[1], 'base64');
    assert.equal(png.subarray(0, 8).toString('hex'), '89504e470d0a1a0a');
    assert(png.readUInt32BE(16) > 0 && png.readUInt32BE(20) > 0);
  }
  for (const variant of ['seamless', 'crease', 'tailored', 'softCap']) {
    const animator = new Animator();
    animator.setWaveVariant(variant);
    for (const mode of ['idle', 'walk', 'run', 'wave', 'run', 'idle']) {
      animator.setMode(mode);
      for (let i = 0; i < 120; i++) {
        const frame = animator.step(1 / 60);
        assert(Math.abs(Object.values(frame.weights).reduce((a, b) => a + b, 0) - 1) < 1e-10);
        const matrices = solveRig(frame.pose, character).parts;
        assert(Object.values(matrices).flat().every(Number.isFinite));
        for (const [upper, lower, joint] of limbs) {
          const p = CHARACTER_JOINTS[character][joint];
          const a = point(mul(matrices[upper], inverse(rest[upper])), p);
          const b = point(mul(matrices[lower], inverse(rest[lower])), p);
          assert(Math.hypot(a.x - b.x, a.y - b.y) < 1e-8, `${character}: detached ${joint}`);
        }
        frames++;
      }
    }
  }
}

const document = rig.createCalibration('char4');
assert.deepEqual(rig.parseCalibration(JSON.parse(JSON.stringify(document)), 'char4'), document);
assert.throws(() => rig.parseCalibration({ ...document, version: 99 }));
assert.throws(() => rig.parseCalibration(document, 'char2'));
const broken = structuredClone(document); broken.rig.geometry.head.w = -1;
assert.throws(() => rig.parseCalibration(broken));
broken.rig.geometry.head.w = 100; broken.rig.joints.elbowL.x = Infinity;
assert.throws(() => rig.parseCalibration(broken));
const unsafe = structuredClone(document); unsafe.rig.images = { head: 'data:image/svg+xml;base64,PHN2Zy8+' };
assert.throws(() => rig.parseCalibration(unsafe));
const original = solveRig(fixture.poses['wave-3'], 'char4');
const edited = structuredClone(document.rig);
edited.geometry.head.cx += 10;
edited.joints.elbowL.x += 3;
const changed = solveRig(fixture.poses['wave-3'], 'char4', undefined, edited);
assert.notDeepEqual(changed.parts.head, original.parts.head);
assert.notDeepEqual(changed.parts.foreArmL, original.parts.foreArmL);
assert.deepEqual(solveRig(fixture.poses['wave-3'], 'char4'), original, 'Editing mutated the built-in preset');
console.log(`PASS: legacy artwork and matrices unchanged; ${frames} frames, four presets, continuous pivots, calibration validation and isolation.`);