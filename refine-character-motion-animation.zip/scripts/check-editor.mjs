import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const { chromium } = await import(process.env.PLAYWRIGHT_MODULE || 'playwright');
const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 1366, height: 1100 }, acceptDownloads: true });
const errors = [];
page.on('pageerror', e => errors.push(e.message));
const base = process.env.BASE_URL || 'http://localhost:5173';
await page.goto(base);
await page.getByRole('button', { name: 'Редактор сборки', exact: true }).click();
await page.locator('.assembly-editor').scrollIntoViewIfNeeded();
await page.waitForTimeout(700);
const number = name => page.getByRole('spinbutton', { name, exact: true });
const initialX = Number(await number('Центр X').inputValue());
const initialY = Number(await number('Центр Y').inputValue());
const metric = async () => parseFloat(await page.locator('.editor-metrics b').nth(1).innerText());
const initialError = await metric();
assert(Number.isFinite(initialError));
await number('Центр X').fill(String(initialX + 8));
await number('Центр Y').fill(String(initialY + 6));
await page.waitForTimeout(600);
const displacedError = await metric();
assert(displacedError > initialError + 1, 'Moving the head should worsen image comparison');
await page.getByRole('button', { name: 'Подогнать деталь по примеру', exact: true }).click();
await page.getByText(/Локальная ошибка уменьшилась/).waitFor({ timeout: 30000 });
await page.waitForTimeout(600);
const fittedError = await metric();
assert(fittedError < displacedError, 'Reference refinement did not improve image loss');
const fittedX = Number(await number('Центр X').inputValue());
assert(Math.abs(fittedX-initialX) < 2, 'Fit should recover a nearby shifted head');
await page.getByRole('button', { name: 'Отменить', exact: true }).click();
assert(Math.abs(Number(await number('Центр X').inputValue())-(initialX+8)) < .02);
await page.getByRole('button', { name: 'Повторить', exact: true }).click();
assert.equal(Number(await number('Центр X').inputValue()), fittedX);
await page.getByRole('button', { name: 'Вернуть исходное положение', exact: true }).click();

// Pointer dragging uses SVG coordinates, including responsive scale and zoom.
const canvas = page.locator('.editor-board svg');
await canvas.scrollIntoViewIfNeeded();
const pt = await canvas.evaluate((el, p) => {
  const q = new DOMPoint(p.x,p.y).matrixTransform(el.getScreenCTM()); return { x:q.x,y:q.y };
}, { x:initialX, y:initialY });
await page.mouse.move(pt.x,pt.y); await page.mouse.down(); await page.mouse.move(pt.x+14,pt.y+7,{steps:5}); await page.mouse.up();
assert(Number(await number('Центр X').inputValue()) > initialX+5, 'Dragging did not move the selected part');
await page.getByRole('button', { name:'Отменить', exact:true }).click();
assert(Math.abs(Number(await number('Центр X').inputValue())-initialX)<.02);

await page.getByRole('button', {name:'Сустав',exact:true}).click();
const jointX = Number(await number('Сустав X').inputValue());
await number('Сустав X').fill(String(jointX+3));
await page.getByRole('button', {name:'Деталь',exact:true}).click();
await page.getByLabel('Режим сравнения').selectOption('difference');
assert(await page.locator('.editor-board svg g').first().evaluate(el=>el.style.mixBlendMode==='difference'));
await page.getByLabel('Режим сравнения').selectOption('overlay');

const refData = await page.locator('.editor-board svg > image').getAttribute('href');
const partData = await page.locator('.editor-board [data-part="head"]').getAttribute('href');
const imageInputs = page.locator('.assembly-editor input[type=file]');
await imageInputs.nth(0).setInputFiles({name:'reference.png',mimeType:'image/png',buffer:Buffer.from(refData.split(',')[1],'base64')});
await page.getByText(/Референс загружен/).waitFor();
await page.getByRole('button', {name:'Деталь',exact:true}).click();
await imageInputs.nth(1).setInputFiles({name:'head.png',mimeType:'image/png',buffer:Buffer.from(partData.split(',')[1],'base64')});
await page.getByText(/Изображение детали заменено/).waitFor();

await page.getByRole('button', {name:'Проверить движение',exact:true}).click();
await page.getByLabel('Движение в редакторе').selectOption('run');
await page.waitForTimeout(300);
const transforms = () => page.locator('.editor-view svg g[transform]').evaluateAll(els=>els.map(el=>el.getAttribute('transform')));
const before = await transforms(); await page.waitForTimeout(150); assert.notDeepEqual(await transforms(),before);
await page.getByRole('button', {name:'Сборка',exact:true}).click();

const downloadPromise = page.waitForEvent('download');
await page.getByRole('button', {name:'Экспорт JSON',exact:true}).click();
const download = await downloadPromise;
const stream = await download.createReadStream(); const chunks=[];
for await (const chunk of stream) chunks.push(chunk);
const exported = JSON.parse(Buffer.concat(chunks).toString());
assert.equal(exported.character,'char4');
assert(Math.abs(exported.rig.joints.elbowL.x-(jointX+3))<.02);
assert(exported.rig.images.head.startsWith('data:image/png;base64,'));

await imageInputs.nth(2).setInputFiles({name:'bad.json',mimeType:'application/json',buffer:Buffer.from('{"version":99}')});
await page.getByRole('alert').waitFor();
assert(Math.abs(Number(await number('Центр X').inputValue())-initialX)<.02);
await imageInputs.nth(2).setInputFiles({name:'roundtrip.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(exported))});
await page.getByText(/Калибровка импортирована/).waitFor();
await page.getByRole('button', {name:'Применить к анимации',exact:true}).click();
await page.getByRole('button', {name:'Редактор сборки',exact:true}).waitFor();
assert.equal(await page.locator('.assembly-editor').count(),0);
await page.reload();
const persisted = await page.evaluate(()=>JSON.parse(localStorage.getItem('motion-rig.v1.applied.char4')));
assert(Math.abs(persisted.rig.joints.elbowL.x-(jointX+3))<.02);

for (const n of [1,2,3,4]) {
  await page.getByRole('button',{name:new RegExp(`Персонаж ${n} `)}).click();
  for (const mode of ['Покой','Ходьба','Бег','Махание рукой']) await page.getByRole('button',{name:new RegExp(mode)}).click();
  for (let v=1;v<=4;v++) await page.getByRole('button',{name:new RegExp(`Вариант ${v}:`)}).click();
}
for (const name of ['Крупный план коленей','Крупный план локтя','Только рука']) await page.getByRole('button',{name:new RegExp(name)}).click();
await page.getByRole('button',{name:/Покой/}).click();
await page.getByRole('button', {name:'Редактор сборки',exact:true}).click();
await page.getByRole('button', {name:'Подогнать деталь по примеру',exact:true}).click();
await page.getByRole('button',{name:'Остановить поиск',exact:true}).click();
await page.getByText(/Подгонка отменена/).waitFor();

if (process.env.CALIBRATION_FILE) {
  await page.locator('.assembly-editor input[type=file]').nth(2).setInputFiles({name:'script-result.json',mimeType:'application/json',buffer:readFileSync(process.env.CALIBRATION_FILE)});
  await page.getByText(/Калибровка импортирована/).waitFor();
}
await page.setViewportSize({width:390,height:844}); await page.waitForTimeout(400);
assert(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'Mobile horizontal overflow');
const svgBox = await canvas.boundingBox(); assert(svgBox.width<=390 && svgBox.height<650,'Default canvas should show the whole figure');
assert.deepEqual(errors,[]);
await browser.close();
console.log(`PASS: manual geometry, SVG dragging, joints, fitting (${displacedError} -> ${fittedError}), undo/redo, difference view, image uploads, animation, JSON validation, persistence, four presets and variants, closeups, cancellation and mobile layout.`);