"""Bounded, reference-guided registration of an already labelled sprite sheet.

Dependencies: pillow, numpy, scipy, opencv-python-headless.
This fits translation, rotation and uniform scale, not anatomy or missing artwork.
"""
import argparse
import base64
import json
from pathlib import Path

import cv2
import numpy as np
from PIL import Image
from scipy.ndimage import distance_transform_edt
from scipy.optimize import minimize


def remove_key(rgb, background):
    rgb = rgb.astype(float)
    bg = np.array(background, dtype=float)
    delta = np.linalg.norm(rgb - bg, axis=2)
    screen = (rgb[:, :, 1] > 145) & (rgb[:, :, 1] - np.maximum(rgb[:, :, 0], rgb[:, :, 2]) > 80)
    fg = (delta > 60) & ~screen
    core = cv2.erode(fg.astype('uint8'), np.ones((3, 3), np.uint8)) > 0
    if not core.any():
        return np.zeros((*rgb.shape[:2], 4), np.uint8)
    nearest = distance_transform_edt(~core, return_distances=False, return_indices=True)
    f = rgb[nearest[0], nearest[1]]
    direction = f - bg
    alpha = np.clip(np.sum((rgb - bg) * direction, axis=2) / np.maximum(np.sum(direction ** 2, axis=2), 1), 0, 1)
    alpha[core] = 1
    alpha[delta < 4] = 0
    clean = np.clip((rgb - bg * (1 - alpha[:, :, None])) / np.maximum(alpha[:, :, None], .01), 0, 255)
    clean[alpha < .02] = 0
    return np.uint8(np.dstack([clean, alpha * 255]).round())


def transform(g, width, height):
    a = np.deg2rad(g['rot'])
    t = np.array([[np.cos(a) * g['w'] / width, -np.sin(a) * g['h'] / height, 0],
                  [np.sin(a) * g['w'] / width, np.cos(a) * g['h'] / height, 0]])
    t[:, 2] = [g['cx'], g['cy']] - t[:, :2] @ np.array([width / 2, height / 2])
    return t


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', required=True)
    parser.add_argument('--sheet', required=True)
    parser.add_argument('--reference', required=True)
    parser.add_argument('--out', required=True)
    parser.add_argument('--passes', type=int, default=2)
    args = parser.parse_args()
    spec = json.loads(Path(args.manifest).read_text())
    out = Path(args.out)
    (out / 'parts').mkdir(parents=True, exist_ok=True)
    source = np.array(Image.open(args.sheet).convert('RGB'))
    target = np.array(Image.open(args.reference).convert('RGB')).astype('float32') / 255
    allowed = {'head', 'tuft', 'torso', 'hem', 'upperArmL', 'upperArmR', 'foreArmL', 'foreArmR', 'thighL', 'thighR', 'shinL', 'shinR'}
    if set(spec['parts']) - allowed:
        raise ValueError('Unknown part slots. Use the fixed humanoid slot names in character-4.json.')
    for group in spec['groups']:
        x0, y0, x1, y1 = group['region']
        if not (0 <= x0 < x1 <= target.shape[1] and 0 <= y0 < y1 <= target.shape[0]):
            raise ValueError('A search region is outside the reference. Update the manifest for this image.')
    background = spec.get('background', [2, 208, 10])
    images, geometry = {}, {}
    for name, part in spec['parts'].items():
        x, y, w, h = part['crop']
        if not (w > 0 and h > 0 and x >= 0 and y >= 0 and x+w <= source.shape[1] and y+h <= source.shape[0]):
            raise ValueError(f'Crop {name} is outside the sheet. Update its labelled crop rectangle.')
        rgba = remove_key(source[y:y+h, x:x+w], background)
        Image.fromarray(rgba).save(out / 'parts' / f'{name}.png')
        image = rgba.astype('float32') / 255
        image[:, :, :3] *= image[:, :, 3, None]
        images[name] = image
        x, y, scale, angle = part['initial']
        geometry[name] = {'cx': x + w * scale / 2, 'cy': y + h * scale / 2,
                          'w': w * scale, 'h': h * scale, 'rot': angle}
    order = spec['order']

    def layer(name, box):
        x0, y0, x1, y1 = box
        im = images[name]
        t = transform(geometry[name], im.shape[1], im.shape[0])
        t[:, 2] -= [x0, y0]
        return cv2.warpAffine(im, t, (x1 - x0, y1 - y0))

    def render(box):
        x0, y0, x1, y1 = box
        image = np.full((y1-y0, x1-x0, 3), np.array(background)/255, dtype='float32')
        for name in order:
            item = layer(name, box)
            image = item[:, :, :3] + image * (1-item[:, :, 3, None])
        return image

    full_box = (0, 0, target.shape[1], target.shape[0])
    initial_loss = float(np.mean((render(full_box)-target)**2))
    report = []
    for iteration in range(max(0, min(args.passes, 5))):
        for group in spec['groups']:
            names, box = group['parts'], group['region']
            x0, y0, x1, y1 = box
            reference = target[y0:y1, x0:x1]
            fixed = {n: layer(n, box) for n in order if n not in names}
            p, bounds = [], []
            for name in names:
                g, shape = geometry[name], images[name].shape
                base = spec['parts'][name]['initial'][2]
                p.extend([g['cx'], g['cy'], g['rot'], g['w']/shape[1]])
                bounds.extend([(g['cx']-14, g['cx']+14), (g['cy']-14, g['cy']+14),
                               (-10, 10), (base*.95, base*1.05)])

            def loss(params):
                for i, name in enumerate(names):
                    cx, cy, angle, scale = params[i*4:i*4+4]
                    h, w = images[name].shape[:2]
                    geometry[name].update(cx=float(cx), cy=float(cy), rot=float(angle), w=float(w*scale), h=float(h*scale))
                image = np.full_like(reference, np.array(background)/255)
                for name in order:
                    item = layer(name, box) if name in names else fixed[name]
                    image = item[:, :, :3] + image * (1-item[:, :, 3, None])
                return float(np.mean(np.minimum((image-reference)**2, .4)))

            before = loss(p)
            result = minimize(loss, p, method='Powell', bounds=bounds,
                              options={'maxiter': 45, 'xtol': .0003, 'ftol': 1e-6})
            if result.fun < before:
                loss(result.x)
            else:
                loss(p)
            report.append({'pass': iteration+1, 'parts': names, 'before': before, 'after': min(before, float(result.fun))})
            print(report[-1], flush=True)

    assembled = render(full_box)
    Image.fromarray(np.uint8(np.clip(assembled*255, 0, 255))).save(out/'assembled.png')
    clean_ref = remove_key(np.uint8(target*255), background)
    rows = np.arange(target.shape[0])[:, None]
    green = (target[:, :, 1] > target[:, :, 0]+.12) & (target[:, :, 1] > target[:, :, 2]+.12) & (rows > 735-spec.get('worldOffset', [0,0])[1])
    clean_ref[green, 3] = 0
    Image.fromarray(clean_ref).save(out/'reference.png')
    offset = spec.get('worldOffset', [0, 0])
    joints = {}
    for name, anchor in spec['anchors'].items():
        if 'part' in anchor:
            part = anchor['part']; h, w = images[part].shape[:2]
            xy = transform(geometry[part], w, h) @ np.array([*anchor['pixel'], 1])
        else:
            xy = np.array(anchor['point'], float)
        joints[name] = dict(zip(['x', 'y'], [round(float(v), 4) for v in xy + offset]))
    reference_geometry = json.loads(json.dumps(geometry))
    for g in geometry.values():
        g['cx'] += offset[0]; g['cy'] += offset[1]
        for key in g: g[key] = round(g[key], 4)
    if 'tuft' not in geometry:
        geometry['tuft'] = {'cx': 250, 'cy': 220, 'w': 1, 'h': 1, 'rot': 0}
        Image.new('RGBA', (1, 1)).save(out/'parts'/'tuft.png')
    sources = {n: 'data:image/png;base64,' + base64.b64encode((out/'parts'/f'{n}.png').read_bytes()).decode() for n in geometry}
    viewport = spec.get('viewport', [122, 138, 500, 642])
    ref_canvas = Image.new('RGBA', (viewport[2], viewport[3]))
    ref_canvas.alpha_composite(Image.fromarray(clean_ref), (int(offset[0]-viewport[0]), int(offset[1]-viewport[1])))
    ref_canvas.save(out/'reference-rig.png')
    source = 'data:image/png;base64,' + base64.b64encode((out/'reference-rig.png').read_bytes()).decode()
    doc = {'version': 1, 'character': spec['character'], 'rig': {'geometry': geometry, 'joints': joints, 'images': sources},
           'reference': {'source': source, 'geometry': {'cx': viewport[0]+viewport[2]/2, 'cy': viewport[1]+viewport[3]/2,
                         'w': viewport[2], 'h': viewport[3], 'rot': 0}}}
    (out/'calibration.json').write_text(json.dumps(doc, indent=2))
    (out/'report.json').write_text(json.dumps({'initialMSE': initial_loss,
        'finalMSE': float(np.mean((assembled-target)**2)), 'stages': report,
        'referenceGeometry': reference_geometry, 'worldOffset': offset}, indent=2))


if __name__ == '__main__':
    main()